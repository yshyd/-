package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 设备巡检记录信息对象 t_camera_inspection_record
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_inspection_record")
public class TCameraInspectionRecord implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 营业执照上的统一社会信用代码 */
        @Schema(description = "营业执照上的统一社会信用代码")
        @Excel(name = "营业执照上的统一社会信用代码")
        private String unisCid;

        /** 监控设备信息监控设备编码 */
        @Schema(description = "监控设备信息监控设备编码")
        @Excel(name = "监控设备信息监控设备编码")
        private String devId;

        /** 1、有效在线监控2、在线但无效监控（对墙、对地、对天花板）3、摄像头被污染4、摄像头抖动等异常、5离线 */
        @Schema(description = "1、有效在线监控2、在线但无效监控（对墙、对地、对天花板）3、摄像头被污染4、摄像头抖动等异常、5离线")
        @Excel(name = "1、有效在线监控2、在线但无效监控", readConverterExp = "对=墙、对地、对天花板")
        private String devStatus;

        /** 巡检时间格式YYYY-MM-DDhh-mm-ss */
        @Schema(description = "巡检时间格式YYYY-MM-DDhh-mm-ss")
        @Excel(name = "巡检时间格式YYYY-MM-DDhh-mm-ss")
        private String ipqcTime;

        /** 0智能巡检、1人工巡检 */
        @Schema(description = "0智能巡检、1人工巡检")
        @Excel(name = "0智能巡检、1人工巡检")
        private String type;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
