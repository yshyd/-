package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)对象 t_recipse_operation
 *
 * @author ysh
 * @date 2025-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_recipse_operation")
public class TRecipseOperation implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 对应食谱ID */
        @Schema(description = "对应食谱ID")
        @Excel(name = "对应食谱ID")
        private Long recipseId;

        /** 操作类型：0创建食谱，1修改食谱，2启用食谱，3禁用食谱，4留样，5修改留样，6提前销样，7正常销样，8试尝，9，试尝修改，10陪餐，11修改陪餐,12修改销样 */
        @Schema(description = "操作类型：0创建食谱，1修改食谱，2启用食谱，3禁用食谱，4留样，5修改留样，6提前销样，7正常销样，8试尝，9，试尝修改，10陪餐，11修改陪餐,12修改销样")
        @Excel(name = "操作类型：0创建食谱，1修改食谱，2启用食谱，3禁用食谱，4留样，5修改留样，6提前销样，7正常销样，8试尝，9，试尝修改，10陪餐，11修改陪餐,12修改销样")
        private Integer type;

        /** 操作说明 */
        @Schema(description = "操作说明")
        @Excel(name = "操作说明")
        private String remarks;

        /** 操作人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人ID(对应sys_user)")
        @Excel(name = "操作人ID(对应sys_user)")
        private Long createUser;

        /** 操作人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人姓名(对应sys_user)")
        @Excel(name = "操作人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 操作时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "操作时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
