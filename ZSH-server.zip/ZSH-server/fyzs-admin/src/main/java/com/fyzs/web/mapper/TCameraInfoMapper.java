package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCameraInfo;
import com.fyzs.web.entity.dto.DeptCameraCountDTO;
import com.fyzs.web.entity.query.TCameraInfoQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 设备管理-摄像头管理Mapper接口
 * 
 * @author ysh
 * @date 2025-12-17
 */
@Mapper
public interface TCameraInfoMapper  extends BaseMapper<TCameraInfo>
{
    /**
     * 查询设备管理-摄像头管理
     * 
     * @param id 设备管理-摄像头管理主键
     * @return 设备管理-摄像头管理
     */
    public TCameraInfoQuery selectTCameraInfoById(Long id);

    /**
     * 查询设备管理-摄像头管理列表
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 设备管理-摄像头管理集合
     */
    public List<TCameraInfoQuery> selectTCameraInfoList(TCameraInfoQuery tCameraInfo);

    /**
     * 新增设备管理-摄像头管理
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 结果
     */
    public int insertTCameraInfo(TCameraInfo tCameraInfo);

    /**
     * 修改设备管理-摄像头管理
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 结果
     */
    public int updateTCameraInfo(TCameraInfo tCameraInfo);

    /**
     * 删除设备管理-摄像头管理
     * 
     * @param id 设备管理-摄像头管理主键
     * @return 结果
     */
    public int deleteTCameraInfoById(Long id);

    /**
     * 批量删除设备管理-摄像头管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraInfoByIds(Long[] ids);

    List<DeptCameraCountDTO> selectDeptCameraCountMap();
}
