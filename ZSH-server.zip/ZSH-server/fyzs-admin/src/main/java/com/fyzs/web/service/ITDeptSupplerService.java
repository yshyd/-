package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDeptSuppler;
import com.fyzs.web.entity.query.TDeptSupplerQuery;

/**
 * 供应商Service接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
public interface ITDeptSupplerService extends IService<TDeptSuppler>
{
    /**
     * 查询供应商
     * 
     * @param id 供应商主键
     * @return 供应商
     */
    public TDeptSuppler selectTDeptSupplerById(Long id);

    /**
     * 查询供应商列表
     * 
     * @param tDeptSuppler 供应商
     * @return 供应商集合
     */
    public List<TDeptSupplerQuery> selectTDeptSupplerList(TDeptSupplerQuery tDeptSuppler);

    /**
     * 新增供应商
     * 
     * @param tDeptSuppler 供应商
     * @return 结果
     */
    public int insertTDeptSuppler(TDeptSuppler tDeptSuppler);

    /**
     * 修改供应商
     * 
     * @param tDeptSuppler 供应商
     * @return 结果
     */
    public int updateTDeptSuppler(TDeptSuppler tDeptSuppler);

    /**
     * 批量删除供应商
     * 
     * @param ids 需要删除的供应商主键集合
     * @return 结果
     */
    public int deleteTDeptSupplerByIds(Long[] ids);

    /**
     * 删除供应商信息
     * 
     * @param id 供应商主键
     * @return 结果
     */
    public int deleteTDeptSupplerById(Long id);
}
