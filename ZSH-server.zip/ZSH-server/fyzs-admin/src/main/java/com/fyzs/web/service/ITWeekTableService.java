package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TWeekTable;
import com.fyzs.web.entity.query.TWeekTableQuery;

/**
 * 学校食堂周排查-周排查Service接口
 * 
 * @author ysh
 * @date 2025-11-28
 */
public interface ITWeekTableService extends IService<TWeekTable>
{
    /**
     * 查询学校食堂周排查-周排查
     * 
     * @param id 学校食堂周排查-周排查主键
     * @return 学校食堂周排查-周排查
     */
    public TWeekTableQuery selectTWeekTableById(Long id);

    /**
     * 查询学校食堂周排查-周排查列表
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 学校食堂周排查-周排查集合
     */
    public List<TWeekTableQuery> selectTWeekTableList(TWeekTableQuery tWeekTable);

    /**
     * 新增学校食堂周排查-周排查
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 结果
     */
    public int insertTWeekTable(TWeekTable tWeekTable);

    /**
     * 修改学校食堂周排查-周排查
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 结果
     */
    public int updateTWeekTable(TWeekTable tWeekTable);

    /**
     * 批量删除学校食堂周排查-周排查
     * 
     * @param ids 需要删除的学校食堂周排查-周排查主键集合
     * @return 结果
     */
    public int deleteTWeekTableByIds(Long[] ids);

    /**
     * 删除学校食堂周排查-周排查信息
     * 
     * @param id 学校食堂周排查-周排查主键
     * @return 结果
     */
    public int deleteTWeekTableById(Long id);

    int cancel(TWeekTable tWeekTable);
}
