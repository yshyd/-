package com.fyzs.web.entity.query;

import com.fyzs.web.entity.TProcurementOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TProcurementOrderQuery extends TProcurementOrder {

    @Schema(description = "供应商名称")
    private String supplerName;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "开始时间")
    private String startTime;

    @Schema(description = "结束时间")
    private String endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
