package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TInspectorQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TInspector;
import com.fyzs.web.service.ITInspectorService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 督察记录Controller
 * 
 * @author ysh
 * @date 2025-12-02
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/inspector")
public class TInspectorController extends BaseController
{

    private final ITInspectorService tInspectorService;

    /**
     * 查询督察记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:list')")
    @GetMapping("/list")
    public TableDataInfo list(TInspectorQuery tInspector)
    {
        startPage();
        List<TInspectorQuery> list = tInspectorService.selectTInspectorList(tInspector);
        return getDataTable(list);
    }

    /**
     * 导出督察记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:export')")
    @Log(title = "督察记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TInspectorQuery tInspector)
    {
        List<TInspectorQuery> list = tInspectorService.selectTInspectorList(tInspector);
        ExcelUtil<TInspectorQuery> util = new ExcelUtil<TInspectorQuery>(TInspectorQuery.class);
        util.exportExcel(response, list, "督察记录数据");
    }

    /**
     * 获取督察记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tInspectorService.selectTInspectorById(id));
    }

    /**
     * 新增督察记录
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:add')")
    @Log(title = "督察记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TInspector tInspector)
    {
        return toAjax(tInspectorService.insertTInspector(tInspector));
    }

    /**
     * 修改督察记录
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:edit')")
    @Log(title = "督察记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TInspector tInspector)
    {
        return toAjax(tInspectorService.updateTInspector(tInspector));
    }

    /**
     * 启用/禁用
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:edit')")
    @Log(title = "督察记录", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TInspector tInspector)
    {
        return toAjax(tInspectorService.cancel(tInspector));
    }

    /**
     * 整改/整改修改(就是修改接口,传id和内容还有状态)
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:edit')")
    @Log(title = "督察记录", businessType = BusinessType.UPDATE)
    @PutMapping("/rectify")
    public AjaxResult rectify(@RequestBody TInspector tInspector){
        return toAjax(tInspectorService.updateById(tInspector));
    }

    /**
     * 删除督察记录
     */
    //@PreAuthorize("@ss.hasPermi('web:inspector:remove')")
    @Log(title = "督察记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tInspectorService.deleteTInspectorByIds(ids));
    }
}
