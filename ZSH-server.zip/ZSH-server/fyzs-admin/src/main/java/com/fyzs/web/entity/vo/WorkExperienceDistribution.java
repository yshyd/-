package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class WorkExperienceDistribution {
    @Schema(description = "小于1年的人数")
    private int lessThanOneYear;
    @Schema(description = "1-3年的人数")
    private int oneToThreeYears;
    @Schema(description = "3-5年的人数")
    private int threeToFiveYears;
    @Schema(description = "5-10年的人数")
    private int fiveToTenYears;
    @Schema(description = "大于10年的人数")
    private int overTenYears;

    private double lessThanOneyearRatio ;
    private double oneToTwoYearsRatio ;
    private double threeToFiveYearsRatio ;
    private double fiveToTenYearsRatio ;
    private double overTenyearsRatio ;
}
