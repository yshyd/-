package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TNewOutbound;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewOutboundDTO extends TNewOutbound {
}
