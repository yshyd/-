package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TNewReviewDTO;
import com.fyzs.web.entity.query.TNewReviewQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewReview;
import com.fyzs.web.service.ITNewReviewService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 盘点Controller
 *
 * @author ysh
 * @date 2025-10-31
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/review")
public class TNewReviewController extends BaseController {

    private final ITNewReviewService tNewReviewService;

    /**
     * 查询盘点列表
     */
    //@PreAuthorize("@ss.hasPermi('web:review:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewReviewQuery tNewReview) {
        startPage();
        List<TNewReviewQuery> list = tNewReviewService.selectTNewReviewList(tNewReview);
        return getDataTable(list);
    }

    /**
     * 导出盘点列表
     */
    //@PreAuthorize("@ss.hasPermi('web:review:export')")
    @Log(title = "盘点", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewReviewQuery tNewReview) {
        List<TNewReviewQuery> list = tNewReviewService.selectTNewReviewList(tNewReview);
        ExcelUtil<TNewReviewQuery> util = new ExcelUtil<TNewReviewQuery>(TNewReviewQuery.class);
        util.exportExcel(response, list, "盘点数据");
    }

    /**
     * 获取盘点详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:review:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(tNewReviewService.selectTNewReviewById(id));
    }

    /**
     * 盘点确认按钮
     */
    @PostMapping("/confirm")
    public AjaxResult confirm(@RequestBody TNewReviewDTO dto) {
        return toAjax(tNewReviewService.confirm(dto));
    }


    /**
     * 新增盘点
     */
    //@PreAuthorize("@ss.hasPermi('web:review:add')")
    @Log(title = "盘点", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewReview tNewReview) {
        return toAjax(tNewReviewService.save(tNewReview));
    }

    /**
     * 修改盘点
     */
    //@PreAuthorize("@ss.hasPermi('web:review:edit')")
    @Log(title = "盘点", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewReview tNewReview) {
        return toAjax(tNewReviewService.updateById(tNewReview));
    }

    /**
     * 删除盘点
     */
    //@PreAuthorize("@ss.hasPermi('web:review:remove')")
    @Log(title = "盘点", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tNewReviewService.deleteTNewReviewByIds(ids));
    }
}
