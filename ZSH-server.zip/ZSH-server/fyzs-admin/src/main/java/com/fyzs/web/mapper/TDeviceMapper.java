package com.fyzs.web.mapper;

import java.util.List;

import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.entity.TDevice;
import com.fyzs.web.entity.dto.DeptCameraCountDTO;
import com.fyzs.web.entity.dto.DeviceTypeCountDTO;
import com.fyzs.web.entity.query.TDeviceQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 设备基础信息Mapper接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
@org.apache.ibatis.annotations.Mapper
public interface TDeviceMapper  extends BaseMapper<TDevice>
{
    /**
     * 查询设备基础信息
     * 
     * @param id 设备基础信息主键
     * @return 设备基础信息
     */
    public TDeviceQuery selectTDeviceById(Long id);

    /**
     * 查询设备基础信息列表
     * 
     * @param tDevice 设备基础信息
     * @return 设备基础信息集合
     */
    public List<TDeviceQuery> selectTDeviceList(TDeviceQuery tDevice);

    /**
     * 新增设备基础信息
     * 
     * @param tDevice 设备基础信息
     * @return 结果
     */
    public int insertTDevice(TDevice tDevice);

    /**
     * 修改设备基础信息
     * 
     * @param tDevice 设备基础信息
     * @return 结果
     */
    public int updateTDevice(TDevice tDevice);

    /**
     * 删除设备基础信息
     * 
     * @param id 设备基础信息主键
     * @return 结果
     */
    public int deleteTDeviceById(Long id);

    /**
     * 批量删除设备基础信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDeviceByIds(Long[] ids);


    List<DeptCameraCountDTO> selectDeptDeviceCountMap(SysAreaDTO sysArea);

    List<DeptCameraCountDTO> selectDeptDeviceAndCameraCountMap(SysAreaDTO sysArea);

    List<DeviceTypeCountDTO> selectDeviceTypeCountByQuery(TDeviceQuery query);

    List<DeptCameraCountDTO> selectDeviceCountMap(@Param("deptIds") List<Long> authDeptIds);

    List<DeptCameraCountDTO> selectCameraCountMap(@Param("deptIds") List<Long> authDeptIds);

}
