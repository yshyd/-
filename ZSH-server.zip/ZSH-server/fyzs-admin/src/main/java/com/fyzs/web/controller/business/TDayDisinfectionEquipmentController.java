package com.fyzs.web.controller.business;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TDayDisinfectionEquipmentQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayDisinfectionEquipment;
import com.fyzs.web.service.ITDayDisinfectionEquipmentService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常消毒-场所设备消毒Controller
 * 
 * @author ysh
 * @date 2025-11-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/equipment")
public class TDayDisinfectionEquipmentController extends BaseController
{

    private final ITDayDisinfectionEquipmentService equipmentService;

    private final ITAlarmService alarmService;

    /**
     * 查询学校食堂日管控-日常消毒-场所设备消毒列表
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayDisinfectionEquipmentQuery query)
    {
        startPage();
        List<TDayDisinfectionEquipmentQuery> list = equipmentService.selectTDayDisinfectionEquipmentList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常消毒-场所设备消毒列表
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:export')")
    @Log(title = "学校食堂日管控-日常消毒-场所设备消毒", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayDisinfectionEquipmentQuery query)
    {
        List<TDayDisinfectionEquipmentQuery> list = equipmentService.selectTDayDisinfectionEquipmentList(query);
        ExcelUtil<TDayDisinfectionEquipmentQuery> util = new ExcelUtil<TDayDisinfectionEquipmentQuery>(TDayDisinfectionEquipmentQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常消毒-场所设备消毒数据");
    }

    /**
     * 获取学校食堂日管控-日常消毒-场所设备消毒详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(equipmentService.selectTDayDisinfectionEquipmentById(id));
    }

    /**
     * 新增学校食堂日管控-日常消毒-场所设备消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:add')")
    @Log(title = "学校食堂日管控-日常消毒-场所设备消毒", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayDisinfectionEquipment equipment)
    {
        equipment.setDelFlag(0);
        return toAjax(equipmentService.save(equipment));
    }

    /**
     * 修改学校食堂日管控-日常消毒-场所设备消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:edit')")
    @Log(title = "学校食堂日管控-日常消毒-场所设备消毒", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayDisinfectionEquipment tDayDisinfectionEquipment)
    {
        return toAjax(equipmentService.updateTDayDisinfectionEquipment(tDayDisinfectionEquipment));
    }


    /**
     * 启用/作废按钮(id,delFlag)
     */
    @Log(title = "学校食堂日管控-日常消毒-场所设备消毒", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayDisinfectionEquipment tDayDisinfectionEquipment){

        return toAjax(equipmentService.updateById(tDayDisinfectionEquipment));
    }
    /**
     * 删除学校食堂日管控-日常消毒-场所设备消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:equipment:remove')")
    @Log(title = "学校食堂日管控-日常消毒-场所设备消毒", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(equipmentService.deleteTDayDisinfectionEquipmentByIds(ids));
    }
}
