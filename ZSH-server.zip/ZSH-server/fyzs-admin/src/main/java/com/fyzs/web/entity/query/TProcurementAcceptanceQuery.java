package com.fyzs.web.entity.query;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TProcurementAcceptance;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TProcurementAcceptanceQuery extends TProcurementAcceptance {

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    @Schema(description = "供应商名称")
    @Excel(name = "供应商名称")
    private String supplerName;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
