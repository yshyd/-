package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class DinerRateAnalysisVO {

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "预计总人餐")
    private Long expectedTotal;

    @Schema(description = "实际总人餐")
    private Long actualTotal;

    @Schema(description = "入口率(%)")
    private Double entryRate; // 保留两位小数
}
