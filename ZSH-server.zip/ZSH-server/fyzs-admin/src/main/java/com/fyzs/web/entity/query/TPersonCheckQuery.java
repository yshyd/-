package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TPersonCheck;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TPersonCheckQuery extends TPersonCheck {
    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    @Schema(description = "食堂人员姓名")
    @Excel(name = "员工姓名")
    private String personName;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
