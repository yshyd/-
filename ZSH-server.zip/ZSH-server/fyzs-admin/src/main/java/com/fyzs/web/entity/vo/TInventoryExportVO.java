package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import lombok.Data;

import java.math.BigDecimal;

/**
 * 商品库存汇总导出对象
 */
@Data
public class TInventoryExportVO {

    /** 商品ID，仅用于标识汇总维度，不导出 */
    private Long commodityId;

    @Excel(name = "商品编码", sort = 1)
    private String commodityCode;

    @Excel(name = "商品名称", sort = 2)
    private String commodityName;

    @Excel(name = "类别名称", sort = 3)
    private String categoryName;

    @Excel(name = "品牌", sort = 4)
    private String brand;

    @Excel(name = "型号", sort = 5)
    private String model;

    @Excel(name = "规格", sort = 6)
    private String specification;

    @Excel(name = "统一计量单位", sort = 7)
    private String purchaUnit;

    @Excel(name = "库存量", sort = 8)
    private BigDecimal number;
}
