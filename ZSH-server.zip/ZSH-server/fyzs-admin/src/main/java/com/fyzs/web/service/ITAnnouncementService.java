package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TAnnouncement;
import com.fyzs.web.entity.dto.TAnnouncementDTO;
import com.fyzs.web.entity.query.TAnnouncementQuery;

/**
 * 公告发布Service接口
 * 
 * @author ysh
 * @date 2025-12-04
 */
public interface ITAnnouncementService extends IService<TAnnouncement>
{
    /**
     * 查询公告发布
     * 
     * @param id 公告发布主键
     * @return 公告发布
     */
    public TAnnouncementQuery selectTAnnouncementById(Long id);

    /**
     * 查询公告发布列表
     * 
     * @param tAnnouncement 公告发布
     * @return 公告发布集合
     */
    public List<TAnnouncementQuery> selectTAnnouncementList(TAnnouncementQuery tAnnouncement);

    /**
     * 新增公告发布
     * 
     * @param tAnnouncement 公告发布
     * @return 结果
     */
    public int insertTAnnouncement(TAnnouncementDTO tAnnouncement);

    /**
     * 修改公告发布
     * 
     * @param tAnnouncement 公告发布
     * @return 结果
     */
    public int updateTAnnouncement(TAnnouncementDTO tAnnouncement);

    /**
     * 批量删除公告发布
     * 
     * @param ids 需要删除的公告发布主键集合
     * @return 结果
     */
    public int deleteTAnnouncementByIds(Long[] ids);

    /**
     * 删除公告发布信息
     * 
     * @param id 公告发布主键
     * @return 结果
     */
    public int deleteTAnnouncementById(Long id);

    List<TAnnouncementQuery> lookList(TAnnouncementQuery tAnnouncement);
}
