package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 留样柜操作日志对象 t_sample_device_operation
 *
 * @author ysh
 * @date 2025-12-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_sample_device_operation")
public class TSampleDeviceOperation implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 留样柜的设备序列号 */
        @Schema(description = "留样柜的设备序列号")
        @Excel(name = "留样柜的设备序列号")
        private String serailNumber;

        /** 柜门号 */
        @Schema(description = "柜门号")
        @Excel(name = "柜门号")
        private Integer number;

        /** 操作类型：0留样1销样2提前销样 */
        @Schema(description = "操作类型：0留样1销样2提前销样")
        @Excel(name = "操作类型：0留样1销样2提前销样")
        private Integer type;

        /** 操作时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "操作时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 操作人姓名(双锁双密码下人员逗号分割) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人姓名(双锁双密码下人员逗号分割)")
        @Excel(name = "操作人姓名(双锁双密码下人员逗号分割)")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
