package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TThStatus;

/**
 * 温湿度监测报警仪实时温湿度Service接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
public interface ITThStatusService extends IService<TThStatus>
{
    /**
     * 查询温湿度监测报警仪实时温湿度
     * 
     * @param id 温湿度监测报警仪实时温湿度主键
     * @return 温湿度监测报警仪实时温湿度
     */
    public TThStatus selectTThStatusById(Long id);

    /**
     * 查询温湿度监测报警仪实时温湿度列表
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 温湿度监测报警仪实时温湿度集合
     */
    public List<TThStatus> selectTThStatusList(TThStatus tThStatus);

    /**
     * 新增温湿度监测报警仪实时温湿度
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 结果
     */
    public int insertTThStatus(TThStatus tThStatus);

    /**
     * 修改温湿度监测报警仪实时温湿度
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 结果
     */
    public int updateTThStatus(TThStatus tThStatus);

    /**
     * 批量删除温湿度监测报警仪实时温湿度
     * 
     * @param ids 需要删除的温湿度监测报警仪实时温湿度主键集合
     * @return 结果
     */
    public int deleteTThStatusByIds(Long[] ids);

    /**
     * 删除温湿度监测报警仪实时温湿度信息
     * 
     * @param id 温湿度监测报警仪实时温湿度主键
     * @return 结果
     */
    public int deleteTThStatusById(Long id);
}
