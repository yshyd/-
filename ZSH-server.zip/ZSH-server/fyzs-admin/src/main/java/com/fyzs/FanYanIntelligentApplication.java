package com.fyzs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * 启动程序
 * 
 * @author ysh
 */
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@EnableScheduling
public class FanYanIntelligentApplication
{
    public static void main(String[] args)
    {
        SpringApplication.run(FanYanIntelligentApplication.class, args);
        System.out.println("帆研智算单体应用启动成功");
    }
}
