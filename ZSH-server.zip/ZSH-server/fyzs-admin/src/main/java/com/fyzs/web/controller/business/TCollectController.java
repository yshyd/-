package com.fyzs.web.controller.business;

import com.fyzs.common.core.domain.AjaxResult;

import com.fyzs.web.entity.query.SummaryQuery;
import com.fyzs.web.service.ICollectService;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

import static com.fyzs.common.core.domain.AjaxResult.success;
import static com.fyzs.common.utils.SecurityUtils.getUserId;

@RestController
@AllArgsConstructor
@RequestMapping("/tx/collect")
public class TCollectController {

    private final ICollectService collectService;

    /**
     * 周汇总
     */

    @ApiOperation("获取周汇总数据")
    @GetMapping("/week")
    public AjaxResult getWeeklySummary(
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
            @RequestParam(required = false) List<Long> deptIds) {

        SummaryQuery query = new SummaryQuery();
        query.setStartDate(startDate);
        query.setEndDate(endDate);
        query.setDeptIds(deptIds);
        query.setUserId(getUserId());
        System.out.println("部门参数: "+deptIds);
        return success(collectService.getWeeklySummary(query));
    }

    /**
     * 月汇总
     */
    @ApiOperation("获取月汇总数据")
    @GetMapping("/month")
    public AjaxResult getMonthlySummary(
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
            @RequestParam(required = false) List<Long> deptIds) {

        SummaryQuery query = new SummaryQuery();
        query.setStartDate(startDate);
        query.setEndDate(endDate);
        query.setDeptIds(deptIds);
        query.setUserId(getUserId());
        return success(collectService.getMonthSummary(query));
    }


}
