package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayRoutineInspection;
import com.fyzs.web.entity.query.TDayRoutineInspectionQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常检查-常规日检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
@Mapper
public interface TDayRoutineInspectionMapper  extends BaseMapper<TDayRoutineInspection>
{
    /**
     * 查询学校食堂日管控-日常检查-常规日检
     * 
     * @param id 学校食堂日管控-日常检查-常规日检主键
     * @return 学校食堂日管控-日常检查-常规日检
     */
    public TDayRoutineInspectionQuery selectTDayRoutineInspectionById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-常规日检列表
     *
     * @return 学校食堂日管控-日常检查-常规日检集合
     */
    public List<TDayRoutineInspectionQuery> selectTDayRoutineInspectionList(TDayRoutineInspectionQuery query);

    /**
     * 新增学校食堂日管控-日常检查-常规日检
     * 
     * @param tDayRoutineInspection 学校食堂日管控-日常检查-常规日检
     * @return 结果
     */
    public int insertTDayRoutineInspection(TDayRoutineInspection tDayRoutineInspection);

    /**
     * 修改学校食堂日管控-日常检查-常规日检
     * 
     * @param tDayRoutineInspection 学校食堂日管控-日常检查-常规日检
     * @return 结果
     */
    public int updateTDayRoutineInspection(TDayRoutineInspection tDayRoutineInspection);

    /**
     * 删除学校食堂日管控-日常检查-常规日检
     * 
     * @param id 学校食堂日管控-日常检查-常规日检主键
     * @return 结果
     */
    public int deleteTDayRoutineInspectionById(Long id);

    /**
     * 批量删除学校食堂日管控-日常检查-常规日检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayRoutineInspectionByIds(Long[] ids);

    // 统计有效常规日检数量（已做数量）
    int countValidRoutineInspections(@Param("startDate") Date startDate,
                                     @Param("endDate") Date endDate,
                                     @Param("deptIds") List<Long> deptIds);

    // 统计正常常规日检数量
    int countNormalRoutineInspections(@Param("startDate") Date startDate,
                                      @Param("endDate") Date endDate,
                                      @Param("deptIds") List<Long> deptIds);

    // 统计异常常规日检数量
    int countAbnormalRoutineInspections(@Param("startDate") Date startDate,
                                        @Param("endDate") Date endDate,
                                        @Param("deptIds") List<Long> deptIds);

}
