package com.fyzs.web.service;

import com.fyzs.web.entity.vo.FoodConsumptionAnalysisVO;
import com.fyzs.web.entity.vo.PractitionerAnalysisVO;

import java.util.Date;

public interface PeriodService {
    /**
     * 分析食材消耗情况
     *
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @param deptId    学校部门ID（可选）
     * @param areaId    区域ID（可选）
     * @return 分析结果
     */
    FoodConsumptionAnalysisVO analyzeFoodConsumption(Date startDate, Date endDate, Long deptId, Long areaId);

    PractitionerAnalysisVO analyzePractitioners(Long deptId, Long areaId);
}
