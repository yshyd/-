package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TReferencePrice;
import com.fyzs.web.entity.dto.TReferencePriceDTO;
import com.fyzs.web.entity.query.TReferencePriceQuery;
import com.fyzs.web.entity.vo.TReferencePriceVO;

/**
 * 食材标准参考价发布记录主Service接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
public interface ITReferencePriceService extends IService<TReferencePrice>
{
    /**
     * 查询食材标准参考价发布记录主
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 食材标准参考价发布记录主
     */
    public TReferencePriceVO selectTReferencePriceById(Long id);

    /**
     * 查询食材标准参考价发布记录主列表
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 食材标准参考价发布记录主集合
     */
    public List<TReferencePriceQuery> selectTReferencePriceList(TReferencePriceQuery tReferencePrice);

    /**
     * 新增食材标准参考价发布记录主
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 结果
     */
    public int insertTReferencePrice(TReferencePriceDTO tReferencePrice);

    /**
     * 修改食材标准参考价发布记录主
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 结果
     */
    public int updateTReferencePrice(TReferencePriceDTO tReferencePrice);

    /**
     * 批量删除食材标准参考价发布记录主
     * 
     * @param ids 需要删除的食材标准参考价发布记录主主键集合
     * @return 结果
     */
    public int deleteTReferencePriceByIds(Long[] ids);

    /**
     * 删除食材标准参考价发布记录主信息
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 结果
     */
    public int deleteTReferencePriceById(Long id);

    int enable(TReferencePrice tReferencePrice);
}
