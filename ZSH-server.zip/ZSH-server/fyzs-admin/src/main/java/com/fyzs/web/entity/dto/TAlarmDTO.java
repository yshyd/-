package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TAlarm;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TAlarmDTO extends TAlarm {
}
