package com.fyzs.web.entity.vo;

import lombok.Data;

import java.util.List;

@Data
public class SecurityRankingVO {
    /**
     * 学校名称
     */
    private String schoolName;

    /**
     * 主体id
     */
    private Long deptId;

    /**
     * 主体类型
     */
    private String deptType;

    /**
     * 总得分
     */
    private Double totalScore;

    /**
     * 下属食堂ids
     * @param schoolName
     * @param totalScore
     * @param deptId
     * @param deptType
     */
    private List<Long> canteenIds;

    public SecurityRankingVO(String schoolName, Double totalScore, Long deptId, String deptType, List<Long> canteenIds) {
        this.schoolName = schoolName;
        this.totalScore = totalScore;
        this.deptId = deptId;
        this.deptType = deptType;
        this.canteenIds = canteenIds;
    }
}
