package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TProcurementOrder;
import com.fyzs.web.entity.query.TProcurementOrderQuery;
import com.fyzs.web.entity.vo.TProcurementOrderVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 商品采购单主Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@org.apache.ibatis.annotations.Mapper
public interface TProcurementOrderMapper  extends BaseMapper<TProcurementOrder>
{
    /**
     * 查询商品采购单主
     * 
     * @param id 商品采购单主主键
     * @return 商品采购单主
     */
    public TProcurementOrder selectTProcurementOrderById(Long id);

    /**
     * 查询商品采购单主列表
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 商品采购单主集合
     */
    public List<TProcurementOrderQuery> selectTProcurementOrderList(TProcurementOrderQuery tProcurementOrder);

    /**
     * 新增商品采购单主
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 结果
     */
    public int insertTProcurementOrder(TProcurementOrder tProcurementOrder);

    /**
     * 修改商品采购单主
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 结果
     */
    public int updateTProcurementOrder(TProcurementOrder tProcurementOrder);

    /**
     * 删除商品采购单主
     * 
     * @param id 商品采购单主主键
     * @return 结果
     */
    public int deleteTProcurementOrderById(Long id);

    /**
     * 批量删除商品采购单主
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTProcurementOrderByIds(Long[] ids);

    String selectMaxOrderNumByDatePrefix(@Param("datePrefix")String datePrefix);

    TProcurementOrderVO selectOrder(Long id);
}
