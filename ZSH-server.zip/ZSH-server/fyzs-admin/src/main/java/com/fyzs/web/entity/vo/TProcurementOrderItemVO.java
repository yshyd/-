package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TProcurementOrderItem;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TProcurementOrderItemVO extends TProcurementOrderItem {
    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;

    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    /** 采购计量单位(用于账单核算) */
    @Schema(description = "采购计量单位(用于账单核算)")
    @Excel(name = "采购计量单位(用于账单核算)")
    private String purchaUnit;

}
