package com.fyzs.web.controller.business;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TDayProductionProcessQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayProductionProcess;
import com.fyzs.web.service.ITDayProductionProcessService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常巡检-食品加工制作过程巡检Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/production/process")
public class TDayProductionProcessController extends BaseController
{

    private final ITDayProductionProcessService processService;

    private final ITAlarmService alarmService;

    /**
     * 查询学校食堂日管控-日常巡检-食品加工制作过程巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:process:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayProductionProcessQuery query)
    {
        startPage();
        List<TDayProductionProcessQuery> list = processService.selectTDayProductionProcessList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常巡检-食品加工制作过程巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:process:export')")
    @Log(title = "学校食堂日管控-日常巡检-食品加工制作过程巡检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayProductionProcessQuery query)
    {
        List<TDayProductionProcessQuery> list = processService.selectTDayProductionProcessList(query);
        ExcelUtil<TDayProductionProcessQuery> util = new ExcelUtil<TDayProductionProcessQuery>(TDayProductionProcessQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常巡检-食品加工制作过程巡检数据");
    }

    /**
     * 获取学校食堂日管控-日常巡检-食品加工制作过程巡检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:process:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(processService.selectTDayProductionProcessById(id));
    }

    /**
     * 新增学校食堂日管控-日常巡检-食品加工制作过程巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:process:add')")
    @Log(title = "学校食堂日管控-日常巡检-食品加工制作过程巡检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayProductionProcess tDayProductionProcess)
    {
        return toAjax(processService.insertTDayProductionProcess(tDayProductionProcess));
    }

    /**
     * 修改学校食堂日管控-日常巡检-食品加工制作过程巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:process:edit')")
    @Log(title = "学校食堂日管控-日常巡检-食品加工制作过程巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayProductionProcess tDayProductionProcess)
    {
        return toAjax(processService.updateTDayProductionProcess(tDayProductionProcess));
    }

    /**
     * 启用/作废(id,delFlag)
     */
    //@PreAuthorize("@ss.hasPermi('web:process:edit')")
    @Log(title = "学校食堂日管控-日常巡检-食品加工制作过程巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayProductionProcess tDayProductionProcess)
    {

        return toAjax(processService.cancel(tDayProductionProcess));
    }
    /**
     * 删除学校食堂日管控-日常巡检-食品加工制作过程巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:process:remove')")
    @Log(title = "学校食堂日管控-日常巡检-食品加工制作过程巡检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(processService.deleteTDayProductionProcessByIds(ids));
    }
}
