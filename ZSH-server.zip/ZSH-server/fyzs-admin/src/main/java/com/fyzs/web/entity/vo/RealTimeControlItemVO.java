package com.fyzs.web.entity.vo;

import lombok.Data;

import java.math.BigDecimal;


@Data
public class RealTimeControlItemVO {
    private String name;           // 模块名称，如“常规日检”
    private BigDecimal completionRate; // 执行率（已完成 / 应做）
    private Integer shouldDo;      // 应做数量
    private Integer done;          // 已做数量
    private Integer notDone;       // 未做数量

    public RealTimeControlItemVO(String name, BigDecimal completionRate) {
        this.name = name;
        this.completionRate = completionRate;
    }

    public RealTimeControlItemVO(String name, BigDecimal completionRate, Integer shouldDo, Integer done, Integer notDone) {
        this.name = name;
        this.completionRate = completionRate;
        this.shouldDo = shouldDo;
        this.done = done;
        this.notDone = notDone;
    }
}

