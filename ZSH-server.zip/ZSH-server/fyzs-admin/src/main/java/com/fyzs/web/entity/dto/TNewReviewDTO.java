package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TNewReview;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewReviewDTO extends TNewReview {
}
