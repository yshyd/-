package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常检查-常规日检对象 t_day_routine_inspection
 *
 * @author ysh
 * @date 2025-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_routine_inspection")
public class TDayRoutineInspection implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 主体ID
     */
    @Schema(description = "主体ID")
    @Excel(name = "主体ID")
    private Long deptId;

    /**
     * 检查时间
     */
    private String date;

    /**
     * 个人卫生检查，0合格1不合格
     */
    @Schema(description = "个人卫生检查，0合格1不合格")
    @Excel(name = "个人卫生检查，0合格1不合格")
    private Integer personalHygiene;

    /**
     * 个人卫生检查不合格整改说明(300字内),个人卫生不合格必填
     */
    @Schema(description = "个人卫生检查不合格整改说明(300字内),个人卫生不合格必填")
    @Excel(name = "个人卫生检查不合格整改说明(300字内),个人卫生不合格必填")
    private String personalHygieneResult;

    /**
     * 身体精神状态是否合格，0合格1不合格
     */
    @Schema(description = "身体精神状态是否合格，0合格1不合格")
    @Excel(name = "身体精神状态是否合格，0合格1不合格")
    private Integer physicalMentalState;

    /**
     * 身体精神状态不合格整改说明300字内，不合格时必填
     */
    @Schema(description = "身体精神状态不合格整改说明300字内，不合格时必填")
    @Excel(name = "身体精神状态不合格整改说明300字内，不合格时必填")
    private String physicalMentalStateResult;

    /**
     * 电器设施-开关插座工况是否合格，0合格1不合格
     */
    @Schema(description = "电器设施-开关插座工况是否合格，0合格1不合格")
    @Excel(name = "电器设施-开关插座工况是否合格，0合格1不合格")
    private Integer switchSocket;

    /**
     * 电器设施-开关插座工况不合格时整改说明300字内，不合格时必填
     */
    @Schema(description = "电器设施-开关插座工况不合格时整改说明300字内，不合格时必填")
    @Excel(name = "电器设施-开关插座工况不合格时整改说明300字内，不合格时必填")
    private String switchSocketResult;

    /**
     * 电器设施-门窗工况是否合格，0合格1不合格
     */
    @Schema(description = "电器设施-门窗工况是否合格，0合格1不合格")
    @Excel(name = "电器设施-门窗工况是否合格，0合格1不合格")
    private Integer doorsWindows;

    /**
     * 电器设施-门窗工况不合格时必填300字内，不合格时必填
     */
    @Schema(description = "电器设施-门窗工况不合格时必填300字内，不合格时必填")
    @Excel(name = "电器设施-门窗工况不合格时必填300字内，不合格时必填")
    private String doorsWindowsResult;

    /**
     * 环境卫生-墙壁角顶是否合格，0合格1不合格
     */
    @Schema(description = "环境卫生-墙壁角顶是否合格，0合格1不合格")
    @Excel(name = "环境卫生-墙壁角顶是否合格，0合格1不合格")
    private Integer wallCornerCeiling;

    /**
     * 环境卫生-墙壁角顶是否合格的整改说明300字内，不合格时必填
     */
    @Schema(description = "环境卫生-墙壁角顶是否合格的整改说明300字内，不合格时必填")
    @Excel(name = "环境卫生-墙壁角顶是否合格的整改说明300字内，不合格时必填")
    private String wallCornerCeilingResult;

    /**
     * 环境卫生-厨房是否合格，0合格1不合格
     */
    @Schema(description = "环境卫生-厨房是否合格，0合格1不合格")
    @Excel(name = "环境卫生-厨房是否合格，0合格1不合格")
    private Integer kitchen;

    /**
     * 环境卫生-厨房不合格时的整改说明，300字内，不合格时必填
     */
    @Schema(description = "环境卫生-厨房不合格时的整改说明，300字内，不合格时必填")
    @Excel(name = "环境卫生-厨房不合格时的整改说明，300字内，不合格时必填")
    private String kitchenResult;

    /**
     * 环境卫生-粗加工场地是否合格，0合格1不合格
     */
    @Schema(description = "环境卫生-粗加工场地是否合格，0合格1不合格")
    @Excel(name = "环境卫生-粗加工场地是否合格，0合格1不合格")
    private Integer roughProcessingSite;

    /**
     * 环境卫生-粗加工场地是否合格，不合格时必填，300字内
     */
    @Schema(description = "环境卫生-粗加工场地是否合格，不合格时必填，300字内")
    @Excel(name = "环境卫生-粗加工场地是否合格，不合格时必填，300字内")
    private String roughProcessingSiteResult;

    /**
     * 环境卫生-下水道是否合格，0合格1不合格
     */
    @Schema(description = "环境卫生-下水道是否合格，0合格1不合格")
    @Excel(name = "环境卫生-下水道是否合格，0合格1不合格")
    private Integer sewer;

    /**
     * 环境卫生-下水道不合格处置说明，300字内，不合格时必填
     */
    @Schema(description = "环境卫生-下水道不合格处置说明，300字内，不合格时必填")
    @Excel(name = "环境卫生-下水道不合格处置说明，300字内，不合格时必填")
    private String sewerResult;

    /**
     * 环境卫生-垃圾桶是否合格，0合格1不合格
     */
    @Schema(description = "环境卫生-垃圾桶是否合格，0合格1不合格")
    @Excel(name = "环境卫生-垃圾桶是否合格，0合格1不合格")
    private Integer trashcan;

    /**
     * 环境卫生-垃圾桶不合格整改说明，300字内，不合格时必填
     */
    @Schema(description = "环境卫生-垃圾桶不合格整改说明，300字内，不合格时必填")
    @Excel(name = "环境卫生-垃圾桶不合格整改说明，300字内，不合格时必填")
    private String trashcanResult;

    /**
     * 原材料粗加工-腐烂变质,0合格1不合格
     */
    @Schema(description = "原材料粗加工-腐烂变质,0合格1不合格")
    @Excel(name = "原材料粗加工-腐烂变质,0合格1不合格")
    private Integer rotDeteriorate;

    /**
     * 原材料粗加工-腐烂变质情况的处置说明，300字内，不合格时必填
     */
    @Schema(description = "原材料粗加工-腐烂变质情况的处置说明，300字内，不合格时必填")
    @Excel(name = "原材料粗加工-腐烂变质情况的处置说明，300字内，不合格时必填")
    private String rotDeteriorateResult;

    /**
     * 原材料粗加工-蔬菜规范与垃圾处理,0合格1不合格
     */
    @Schema(description = "原材料粗加工-蔬菜规范与垃圾处理,0合格1不合格")
    @Excel(name = "原材料粗加工-蔬菜规范与垃圾处理,0合格1不合格")
    private Integer vegetableStandardsGarbageDisposal;

    /**
     * 原材料粗加工-蔬菜规范与垃圾处理不合格的处置说明，300字内，不合格时必填
     */
    @Schema(description = "原材料粗加工-蔬菜规范与垃圾处理不合格的处置说明，300字内，不合格时必填")
    @Excel(name = "原材料粗加工-蔬菜规范与垃圾处理不合格的处置说明，300字内，不合格时必填")
    private String vegetableStandardsGarbageDisposalResult;

    /**
     * 原材料粗加工-荤素分板切配0合格1不合格
     */
    @Schema(description = "原材料粗加工-荤素分板切配0合格1不合格")
    @Excel(name = "原材料粗加工-荤素分板切配0合格1不合格")
    private Integer meatAndVegetables;

    /**
     * 原材料粗加工-荤素分板切配不合格处置说明，300内，不合格必填
     */
    @Schema(description = "原材料粗加工-荤素分板切配不合格处置说明，300内，不合格必填")
    @Excel(name = "原材料粗加工-荤素分板切配不合格处置说明，300内，不合格必填")
    private String meatAndVegetablesResult;

    /**
     * 原材料粗加工-分盆分筐0合格1不合格
     */
    @Schema(description = "原材料粗加工-分盆分筐0合格1不合格")
    @Excel(name = "原材料粗加工-分盆分筐0合格1不合格")
    private Integer basinFrame;

    /**
     * 原材料粗加工-分盆分筐不合格处置说明，300字内，不合格必填
     */
    @Schema(description = "原材料粗加工-分盆分筐不合格处置说明，300字内，不合格必填")
    @Excel(name = "原材料粗加工-分盆分筐不合格处置说明，300字内，不合格必填")
    private String basinFrameResult;

    /**
     * 烹饪加工-饭菜足量下锅0合格1不合格
     */
    @Schema(description = "烹饪加工-饭菜足量下锅0合格1不合格")
    @Excel(name = "烹饪加工-饭菜足量下锅0合格1不合格")
    private Integer meal;

    /**
     * 烹饪加工-饭菜足量下锅不合格整改说明，300字内，不合格时必填
     */
    @Schema(description = "烹饪加工-饭菜足量下锅不合格整改说明，300字内，不合格时必填")
    @Excel(name = "烹饪加工-饭菜足量下锅不合格整改说明，300字内，不合格时必填")
    private String mealResult;

    /**
     * 烹饪加工-午餐营养丰富0合格1不合格
     */
    @Schema(description = "烹饪加工-午餐营养丰富0合格1不合格")
    @Excel(name = "烹饪加工-午餐营养丰富0合格1不合格")
    private Integer lunch;

    /**
     * 烹饪加工-午餐营养丰富不合格处置说明，300内，不合格必填
     */
    @Schema(description = "烹饪加工-午餐营养丰富不合格处置说明，300内，不合格必填")
    @Excel(name = "烹饪加工-午餐营养丰富不合格处置说明，300内，不合格必填")
    private String lunchResult;

    /**
     * 售卖或分餐0合格1不合格
     */
    @Schema(description = "售卖或分餐0合格1不合格")
    @Excel(name = "售卖或分餐0合格1不合格")
    private Integer sellIndividualMeals;

    /**
     * 售卖或分餐不合格处置说明，300内，不合格必填
     */
    @Schema(description = "售卖或分餐不合格处置说明，300内，不合格必填")
    @Excel(name = "售卖或分餐不合格处置说明，300内，不合格必填")
    private String sellIndividualMealsResult;

    /**
     * 食品留样0合格1不合格
     */
    @Schema(description = "食品留样0合格1不合格")
    @Excel(name = "食品留样0合格1不合格")
    private Integer reserved;

    /**
     * 留样不合格整改说明，300内，不合格必填
     */
    @Schema(description = "留样不合格整改说明，300内，不合格必填")
    @Excel(name = "留样不合格整改说明，300内，不合格必填")
    private String reservedResult;

    /**
     * 成品饭菜0合格1不合格
     */
    @Schema(description = "成品饭菜0合格1不合格")
    @Excel(name = "成品饭菜0合格1不合格")
    private Integer finishedMeal;

    /**
     * 成品饭菜不合格处置说明，300内，不合格必填
     */
    @Schema(description = "成品饭菜不合格处置说明，300内，不合格必填")
    @Excel(name = "成品饭菜不合格处置说明，300内，不合格必填")
    private String finishedMealResult;

    /**
     * 灶具是否合格0合格1不合格
     */
    @Schema(description = "灶具是否合格0合格1不合格")
    @Excel(name = "灶具是否合格0合格1不合格")
    private Integer stove;

    /**
     * 灶具不合格处置说明，300内，不合格必填
     */
    @Schema(description = "灶具不合格处置说明，300内，不合格必填")
    @Excel(name = "灶具不合格处置说明，300内，不合格必填")
    private String stoveResult;

    /**
     * 厨具是否合格0合格1不合格
     */
    @Schema(description = "厨具是否合格0合格1不合格")
    @Excel(name = "厨具是否合格0合格1不合格")
    private Integer kitchenware;

    /**
     * 厨具不合格处置说明，300内，不合格必填
     */
    @Schema(description = "厨具不合格处置说明，300内，不合格必填")
    @Excel(name = "厨具不合格处置说明，300内，不合格必填")
    private String kitchenwareResult;

    /**
     * 操作台是否合格0合格1不合格
     */
    @Schema(description = "操作台是否合格0合格1不合格")
    @Excel(name = "操作台是否合格0合格1不合格")
    private Integer operationConsole;

    /**
     * 操作台不合格处置说明，300内，不合格必填
     */
    @Schema(description = "操作台不合格处置说明，300内，不合格必填")
    @Excel(name = "操作台不合格处置说明，300内，不合格必填")
    private String operationConsoleResult;

    /**
     * 洗涤消毒池是否合格0合格1不合格
     */
    @Schema(description = "洗涤消毒池是否合格0合格1不合格")
    @Excel(name = "洗涤消毒池是否合格0合格1不合格")
    private Integer disinfectionTank;

    /**
     * 洗涤消毒池不合格处置说明，300内，不合格必填
     */
    @Schema(description = "洗涤消毒池不合格处置说明，300内，不合格必填")
    @Excel(name = "洗涤消毒池不合格处置说明，300内，不合格必填")
    private String disinfectionTankResult;

    /**
     * 餐具是否合格0合格1合格
     */
    @Schema(description = "餐具是否合格0合格1合格")
    @Excel(name = "餐具是否合格0合格1合格")
    private Integer tableware;

    /**
     * 餐具不合格处置说明，300内，不合格必填
     */
    @Schema(description = "餐具不合格处置说明，300内，不合格必填")
    @Excel(name = "餐具不合格处置说明，300内，不合格必填")
    private String tablewareResult;

    /**
     * 消防是否合格0合格1不合格
     */
    @Schema(description = "消防是否合格0合格1不合格")
    @Excel(name = "消防是否合格0合格1不合格")
    private Integer fireFightingEquipment;

    /**
     * 消防不合格处置说明300，不合格时必填
     */
    @Schema(description = "消防不合格处置说明300，不合格时必填")
    @Excel(name = "消防不合格处置说明300，不合格时必填")
    private String fireFightingEquipmentResult;

    /**
     * 四害设施是否合格0合格1不合格
     */
    @Schema(description = "四害设施是否合格0合格1不合格")
    @Excel(name = "四害设施是否合格0合格1不合格")
    private Integer fourPestsFacilities;

    /**
     * 四害设施不合格处置说明，300内，不合格必填
     */
    @Schema(description = "四害设施不合格处置说明，300内，不合格必填")
    @Excel(name = "四害设施不合格处置说明，300内，不合格必填")
    private String fourPestsFacilitiesResult;

    /**
     * 最终检查结果0合格1不合格，但凡有一项不合格都是不合格
     */
    @Schema(description = "最终检查结果0合格1不合格，但凡有一项不合格都是不合格")
    @Excel(name = "最终检查结果0合格1不合格，但凡有一项不合格都是不合格")
    private Integer result;

    /**
     * 检查人
     */
    @Schema(description = "检查人")
    @Excel(name = "检查人")
    private String checkPerson;

    /**
     * 检查时间，年月日时分(格式：2025-05-05 08:40)
     */
    @Schema(description = "检查时间，年月日时分(格式：2025-05-05 08:40)")
    @Excel(name = "检查时间，年月日时分(格式：2025-05-05 08:40)")
    private String checkTime;

    /**
     * 0有效1作废
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "0有效1作废")
    private Integer delFlag;


    /**
     * 创建人id(日检人)
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人id(日检人)")
    @Excel(name = "创建人id(日检人)")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

}
