package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import lombok.Data;

import java.util.Date;

/**
 * 食堂菜谱留样导出对象
 */
@Data
public class TFoodRecipseExportVO {

    @Excel(name = "主体名称", sort = 1)
    private String deptName;

    @Excel(name = "日期", sort = 2)
    private String date;

    @Excel(name = "类型", sort = 3, readConverterExp = "1=早餐,2=午餐,3=晚餐")
    private String type;

    @Excel(name = "样品名称", sort = 4)
    private String name;

    @Excel(name = "状态", sort = 5, readConverterExp = "0=有效,1=禁用")
    private Integer delFlag;

    @Excel(name = "留样状态", sort = 6, readConverterExp = "0=未留样,1=已留样,2=已销样")
    private String isReserved;

    @Excel(name = "留样人", sort = 7)
    private String reservedPersonName;

    @Excel(name = "留样时间", sort = 8, width = 22, dateFormat = "yyyy-MM-dd HH:mm")
    private Date reservedTime;

    @Excel(name = "销样人", sort = 9)
    private String cancleSamplePerson;

    @Excel(name = "销样时间", sort = 10, width = 22, dateFormat = "yyyy-MM-dd HH:mm")
    private Date cancleSampleTime;
}
