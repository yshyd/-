package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂周排查-文件是否有缺失对象 t_week_file
 *
 * @author ysh
 * @date 2025-11-27
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_week_file")
public class TWeekFile implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体名称 */
        @Schema(description = "主体名称")
        @Excel(name = "主体名称")
        private Long deptId;

        /** 年度 */
        @Schema(description = "年度")
        @Excel(name = "年度")
        private Long year;

        /** 周度(这一年第多少周) */
        @Schema(description = "周度(这一年第多少周)")
        @Excel(name = "周度(这一年第多少周)")
        private Long week;

        /** 作用开始日期，格式：2025-11-24 */
        @Schema(description = "作用开始日期，格式：2025-11-24")
        @Excel(name = "作用开始日期，格式：2025-11-24")
        private String startDate;

        /** 作用结束日期，格式：2025-11-30 */
        @Schema(description = "作用结束日期，格式：2025-11-30")
        @Excel(name = "作用结束日期，格式：2025-11-30")
        private String endDate;

        /** 文件是否存在异常0否1是 0否1是 */
        @Schema(description = "文件是否存在异常0否1是 0否1是")
        @Excel(name = "文件是否存在异常0否1是 0否1是")
        private Integer isAbnormal;

        /** 异常处置说明，整体不达标必填，500字内 */
        @Schema(description = "异常处置说明，整体不达标必填，500字内")
        @Excel(name = "异常处置说明，整体不达标必填，500字内")
        private String remarks;

        /** 排查人 */
        @Schema(description = "排查人")
        @Excel(name = "排查人")
        private String searchPeople;

        /** 排查时间 */
        @Schema(description = "排查时间")
        @Excel(name = "排查时间")
        private String searchTime;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
