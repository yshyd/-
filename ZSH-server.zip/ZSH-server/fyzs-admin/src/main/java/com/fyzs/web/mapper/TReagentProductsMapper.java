package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TReagentProducts;
import com.fyzs.web.entity.query.TReagentProductsQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 快检仪-项目检测Mapper接口
 * 
 * @author ysh
 * @date 2026-01-09
 */
@Mapper
public interface TReagentProductsMapper  extends BaseMapper<TReagentProducts>
{
    /**
     * 查询快检仪-项目检测
     * 
     * @param id 快检仪-项目检测主键
     * @return 快检仪-项目检测
     */
    public TReagentProducts selectTReagentProductsById(Long id);

    /**
     * 查询快检仪-项目检测列表
     * 
     * @param tReagentProducts 快检仪-项目检测
     * @return 快检仪-项目检测集合
     */
    public List<TReagentProductsQuery> selectTReagentProductsList(TReagentProductsQuery tReagentProducts);

    /**
     * 新增快检仪-项目检测
     * 
     * @param tReagentProducts 快检仪-项目检测
     * @return 结果
     */
    public int insertTReagentProducts(TReagentProducts tReagentProducts);

    /**
     * 修改快检仪-项目检测
     * 
     * @param tReagentProducts 快检仪-项目检测
     * @return 结果
     */
    public int updateTReagentProducts(TReagentProducts tReagentProducts);

    /**
     * 删除快检仪-项目检测
     * 
     * @param id 快检仪-项目检测主键
     * @return 结果
     */
    public int deleteTReagentProductsById(Long id);

    /**
     * 批量删除快检仪-项目检测
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTReagentProductsByIds(Long[] ids);
}
