package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TAnnouncementItem;
import com.fyzs.web.entity.query.TAnnouncementItemQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 公告查阅Mapper接口
 * 
 * @author ysh
 * @date 2025-12-04
 */
@org.apache.ibatis.annotations.Mapper
public interface TAnnouncementItemMapper  extends BaseMapper<TAnnouncementItem>
{
    /**
     * 查询公告查阅
     * 
     * @param id 公告查阅主键
     * @return 公告查阅
     */
    public TAnnouncementItem selectTAnnouncementItemById(Long id);

    /**
     * 查询公告查阅列表
     * 
     * @param tAnnouncementItem 公告查阅
     * @return 公告查阅集合
     */
    public List<TAnnouncementItemQuery> selectTAnnouncementItemList(TAnnouncementItemQuery tAnnouncementItem);

    /**
     * 新增公告查阅
     * 
     * @param tAnnouncementItem 公告查阅
     * @return 结果
     */
    public int insertTAnnouncementItem(TAnnouncementItem tAnnouncementItem);

    /**
     * 修改公告查阅
     * 
     * @param tAnnouncementItem 公告查阅
     * @return 结果
     */
    public int updateTAnnouncementItem(TAnnouncementItem tAnnouncementItem);

    /**
     * 删除公告查阅
     * 
     * @param id 公告查阅主键
     * @return 结果
     */
    public int deleteTAnnouncementItemById(Long id);

    /**
     * 批量删除公告查阅
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTAnnouncementItemByIds(Long[] ids);
}
