package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TProcurementOrderItem;

/**
 * 采购计划副Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITProcurementOrderItemService extends IService<TProcurementOrderItem>
{
    /**
     * 查询采购计划副
     * 
     * @param id 采购计划副主键
     * @return 采购计划副
     */
    public TProcurementOrderItem selectTProcurementOrderItemById(Long id);

    /**
     * 查询采购计划副列表
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 采购计划副集合
     */
    public List<TProcurementOrderItem> selectTProcurementOrderItemList(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 新增采购计划副
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 结果
     */
    public int insertTProcurementOrderItem(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 修改采购计划副
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 结果
     */
    public int updateTProcurementOrderItem(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 批量删除采购计划副
     * 
     * @param ids 需要删除的采购计划副主键集合
     * @return 结果
     */
    public int deleteTProcurementOrderItemByIds(Long[] ids);

    /**
     * 删除采购计划副信息
     * 
     * @param id 采购计划副主键
     * @return 结果
     */
    public int deleteTProcurementOrderItemById(Long id);
}
