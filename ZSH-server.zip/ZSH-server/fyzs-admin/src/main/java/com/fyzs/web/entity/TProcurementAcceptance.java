package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 商品采购验收对象 t_procurement_acceptance
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_procurement_acceptance")
public class TProcurementAcceptance implements Serializable {

    private static final long serialVersionUID = 1L;

        /** id */
        @Schema(description = "id")
        private Long id;

        /** 对应主体id */
        @Schema(description = "对应主体id")
        @Excel(name = "对应主体id")
        private Long deptId;

        /** 关联采购订单id */
        @Schema(description = "关联采购订单id")
        @Excel(name = "关联采购订单id")
        private Long productionOrderId;

        /** 供应商id */
        @Schema(description = "供应商id")
        @Excel(name = "供应商id")
        private Long supplerId;

        /** 商品验收单号(格式：YSD20251029000001依次递增) */
        @Schema(description = "商品验收单号(格式：YSD20251029000001依次递增)")
        @Excel(name = "商品验收单号(格式：YSD20251029000001依次递增)")
        private String accetpanceNo;

        /** 验收状态：0未验收1部分验收2全部验收 */
        @Schema(description = "验收状态：0未验收1部分验收2全部验收")
        @Excel(name = "验收状态：0未验收1部分验收2全部验收")
        private Integer acceptanceStatus;

        /** 结算状态：0未结算1已结算 */
        @Schema(description = "结算状态：0未结算1已结算")
        @Excel(name = "结算状态：0未结算1已结算")
        private Integer settlementStatus;

        /** 预计验收日期(采购单生成的时候填写的到货日期) */
        @Schema(description = "预计验收日期(采购单生成的时候填写的到货日期)")
        @Excel(name = "预计验收日期(采购单生成的时候填写的到货日期)")
        private String expectedTime;

        /** 验收人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "验收人")
        @Excel(name = "验收人")
        private Long createUser;

        /** 验收人人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "验收人人姓名")
        @Excel(name = "验收人人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
