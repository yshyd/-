package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraRegulationsVideo;
import com.fyzs.web.service.ITCameraRegulationsVideoService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规识别视频固证文件存储信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/video")
public class TCameraRegulationsVideoController extends BaseController
{

    private final ITCameraRegulationsVideoService tCameraRegulationsVideoService;

    /**
     * 查询违法违规识别视频固证文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:video:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraRegulationsVideo tCameraRegulationsVideo)
    {
        startPage();
        List<TCameraRegulationsVideo> list = tCameraRegulationsVideoService.selectTCameraRegulationsVideoList(tCameraRegulationsVideo);
        return getDataTable(list);
    }

    /**
     * 导出违法违规识别视频固证文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:video:export')")
    @Log(title = "违法违规识别视频固证文件存储信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraRegulationsVideo tCameraRegulationsVideo)
    {
        List<TCameraRegulationsVideo> list = tCameraRegulationsVideoService.selectTCameraRegulationsVideoList(tCameraRegulationsVideo);
        ExcelUtil<TCameraRegulationsVideo> util = new ExcelUtil<TCameraRegulationsVideo>(TCameraRegulationsVideo.class);
        util.exportExcel(response, list, "违法违规识别视频固证文件存储信息数据");
    }

    /**
     * 获取违法违规识别视频固证文件存储信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:video:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraRegulationsVideoService.selectTCameraRegulationsVideoById(id));
    }

    /**
     * 新增违法违规识别视频固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:video:add')")
    @Log(title = "违法违规识别视频固证文件存储信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraRegulationsVideo tCameraRegulationsVideo)
    {
        return toAjax(tCameraRegulationsVideoService.save(tCameraRegulationsVideo));
    }

    /**
     * 修改违法违规识别视频固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:video:edit')")
    @Log(title = "违法违规识别视频固证文件存储信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraRegulationsVideo tCameraRegulationsVideo)
    {
        return toAjax(tCameraRegulationsVideoService.updateById(tCameraRegulationsVideo));
    }

    /**
     * 删除违法违规识别视频固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:video:remove')")
    @Log(title = "违法违规识别视频固证文件存储信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraRegulationsVideoService.deleteTCameraRegulationsVideoByIds(ids));
    }
}
