package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.entity.TNewOutbound;
import com.fyzs.web.entity.dto.TNewOutboundDTO;
import com.fyzs.web.entity.query.TNewOutboundQuery;
import com.fyzs.web.entity.vo.TNewOutboundExportVO;

/**
 * 出库记录Service接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
public interface ITNewOutboundService extends IService<TNewOutbound>
{
    /**
     * 查询出库记录
     * 
     * @param id 出库记录主键
     * @return 出库记录
     */
    public TNewOutboundQuery selectTNewOutboundById(Long id);

    /**
     * 查询出库记录列表
     * 
     * @param tNewOutbound 出库记录
     * @return 出库记录集合
     */
    public List<TNewOutboundQuery> selectTNewOutboundList(TNewOutboundQuery tNewOutbound);

    /**
     * 根据筛选条件查询全部出库导出数据（不分页）
     *
     * @param tNewOutbound 出库记录筛选条件
     * @return 出库记录集合
     */
    public List<TNewOutboundExportVO> selectTNewOutboundExportList(TNewOutboundQuery tNewOutbound);

    /**
     * 新增出库记录
     * 
     * @param tNewOutbound 出库记录
     * @return 结果
     */
    public int insertTNewOutbound(TNewOutbound tNewOutbound);

    /**
     * 修改出库记录
     * 
     * @param tNewOutbound 出库记录
     * @return 结果
     */
    public int updateTNewOutbound(TNewOutbound tNewOutbound);

    /**
     * 批量删除出库记录
     * 
     * @param ids 需要删除的出库记录主键集合
     * @return 结果
     */
    public int deleteTNewOutboundByIds(Long[] ids);

    /**
     * 删除出库记录信息
     * 
     * @param id 出库记录主键
     * @return 结果
     */
    public int deleteTNewOutboundById(Long id);

    int confirm(TNewOutboundDTO dto);

    List<TNewOutboundQuery> selectTNewOutList(TNewOutboundQuery tNewOutbound);
}
