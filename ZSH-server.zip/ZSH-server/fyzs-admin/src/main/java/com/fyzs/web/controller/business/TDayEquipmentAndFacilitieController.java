package com.fyzs.web.controller.business;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TDayEquipmentAndFacilitieQuery;
import com.fyzs.web.mapper.TAlarmMapper;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayEquipmentAndFacilitie;
import com.fyzs.web.service.ITDayEquipmentAndFacilitieService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常巡检-设备设施巡检Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/facilitie")
public class TDayEquipmentAndFacilitieController extends BaseController
{

    private final ITDayEquipmentAndFacilitieService facilitieService;

    private final ITAlarmService alarmService;

    /**
     * 查询学校食堂日管控-日常巡检-设备设施巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayEquipmentAndFacilitieQuery query)
    {
        startPage();
        List<TDayEquipmentAndFacilitieQuery> list = facilitieService.selectTDayEquipmentAndFacilitieList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常巡检-设备设施巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:export')")
    @Log(title = "学校食堂日管控-日常巡检-设备设施巡检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayEquipmentAndFacilitieQuery query)
    {
        List<TDayEquipmentAndFacilitieQuery> list = facilitieService.selectTDayEquipmentAndFacilitieList(query);
        ExcelUtil<TDayEquipmentAndFacilitieQuery> util = new ExcelUtil<TDayEquipmentAndFacilitieQuery>(TDayEquipmentAndFacilitieQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常巡检-设备设施巡检数据");
    }

    /**
     * 获取学校食堂日管控-日常巡检-设备设施巡检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(facilitieService.selectTDayEquipmentAndFacilitieById(id));
    }

    /**
     * 新增学校食堂日管控-日常巡检-设备设施巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:add')")
    @Log(title = "学校食堂日管控-日常巡检-设备设施巡检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayEquipmentAndFacilitie facilitie)
    {
        return toAjax(facilitieService.insertTDayEquipmentAndFacilitie(facilitie));
    }

    /**
     * 修改学校食堂日管控-日常巡检-设备设施巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:edit')")
    @Log(title = "学校食堂日管控-日常巡检-设备设施巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayEquipmentAndFacilitie facilitie)
    {
        return toAjax(facilitieService.updateTDayEquipmentAndFacilitie(facilitie));
    }

    /**
     * 启用/作废(id,delFlag)
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:edit')")
    @Log(title = "学校食堂日管控-日常巡检-设备设施巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayEquipmentAndFacilitie tDayEquipmentAndFacilitie)
    {
        return toAjax(facilitieService.cancel(tDayEquipmentAndFacilitie));
    }

    /**
     * 删除学校食堂日管控-日常巡检-设备设施巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:facilitie:remove')")
    @Log(title = "学校食堂日管控-日常巡检-设备设施巡检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(facilitieService.deleteTDayEquipmentAndFacilitieByIds(ids));
    }
}
