package com.fyzs.web.entity.dto;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TNewProcurementAcceptance;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewProcurementAcceptanceDTO extends TNewProcurementAcceptance {

    @Schema(description = "按钮类型 1是入库 2是入库并出库")
    private Integer btnType;

}
