package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TMonitoringLinksConfig;
import com.fyzs.web.entity.dto.TreeNode;


/**
 * 关键监控环节配置Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITMonitoringLinksConfigService extends IService<TMonitoringLinksConfig>
{
    /**
     * 查询关键监控环节配置
     * 
     * @param id 关键监控环节配置主键
     * @return 关键监控环节配置
     */
    public TMonitoringLinksConfig selectTMonitoringLinksConfigById(Long id);

    /**
     * 查询关键监控环节配置列表
     * 
     * @param tMonitoringLinksConfig 关键监控环节配置
     * @return 关键监控环节配置集合
     */
    public List<TMonitoringLinksConfig> selectTMonitoringLinksConfigList(TMonitoringLinksConfig tMonitoringLinksConfig);

    public List<TMonitoringLinksConfig> selectConfigList(TMonitoringLinksConfig tMonitoringLinksConfig);
    /**
     * 新增关键监控环节配置
     * 
     * @param tMonitoringLinksConfig 关键监控环节配置
     * @return 结果
     */
    public int insertTMonitoringLinksConfig(TMonitoringLinksConfig tMonitoringLinksConfig);

    /**
     * 修改关键监控环节配置
     * 
     * @param tMonitoringLinksConfig 关键监控环节配置
     * @return 结果
     */
    public int updateTMonitoringLinksConfig(TMonitoringLinksConfig tMonitoringLinksConfig);

    /**
     * 批量删除关键监控环节配置
     * 
     * @param ids 需要删除的关键监控环节配置主键集合
     * @return 结果
     */
    public int deleteTMonitoringLinksConfigByIds(Long[] ids);

    /**
     * 删除关键监控环节配置信息
     * 
     * @param id 关键监控环节配置主键
     * @return 结果
     */
    public int deleteTMonitoringLinksConfigById(Long id);

    List<TreeNode> buildTree(List<TMonitoringLinksConfig> list);
}
