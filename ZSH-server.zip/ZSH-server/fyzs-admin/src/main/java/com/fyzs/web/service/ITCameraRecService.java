package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraRec;

/**
 * 可视化视频监控回放信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraRecService extends IService<TCameraRec>
{
    /**
     * 查询可视化视频监控回放信息
     * 
     * @param id 可视化视频监控回放信息主键
     * @return 可视化视频监控回放信息
     */
    public TCameraRec selectTCameraRecById(Long id);

    /**
     * 查询可视化视频监控回放信息列表
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 可视化视频监控回放信息集合
     */
    public List<TCameraRec> selectTCameraRecList(TCameraRec tCameraRec);

    /**
     * 新增可视化视频监控回放信息
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 结果
     */
    public int insertTCameraRec(TCameraRec tCameraRec);

    /**
     * 修改可视化视频监控回放信息
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 结果
     */
    public int updateTCameraRec(TCameraRec tCameraRec);

    /**
     * 批量删除可视化视频监控回放信息
     * 
     * @param ids 需要删除的可视化视频监控回放信息主键集合
     * @return 结果
     */
    public int deleteTCameraRecByIds(Long[] ids);

    /**
     * 删除可视化视频监控回放信息信息
     * 
     * @param id 可视化视频监控回放信息主键
     * @return 结果
     */
    public int deleteTCameraRecById(Long id);
}
