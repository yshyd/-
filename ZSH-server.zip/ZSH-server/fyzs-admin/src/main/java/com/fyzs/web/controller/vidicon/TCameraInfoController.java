package com.fyzs.web.controller.vidicon;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.entity.dto.TCameraInfoDTO;
import com.fyzs.web.entity.query.TCameraInfoQuery;
import com.fyzs.web.utils.EzvizAddressUtil;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraInfo;
import com.fyzs.web.service.ITCameraInfoService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 设备管理-摄像头管理Controller
 * 
 * @author ysh
 * @date 2025-12-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/camera/info")
public class TCameraInfoController extends BaseController
{

    private final ITCameraInfoService tCameraInfoService;

    private  final EzvizAddressUtil ezvizAddressUtil;

    /**
     * 查询设备管理-摄像头管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:info:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraInfoQuery tCameraInfo)
    {
//        startPage();
        List<TCameraInfoQuery> list = tCameraInfoService.selectTCameraInfoList(tCameraInfo);
        return getDataTable(list);
    }

    /**
     * 导出设备管理-摄像头管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:info:export')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraInfoQuery tCameraInfo)
    {
        List<TCameraInfoQuery> list = tCameraInfoService.selectTCameraInfoList(tCameraInfo);
        ExcelUtil<TCameraInfoQuery> util = new ExcelUtil<TCameraInfoQuery>(TCameraInfoQuery.class);
        util.exportExcel(response, list, "设备管理-摄像头管理数据");
    }

    /**
     * 获取设备管理-摄像头管理详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:info:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraInfoService.selectTCameraInfoById(id));
    }

    /**
     * 新增设备管理-摄像头管理
     */
    //@PreAuthorize("@ss.hasPermi('web:info:add')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraInfoDTO dto)
    {

        return toAjax(tCameraInfoService.insertTCameraInfo(dto));
    }

    /**
     * 修改设备管理-摄像头管理
     */
    //@PreAuthorize("@ss.hasPermi('web:info:edit')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraInfoDTO tCameraInfo)
    {

        return toAjax(tCameraInfoService.updateTCameraInfo(tCameraInfo));
    }

    /**
     * 启用/禁用
     */
    //@PreAuthorize("@ss.hasPermi('web:info:edit')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TCameraInfo tCameraInfo)
    {

        return toAjax(tCameraInfoService.updateById(tCameraInfo));
    }

    /**
     * 更新地址
     */
//@PreAuthorize("@ss.hasPermi('web:info:edit')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.UPDATE)
    @PutMapping("/edit/address")
    public AjaxResult updateAddress(@RequestBody TCameraInfo tCameraInfo) {
        // 获取accessToken
        String accessToken = ezvizAddressUtil.getAccessToken();
        if (accessToken == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }
        if (ObjectUtils.isEmpty(tCameraInfo.getId())){
            return error("设备ID为空");
        }
        TCameraInfo cameraInfo = tCameraInfoService.getById(tCameraInfo.getId());
        String deviceSerial = cameraInfo.getSerialNumber();
        Long channelNo = cameraInfo.getChannelNumber();
        // 获取各种地址
        String ezopenUrlLive = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 1, 1, 1);
        if (ezopenUrlLive == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String rtmpUrlLive = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 3, 1, 1);
        if (rtmpUrlLive == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String hlsUrlLive = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 2, 1, 1);
        if (hlsUrlLive == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String ezopenUrlLiveItem = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 1, 2, 1);
        if (ezopenUrlLiveItem == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String rtmpUrlLiveItem = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 3, 2, 1);
        if (rtmpUrlLiveItem == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String hlsUrlLiveItem = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 2, 2, 1);
        if (hlsUrlLiveItem == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        String ezopenUrlRec = ezvizAddressUtil.getLiveAddress(accessToken, deviceSerial, channelNo, 1, null, 2);
        if (ezopenUrlRec == null) {
            return error("萤石云获取地址接口异常，无法更新地址");
        }

        // 设置地址并更新数据库
        tCameraInfo.setEzopenUrlLive(ezopenUrlLive);
        tCameraInfo.setRtmpUrlLive(rtmpUrlLive);
        tCameraInfo.setHlsUrlLive(hlsUrlLive);
        tCameraInfo.setEzopenUrlLiveItem(ezopenUrlLiveItem);
        tCameraInfo.setRtmpUrlLiveItem(rtmpUrlLiveItem);
        tCameraInfo.setHlsUrlLiveItem(hlsUrlLiveItem);
        tCameraInfo.setEzopenUrlRec(ezopenUrlRec);

        return toAjax(tCameraInfoService.updateById(tCameraInfo));
    }


    /**
     * 删除设备管理-摄像头管理
     */
    //@PreAuthorize("@ss.hasPermi('web:info:remove')")
    @Log(title = "设备管理-摄像头管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraInfoService.deleteTCameraInfoByIds(ids));
    }

    /**
     * 区域主体权限树(带数量)
     */
    @GetMapping("/areaDataTree")
    public AjaxResult areaDataTree() {
        return success(tCameraInfoService.areaDataTree());
    }
}
