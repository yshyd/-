package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TThAlarm;
import com.fyzs.web.entity.query.TThAlarmQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 温湿度检测仪的告警记录Mapper接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
@Mapper
public interface TThAlarmMapper  extends BaseMapper<TThAlarm>
{
    /**
     * 查询温湿度检测仪的告警记录
     * 
     * @param id 温湿度检测仪的告警记录主键
     * @return 温湿度检测仪的告警记录
     */
    public TThAlarm selectTThAlarmById(Long id);

    /**
     * 查询温湿度检测仪的告警记录列表
     * 
     * @param tThAlarm 温湿度检测仪的告警记录
     * @return 温湿度检测仪的告警记录集合
     */
    public List<TThAlarmQuery> selectTThAlarmList(TThAlarmQuery tThAlarm);

    /**
     * 新增温湿度检测仪的告警记录
     * 
     * @param tThAlarm 温湿度检测仪的告警记录
     * @return 结果
     */
    public int insertTThAlarm(TThAlarm tThAlarm);

    /**
     * 修改温湿度检测仪的告警记录
     * 
     * @param tThAlarm 温湿度检测仪的告警记录
     * @return 结果
     */
    public int updateTThAlarm(TThAlarm tThAlarm);

    /**
     * 删除温湿度检测仪的告警记录
     * 
     * @param id 温湿度检测仪的告警记录主键
     * @return 结果
     */
    public int deleteTThAlarmById(Long id);

    /**
     * 批量删除温湿度检测仪的告警记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTThAlarmByIds(Long[] ids);
}
