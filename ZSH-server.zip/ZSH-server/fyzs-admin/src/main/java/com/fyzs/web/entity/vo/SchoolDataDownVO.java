package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SchoolDataDownVO {

    @Schema(description = "学校名称")
    private String deptName;

    /** 学校类型：0幼儿园、1小学、2初中、3九年一贯制、4十二年一贯制、5高中、6完中、7中职、8特殊教育、9大专、10大学 */
    @Schema(description = "学校类型：0幼儿园、1小学、2初中、3九年一贯制、4十二年一贯制、5高中、6完中、7中职、8特殊教育、9大专、10大学")
    private Integer type;

    @Schema(description = "校长")
    private String leRep;

    @Schema(description = "校长电话")
    private String phone;

    @Schema(description = "证件图片URL")
    private String img;
}
