package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import lombok.Data;

/**
 * 食堂人员日检导出对象
 */
@Data
public class TPersonCheckExportVO {

    @Excel(name = "主体名称", sort = 1)
    private String deptName;

    @Excel(name = "员工姓名", sort = 2)
    private String personName;

    @Excel(name = "体温", sort = 3)
    private String temperature;

    @Excel(name = "类型", sort = 4, readConverterExp = "1=晨检,2=午检,3=晚检")
    private String type;

    @Excel(name = "是否发热", sort = 5, readConverterExp = "0=否,1=是")
    private String isHighTemperature;

    @Excel(name = "指甲油", sort = 6, readConverterExp = "0=否,1=是")
    private String isNailPolish;

    @Excel(name = "指甲过长", sort = 7, readConverterExp = "0=否,1=是")
    private String isNails;

    @Excel(name = "佩戴饰品", sort = 8, readConverterExp = "0=否,1=是")
    private String isRing;

    @Excel(name = "手部异物", sort = 9, readConverterExp = "0=否,1=是")
    private String isForeignObject;

    @Excel(name = "着装规范", sort = 10, readConverterExp = "0=规范,1=不规范")
    private String isDressCode;

    @Excel(name = "状态", sort = 11, readConverterExp = "0=有效,1=作废")
    private Integer delFlag;

    @Excel(name = "检查时间", sort = 12, width = 22)
    private String date;
}
