package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TMonthPlan;
import com.fyzs.web.entity.query.TMonthPlanQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 食安监管-月调度-月计划Mapper接口
 * 
 * @author ysh
 * @date 2025-12-02
 */
@org.apache.ibatis.annotations.Mapper
public interface TMonthPlanMapper  extends BaseMapper<TMonthPlan>
{
    /**
     * 查询食安监管-月调度-月计划
     * 
     * @param id 食安监管-月调度-月计划主键
     * @return 食安监管-月调度-月计划
     */
    public TMonthPlanQuery selectTMonthPlanById(Long id);

    /**
     * 查询食安监管-月调度-月计划列表
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 食安监管-月调度-月计划集合
     */
    public List<TMonthPlanQuery> selectTMonthPlanList(TMonthPlanQuery tMonthPlan);

    /**
     * 新增食安监管-月调度-月计划
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 结果
     */
    public int insertTMonthPlan(TMonthPlan tMonthPlan);

    /**
     * 修改食安监管-月调度-月计划
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 结果
     */
    public int updateTMonthPlan(TMonthPlan tMonthPlan);

    /**
     * 删除食安监管-月调度-月计划
     * 
     * @param id 食安监管-月调度-月计划主键
     * @return 结果
     */
    public int deleteTMonthPlanById(Long id);

    /**
     * 批量删除食安监管-月调度-月计划
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTMonthPlanByIds(Long[] ids);
}
