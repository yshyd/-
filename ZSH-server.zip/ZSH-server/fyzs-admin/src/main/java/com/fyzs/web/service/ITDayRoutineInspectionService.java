package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayRoutineInspection;
import com.fyzs.web.entity.query.TDayRoutineInspectionQuery;

/**
 * 学校食堂日管控-日常检查-常规日检Service接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
public interface ITDayRoutineInspectionService extends IService<TDayRoutineInspection>
{
    /**
     * 查询学校食堂日管控-日常检查-常规日检
     * 
     * @param id 学校食堂日管控-日常检查-常规日检主键
     * @return 学校食堂日管控-日常检查-常规日检
     */
    public TDayRoutineInspectionQuery selectTDayRoutineInspectionById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-常规日检列表
     *
     * @return 学校食堂日管控-日常检查-常规日检集合
     */
    public List<TDayRoutineInspectionQuery> selectTDayRoutineInspectionList(TDayRoutineInspectionQuery query);

    /**
     * 新增学校食堂日管控-日常检查-常规日检
     * 
     * @param tDayRoutineInspection 学校食堂日管控-日常检查-常规日检
     * @return 结果
     */
    public int insertTDayRoutineInspection(TDayRoutineInspection tDayRoutineInspection);

    /**
     * 修改学校食堂日管控-日常检查-常规日检
     * 
     * @param tDayRoutineInspection 学校食堂日管控-日常检查-常规日检
     * @return 结果
     */
    public int updateTDayRoutineInspection(TDayRoutineInspection tDayRoutineInspection);

    /**
     * 批量删除学校食堂日管控-日常检查-常规日检
     * 
     * @param ids 需要删除的学校食堂日管控-日常检查-常规日检主键集合
     * @return 结果
     */
    public int deleteTDayRoutineInspectionByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常检查-常规日检信息
     * 
     * @param id 学校食堂日管控-日常检查-常规日检主键
     * @return 结果
     */
    public int deleteTDayRoutineInspectionById(Long id);

    int cancel(TDayRoutineInspection tDayRoutineInspection);
}
