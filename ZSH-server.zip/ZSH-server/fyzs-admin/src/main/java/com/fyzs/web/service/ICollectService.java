package com.fyzs.web.service;

import com.fyzs.web.entity.dto.FoodSampleDTO;
import com.fyzs.web.entity.dto.SummaryItemDTO;
import com.fyzs.web.entity.query.SummaryQuery;

import java.text.ParseException;
import java.util.Map;

public interface ICollectService {
    /**
     * 获取周汇总数据
     * @param query 查询条件
     * @return 各模块的汇总数据
     */
    Map<String, Object> getWeeklySummary(SummaryQuery query);

    // 各模块独立统计方法（用于并行处理）

    /** 员工日检表*/
    SummaryItemDTO getEmployeeDailyCheckSummary(SummaryQuery query) throws ParseException;
    /** 常规日检表 */
    SummaryItemDTO getRoutineInspectionSummary(SummaryQuery query);
    /** 日常快检表 */
    SummaryItemDTO getQuickCheckSummary(SummaryQuery query);
    /** 日常抽检表 */
    SummaryItemDTO getRandomInspectionSummary(SummaryQuery query);
    /** 餐饮具消毒 */
    SummaryItemDTO getTablewareDisinfectionSummary(SummaryQuery query);
    /** 场所设备消毒 */
    SummaryItemDTO getEquipmentDisinfectionSummary(SummaryQuery query);
    /** 垃圾消毒 */
    SummaryItemDTO getGarbageDisinfectionSummary(SummaryQuery query);
    /** 库房贮藏巡检 */
    SummaryItemDTO getStorageInspectionSummary(SummaryQuery query);
    /** 设备设施巡检 */
    SummaryItemDTO getFacilityInspectionSummary(SummaryQuery query);
    /** 场所环境巡检 */
    SummaryItemDTO getEnvironmentInspectionSummary(SummaryQuery query);
    /** 食品加工制作过程巡检 */
    SummaryItemDTO getFoodProcessInspectionSummary(SummaryQuery query);
    /** 每日食谱 */
    SummaryItemDTO getFoodMenuSummary(SummaryQuery query);
    /** 日常留样 */
    FoodSampleDTO getFoodSampleSummary(SummaryQuery query);
    /** 日常试尝 */
    SummaryItemDTO getFoodTastingSummary(SummaryQuery query);
    /** 就餐人数 */
    SummaryItemDTO getDinerCountSummary(SummaryQuery query);
    /** 餐厨垃圾 */
    SummaryItemDTO getKitchenWasteSummary(SummaryQuery query);
    /** 周检表 */
    SummaryItemDTO getWeeklyCheckSummary(SummaryQuery query);

    Map<String, Object> getMonthSummary(SummaryQuery query);
}
