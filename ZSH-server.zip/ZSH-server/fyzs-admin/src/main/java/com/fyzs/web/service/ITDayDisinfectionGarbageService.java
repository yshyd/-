package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayDisinfectionGarbage;
import com.fyzs.web.entity.query.TDayDisinfectionGarbageQuery;

/**
 * 学校食堂日管控-日常消毒-垃圾区域消毒Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayDisinfectionGarbageService extends IService<TDayDisinfectionGarbage>
{
    /**
     * 查询学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param id 学校食堂日管控-日常消毒-垃圾区域消毒主键
     * @return 学校食堂日管控-日常消毒-垃圾区域消毒
     */
    public TDayDisinfectionGarbageQuery selectTDayDisinfectionGarbageById(Long id);

    /**
     * 查询学校食堂日管控-日常消毒-垃圾区域消毒列表
     * 
     * @param query 学校食堂日管控-日常消毒-垃圾区域消毒
     * @return 学校食堂日管控-日常消毒-垃圾区域消毒集合
     */
    public List<TDayDisinfectionGarbageQuery> selectTDayDisinfectionGarbageList(TDayDisinfectionGarbageQuery query);

    /**
     * 新增学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param tDayDisinfectionGarbage 学校食堂日管控-日常消毒-垃圾区域消毒
     * @return 结果
     */
    public int insertTDayDisinfectionGarbage(TDayDisinfectionGarbage tDayDisinfectionGarbage);

    /**
     * 修改学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param tDayDisinfectionGarbage 学校食堂日管控-日常消毒-垃圾区域消毒
     * @return 结果
     */
    public int updateTDayDisinfectionGarbage(TDayDisinfectionGarbage tDayDisinfectionGarbage);

    /**
     * 批量删除学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param ids 需要删除的学校食堂日管控-日常消毒-垃圾区域消毒主键集合
     * @return 结果
     */
    public int deleteTDayDisinfectionGarbageByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常消毒-垃圾区域消毒信息
     * 
     * @param id 学校食堂日管控-日常消毒-垃圾区域消毒主键
     * @return 结果
     */
    public int deleteTDayDisinfectionGarbageById(Long id);
}
