package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 快检仪-项目检测对象 t_reagent_products
 *
 * @author ysh
 * @date 2026-01-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_reagent_products")
public class TReagentProducts implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 对应的可用设备型号 */
        @Schema(description = "对应的可用设备型号")
        @Excel(name = "对应的可用设备型号")
        private String type;

        /** 食材类别ID */
        @Schema(description = "食材类别ID")
        @Excel(name = "食材类别ID")
        private Long categoryId;

        /** 检测项 */
        @Schema(description = "检测项")
        @Excel(name = "检测项")
        private String productName;

        /** 货号 */
        @Schema(description = "货号")
        @Excel(name = "货号")
        private String productCode;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建ID(对应sys_user)")
        @Excel(name = "创建ID(对应sys_user)")
        private Long createUser;

        /** 创建姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建姓名(对应sys_user)")
        @Excel(name = "创建姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
