package com.fyzs.web.controller.device;

import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.common.utils.ImageURL;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.system.domain.TOrganizationDetail;
import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.controller.common.CommonController;
import com.fyzs.web.entity.*;
import com.fyzs.web.entity.dto.TDeviceDTO;
import com.fyzs.web.entity.query.TDeviceQuery;
import com.fyzs.web.entity.vo.DeviceOverviewVO;
import com.fyzs.web.mapper.*;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.service.ITDeviceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 设备基础信息Controller
 * 
 * @author ysh
 * @date 2025-12-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/device")
public class TDeviceController extends BaseController
{

    private final ITDeviceService tDeviceService;

    private final TDoorStatusMapper tDoorStatusMapper;

    private final TGasStatusMapper tGasStatusMapper;

    private final TThStatusMapper tThStatusMapper;

    private final TAirRecodeMapper tAirRecodeMapper;

    /**
     * 查询设备基础信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:device:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDeviceQuery tDevice)
    {
        startPage();
        List<TDeviceQuery> list = tDeviceService.selectTDeviceList(tDevice);
        return getDataTable(list);
    }

    /**
     * 导出设备基础信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:device:export')")
    @Log(title = "设备基础信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDeviceQuery tDevice)
    {
        List<TDeviceQuery> list = tDeviceService.selectTDeviceList(tDevice);
        ExcelUtil<TDeviceQuery> util = new ExcelUtil<TDeviceQuery>(TDeviceQuery.class);
        util.exportExcel(response, list, "设备基础信息数据");
    }

    /**
     * 获取设备基础信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:device:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDeviceService.selectTDeviceById(id));
    }

    /**
     * 新增设备基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:device:add')")
    @Log(title = "设备基础信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDevice tDevice)
    {
        long count = tDeviceService.count(new LambdaQueryWrapper<>(TDevice.class)
                .eq(TDevice::getSerialNumber, tDevice.getSerialNumber())
        );
        if (count > 0){
            return error("设备序列号重复，无法绑定设备");
        }
        if (tDevice.getType().equals(0)){
            TDoorStatus tDoorStatus = new TDoorStatus();
            tDoorStatus.setSerailNumber(tDevice.getSerialNumber());
            tDoorStatus.setCreateUser(getUserId());
            tDoorStatus.setCreateName(SecurityUtils.getLoginUser().getUser().getNickName());
            tDoorStatus.setCreateDate(new Date());
            tDoorStatusMapper.insert(tDoorStatus);
        }

        if (tDevice.getType().equals(9)){
            TGasStatus tGasStatus = new TGasStatus();
            tGasStatus.setSerialNumber(tDevice.getSerialNumber());
            tGasStatusMapper.insert(tGasStatus);
        }

        if (tDevice.getType().equals(8)){
            TThStatus tThStatus = new TThStatus();
            tThStatus.setSerialNumber(tDevice.getSerialNumber());
            tThStatusMapper.insert(tThStatus);
        }

        tDevice.setDelFlag(0L);
        return toAjax(tDeviceService.save(tDevice));
    }

    /**
     * 修改设备基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:device:edit')")
    @Log(title = "设备基础信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDevice tDevice)
    {
        long count = tDeviceService.count(new LambdaQueryWrapper<>(TDevice.class)
                .eq(TDevice::getSerialNumber, tDevice.getSerialNumber())
                .ne(TDevice::getId, tDevice.getId())
        );
        if (count > 0){
            return error("设备序列号重复，无法绑定设备");
        }
        // 先查询原记录
        TDevice existingLicense = tDeviceService.getById(tDevice.getId());
        if (ObjectUtils.isNotEmpty(existingLicense)) {
            // 处理图片字段 - 假设实体中有 licenseImg 字段
            if (StringUtils.isNotEmpty(existingLicense.getImg())) {
                // 如果修改后的图片为空或者与原图片不同，则删除原图片
                if (StringUtils.isEmpty(tDevice.getImg()) ||
                        !existingLicense.getImg().equals(tDevice.getImg())) {
                    String[] originalImages = existingLicense.getImg().split(",");
                    for (String imageUrl : originalImages) {
                        String key = ImageURL.extractKeyFromUrl(imageUrl.trim());
                        if (StringUtils.isNotBlank(key)) {
                            CommonController.deleteOldImage(key);
                        }
                    }
                }
            }
        }
        return toAjax(tDeviceService.updateById(tDevice));
    }

    /**
     * 批量启用/禁用设备(多选与单选)
     */
    @Log(title = "设备基础信息", businessType = BusinessType.UPDATE)
    @PostMapping("/enable")
    public AjaxResult enable(@RequestBody TDeviceDTO tDevice) {

        if (tDevice.getIds() == null || tDevice.getIds().length == 0) {
            return AjaxResult.error("请选择要操作的设备");
        }

        if (tDevice.getDelFlag() == null || (tDevice.getDelFlag() != 0 && tDevice.getDelFlag() != 1)) {
            return AjaxResult.error("状态参数不正确");
        }

        boolean result = tDeviceService.updateBatchEnable(tDevice.getIds(), tDevice.getDelFlag());

        if (result) {
            return AjaxResult.success("操作成功");
        } else {
            return AjaxResult.error("操作失败");
        }
    }

    /**
     * 删除设备基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:device:remove')")
    @Log(title = "设备基础信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDeviceService.deleteTDeviceByIds(ids));
    }

    /**
     * 区域主体权限树(带数量)
     */
    @GetMapping("/areaDataTree")
    public AjaxResult areaDataTree(SysAreaDTO sysArea) {
        return success(tDeviceService.areaDataTree(sysArea));
    }

    /**
     * 区域主体权限树（含摄像头与设备合并总数）
     */
    @GetMapping("/areaDataTreeWithTotal")
    public AjaxResult areaDataTreeWithTotal(SysAreaDTO sysArea) {
        return success(tDeviceService.areaDataTreeWithTotal(sysArea));
    }

    /**
     * 设备总览（按类型统计：t_device + t_camera 启用设备总数）
     */
    @GetMapping("/deviceSummary")
    public AjaxResult deviceSummary(TDeviceQuery query) {
        return success(tDeviceService.getDeviceSummary(query));
    }

}
