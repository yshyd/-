package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TReferencePriceItemQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TReferencePriceItem;
import com.fyzs.web.service.ITReferencePriceItemService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食材标准参考价发布记录主Controller
 * 
 * @author ysh
 * @date 2025-11-24
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/reference/item")
public class TReferencePriceItemController extends BaseController
{

    private final ITReferencePriceItemService tReferencePriceItemService;

    /**
     * 查询食材标准参考价发布记录主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:list')")
    @GetMapping("/list")
    public TableDataInfo list(TReferencePriceItemQuery tReferencePriceItem)
    {
        startPage();
        List<TReferencePriceItemQuery> list = tReferencePriceItemService.selectTReferencePriceItemList(tReferencePriceItem);
        return getDataTable(list);
    }

    /**
     * 导出食材标准参考价发布记录主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:export')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TReferencePriceItemQuery tReferencePriceItem)
    {
        List<TReferencePriceItemQuery> list = tReferencePriceItemService.selectTReferencePriceItemList(tReferencePriceItem);
        ExcelUtil<TReferencePriceItemQuery> util = new ExcelUtil<TReferencePriceItemQuery>(TReferencePriceItemQuery.class);
        util.exportExcel(response, list, "食材标准参考价发布记录主数据");
    }

    /**
     * 获取食材标准参考价发布记录主详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:item:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tReferencePriceItemService.selectTReferencePriceItemById(id));
    }

    /**
     * 新增食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:item:add')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TReferencePriceItem tReferencePriceItem)
    {
        return toAjax(tReferencePriceItemService.save(tReferencePriceItem));
    }

    /**
     * 修改食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:item:edit')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TReferencePriceItem tReferencePriceItem)
    {
        return toAjax(tReferencePriceItemService.updateById(tReferencePriceItem));
    }

    /**
     * 删除食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:item:remove')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tReferencePriceItemService.deleteTReferencePriceItemByIds(ids));
    }
}
