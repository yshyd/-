package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 可燃气体监测报警仪实时状态对象 t_gas_status
 *
 * @author ysh
 * @date 2026-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_gas_status")
public class TGasStatus implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 对应t_device中的serial_number */
        @Schema(description = "对应t_device中的serial_number")
        @Excel(name = "对应t_device中的serial_number")
        private String serialNumber;

        /** 实时浓度(%LEL) */
        @Schema(description = "实时浓度(%LEL)")
        @Excel(name = "实时浓度(%LEL)")
        private String concentration;

        /** 设备网络状态(0:正常4:离线) */
        @Schema(description = "设备网络状态(0:正常4:离线)")
        @Excel(name = "设备网络状态(0:正常4:离线)")
        private Integer deviceState;


        /** 更新时间(当前系统时间) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "更新时间(当前系统时间)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "更新时间(当前系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
