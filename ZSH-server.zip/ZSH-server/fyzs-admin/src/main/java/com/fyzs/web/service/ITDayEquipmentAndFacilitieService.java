package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayEquipmentAndFacilitie;
import com.fyzs.web.entity.query.TDayEquipmentAndFacilitieQuery;

/**
 * 学校食堂日管控-日常巡检-设备设施巡检Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayEquipmentAndFacilitieService extends IService<TDayEquipmentAndFacilitie>
{
    /**
     * 查询学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param id 学校食堂日管控-日常巡检-设备设施巡检主键
     * @return 学校食堂日管控-日常巡检-设备设施巡检
     */
    public TDayEquipmentAndFacilitieQuery selectTDayEquipmentAndFacilitieById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-设备设施巡检列表
     *
     * @return 学校食堂日管控-日常巡检-设备设施巡检集合
     */
    public List<TDayEquipmentAndFacilitieQuery> selectTDayEquipmentAndFacilitieList(TDayEquipmentAndFacilitieQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-设备设施巡检
     * 

     * @return 结果
     */
    public int insertTDayEquipmentAndFacilitie(TDayEquipmentAndFacilitie facilitie);

    /**
     * 修改学校食堂日管控-日常巡检-设备设施巡检
     * 

     * @return 结果
     */
    public int updateTDayEquipmentAndFacilitie(TDayEquipmentAndFacilitie facilitie);

    /**
     * 批量删除学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param ids 需要删除的学校食堂日管控-日常巡检-设备设施巡检主键集合
     * @return 结果
     */
    public int deleteTDayEquipmentAndFacilitieByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常巡检-设备设施巡检信息
     * 
     * @param id 学校食堂日管控-日常巡检-设备设施巡检主键
     * @return 结果
     */
    public int deleteTDayEquipmentAndFacilitieById(Long id);

    int cancel(TDayEquipmentAndFacilitie tDayEquipmentAndFacilitie);
}
