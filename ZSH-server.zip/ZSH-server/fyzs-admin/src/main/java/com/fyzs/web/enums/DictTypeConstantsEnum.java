package com.fyzs.web.enums;

public enum DictTypeConstantsEnum {
    DEVICE_TYPE(0, "device_type");

    private final Integer code;
    private final String name;

    DictTypeConstantsEnum(Integer code, String name) {
        this.code = code;
        this.name = name;
    }

    public Integer getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    /**
     * 根据类型code获取类型名称
     *
     * @param code 类型code
     * @return 类型名称
     */
    public static String getNameByCode(Integer code) {
        if (code == null) {
            return "";
        }
        for (DictTypeConstantsEnum type : DictTypeConstantsEnum.values()) {
            if (type.getCode().equals(code)) {
                return type.getName();
            }
        }
        return "";
    }
}
