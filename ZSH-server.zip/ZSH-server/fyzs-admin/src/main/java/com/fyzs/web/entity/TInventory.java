package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 商品批次库存对象 t_inventory
 *
 * @author ysh
 * @date 2025-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_inventory")
public class TInventory implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 仓库ID */
        @Schema(description = "仓库ID")
        @Excel(name = "仓库ID")
        private Long warehouseId;

        /** 对应的入库记录ID */
        @Schema(description = "对应的入库记录ID")
        @Excel(name = "对应的入库记录ID")
        private Long procurementWarehouseId;

        /** 供应商ID(可能有，也可能没有) */
        @Schema(description = "供应商ID(可能有，也可能没有)")
        @Excel(name = "供应商ID(可能有，也可能没有)")
        private Long supplerId;

        /** 验收ID */
        @Schema(description = "验收ID")
        private Long acceptanceId;

        /** 采购ID(验收入库必传) */
        @Schema(description = "采购ID(验收入库必传)")
        @Excel(name = "采购ID(验收入库必传)")
        private Long procurementId;

        /** 采购单号(验收入库必传) */
        @Schema(description = "采购单号(验收入库必传)")
        @Excel(name = "采购单号(验收入库必传)")
        private String procurementNum;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 批次 */
        @Schema(description = "批次")
        @Excel(name = "批次")
        private String batch;

        /** 生产日期(验收时必填) */
        @Schema(description = "生产日期(验收时必填)")
        @Excel(name = "生产日期(验收时必填)")
        private String productionDate;

        /** 保质期数量(验收时必填) */
        @Schema(description = "保质期数量(验收时必填)")
        @Excel(name = "保质期数量(验收时必填)")
        private Integer shelfLifeNumber;

        /** 保质期类型(0天，1月)，验收时必填 */
        @Schema(description = "保质期类型(0天，1月)，验收时必填")
        @Excel(name = "保质期类型(0天，1月)，验收时必填")
        private Integer shelfLifeType;

        /** 保质期到期日期(验收时计算) */
        @Schema(description = "保质期到期日期(验收时计算)")
        @Excel(name = "保质期到期日期(验收时计算)")
        private String endDate;

        /** 库存量 */
        @Schema(description = "库存量")
        @Excel(name = "库存量")
        private BigDecimal number;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
