package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraRegulationsImg;

/**
 * 违法违规识别图片固证文件存储信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraRegulationsImgService extends IService<TCameraRegulationsImg>
{
    /**
     * 查询违法违规识别图片固证文件存储信息
     * 
     * @param id 违法违规识别图片固证文件存储信息主键
     * @return 违法违规识别图片固证文件存储信息
     */
    public TCameraRegulationsImg selectTCameraRegulationsImgById(Long id);

    /**
     * 查询违法违规识别图片固证文件存储信息列表
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 违法违规识别图片固证文件存储信息集合
     */
    public List<TCameraRegulationsImg> selectTCameraRegulationsImgList(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 新增违法违规识别图片固证文件存储信息
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 结果
     */
    public int insertTCameraRegulationsImg(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 修改违法违规识别图片固证文件存储信息
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 结果
     */
    public int updateTCameraRegulationsImg(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 批量删除违法违规识别图片固证文件存储信息
     * 
     * @param ids 需要删除的违法违规识别图片固证文件存储信息主键集合
     * @return 结果
     */
    public int deleteTCameraRegulationsImgByIds(Long[] ids);

    /**
     * 删除违法违规识别图片固证文件存储信息信息
     * 
     * @param id 违法违规识别图片固证文件存储信息主键
     * @return 结果
     */
    public int deleteTCameraRegulationsImgById(Long id);
}
