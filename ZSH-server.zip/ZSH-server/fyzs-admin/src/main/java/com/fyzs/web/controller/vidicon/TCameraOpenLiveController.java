package com.fyzs.web.controller.vidicon;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraOpenLive;
import com.fyzs.web.service.ITCameraOpenLiveService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 明厨亮灶三方接入信息Controller
 * 
 * @author ysh
 * @date 2025-12-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/camera/open/live")
public class TCameraOpenLiveController extends BaseController
{

    private final ITCameraOpenLiveService tCameraOpenLiveService;

    /**
     * 查询明厨亮灶三方接入信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:live:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraOpenLive tCameraOpenLive)
    {
        startPage();
        List<TCameraOpenLive> list = tCameraOpenLiveService.selectTCameraOpenLiveList(tCameraOpenLive);
        return getDataTable(list);
    }

    /**
     * 导出明厨亮灶三方接入信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:live:export')")
    @Log(title = "明厨亮灶三方接入信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraOpenLive tCameraOpenLive)
    {
        List<TCameraOpenLive> list = tCameraOpenLiveService.selectTCameraOpenLiveList(tCameraOpenLive);
        ExcelUtil<TCameraOpenLive> util = new ExcelUtil<TCameraOpenLive>(TCameraOpenLive.class);
        util.exportExcel(response, list, "明厨亮灶三方接入信息数据");
    }

    /**
     * 获取明厨亮灶三方接入信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraOpenLiveService.selectTCameraOpenLiveById(id));
    }

    /**
     * 新增明厨亮灶三方接入信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:add')")
    @Log(title = "明厨亮灶三方接入信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraOpenLive tCameraOpenLive)
    {
        return toAjax(tCameraOpenLiveService.save(tCameraOpenLive));
    }

    /**
     * 修改明厨亮灶三方接入信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:edit')")
    @Log(title = "明厨亮灶三方接入信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraOpenLive tCameraOpenLive)
    {
        return toAjax(tCameraOpenLiveService.updateById(tCameraOpenLive));
    }

    /**
     * 删除明厨亮灶三方接入信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:remove')")
    @Log(title = "明厨亮灶三方接入信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraOpenLiveService.deleteTCameraOpenLiveByIds(ids));
    }
}
