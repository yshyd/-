package com.fyzs.web.entity.query;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TDeptCommodity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TDeptCommodityQuery extends TDeptCommodity {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;


    @Schema(description = "类别名称")
    private String categoryName;
    /**
     * 商品编码(添加时自动生成：SP+0000001的递增，开始)
     */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /**
     * 商品名称
     */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;

    /**
     * 商品类别id
     */
    @Schema(description = "商品类别id")
    @Excel(name = "商品类别id")
    private Long categoryId;

    /**
     * 品牌
     */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /**
     * 型号
     */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /**
     * 商品图片
     */
    @Schema(description = "商品图片")
    private String imgUrl;

    /**
     * 规格
     */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
