package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 库存操作记录对象 t_new_inventory_operation
 *
 * @author ysh
 * @date 2025-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_inventory_operation")
public class TNewInventoryOperation implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 批次库存ID */
        @Schema(description = "批次库存ID")
        @Excel(name = "批次库存ID")
        private Long inventoryId;

        /** 操作类型：0采购验收入库1初始入库2调拨入库3盘盈入库4退领入库5退货撤销入库6验收后立即出库7领用出库8调拨出库9盘亏出库10退货出库 */
        @Schema(description = "操作类型：0采购验收入库1初始入库2调拨入库3盘盈入库4退领入库5退货撤销入库6验收后立即出库7领用出库8调拨出库9盘亏出库10退货出库")
        @Excel(name = "操作类型：0采购验收入库1初始入库2调拨入库3盘盈入库4退领入库5退货撤销入库6验收后立即出库7领用出库8调拨出库9盘亏出库10退货出库")
        private Integer type;

        /** 数量 */
        @Schema(description = "数量")
        @Excel(name = "数量")
        private BigDecimal number;

        /** 操作详细说明 */
        @Schema(description = "操作详细说明")
        @Excel(name = "操作详细说明")
        private String remarks;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
