package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TMonitoringLinksConfig;
import lombok.Data;

@Data
public class ConfigWithNumDTO {
    private TMonitoringLinksConfig config;
    private Long cameraNum;
    private boolean isCommonConfig;
    private TMonitoringLinksConfigDTO originalDTO; // 原始DTO，用于获取区域和部门信息
    public  ConfigWithNumDTO(TMonitoringLinksConfig config, Long cameraNum, boolean isCommonConfig) {
        this.config = config;
        this.cameraNum = cameraNum;
        this.isCommonConfig = isCommonConfig;
    }
    public  ConfigWithNumDTO(TMonitoringLinksConfig config, Long cameraNum, boolean isCommonConfig, TMonitoringLinksConfigDTO originalDTO) {
        this.config = config;
        this.cameraNum = cameraNum;
        this.isCommonConfig = isCommonConfig;
        this.originalDTO = originalDTO;
    }


}
