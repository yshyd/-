package com.fyzs.web.entity.query;

import com.fyzs.web.entity.TWarehouse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TWarehouseQuery extends TWarehouse {

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
