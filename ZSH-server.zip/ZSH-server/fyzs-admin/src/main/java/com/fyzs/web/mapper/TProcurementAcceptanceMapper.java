package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TProcurementAcceptance;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 商品采购验收Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@org.apache.ibatis.annotations.Mapper
public interface TProcurementAcceptanceMapper  extends BaseMapper<TProcurementAcceptance>
{
    /**
     * 查询商品采购验收
     * 
     * @param id 商品采购验收主键
     * @return 商品采购验收
     */
    public TProcurementAcceptance selectTProcurementAcceptanceById(Long id);

    /**
     * 查询商品采购验收列表
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 商品采购验收集合
     */
    public List<TProcurementAcceptance> selectTProcurementAcceptanceList(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 新增商品采购验收
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int insertTProcurementAcceptance(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 修改商品采购验收
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int updateTProcurementAcceptance(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 删除商品采购验收
     * 
     * @param id 商品采购验收主键
     * @return 结果
     */
    public int deleteTProcurementAcceptanceById(Long id);

    /**
     * 批量删除商品采购验收
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTProcurementAcceptanceByIds(Long[] ids);

    /**
     * 查询指定日期前缀的最大验收单号
     */
    String selectMaxAcceptanceNoByDatePrefix(@Param("datePrefix") String datePrefix);
}
