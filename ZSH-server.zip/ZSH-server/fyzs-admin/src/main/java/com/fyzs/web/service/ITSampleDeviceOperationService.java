package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TSampleDeviceOperation;
import com.fyzs.web.entity.query.TSampleDeviceOperationQuery;

/**
 * 留样柜操作日志Service接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
public interface ITSampleDeviceOperationService extends IService<TSampleDeviceOperation>
{
    /**
     * 查询留样柜操作日志
     * 
     * @param id 留样柜操作日志主键
     * @return 留样柜操作日志
     */
    public TSampleDeviceOperationQuery selectTSampleDeviceOperationById(Long id);

    /**
     * 查询留样柜操作日志列表
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 留样柜操作日志集合
     */
    public List<TSampleDeviceOperationQuery> selectTSampleDeviceOperationList(TSampleDeviceOperationQuery tSampleDeviceOperation);

    /**
     * 新增留样柜操作日志
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 结果
     */
    public int insertTSampleDeviceOperation(TSampleDeviceOperation tSampleDeviceOperation);

    /**
     * 修改留样柜操作日志
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 结果
     */
    public int updateTSampleDeviceOperation(TSampleDeviceOperation tSampleDeviceOperation);

    /**
     * 批量删除留样柜操作日志
     * 
     * @param ids 需要删除的留样柜操作日志主键集合
     * @return 结果
     */
    public int deleteTSampleDeviceOperationByIds(Long[] ids);

    /**
     * 删除留样柜操作日志信息
     * 
     * @param id 留样柜操作日志主键
     * @return 结果
     */
    public int deleteTSampleDeviceOperationById(Long id);
}
