package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraLive;

/**
 * 可视化视频监控实时调用信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraLiveService extends IService<TCameraLive>
{
    /**
     * 查询可视化视频监控实时调用信息
     * 
     * @param id 可视化视频监控实时调用信息主键
     * @return 可视化视频监控实时调用信息
     */
    public TCameraLive selectTCameraLiveById(Long id);

    /**
     * 查询可视化视频监控实时调用信息列表
     * 
     * @param tCameraLive 可视化视频监控实时调用信息
     * @return 可视化视频监控实时调用信息集合
     */
    public List<TCameraLive> selectTCameraLiveList(TCameraLive tCameraLive);

    /**
     * 新增可视化视频监控实时调用信息
     * 
     * @param tCameraLive 可视化视频监控实时调用信息
     * @return 结果
     */
    public int insertTCameraLive(TCameraLive tCameraLive);

    /**
     * 修改可视化视频监控实时调用信息
     * 
     * @param tCameraLive 可视化视频监控实时调用信息
     * @return 结果
     */
    public int updateTCameraLive(TCameraLive tCameraLive);

    /**
     * 批量删除可视化视频监控实时调用信息
     * 
     * @param ids 需要删除的可视化视频监控实时调用信息主键集合
     * @return 结果
     */
    public int deleteTCameraLiveByIds(Long[] ids);

    /**
     * 删除可视化视频监控实时调用信息信息
     * 
     * @param id 可视化视频监控实时调用信息主键
     * @return 结果
     */
    public int deleteTCameraLiveById(Long id);
}
