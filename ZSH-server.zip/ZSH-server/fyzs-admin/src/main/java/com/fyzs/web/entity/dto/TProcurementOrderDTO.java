package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TProcurementOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TProcurementOrderDTO extends TProcurementOrder {

    @Schema(description = "商品列表")
    @NotNull(message = "商品列表不能为空")
    private List<TProcurementOrderItemDTO> detailList;
}
