package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TWeekSupplierRisk;
import com.fyzs.web.entity.query.TWeekSupplierRiskQuery;

/**
 * 学校食堂周排查-供应商风险排查Service接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
public interface ITWeekSupplierRiskService extends IService<TWeekSupplierRisk>
{
    /**
     * 查询学校食堂周排查-供应商风险排查
     * 
     * @param id 学校食堂周排查-供应商风险排查主键
     * @return 学校食堂周排查-供应商风险排查
     */
    public TWeekSupplierRiskQuery selectTWeekSupplierRiskById(Long id);

    /**
     * 查询学校食堂周排查-供应商风险排查列表
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 学校食堂周排查-供应商风险排查集合
     */
    public List<TWeekSupplierRiskQuery> selectTWeekSupplierRiskList(TWeekSupplierRiskQuery tWeekSupplierRisk);

    /**
     * 新增学校食堂周排查-供应商风险排查
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 结果
     */
    public int insertTWeekSupplierRisk(TWeekSupplierRisk tWeekSupplierRisk);

    /**
     * 修改学校食堂周排查-供应商风险排查
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 结果
     */
    public int updateTWeekSupplierRisk(TWeekSupplierRisk tWeekSupplierRisk);

    /**
     * 批量删除学校食堂周排查-供应商风险排查
     * 
     * @param ids 需要删除的学校食堂周排查-供应商风险排查主键集合
     * @return 结果
     */
    public int deleteTWeekSupplierRiskByIds(Long[] ids);

    /**
     * 删除学校食堂周排查-供应商风险排查信息
     * 
     * @param id 学校食堂周排查-供应商风险排查主键
     * @return 结果
     */
    public int deleteTWeekSupplierRiskById(Long id);

    int cancel(TWeekSupplierRisk tWeekSupplierRisk);
}
