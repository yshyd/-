package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.web.entity.TAnnouncement;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TAnnouncementQuery extends TAnnouncement {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "列表")
    private List<Long> deptIds;

    @Schema(description = "公告 ID 列表")
    private List<Long> ids;

    @Schema(description = "是否有权限 0 有 1 否")
    private Integer isAuth;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;


}
