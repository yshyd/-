package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayEquipmentAndFacilitie;
import com.fyzs.web.entity.query.TDayEquipmentAndFacilitieQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常巡检-设备设施巡检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@Mapper
public interface TDayEquipmentAndFacilitieMapper  extends BaseMapper<TDayEquipmentAndFacilitie>
{
    /**
     * 查询学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param id 学校食堂日管控-日常巡检-设备设施巡检主键
     * @return 学校食堂日管控-日常巡检-设备设施巡检
     */
    public TDayEquipmentAndFacilitieQuery selectTDayEquipmentAndFacilitieById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-设备设施巡检列表
     *
     * @return 学校食堂日管控-日常巡检-设备设施巡检集合
     */
    public List<TDayEquipmentAndFacilitieQuery> selectTDayEquipmentAndFacilitieList(TDayEquipmentAndFacilitieQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param tDayEquipmentAndFacilitie 学校食堂日管控-日常巡检-设备设施巡检
     * @return 结果
     */
    public int insertTDayEquipmentAndFacilitie(TDayEquipmentAndFacilitie tDayEquipmentAndFacilitie);

    /**
     * 修改学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param tDayEquipmentAndFacilitie 学校食堂日管控-日常巡检-设备设施巡检
     * @return 结果
     */
    public int updateTDayEquipmentAndFacilitie(TDayEquipmentAndFacilitie tDayEquipmentAndFacilitie);

    /**
     * 删除学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param id 学校食堂日管控-日常巡检-设备设施巡检主键
     * @return 结果
     */
    public int deleteTDayEquipmentAndFacilitieById(Long id);

    /**
     * 批量删除学校食堂日管控-日常巡检-设备设施巡检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayEquipmentAndFacilitieByIds(Long[] ids);

    int countValidInspections(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    int countNormalInspections(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    int countAbnormalInspections(@Param("startDate") Date startDate,
                                 @Param("endDate") Date endDate,
                                 @Param("deptIds") List<Long> deptIds);
}
