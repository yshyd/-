package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCanteenPractitioners;
import com.fyzs.web.entity.query.TCanteenPractitionersQuery;

/**
 * 食堂人员基础信息Service接口
 * 
 * @author ysh
 * @date 2025-10-26
 */
public interface ITCanteenPractitionersService extends IService<TCanteenPractitioners>
{
    /**
     * 查询食堂人员基础信息
     * 
     * @param id 食堂人员基础信息主键
     * @return 食堂人员基础信息
     */
    public TCanteenPractitioners selectTCanteenPractitionersById(Long id);

    /**
     * 查询食堂人员基础信息列表
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 食堂人员基础信息集合
     */
    public List<TCanteenPractitionersQuery> selectTCanteenPractitionersList(TCanteenPractitionersQuery tCanteenPractitioners);

    /**
     * 新增食堂人员基础信息
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 结果
     */
    public int insertTCanteenPractitioners(TCanteenPractitioners tCanteenPractitioners);

    /**
     * 修改食堂人员基础信息
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 结果
     */
    public int updateTCanteenPractitioners(TCanteenPractitioners tCanteenPractitioners);

    /**
     * 批量删除食堂人员基础信息
     * 
     * @param ids 需要删除的食堂人员基础信息主键集合
     * @return 结果
     */
    public int deleteTCanteenPractitionersByIds(Long[] ids);

    /**
     * 删除食堂人员基础信息信息
     * 
     * @param id 食堂人员基础信息主键
     * @return 结果
     */
    public int deleteTCanteenPractitionersById(Long id);
}
