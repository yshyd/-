package com.fyzs.web.service;

import com.fyzs.web.entity.query.TBusinessQuery;
import com.fyzs.web.entity.vo.TBusinessVO;

import java.util.List;

public interface ITBusinessService {
    List<TBusinessQuery> selectBusinessList(TBusinessQuery businessQuery);

    List<TBusinessVO> selectBusinessDetailList(TBusinessQuery businessQuery);
}
