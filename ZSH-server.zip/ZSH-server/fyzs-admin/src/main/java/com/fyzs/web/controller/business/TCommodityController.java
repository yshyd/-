package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TCommodityQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCommodity;
import com.fyzs.web.service.ITCommodityService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 系统标准商品库Controller
 * 
 * @author ysh
 * @date 2025-10-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/commodity")
public class TCommodityController extends BaseController
{

    private final ITCommodityService tCommodityService;

    /**
     * 查询系统标准商品库列表
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCommodityQuery tCommodity)
    {
        startPage();
        List<TCommodityQuery> list = tCommodityService.selectTCommodityList(tCommodity);
        return getDataTable(list);
    }

    /**
     * 导出系统标准商品库列表
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:export')")
    @Log(title = "系统标准商品库", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCommodityQuery tCommodity)
    {
        List<TCommodityQuery> list = tCommodityService.selectTCommodityList(tCommodity);
        ExcelUtil<TCommodityQuery> util = new ExcelUtil<TCommodityQuery>(TCommodityQuery.class);
        util.exportExcel(response, list, "系统标准商品库数据");
    }

    /**
     * 获取系统标准商品库详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCommodityService.selectTCommodityById(id));
    }

    /**
     * 新增系统标准商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:add')")
    @Log(title = "系统标准商品库", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCommodity tCommodity)
    {
        String commodityCode = tCommodityService.generateCommodityCode();
        tCommodity.setCommodityCode(commodityCode);
        tCommodity.setDelFlag(0);
        return toAjax(tCommodityService.save(tCommodity));
    }

    /**
     * 修改系统标准商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:edit')")
    @Log(title = "系统标准商品库", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCommodity tCommodity)
    {
        return toAjax(tCommodityService.updateById(tCommodity));
    }

    /**
     * 删除系统标准商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:remove')")
    @Log(title = "系统标准商品库", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCommodityService.deleteTCommodityByIds(ids));
    }
}
