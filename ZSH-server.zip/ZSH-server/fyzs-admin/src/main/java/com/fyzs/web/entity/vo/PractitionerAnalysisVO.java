package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class PractitionerAnalysisVO {

    // 性别分布
    @Schema(description = "性别分布")
    private GenderDistribution genderDistribution;

    //人员分布
    @Schema(description = "人员分布")
    private List<PositionDistribution> positionDistributions;

    // 健康证状态
    @Schema(description = "健康证状态")
    private HealthCertificateStatus healthCertificateStatus;

    // 年龄分布
    @Schema(description = "年龄分布")
    private AgeDistribution ageDistribution;

    // 学历分布
    @Schema(description = "学历分布")
    private EducationDistribution educationDistribution;

    // 工龄分布
    @Schema(description = "工龄分布")
    private WorkExperienceDistribution workExperienceDistribution;
}
