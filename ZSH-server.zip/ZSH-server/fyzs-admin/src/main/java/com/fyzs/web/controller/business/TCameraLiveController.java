package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraLive;
import com.fyzs.web.service.ITCameraLiveService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 可视化视频监控实时调用信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/live")
public class TCameraLiveController extends BaseController
{

    private final ITCameraLiveService tCameraLiveService;

    /**
     * 查询可视化视频监控实时调用信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:live:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraLive tCameraLive)
    {
        startPage();
        List<TCameraLive> list = tCameraLiveService.selectTCameraLiveList(tCameraLive);
        return getDataTable(list);
    }

    /**
     * 导出可视化视频监控实时调用信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:live:export')")
    @Log(title = "可视化视频监控实时调用信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraLive tCameraLive)
    {
        List<TCameraLive> list = tCameraLiveService.selectTCameraLiveList(tCameraLive);
        ExcelUtil<TCameraLive> util = new ExcelUtil<TCameraLive>(TCameraLive.class);
        util.exportExcel(response, list, "可视化视频监控实时调用信息数据");
    }

    /**
     * 获取可视化视频监控实时调用信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraLiveService.selectTCameraLiveById(id));
    }

    /**
     * 新增可视化视频监控实时调用信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:add')")
    @Log(title = "可视化视频监控实时调用信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraLive tCameraLive)
    {
        return toAjax(tCameraLiveService.save(tCameraLive));
    }

    /**
     * 修改可视化视频监控实时调用信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:edit')")
    @Log(title = "可视化视频监控实时调用信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraLive tCameraLive)
    {
        return toAjax(tCameraLiveService.updateById(tCameraLive));
    }

    /**
     * 删除可视化视频监控实时调用信息
     */
    //@PreAuthorize("@ss.hasPermi('web:live:remove')")
    @Log(title = "可视化视频监控实时调用信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraLiveService.deleteTCameraLiveByIds(ids));
    }
}
