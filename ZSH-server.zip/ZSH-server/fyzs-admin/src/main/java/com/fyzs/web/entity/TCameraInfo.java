package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 设备管理-摄像头管理对象 t_camera_info
 *
 * @author ysh
 * @date 2025-12-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_info")
public class TCameraInfo implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 点位名称 */
        @Schema(description = "点位名称")
        @Excel(name = "点位名称")
        private String name;

        /** 设备序列号(NVR或者摄像头)，平台自建时必填 */
        @Schema(description = "设备序列号(NVR或者摄像头)，平台自建时必填")
        @Excel(name = "设备序列号(NVR或者摄像头)，平台自建时必填")
        private String serialNumber;

        /** 通道号，平台自建时必填 */
        @Schema(description = "通道号，平台自建时必填")
        @Excel(name = "通道号，平台自建时必填")
        private Long channelNumber;

        /** 排序 */
        @Schema(description = "排序")
        @Excel(name = "排序")
        private Long sort;

        /** 类型：0平台自建1三方接入 */
        @Schema(description = "类型：0平台自建1三方接入")
        @Excel(name = "类型：0平台自建1三方接入")
        private Integer type;

        /** 授权码：三方接入时必填 */
        @Schema(description = "授权码：三方接入时必填")
        @Excel(name = "授权码：三方接入时必填")
        private String authCode;

        /** ezopen格式的直播主码流地址(PC高清播放) */
        @Schema(description = "ezopen格式的直播主码流地址(PC高清播放)")
        @Excel(name = "ezopen格式的直播主码流地址(PC高清播放)")
        private String ezopenUrlLive;

        /** ezopen格式的直播子码流地址(PC多窗口播放) */
        @Schema(description = "ezopen格式的直播子码流地址(PC多窗口播放)")
        @Excel(name = "ezopen格式的直播子码流地址(PC多窗口播放)")
        private String ezopenUrlLiveItem;

        /** ezopen格式的回放地址(PC回放) */
        @Schema(description = "ezopen格式的回放地址(PC回放)")
        @Excel(name = "ezopen格式的回放地址(PC回放)")
        private String ezopenUrlRec;

        /** rtmp格式的直播主码流地址(小程序) */
        @Schema(description = "rtmp格式的直播主码流地址(小程序)")
        @Excel(name = "rtmp格式的直播主码流地址(小程序)")
        private String rtmpUrlLive;

        /** rtmp格式的直播子码流地址(小程序) */
        @Schema(description = "rtmp格式的直播子码流地址(小程序)")
        @Excel(name = "rtmp格式的直播子码流地址(小程序)")
        private String rtmpUrlLiveItem;

        /** hls格式的直播主码流地址(上层接口对接) */
        @Schema(description = "hls格式的直播主码流地址(上层接口对接)")
        @Excel(name = "hls格式的直播主码流地址(上层接口对接)")
        private String hlsUrlLive;

        /** hls格式的直播子码流地址(上层接口对接) */
        @Schema(description = "hls格式的直播子码流地址(上层接口对接)")
        @Excel(name = "hls格式的直播子码流地址(上层接口对接)")
        private String hlsUrlLiveItem;

        /** 状态：0使用1禁用 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "状态：0使用1禁用")
        private Integer delFlag;

        /** 创建人ID */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID")
        @Excel(name = "创建人ID")
        private Long createUser;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
