package com.fyzs.web.controller.aibox;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TSnapshotQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TSnapshot;
import com.fyzs.web.service.ITSnapshotService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * AI盒子违规抓拍Controller
 * 
 * @author ysh
 * @date 2026-01-05
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/snapshot")
public class TSnapshotController extends BaseController
{

    private final ITSnapshotService tSnapshotService;

    /**
     * 查询AI盒子违规抓拍列表
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:list')")
    @GetMapping("/list")
    public TableDataInfo list(TSnapshotQuery tSnapshot)
    {
        startPage();
        List<TSnapshotQuery> list = tSnapshotService.selectTSnapshotList(tSnapshot);
        return getDataTable(list);
    }

    /**
     * 导出AI盒子违规抓拍列表
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:export')")
    @Log(title = "AI盒子违规抓拍", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TSnapshotQuery tSnapshot)
    {
        List<TSnapshotQuery> list = tSnapshotService.selectTSnapshotList(tSnapshot);
        ExcelUtil<TSnapshotQuery> util = new ExcelUtil<TSnapshotQuery>(TSnapshotQuery.class);
        util.exportExcel(response, list, "AI盒子违规抓拍数据");
    }

    /**
     * 获取AI盒子违规抓拍详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tSnapshotService.selectTSnapshotById(id));
    }

    /**
     * 新增AI盒子违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:add')")
    @Log(title = "AI盒子违规抓拍", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TSnapshot tSnapshot)
    {
        return toAjax(tSnapshotService.save(tSnapshot));
    }

    /**
     * 修改AI盒子违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:edit')")
    @Log(title = "AI盒子违规抓拍", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TSnapshot tSnapshot)
    {
        return toAjax(tSnapshotService.updateById(tSnapshot));
    }

    /**
     * 删除AI盒子违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:snapshot:remove')")
    @Log(title = "AI盒子违规抓拍", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tSnapshotService.deleteTSnapshotByIds(ids));
    }
}
