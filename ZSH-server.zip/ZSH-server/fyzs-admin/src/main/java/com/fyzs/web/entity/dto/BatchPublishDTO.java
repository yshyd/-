package com.fyzs.web.entity.dto;

import lombok.Data;

@Data
public class BatchPublishDTO {
    private Long[] ids;
    private String delFlag;
}
