package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 商品采购对象 t_new_procurement
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_procurement")
public class TNewProcurement implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")

        private Long deptId;

        /** 采购订单号(格式：CGD202510280001依次递增) */
        @Schema(description = "采购订单号(格式：CGD202510280001依次递增)")
        @Excel(name = "采购订单号(格式：CGD202510280001依次递增)")
        private String procurementNum;

        /** 供应商id */
        @Schema(description = "供应商id")
        @Excel(name = "供应商id")
        private Long supplerId;

        /** 商品id */
        @Schema(description = "商品id")
        @Excel(name = "商品id")
        private Long commodityId;

        /** 采购量 */
        @Schema(description = "采购量")
        @Excel(name = "采购量")
        private BigDecimal number;

        /** 结算状态：-1作废、0待验收、 1已验收、2已入库待结算、3已结算 */
        @Schema(description = "结算状态：-1作废、0待验收、 1已验收、2已入库待结算、3已结算 ")
        @Excel(name = "结算状态：-1作废、0待验收、 1已验收、2已入库待结算、3已结算 ")
        private Integer status;

        /** 到货日期 */
        @Schema(description = "到货日期")
        @Excel(name = "到货日期")
        private String date;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
