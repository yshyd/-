package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCameraRec;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 可视化视频监控回放信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TCameraRecMapper  extends BaseMapper<TCameraRec>
{
    /**
     * 查询可视化视频监控回放信息
     * 
     * @param id 可视化视频监控回放信息主键
     * @return 可视化视频监控回放信息
     */
    public TCameraRec selectTCameraRecById(Long id);

    /**
     * 查询可视化视频监控回放信息列表
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 可视化视频监控回放信息集合
     */
    public List<TCameraRec> selectTCameraRecList(TCameraRec tCameraRec);

    /**
     * 新增可视化视频监控回放信息
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 结果
     */
    public int insertTCameraRec(TCameraRec tCameraRec);

    /**
     * 修改可视化视频监控回放信息
     * 
     * @param tCameraRec 可视化视频监控回放信息
     * @return 结果
     */
    public int updateTCameraRec(TCameraRec tCameraRec);
    public int updateTCameraRecByCameraId(TCameraRec tCameraRec);

    /**
     * 删除可视化视频监控回放信息
     * 
     * @param id 可视化视频监控回放信息主键
     * @return 结果
     */
    public int deleteTCameraRecById(Long id);

    /**
     * 批量删除可视化视频监控回放信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraRecByIds(Long[] ids);
    public int deleteTCameraRecBy(Long[] ids);
}
