package com.fyzs.web.entity.query;


import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TCanteenPractitioners;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * 食堂人员基础信息对象 t_canteen_practitioners
 *
 * @author ysh
 * @date 2025-10-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class TCanteenPractitionersQuery extends TCanteenPractitioners {

    private List<Long> deptIds;       // 选中的组织ID列表


    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    private int offset;
    private int limit;
}
