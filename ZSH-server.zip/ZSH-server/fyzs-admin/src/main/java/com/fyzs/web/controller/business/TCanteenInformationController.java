package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TCanteenInformationQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCanteenInformation;
import com.fyzs.web.service.ITCanteenInformationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食堂信息档案Controller
 * 
 * @author ysh
 * @date 2025-12-08
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/canteen/information")
public class TCanteenInformationController extends BaseController
{

    private final ITCanteenInformationService tCanteenInformationService;

    /**
     * 查询食堂信息档案列表
     */
    //@PreAuthorize("@ss.hasPermi('web:information:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCanteenInformationQuery tCanteenInformation)
    {
        startPage();
        List<TCanteenInformationQuery> list = tCanteenInformationService.selectTCanteenInformationList(tCanteenInformation);
        return getDataTable(list);
    }

    /**
     * 导出食堂信息档案列表
     */
    //@PreAuthorize("@ss.hasPermi('web:information:export')")
    @Log(title = "食堂信息档案", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCanteenInformationQuery tCanteenInformation)
    {
        List<TCanteenInformationQuery> list = tCanteenInformationService.selectTCanteenInformationList(tCanteenInformation);
        ExcelUtil<TCanteenInformationQuery> util = new ExcelUtil<TCanteenInformationQuery>(TCanteenInformationQuery.class);
        util.exportExcel(response, list, "食堂信息档案数据");
    }

    /**
     * 获取食堂信息档案详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:information:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {


        return success(tCanteenInformationService.selectTCanteenInformationById(id));
    }

    /**
     * 新增食堂信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:add')")
    @Log(title = "食堂信息档案", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCanteenInformation tCanteenInformation)
    {
        TCanteenInformation one = tCanteenInformationService.getOne(new LambdaQueryWrapper<>(TCanteenInformation.class)
                .eq(TCanteenInformation::getDeptId, tCanteenInformation.getDeptId())
                .eq(TCanteenInformation::getAreaId, tCanteenInformation.getAreaId())
        );
        tCanteenInformation.setDelFlag(0);
        if (!ObjectUtils.isEmpty( one)){
            tCanteenInformation.setId(one.getId());
            return toAjax(tCanteenInformationService.updateById(tCanteenInformation));
        }

        return toAjax(tCanteenInformationService.save(tCanteenInformation));
    }

    /**
     * 修改食堂信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:edit')")
    @Log(title = "食堂信息档案", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCanteenInformation tCanteenInformation)
    {
        return toAjax(tCanteenInformationService.updateById(tCanteenInformation));
    }

    /**
     * 删除食堂信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:remove')")
    @Log(title = "食堂信息档案", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCanteenInformationService.deleteTCanteenInformationByIds(ids));
    }
}
