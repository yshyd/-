package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.BatchPublishDTO;
import com.fyzs.web.entity.query.TCommodityPriceQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCommodityPrice;
import com.fyzs.web.service.ITCommodityPriceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 价格管理Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/commodity/price")
public class TCommodityPriceController extends BaseController
{

    private final ITCommodityPriceService tCommodityPriceService;

    /**
     * 查询价格管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:price:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCommodityPriceQuery tCommodityPrice)
    {
        startPage();
        List<TCommodityPriceQuery> list = tCommodityPriceService.selectTCommodityPriceList(tCommodityPrice);
        return getDataTable(list);
    }

    /**
     * 导出价格管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:price:export')")
    @Log(title = "价格管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCommodityPriceQuery tCommodityPrice)
    {
        List<TCommodityPriceQuery> list = tCommodityPriceService.selectTCommodityPriceList(tCommodityPrice);
        ExcelUtil<TCommodityPriceQuery> util = new ExcelUtil<TCommodityPriceQuery>(TCommodityPriceQuery.class);
        util.exportExcel(response, list, "价格管理数据");
    }

    /**
     * 获取价格管理详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:price:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCommodityPriceService.selectTCommodityPriceById(id));
    }

    /**
     * 新增价格管理
     */
    //@PreAuthorize("@ss.hasPermi('web:price:add')")
    @Log(title = "价格管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCommodityPrice tCommodityPrice)
    {
        return toAjax(tCommodityPriceService.insertTCommodityPrice(tCommodityPrice));
    }


    /**
     * 批量发布
     */
    @Log(title = "价格管理", businessType = BusinessType.UPDATE)
    @PostMapping("/batchPublish")
    public AjaxResult batchPublish(@RequestBody BatchPublishDTO batchPublishDTO) {
        return toAjax(tCommodityPriceService.batchPublish(batchPublishDTO.getIds(), batchPublishDTO.getDelFlag()));
    }

    /**
     * 修改价格管理
     */
    //@PreAuthorize("@ss.hasPermi('web:price:edit')")
    @Log(title = "价格管理", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCommodityPrice tCommodityPrice)
    {
        return toAjax(tCommodityPriceService.updateById(tCommodityPrice));
    }

    /**
     * 删除价格管理
     */
    //@PreAuthorize("@ss.hasPermi('web:price:remove')")
    @Log(title = "价格管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCommodityPriceService.deleteTCommodityPriceByIds(ids));
    }
}
