package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayPlaceCheck;
import com.fyzs.web.entity.query.TDayPlaceCheckQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常巡检-场所环境卫生巡检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@org.apache.ibatis.annotations.Mapper
public interface TDayPlaceCheckMapper  extends BaseMapper<TDayPlaceCheck>
{
    /**
     * 查询学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param id 学校食堂日管控-日常巡检-场所环境卫生巡检主键
     * @return 学校食堂日管控-日常巡检-场所环境卫生巡检
     */
    public TDayPlaceCheckQuery selectTDayPlaceCheckById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-场所环境卫生巡检列表
     * 

     * @return 学校食堂日管控-日常巡检-场所环境卫生巡检集合
     */
    public List<TDayPlaceCheckQuery> selectTDayPlaceCheckList(TDayPlaceCheckQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param tDayPlaceCheck 学校食堂日管控-日常巡检-场所环境卫生巡检
     * @return 结果
     */
    public int insertTDayPlaceCheck(TDayPlaceCheck tDayPlaceCheck);

    /**
     * 修改学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param tDayPlaceCheck 学校食堂日管控-日常巡检-场所环境卫生巡检
     * @return 结果
     */
    public int updateTDayPlaceCheck(TDayPlaceCheck tDayPlaceCheck);

    /**
     * 删除学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param id 学校食堂日管控-日常巡检-场所环境卫生巡检主键
     * @return 结果
     */
    public int deleteTDayPlaceCheckById(Long id);

    /**
     * 批量删除学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayPlaceCheckByIds(Long[] ids);

    int countValidInspections(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    int countNormalInspections(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    int countAbnormalInspections(@Param("startDate") Date startDate,
                                 @Param("endDate") Date endDate,
                                 @Param("deptIds") List<Long> deptIds);
}
