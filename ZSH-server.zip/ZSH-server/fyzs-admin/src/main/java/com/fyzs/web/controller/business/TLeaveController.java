package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TLeaveQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TLeave;
import com.fyzs.web.service.ITLeaveService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食堂人员请假信息管理Controller
 * 
 * @author ysh
 * @date 2025-10-26
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/leave")
public class TLeaveController extends BaseController
{

    private final ITLeaveService tLeaveService;

    /**
     * 查询食堂人员请假信息管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:list')")
    @GetMapping("/list")
    public TableDataInfo list(TLeaveQuery tLeave)
    {
        startPage();
        List<TLeaveQuery> list = tLeaveService.selectTLeaveList(tLeave);
        return getDataTable(list);
    }

    /**
     * 导出食堂人员请假信息管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:export')")
    @Log(title = "食堂人员请假信息管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TLeaveQuery tLeave)
    {
        List<TLeaveQuery> list = tLeaveService.selectTLeaveList(tLeave);
        ExcelUtil<TLeaveQuery> util = new ExcelUtil<TLeaveQuery>(TLeaveQuery.class);
        util.exportExcel(response, list, "食堂人员请假信息管理数据");
    }

    /**
     * 获取食堂人员请假信息管理详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tLeaveService.selectTLeaveById(id));
    }

    /**
     * 新增食堂人员请假信息管理
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:add')")
    @Log(title = "食堂人员请假信息管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TLeave tLeave)
    {

        long count = tLeaveService.count(new LambdaQueryWrapper<TLeave>()
                .eq(TLeave::getDeptId, tLeave.getDeptId())
                .eq(TLeave::getPersonId, tLeave.getPersonId())
                .le(TLeave::getStartDate, tLeave.getEndDate())
                .ge(TLeave::getEndDate, tLeave.getStartDate()));

        if (count > 0) {
            return AjaxResult.error("该人员在指定日期范围内已有请假记录，请勿重复添加");
        }
        tLeave.setDelFlag("0");
        return toAjax(tLeaveService.save(tLeave));
    }

    /**
     * 修改食堂人员请假信息管理
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:edit')")
    @Log(title = "食堂人员请假信息管理", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TLeave tLeave)
    {
        return toAjax(tLeaveService.updateById(tLeave));
    }

    /**
     * 删除食堂人员请假信息管理
     */
    //@PreAuthorize("@ss.hasPermi('web:leave:remove')")
    @Log(title = "食堂人员请假信息管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tLeaveService.deleteTLeaveByIds(ids));
    }
}
