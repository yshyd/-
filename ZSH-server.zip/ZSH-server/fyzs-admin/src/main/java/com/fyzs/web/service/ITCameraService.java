package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.core.domain.entity.vo.AreaDeptTreeVO;
import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.entity.TCamera;
import com.fyzs.web.entity.dto.CustomCameraDTO;
import com.fyzs.web.entity.dto.TCameraDTO;
import com.fyzs.web.entity.query.TCameraQuery;

/**
 * 可视化视频监控设备基本信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraService extends IService<TCamera>
{
    /**
     * 查询可视化视频监控设备基本信息
     * 
     * @param id 可视化视频监控设备基本信息主键
     * @return 可视化视频监控设备基本信息
     */
    public TCamera selectTCameraById(Long id);

    /**
     * 查询可视化视频监控设备基本信息列表
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 可视化视频监控设备基本信息集合
     */
    public List<TCamera> selectTCameraList(TCamera tCamera);

    /**
     * 新增可视化视频监控设备基本信息
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 结果
     */
    public int insertTCamera(CustomCameraDTO tCamera);

    /**
     * 修改可视化视频监控设备基本信息
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 结果
     */
    public int updateTCamera(TCamera tCamera);

    /**
     * 批量删除可视化视频监控设备基本信息
     * 
     * @param ids 需要删除的可视化视频监控设备基本信息主键集合
     * @return 结果
     */
    public int deleteTCameraByIds(Long[] ids);

    /**
     * 删除可视化视频监控设备基本信息信息
     * 
     * @param id 可视化视频监控设备基本信息主键
     * @return 结果
     */
    public int deleteTCameraById(Long id);

    int addCamera(TCameraDTO dto);

    TCameraQuery getRelationInfo(Long id);

    int updateCamera(CustomCameraDTO tCamera);

    List<TCameraQuery> relevanceList(TCameraQuery tCamera);

    List<AreaDeptTreeVO> areaDataTree(SysAreaDTO sysArea);
}
