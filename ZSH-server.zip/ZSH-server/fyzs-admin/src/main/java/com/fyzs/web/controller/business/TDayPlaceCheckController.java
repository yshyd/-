package com.fyzs.web.controller.business;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TDayPlaceCheckQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayPlaceCheck;
import com.fyzs.web.service.ITDayPlaceCheckService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常巡检-场所环境卫生巡检Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/place/check")
public class TDayPlaceCheckController extends BaseController
{

    private final ITDayPlaceCheckService tDayPlaceCheckService;

    private final ITAlarmService alarmService;


    /**
     * 查询学校食堂日管控-日常巡检-场所环境卫生巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayPlaceCheckQuery query)
    {
        startPage();
        List<TDayPlaceCheckQuery> list = tDayPlaceCheckService.selectTDayPlaceCheckList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常巡检-场所环境卫生巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:export')")
    @Log(title = "学校食堂日管控-日常巡检-场所环境卫生巡检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayPlaceCheckQuery query)
    {
        List<TDayPlaceCheckQuery> list = tDayPlaceCheckService.selectTDayPlaceCheckList(query);
        ExcelUtil<TDayPlaceCheckQuery> util = new ExcelUtil<TDayPlaceCheckQuery>(TDayPlaceCheckQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常巡检-场所环境卫生巡检数据");
    }

    /**
     * 获取学校食堂日管控-日常巡检-场所环境卫生巡检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:check:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDayPlaceCheckService.selectTDayPlaceCheckById(id));
    }

    /**
     * 新增学校食堂日管控-日常巡检-场所环境卫生巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:add')")
    @Log(title = "学校食堂日管控-日常巡检-场所环境卫生巡检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayPlaceCheck tDayPlaceCheck)
    {
        return toAjax(tDayPlaceCheckService.insertTDayPlaceCheck(tDayPlaceCheck));
    }

    /**
     * 修改学校食堂日管控-日常巡检-场所环境卫生巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:edit')")
    @Log(title = "学校食堂日管控-日常巡检-场所环境卫生巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayPlaceCheck tDayPlaceCheck)
    {
        return toAjax(tDayPlaceCheckService.updateTDayPlaceCheck(tDayPlaceCheck));
    }

    /**
     * 启用/作废(id,delFlag)
     */
    //@PreAuthorize("@ss.hasPermi('web:check:edit')")
    @Log(title = "学校食堂日管控-日常巡检-场所环境卫生巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayPlaceCheck tDayPlaceCheck)
    {

        return toAjax(tDayPlaceCheckService.cancel(tDayPlaceCheck));
    }

    /**
     * 删除学校食堂日管控-日常巡检-场所环境卫生巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:remove')")
    @Log(title = "学校食堂日管控-日常巡检-场所环境卫生巡检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDayPlaceCheckService.deleteTDayPlaceCheckByIds(ids));
    }
}
