package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TSchoolInformation;
import com.fyzs.web.entity.query.TSchoolInformationQuery;

/**
 * 学校信息档案Service接口
 * 
 * @author ysh
 * @date 2025-12-08
 */
public interface ITSchoolInformationService extends IService<TSchoolInformation>
{
    /**
     * 查询学校信息档案
     * 
     * @param id 学校信息档案主键
     * @return 学校信息档案
     */
    public TSchoolInformationQuery selectTSchoolInformationById(Long id);

    /**
     * 查询学校信息档案列表
     * 
     * @param tSchoolInformation 学校信息档案
     * @return 学校信息档案集合
     */
    public List<TSchoolInformationQuery> selectTSchoolInformationList(TSchoolInformationQuery tSchoolInformation);

    /**
     * 新增学校信息档案
     * 
     * @param tSchoolInformation 学校信息档案
     * @return 结果
     */
    public int insertTSchoolInformation(TSchoolInformation tSchoolInformation);

    /**
     * 修改学校信息档案
     * 
     * @param tSchoolInformation 学校信息档案
     * @return 结果
     */
    public int updateTSchoolInformation(TSchoolInformation tSchoolInformation);

    /**
     * 批量删除学校信息档案
     * 
     * @param ids 需要删除的学校信息档案主键集合
     * @return 结果
     */
    public int deleteTSchoolInformationByIds(Long[] ids);

    /**
     * 删除学校信息档案信息
     * 
     * @param id 学校信息档案主键
     * @return 结果
     */
    public int deleteTSchoolInformationById(Long id);
}
