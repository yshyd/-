package com.fyzs.web.entity.vo;

import lombok.Data;

import java.util.List;

@Data
public class RoleDeptsVO {

    private Long deptId;

    private List<Long> deptIds;       // 选中的组织ID列表
}
