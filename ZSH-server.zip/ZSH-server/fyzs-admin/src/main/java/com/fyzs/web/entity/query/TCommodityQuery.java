package com.fyzs.web.entity.query;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TCommodity;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCommodityQuery extends TCommodity {

    @Schema(description = "类别名称")
    @Excel(name = "商品类别")
    private String categoryName;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
