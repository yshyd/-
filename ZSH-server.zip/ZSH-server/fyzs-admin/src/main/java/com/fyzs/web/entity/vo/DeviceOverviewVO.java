package com.fyzs.web.entity.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeviceOverviewVO implements Serializable {

    private String name ;

    private Integer count ;

}
