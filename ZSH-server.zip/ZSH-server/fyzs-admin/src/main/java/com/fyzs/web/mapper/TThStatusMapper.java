package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TThStatus;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 温湿度监测报警仪实时温湿度Mapper接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
@Mapper
public interface TThStatusMapper  extends BaseMapper<TThStatus>
{
    /**
     * 查询温湿度监测报警仪实时温湿度
     * 
     * @param id 温湿度监测报警仪实时温湿度主键
     * @return 温湿度监测报警仪实时温湿度
     */
    public TThStatus selectTThStatusById(Long id);

    /**
     * 查询温湿度监测报警仪实时温湿度列表
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 温湿度监测报警仪实时温湿度集合
     */
    public List<TThStatus> selectTThStatusList(TThStatus tThStatus);

    /**
     * 新增温湿度监测报警仪实时温湿度
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 结果
     */
    public int insertTThStatus(TThStatus tThStatus);

    /**
     * 修改温湿度监测报警仪实时温湿度
     * 
     * @param tThStatus 温湿度监测报警仪实时温湿度
     * @return 结果
     */
    public int updateTThStatus(TThStatus tThStatus);

    /**
     * 删除温湿度监测报警仪实时温湿度
     * 
     * @param id 温湿度监测报警仪实时温湿度主键
     * @return 结果
     */
    public int deleteTThStatusById(Long id);

    /**
     * 批量删除温湿度监测报警仪实时温湿度
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTThStatusByIds(Long[] ids);
}
