package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TIncomeExpenditure;
import com.fyzs.web.entity.query.TIncomeExpenditureQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 采购管理-经费管理-收支管理Mapper接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
@Mapper
public interface TIncomeExpenditureMapper  extends BaseMapper<TIncomeExpenditure>
{
    /**
     * 查询采购管理-经费管理-收支管理
     * 
     * @param id 采购管理-经费管理-收支管理主键
     * @return 采购管理-经费管理-收支管理
     */
    public TIncomeExpenditureQuery selectTIncomeExpenditureById(Long id);

    /**
     * 查询采购管理-经费管理-收支管理列表
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 采购管理-经费管理-收支管理集合
     */
    public List<TIncomeExpenditureQuery> selectTIncomeExpenditureList(TIncomeExpenditureQuery tIncomeExpenditure);

    /**
     * 新增采购管理-经费管理-收支管理
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 结果
     */
    public int insertTIncomeExpenditure(TIncomeExpenditure tIncomeExpenditure);

    /**
     * 修改采购管理-经费管理-收支管理
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 结果
     */
    public int updateTIncomeExpenditure(TIncomeExpenditure tIncomeExpenditure);

    /**
     * 删除采购管理-经费管理-收支管理
     * 
     * @param id 采购管理-经费管理-收支管理主键
     * @return 结果
     */
    public int deleteTIncomeExpenditureById(Long id);

    /**
     * 批量删除采购管理-经费管理-收支管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTIncomeExpenditureByIds(Long[] ids);
}
