package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TAlarmQuery;

/**
 * 预警信息Service接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
public interface ITAlarmService extends IService<TAlarm>
{
    /**
     * 查询预警信息
     * 
     * @param id 预警信息主键
     * @return 预警信息
     */
    public TAlarmQuery selectTAlarmById(Long id);

    /**
     * 查询预警信息列表
     *
     * @return 预警信息集合
     */
    public List<TAlarmQuery> selectTAlarmList(TAlarmQuery query);

    /**
     * 新增预警信息
     * 
     * @param tAlarm 预警信息
     * @return 结果
     */
    public int insertTAlarm(TAlarm tAlarm);

    /**
     * 修改预警信息
     * 
     * @param tAlarm 预警信息
     * @return 结果
     */
    public int updateTAlarm(TAlarm tAlarm);

    /**
     * 批量删除预警信息
     * 
     * @param ids 需要删除的预警信息主键集合
     * @return 结果
     */
    public int deleteTAlarmByIds(Long[] ids);

    /**
     * 删除预警信息信息
     * 
     * @param id 预警信息主键
     * @return 结果
     */
    public int deleteTAlarmById(Long id);

    int updateStateByIds(List<Long> alarmIds, int i);

    int batchDispose(List<TAlarm> list);
}
