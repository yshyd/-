package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TRegulationsDelFile;
import com.fyzs.web.service.ITRegulationsDelFileService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规处置证明文件存储信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/reg/file")
public class TRegulationsDelFileController extends BaseController
{

    private final ITRegulationsDelFileService tRegulationsDelFileService;

    /**
     * 查询违法违规处置证明文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:file:list')")
    @GetMapping("/list")
    public TableDataInfo list(TRegulationsDelFile tRegulationsDelFile)
    {
        startPage();
        List<TRegulationsDelFile> list = tRegulationsDelFileService.selectTRegulationsDelFileList(tRegulationsDelFile);
        return getDataTable(list);
    }

    /**
     * 导出违法违规处置证明文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:file:export')")
    @Log(title = "违法违规处置证明文件存储信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TRegulationsDelFile tRegulationsDelFile)
    {
        List<TRegulationsDelFile> list = tRegulationsDelFileService.selectTRegulationsDelFileList(tRegulationsDelFile);
        ExcelUtil<TRegulationsDelFile> util = new ExcelUtil<TRegulationsDelFile>(TRegulationsDelFile.class);
        util.exportExcel(response, list, "违法违规处置证明文件存储信息数据");
    }

    /**
     * 获取违法违规处置证明文件存储信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:file:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tRegulationsDelFileService.selectTRegulationsDelFileById(id));
    }

    /**
     * 新增违法违规处置证明文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:file:add')")
    @Log(title = "违法违规处置证明文件存储信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TRegulationsDelFile tRegulationsDelFile)
    {
        return toAjax(tRegulationsDelFileService.save(tRegulationsDelFile));
    }

    /**
     * 修改违法违规处置证明文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:file:edit')")
    @Log(title = "违法违规处置证明文件存储信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TRegulationsDelFile tRegulationsDelFile)
    {
        return toAjax(tRegulationsDelFileService.updateById(tRegulationsDelFile));
    }

    /**
     * 删除违法违规处置证明文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:file:remove')")
    @Log(title = "违法违规处置证明文件存储信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tRegulationsDelFileService.deleteTRegulationsDelFileByIds(ids));
    }
}
