package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayQuickCheck;
import com.fyzs.web.entity.query.TDayQuickCheckQuery;

/**
 * 学校食堂日管控-日常检查-日常快检Service接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
public interface ITDayQuickCheckService extends IService<TDayQuickCheck>
{
    /**
     * 查询学校食堂日管控-日常检查-日常快检
     * 
     * @param id 学校食堂日管控-日常检查-日常快检主键
     * @return 学校食堂日管控-日常检查-日常快检
     */
    public TDayQuickCheckQuery selectTDayQuickCheckById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-日常快检列表
     *
     * @return 学校食堂日管控-日常检查-日常快检集合
     */
    public List<TDayQuickCheckQuery> selectTDayQuickCheckList(TDayQuickCheckQuery query);

    /**
     * 新增学校食堂日管控-日常检查-日常快检
     * 
     * @param tDayQuickCheck 学校食堂日管控-日常检查-日常快检
     * @return 结果
     */
    public int insertTDayQuickCheck(TDayQuickCheck tDayQuickCheck);

    /**
     * 修改学校食堂日管控-日常检查-日常快检
     * 
     * @param tDayQuickCheck 学校食堂日管控-日常检查-日常快检
     * @return 结果
     */
    public int updateTDayQuickCheck(TDayQuickCheck tDayQuickCheck);

    /**
     * 批量删除学校食堂日管控-日常检查-日常快检
     * 
     * @param ids 需要删除的学校食堂日管控-日常检查-日常快检主键集合
     * @return 结果
     */
    public int deleteTDayQuickCheckByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常检查-日常快检信息
     * 
     * @param id 学校食堂日管控-日常检查-日常快检主键
     * @return 结果
     */
    public int deleteTDayQuickCheckById(Long id);

    int batchCancel(Long[] ids);

    int enable(TDayQuickCheck tDayQuickCheck);
}
