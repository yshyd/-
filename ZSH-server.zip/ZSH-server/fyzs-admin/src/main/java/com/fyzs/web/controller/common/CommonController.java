package com.fyzs.web.controller.common;


import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.common.annotation.Log;
import com.fyzs.common.constant.HttpStatus;
import com.fyzs.common.core.domain.R;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.common.exception.ServiceException;
import com.fyzs.common.utils.DateUtils;
import com.fyzs.common.utils.Helper;
import com.fyzs.common.utils.cos.COSUtil;
import com.qcloud.cos.COSClient;
import com.qcloud.cos.model.DeleteObjectRequest;
import com.qcloud.cos.model.PutObjectResult;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;

import net.coobird.thumbnailator.Thumbnails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.fyzs.common.config.FyzsConfig;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.common.utils.file.FileUploadUtils;
import com.fyzs.common.utils.file.FileUtils;
import com.fyzs.framework.config.ServerConfig;

/**
 * 通用请求处理
 * 
 * @author ysh
 */
@RestController
@RequestMapping("/common")
@AllArgsConstructor
public class CommonController
{
    private static final Logger log = LoggerFactory.getLogger(CommonController.class);


    private  final ServerConfig serverConfig;

    private static final String FILE_DELIMETER = ",";


    private  final COSUtil cosUtil;

    /**
     * 通用下载请求
     * 
     * @param fileName 文件名称
     * @param delete 是否删除
     */
    @GetMapping("/download")
    public void fileDownload(String fileName, Boolean delete, HttpServletResponse response, HttpServletRequest request)
    {
        try
        {
            if (!FileUtils.checkAllowDownload(fileName))
            {
                throw new Exception(StringUtils.format("文件名称({})非法，不允许下载。 ", fileName));
            }
            String realFileName = System.currentTimeMillis() + fileName.substring(fileName.indexOf("_") + 1);
            String filePath = FyzsConfig.getDownloadPath() + fileName;

            response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
            FileUtils.setAttachmentResponseHeader(response, realFileName);
            FileUtils.writeBytes(filePath, response.getOutputStream());
            if (delete)
            {
                FileUtils.deleteFile(filePath);
            }
        }
        catch (Exception e)
        {
            log.error("下载文件失败", e);
        }
    }

    /**
     * 通用上传请求（单个）
     */
    @PostMapping("/upload")
    public AjaxResult uploadFile(MultipartFile file) throws Exception
    {
        try
        {
            // 上传文件路径
            String filePath = FyzsConfig.getUploadPath();
            // 上传并返回新文件名称
            String fileName = FileUploadUtils.upload(filePath, file);
            String url = serverConfig.getUrl() + fileName;
            AjaxResult ajax = AjaxResult.success();
            ajax.put("url", url);
            ajax.put("fileName", fileName);
            ajax.put("newFileName", FileUtils.getName(fileName));
            ajax.put("originalFilename", file.getOriginalFilename());
            return ajax;
        }
        catch (Exception e)
        {
            return AjaxResult.error(e.getMessage());
        }
    }

    /**
     * 通用上传请求（多个）
     */
    @PostMapping("/uploads")
    public AjaxResult uploadFiles(List<MultipartFile> files) throws Exception
    {
        try
        {
            // 上传文件路径
            String filePath = FyzsConfig.getUploadPath();
            List<String> urls = new ArrayList<String>();
            List<String> fileNames = new ArrayList<String>();
            List<String> newFileNames = new ArrayList<String>();
            List<String> originalFilenames = new ArrayList<String>();
            for (MultipartFile file : files)
            {
                // 上传并返回新文件名称
                String fileName = FileUploadUtils.upload(filePath, file);
                String url = serverConfig.getUrl() + fileName;
                urls.add(url);
                fileNames.add(fileName);
                newFileNames.add(FileUtils.getName(fileName));
                originalFilenames.add(file.getOriginalFilename());
            }
            AjaxResult ajax = AjaxResult.success();
            ajax.put("urls", StringUtils.join(urls, FILE_DELIMETER));
            ajax.put("fileNames", StringUtils.join(fileNames, FILE_DELIMETER));
            ajax.put("newFileNames", StringUtils.join(newFileNames, FILE_DELIMETER));
            ajax.put("originalFilenames", StringUtils.join(originalFilenames, FILE_DELIMETER));
            return ajax;
        }
        catch (Exception e)
        {
            return AjaxResult.error(e.getMessage());
        }
    }
    /**
     * 通用上传请求（单个）- 支持图片压缩
     */
    @PostMapping("/uploadCos")
    public AjaxResult uploadFileCos(MultipartFile file, Long type) throws Exception {
        COSClient cosClient = cosUtil.getClient();

        // 根据 type 区分存储路径
        String imageDirectory = "";
        if (type != null) {
            if (type == 1) { // 业务文件存储
                imageDirectory = "business/" + DateUtils.parseDateToStr("yyyy/MM/dd", DateUtils.getNowDate());
            } else if (type == 2) { // 固定文件存储
                imageDirectory = "fixed/" + DateUtils.parseDateToStr("yyyy/MM/dd", DateUtils.getNowDate());
            } else {
                imageDirectory = "business/" + DateUtils.parseDateToStr("yyyy/MM/dd", DateUtils.getNowDate());
            }
        } else {
            imageDirectory = "business/" + DateUtils.parseDateToStr("yyyy/MM/dd", DateUtils.getNowDate());
        }

        try {
            // 判断是否为图片类型，如果是则进行50%压缩
            String originalFilename = file.getOriginalFilename();
            File processedFile;
            if (isSupportedImageFile(originalFilename)) {
                // 图片文件进行50%压缩
                processedFile = compressImage(file, 0.5);
            } else {
                // 非图片文件直接转换
                processedFile = multipartFileToFile(file);
            }

            String timestamp = String.valueOf(System.currentTimeMillis());
            String path = imageDirectory + "/" + timestamp + "_" + originalFilename;
            System.out.println("桶名称：" + cosUtil.getBucketName());

            // 上传图片
            PutObjectResult putObjectResult = cosClient.putObject(cosUtil.getBucketName(), path, processedFile);

            // 生成图片的URL
            String url = "https://" + cosUtil.getBucketName() + "." + cosUtil.getEndpoint() + "/" + path;

            boolean isBlank = StringUtils.isBlank(putObjectResult.getContentMd5());
            if (isBlank) {
                System.out.println("上传失败");
            } else {
                if (processedFile.exists()) {
                    processedFile.delete(); // 清理临时文件
                }
            }

            AjaxResult ajax = AjaxResult.success();
            ajax.put("url", url);
            ajax.put("originalFilename", file.getOriginalFilename());
            return ajax;
        } catch (Exception e) {
            return AjaxResult.error(e.getMessage());
        } finally {
            cosClient.shutdown();
        }
    }


    /**
     * 图片压缩处理 - 使用多种方式尝试压缩
     * @param file 原始文件
     * @param scale 压缩比例
     * @return 压缩后的临时文件
     */
    private File compressImage(MultipartFile file, double scale) throws IOException {
        String originalFilename = file.getOriginalFilename();
        String extension = getFileExtension(originalFilename).toLowerCase();

        if (!isSupportedImageFile(originalFilename)) {
            throw new IOException("不支持的图片格式，文件扩展名：" + extension);
        }

        // 创建输出文件
        File outputFile = File.createTempFile("compressed_" + System.currentTimeMillis(), "." + extension);

        try {
            log.info("开始压缩图片 | 名称={} | 大小={} | 类型={}",
                    originalFilename, file.getSize(), file.getContentType());

            // 尝试方法1: 使用Thumbnailator
            try {
                BufferedImage originalImage;
                try (InputStream inputStream = file.getInputStream()) {
                    originalImage = ImageIO.read(inputStream);
                }

                if (originalImage != null) {
                    Thumbnails.of(originalImage)
                            .scale(scale)
                            .outputQuality(0.8)
                            .toFile(outputFile);

                    if (outputFile.length() > 0) {
                        return outputFile;
                    }
                }
            } catch (Exception e) {
                log.warn("Thumbnailator压缩失败，尝试其他方法", e);
            }

            // 尝试方法2: 使用Java原生Graphics2D进行缩放
            try {
                BufferedImage originalImage;
                try (InputStream inputStream = file.getInputStream()) {
                    originalImage = ImageIO.read(inputStream);
                }

                if (originalImage != null) {
                    int targetWidth = (int)(originalImage.getWidth() * scale);
                    int targetHeight = (int)(originalImage.getHeight() * scale);

                    BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
                    Graphics2D g2d = resizedImage.createGraphics();
                    g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g2d.setColor(Color.WHITE);
                    g2d.fillRect(0, 0, targetWidth, targetHeight);
                    g2d.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
                    g2d.dispose();

                    // 正确的写入方式
                    try (FileOutputStream fos = new FileOutputStream(outputFile)) {
                        if ("png".equalsIgnoreCase(extension)) {
                            ImageIO.write(resizedImage, "png", fos);
                        } else {
                            ImageIO.write(resizedImage, "jpg", fos);
                        }
                    }

                    if (outputFile.length() > 0) {
                        return outputFile;
                    }
                }
            } catch (Exception e) {
                log.warn("Graphics2D压缩失败，尝试最后手段", e);
            }

            // 尝试方法3: 直接保存原始图片（不压缩）
            log.warn("所有压缩方法都失败，返回原始图片");
            try (FileOutputStream fos = new FileOutputStream(outputFile);
                 InputStream is = file.getInputStream()) {
                byte[] buffer = new byte[8192];
                int bytesRead;
                while ((bytesRead = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, bytesRead);
                }
            }

        } catch (Exception e) {
            log.error("图片压缩失败，原始文件名：{}", originalFilename, e);
            // 清理可能创建的部分文件
            if (outputFile.exists() && outputFile.length() == 0) {
                outputFile.delete();
            }
            throw new IOException("图片处理失败：" + e.getMessage(), e);
        }

        return outputFile;
    }


    /**
     * 备用图片压缩方法，在主方法失败时使用
     */
    private File fallbackCompressImage(MultipartFile file, double scale) throws IOException {
        try {
            String originalFilename = file.getOriginalFilename();
            String extension = getFileExtension(originalFilename);

            File tempFile = File.createTempFile("img_" + System.currentTimeMillis(), "." + extension);
            file.transferTo(tempFile);

            BufferedImage originalImage = ImageIO.read(tempFile);
            if (originalImage == null) {
                log.warn("ImageIO 无法读取图片，直接返回原文件：{}", tempFile.getAbsolutePath());
                return tempFile;
            }

            int targetWidth = (int)(originalImage.getWidth() * scale);
            int targetHeight = (int)(originalImage.getHeight() * scale);

            Image scaledImage = originalImage.getScaledInstance(targetWidth, targetHeight, Image.SCALE_SMOOTH);
            BufferedImage resizedImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = resizedImage.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2d.setColor(Color.WHITE);
            g2d.fillRect(0, 0, targetWidth, targetHeight);
            g2d.drawImage(scaledImage, 0, 0, null);
            g2d.dispose();

            File outputFile = File.createTempFile("compressed_" + System.currentTimeMillis(), "." + extension);

            try (OutputStream os = new FileOutputStream(outputFile)) {
                if ("png".equalsIgnoreCase(extension)) {
                    ImageIO.write(resizedImage, "png", os);
                } else if ("jpg".equalsIgnoreCase(extension) || "jpeg".equalsIgnoreCase(extension)) {
                    ImageIO.write(resizedImage, "jpg", os);
                } else if ("gif".equalsIgnoreCase(extension)) {
                    ImageIO.write(resizedImage, "gif", os);
                } else {
                    ImageIO.write(resizedImage, extension, os);
                }
            }

            if (tempFile.exists()) {
                tempFile.delete();
            }

            return outputFile;
        } catch (Exception e) {
            log.error("备用图片压缩也失败了", e);
            throw new IOException("图片处理失败：" + e.getMessage(), e);
        }
    }

    /**
     * 检查是否为支持的图片格式（通过文件扩展名）
     */
    private boolean isSupportedImageFile(String filename) {
        if (filename == null) {
            return false;
        }
        String extension = getFileExtension(filename).toLowerCase();
        return "jpg".equals(extension) ||
                "jpeg".equals(extension) ||
                "png".equals(extension) ||
                "gif".equals(extension) ||
                "bmp".equals(extension) ||
                "webp".equals(extension);
    }

    /**
     * 获取文件扩展名
     */
    private String getFileExtension(String filename) {
        if (filename == null) {
            return "";
        }
        int lastDotIndex = filename.lastIndexOf(".");
        if (lastDotIndex == -1) {
            return "";
        }
        return filename.substring(lastDotIndex + 1);
    }



    /**
     * MultipartFile类型的文件转换为 File 的文件
     *
     * @param multipartFile
     * @return
     */
    private File multipartFileToFile(MultipartFile multipartFile) {
        try {
            File tempFile = File.createTempFile("temp", multipartFile.getOriginalFilename());
            multipartFile.transferTo(tempFile);
            return tempFile;
        } catch (IOException e) {
            log.error("文件转换失败！");
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 本地资源通用下载
     */
    @GetMapping("/download/resource")
    public void resourceDownload(String resource, HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        try
        {
            if (!FileUtils.checkAllowDownload(resource))
            {
                throw new Exception(StringUtils.format("资源文件({})非法，不允许下载。 ", resource));
            }
            // 本地资源路径
            String localPath = FyzsConfig.getProfile();
            // 数据库资源地址
            String downloadPath = localPath + FileUtils.stripPrefix(resource);
            // 下载名称
            String downloadName = StringUtils.substringAfterLast(downloadPath, "/");
            response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
            FileUtils.setAttachmentResponseHeader(response, downloadName);
            FileUtils.writeBytes(downloadPath, response.getOutputStream());
        }
        catch (Exception e)
        {
            log.error("下载文件失败", e);
        }
    }

    // 删除图片
//    @DeleteMapping("/delete/image")
    public static void deleteOldImage(@RequestParam String key) {
        COSClient cosClient = COSUtil.getClient();
        try {
            DeleteObjectRequest deleteRequest = new DeleteObjectRequest(COSUtil.getBucketName(), key);
            cosClient.deleteObject(deleteRequest);
            System.out.println("删除成功：" + key);
        } catch (Exception e) {
            log.error("删除图片失败：" + key, e);
            throw new ServiceException("删除图片失败：" + e.getMessage());
        } finally {
            cosClient.shutdown();
        }
    }
}
