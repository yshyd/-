package com.fyzs.web.entity.dto;


import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class TreeNode {
    private String code; // 第一、二级使用 code 字段
    private Long id;     // 第三级使用 id 字段（数据库主键）
    private String name;
    private Long cameraNum;
    private List<TreeNode> children = new ArrayList<>();
}
