package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCommodityCategory;
import com.fyzs.web.service.ITCommodityCategoryService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品分类Controller
 * 
 * @author ysh
 * @date 2025-10-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/category")
public class TCommodityCategoryController extends BaseController
{

    private final ITCommodityCategoryService tCommodityCategoryService;

    /**
     * 查询商品分类列表
     */
    //@PreAuthorize("@ss.hasPermi('web:category:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCommodityCategory tCommodityCategory)
    {
        startPage();
        List<TCommodityCategory> list = tCommodityCategoryService.selectTCommodityCategoryList(tCommodityCategory);
        return getDataTable(list);
    }

    /**
     * 下拉列表
     * @param tCommodityCategory
     * @return
     */
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TCommodityCategory tCommodityCategory)
    {
        List<TCommodityCategory> list = tCommodityCategoryService.selectTCommodityCategoryList(tCommodityCategory);
        return getDataTable(list);
    }
    /**
     * 导出商品分类列表
     */
    //@PreAuthorize("@ss.hasPermi('web:category:export')")
    @Log(title = "商品分类", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCommodityCategory tCommodityCategory)
    {
        List<TCommodityCategory> list = tCommodityCategoryService.selectTCommodityCategoryList(tCommodityCategory);
        ExcelUtil<TCommodityCategory> util = new ExcelUtil<TCommodityCategory>(TCommodityCategory.class);
        util.exportExcel(response, list, "商品分类数据");
    }

    /**
     * 获取商品分类详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:category:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCommodityCategoryService.selectTCommodityCategoryById(id));
    }

    /**
     * 新增商品分类
     */
    //@PreAuthorize("@ss.hasPermi('web:category:add')")
    @Log(title = "商品分类", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCommodityCategory tCommodityCategory)
    {
        return toAjax(tCommodityCategoryService.save(tCommodityCategory));
    }

    /**
     * 修改商品分类
     */
    //@PreAuthorize("@ss.hasPermi('web:category:edit')")
    @Log(title = "商品分类", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCommodityCategory tCommodityCategory)
    {
        return toAjax(tCommodityCategoryService.updateById(tCommodityCategory));
    }

    /**
     * 删除商品分类
     */
    //@PreAuthorize("@ss.hasPermi('web:category:remove')")
    @Log(title = "商品分类", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCommodityCategoryService.deleteTCommodityCategoryByIds(ids));
    }
}
