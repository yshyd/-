package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TNewProcurementAcceptance;
import com.fyzs.web.entity.dto.TNewProcurementAcceptanceDTO;
import com.fyzs.web.entity.query.TAcceptanceQuery;
import com.fyzs.web.entity.query.TNewProcurementAcceptanceQuery;
import com.fyzs.web.entity.vo.TNewProcurementAcceptanceVO;

/**
 * 商品采购验收Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITNewProcurementAcceptanceService extends IService<TNewProcurementAcceptance>
{
    /**
     * 查询商品采购验收
     * 
     * @param id 商品采购验收主键
     * @return 商品采购验收
     */
    public TNewProcurementAcceptanceQuery selectTNewProcurementAcceptanceById(Long id);

    /**
     * 查询商品采购验收列表
     * 
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 商品采购验收集合
     */
    public List<TNewProcurementAcceptanceQuery> selectTNewProcurementAcceptanceList(TNewProcurementAcceptanceQuery tNewProcurementAcceptance);

    /**
     * 根据筛选条件查询全部商品采购验收导出数据（不分页）
     *
     * @param tNewProcurementAcceptance 商品采购验收筛选条件
     * @return 商品采购验收集合
     */
    public List<TNewProcurementAcceptanceQuery> selectTNewProcurementAcceptanceExportList(TNewProcurementAcceptanceQuery tNewProcurementAcceptance);

    /**
     * 新增商品采购验收
     * 
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int insertTNewProcurementAcceptance(TNewProcurementAcceptance tNewProcurementAcceptance);

    /**
     * 修改商品采购验收
     * 
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int updateTNewProcurementAcceptance(TNewProcurementAcceptance tNewProcurementAcceptance);

    /**
     * 批量删除商品采购验收
     * 
     * @param ids 需要删除的商品采购验收主键集合
     * @return 结果
     */
    public int deleteTNewProcurementAcceptanceByIds(Long[] ids);

    /**
     * 删除商品采购验收信息
     * 
     * @param id 商品采购验收主键
     * @return 结果
     */
    public int deleteTNewProcurementAcceptanceById(Long id);

    int warehoused(TNewProcurementAcceptanceDTO dto);

    TNewProcurementAcceptanceVO listDetail(Long id);

    int settlement(List<TNewProcurementAcceptanceDTO> dtos);

    List<TNewProcurementAcceptanceVO> queryPrice(Long[] ids);

    List<TAcceptanceQuery> settlementWarning(TAcceptanceQuery query);
}
