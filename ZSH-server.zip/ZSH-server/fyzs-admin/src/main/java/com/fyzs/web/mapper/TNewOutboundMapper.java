package com.fyzs.web.mapper;

import java.math.BigDecimal;
import java.util.List;
import com.fyzs.web.entity.TNewOutbound;
import com.fyzs.web.entity.query.TNewOutboundQuery;
import com.fyzs.web.entity.vo.TNewOutboundExportVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 出库记录Mapper接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
@Mapper
public interface TNewOutboundMapper  extends BaseMapper<TNewOutbound>
{
    /**
     * 查询出库记录
     * 
     * @param id 出库记录主键
     * @return 出库记录
     */
    public TNewOutboundQuery selectTNewOutboundById(Long id);

    /**
     * 查询出库记录列表
     * 
     * @param tNewOutbound 出库记录
     * @return 出库记录集合
     */
    public List<TNewOutboundQuery> selectTNewOutboundList(TNewOutboundQuery tNewOutbound);

    /**
     * 根据筛选条件查询全部出库导出数据
     *
     * @param tNewOutbound 出库记录筛选条件
     * @return 出库记录集合
     */
    public List<TNewOutboundExportVO> selectTNewOutboundExportList(TNewOutboundQuery tNewOutbound);

    /**
     * 新增出库记录
     * 
     * @param tNewOutbound 出库记录
     * @return 结果
     */
    public int insertTNewOutbound(TNewOutbound tNewOutbound);

    /**
     * 修改出库记录
     * 
     * @param tNewOutbound 出库记录
     * @return 结果
     */
    public int updateTNewOutbound(TNewOutbound tNewOutbound);

    /**
     * 删除出库记录
     * 
     * @param id 出库记录主键
     * @return 结果
     */
    public int deleteTNewOutboundById(Long id);

    /**
     * 批量删除出库记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewOutboundByIds(Long[] ids);

    List<TNewOutboundQuery> selectOutboundList(TNewOutboundQuery query);

    List<TNewOutboundQuery> getOutbounds(TNewOutboundQuery query);

    /**
     * 统计指定商品和批次的出库数量总和
     * @param commodityId 商品 ID
     * @param batch 批次
     * @return 出库数量总和
     */
    BigDecimal sumOutNumberByCommodityAndBatch(@Param("commodityId") Long commodityId,@Param("batch") String batch);

    List<TNewOutboundQuery> selectTNewOutList(TNewOutboundQuery tNewOutbound);
    /**
     * 统计指定商品和批次且指定类型的出库数量总和
     * @param commodityId 商品 ID
     * @param batch 批次
     * @return 出库数量总和
     */
    BigDecimal sumOutNumberByCommodityAndBatchWithType(@Param("commodityId") Long commodityId,@Param("batch") String batch);
}
