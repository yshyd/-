package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCanteenInformation;
import com.fyzs.web.entity.query.TCanteenInformationQuery;

/**
 * 食堂信息档案Service接口
 * 
 * @author ysh
 * @date 2025-12-08
 */
public interface ITCanteenInformationService extends IService<TCanteenInformation>
{
    /**
     * 查询食堂信息档案
     * 
     * @param id 食堂信息档案主键
     * @return 食堂信息档案
     */
    public TCanteenInformationQuery selectTCanteenInformationById(Long id);

    /**
     * 查询食堂信息档案列表
     * 
     * @param tCanteenInformation 食堂信息档案
     * @return 食堂信息档案集合
     */
    public List<TCanteenInformationQuery> selectTCanteenInformationList(TCanteenInformationQuery tCanteenInformation);

    /**
     * 新增食堂信息档案
     * 
     * @param tCanteenInformation 食堂信息档案
     * @return 结果
     */
    public int insertTCanteenInformation(TCanteenInformation tCanteenInformation);

    /**
     * 修改食堂信息档案
     * 
     * @param tCanteenInformation 食堂信息档案
     * @return 结果
     */
    public int updateTCanteenInformation(TCanteenInformation tCanteenInformation);

    /**
     * 批量删除食堂信息档案
     * 
     * @param ids 需要删除的食堂信息档案主键集合
     * @return 结果
     */
    public int deleteTCanteenInformationByIds(Long[] ids);

    /**
     * 删除食堂信息档案信息
     * 
     * @param id 食堂信息档案主键
     * @return 结果
     */
    public int deleteTCanteenInformationById(Long id);
}
