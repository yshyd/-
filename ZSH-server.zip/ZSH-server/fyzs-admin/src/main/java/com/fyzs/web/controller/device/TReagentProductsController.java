package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TReagentProductsQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TReagentProducts;
import com.fyzs.web.service.ITReagentProductsService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 快检仪-项目检测Controller
 * 
 * @author ysh
 * @date 2026-01-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/products")
public class TReagentProductsController extends BaseController
{

    private final ITReagentProductsService tReagentProductsService;

    /**
     * 查询快检仪-项目检测列表
     */
    //@PreAuthorize("@ss.hasPermi('web:products:list')")
    @GetMapping("/list")
    public TableDataInfo list(TReagentProductsQuery tReagentProducts)
    {
        startPage();
        List<TReagentProductsQuery> list = tReagentProductsService.selectTReagentProductsList(tReagentProducts);
        return getDataTable(list);
    }

    /**
     * 导出快检仪-项目检测列表
     */
    //@PreAuthorize("@ss.hasPermi('web:products:export')")
    @Log(title = "快检仪-项目检测", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TReagentProductsQuery tReagentProducts)
    {
        List<TReagentProductsQuery> list = tReagentProductsService.selectTReagentProductsList(tReagentProducts);
        ExcelUtil<TReagentProductsQuery> util = new ExcelUtil<TReagentProductsQuery>(TReagentProductsQuery.class);
        util.exportExcel(response, list, "快检仪-项目检测数据");
    }

    /**
     * 获取快检仪-项目检测详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:products:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tReagentProductsService.selectTReagentProductsById(id));
    }

    /**
     * 新增快检仪-项目检测
     */
    //@PreAuthorize("@ss.hasPermi('web:products:add')")
    @Log(title = "快检仪-项目检测", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TReagentProducts tReagentProducts)
    {
        return toAjax(tReagentProductsService.save(tReagentProducts));
    }

    /**
     * 修改快检仪-项目检测
     */
    //@PreAuthorize("@ss.hasPermi('web:products:edit')")
    @Log(title = "快检仪-项目检测", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TReagentProducts tReagentProducts)
    {
        return toAjax(tReagentProductsService.updateById(tReagentProducts));
    }

    /**
     * 删除快检仪-项目检测
     */
    //@PreAuthorize("@ss.hasPermi('web:products:remove')")
    @Log(title = "快检仪-项目检测", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tReagentProductsService.deleteTReagentProductsByIds(ids));
    }
}
