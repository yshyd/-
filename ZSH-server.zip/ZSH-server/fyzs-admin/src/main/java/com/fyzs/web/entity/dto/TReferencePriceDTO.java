package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TReferencePrice;
import com.fyzs.web.entity.TReferencePriceItem;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TReferencePriceDTO extends TReferencePrice {

    @Schema(description = "商品列表")
    private List<TReferencePriceItemDTO> commodityList;
}
