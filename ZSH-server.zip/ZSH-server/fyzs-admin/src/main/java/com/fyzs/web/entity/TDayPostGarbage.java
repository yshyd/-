package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食安监管-日管控-餐厨垃圾对象 t_day_post_garbage
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_post_garbage")
public class TDayPostGarbage implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 处置时间 */
        @Schema(description = "处置时间")
        @Excel(name = "处置时间")
        private String date;

        /** 废弃物类型0餐厨垃圾、1其他垃圾、2可回收物、3有害垃圾、4废弃油脂 */
        @Schema(description = "废弃物类型0餐厨垃圾、1其他垃圾、2可回收物、3有害垃圾、4废弃油脂")
        @Excel(name = "废弃物类型0餐厨垃圾、1其他垃圾、2可回收物、3有害垃圾、4废弃油脂")
        private String type;

        /** 数量(KG) */
        @Schema(description = "数量(KG)")
        @Excel(name = "数量(KG)")
        private BigDecimal number;

        /** 用途：300字内 */
        @Schema(description = "用途：300字内")
        @Excel(name = "用途：300字内")
        private String purpose;

        /** 收购单位 */
        @Schema(description = "收购单位")
        @Excel(name = "收购单位")
        private String acquiringEntity;

        /** 收购单位联系人 */
        @Schema(description = "收购单位联系人")
        @Excel(name = "收购单位联系人")
        private String acquiringEntityPerson;

        /** 收购单位联系电话 */
        @Schema(description = "收购单位联系电话")
        @Excel(name = "收购单位联系电话")
        private String acquiringEntityPhone;

        /** 记录人 */
        @Schema(description = "记录人")
        @Excel(name = "记录人")
        private String recorder;

        /** 执行人 */
        @Schema(description = "执行人")
        @Excel(name = "执行人")
        private String executor;

        /** 审核人 */
        @Schema(description = "审核人")
        @Excel(name = "审核人")
        private String reviewer;

        /** 备注：300字内 */
        @Schema(description = "备注：300字内")
        @Excel(name = "备注：300字内")
        private String remarks;

        /** 现场照片 */
        @Schema(description = "现场照片")
        @Excel(name = "现场照片")
        private String img;

        /** 状态：0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "状态：0有效1作废")
        private Integer delFlag;

        /** 巡检人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人ID(对应sys_user)")
        @Excel(name = "巡检人ID(对应sys_user)")
        private Long createUser;

        /** 巡检人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人姓名(对应sys_user)")
        @Excel(name = "巡检人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
