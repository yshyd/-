package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.web.entity.TCameraInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCameraInfoQuery extends TCameraInfo {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    /** 网络状态：0-不详, 1-在线, 2-离线 */
    @Schema(description = "网络状态：0-不详, 1-在线, 2-离线")
    private Integer netStatus;

    @Schema(description = "接入单位")
    private String companyName;

    @Schema(description = "接入单位联系人")
    private String contactPerson;

    @Schema(description = "接入单位联系电话")
    private String cantactPhone;


}
