package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TNewInventoryOperation;
import com.fyzs.web.entity.query.TNewInventoryOperationQuery;

/**
 * 库存操作记录Service接口
 * 
 * @author ysh
 * @date 2025-10-31
 */
public interface ITNewInventoryOperationService extends IService<TNewInventoryOperation>
{
    /**
     * 查询库存操作记录
     * 
     * @param id 库存操作记录主键
     * @return 库存操作记录
     */
    public TNewInventoryOperationQuery selectTNewInventoryOperationById(Long id);

    /**
     * 查询库存操作记录列表
     * 
     * @param tNewInventoryOperation 库存操作记录
     * @return 库存操作记录集合
     */
    public List<TNewInventoryOperationQuery> selectTNewInventoryOperationList(TNewInventoryOperationQuery tNewInventoryOperation);

    /**
     * 新增库存操作记录
     * 
     * @param tNewInventoryOperation 库存操作记录
     * @return 结果
     */
    public int insertTNewInventoryOperation(TNewInventoryOperation tNewInventoryOperation);

    /**
     * 修改库存操作记录
     * 
     * @param tNewInventoryOperation 库存操作记录
     * @return 结果
     */
    public int updateTNewInventoryOperation(TNewInventoryOperation tNewInventoryOperation);

    /**
     * 批量删除库存操作记录
     * 
     * @param ids 需要删除的库存操作记录主键集合
     * @return 结果
     */
    public int deleteTNewInventoryOperationByIds(Long[] ids);

    /**
     * 删除库存操作记录信息
     * 
     * @param id 库存操作记录主键
     * @return 结果
     */
    public int deleteTNewInventoryOperationById(Long id);
}
