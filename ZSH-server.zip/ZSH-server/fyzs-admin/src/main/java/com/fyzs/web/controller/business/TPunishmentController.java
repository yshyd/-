package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TPunishmentQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TPunishment;
import com.fyzs.web.service.ITPunishmentService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食安监管-督察处罚Controller
 * 
 * @author ysh
 * @date 2025-12-02
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/punishment")
public class TPunishmentController extends BaseController
{

    private final ITPunishmentService tPunishmentService;

    /**
     * 查询食安监管-督察处罚列表
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:list')")
    @GetMapping("/list")
    public TableDataInfo list(TPunishmentQuery tPunishment)
    {
        startPage();
        List<TPunishmentQuery> list = tPunishmentService.selectTPunishmentList(tPunishment);
        return getDataTable(list);
    }

    /**
     * 导出食安监管-督察处罚列表
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:export')")
    @Log(title = "食安监管-督察处罚", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TPunishmentQuery tPunishment)
    {
        List<TPunishmentQuery> list = tPunishmentService.selectTPunishmentList(tPunishment);
        ExcelUtil<TPunishmentQuery> util = new ExcelUtil<TPunishmentQuery>(TPunishmentQuery.class);
        util.exportExcel(response, list, "食安监管-督察处罚数据");
    }

    /**
     * 获取食安监管-督察处罚详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tPunishmentService.selectTPunishmentById(id));
    }

    /**
     * 新增食安监管-督察处罚
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:add')")
    @Log(title = "食安监管-督察处罚", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TPunishment tPunishment)
    {
        tPunishment.setDelFlag(0);
        return toAjax(tPunishmentService.save(tPunishment));
    }

    /**
     * 修改食安监管-督察处罚
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:edit')")
    @Log(title = "食安监管-督察处罚", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TPunishment tPunishment)
    {
        return toAjax(tPunishmentService.updateById(tPunishment));
    }

    /**
     * 删除食安监管-督察处罚
     */
    //@PreAuthorize("@ss.hasPermi('web:punishment:remove')")
    @Log(title = "食安监管-督察处罚", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tPunishmentService.deleteTPunishmentByIds(ids));
    }
}
