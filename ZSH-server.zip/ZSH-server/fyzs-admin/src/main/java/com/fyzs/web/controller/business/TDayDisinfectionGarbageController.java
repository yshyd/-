package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.common.utils.ImageURL;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.web.controller.common.CommonController;
import com.fyzs.web.entity.TDayProductionProcess;
import com.fyzs.web.entity.query.TDayDisinfectionGarbageQuery;
import com.fyzs.web.service.ITDayDisinfectionGarbageService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayDisinfectionGarbage;

import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常消毒-垃圾区域消毒Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/disinfection/garbage")
public class TDayDisinfectionGarbageController extends BaseController
{

    private final ITDayDisinfectionGarbageService garbageService;

    /**
     * 查询学校食堂日管控-日常消毒-垃圾区域消毒列表
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayDisinfectionGarbageQuery query)
    {
        startPage();
        List<TDayDisinfectionGarbageQuery> list = garbageService.selectTDayDisinfectionGarbageList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常消毒-垃圾区域消毒列表
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:export')")
    @Log(title = "学校食堂日管控-日常消毒-垃圾区域消毒", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayDisinfectionGarbageQuery query)
    {
        List<TDayDisinfectionGarbageQuery> list = garbageService.selectTDayDisinfectionGarbageList(query);
        ExcelUtil<TDayDisinfectionGarbageQuery> util = new ExcelUtil<TDayDisinfectionGarbageQuery>(TDayDisinfectionGarbageQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常消毒-垃圾区域消毒数据");
    }

    /**
     * 获取学校食堂日管控-日常消毒-垃圾区域消毒详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(garbageService.selectTDayDisinfectionGarbageById(id));
    }

    /**
     * 新增学校食堂日管控-日常消毒-垃圾区域消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:add')")
    @Log(title = "学校食堂日管控-日常消毒-垃圾区域消毒", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayDisinfectionGarbage tDayDisinfectionGarbage)
    {
        tDayDisinfectionGarbage.setDelFlag(0);
        return toAjax(garbageService.save(tDayDisinfectionGarbage));
    }

    /**
     * 修改学校食堂日管控-日常消毒-垃圾区域消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:edit')")
    @Log(title = "学校食堂日管控-日常消毒-垃圾区域消毒", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayDisinfectionGarbage tDayDisinfectionGarbage)
    {
        // 考虑删不删图片
        TDayDisinfectionGarbage garbage = garbageService.getById(tDayDisinfectionGarbage.getId());
        if (garbage != null && StringUtils.isNotBlank(garbage.getDisinfectionImg())
                && !garbage.getDisinfectionImg().equals(tDayDisinfectionGarbage.getDisinfectionImg())) {
            String[] originalImages = garbage.getDisinfectionImg().split(",");
            for (String imageUrl : originalImages) {
                String key = ImageURL.extractKeyFromUrl(imageUrl.trim());
                if (StringUtils.isNotBlank(key)) {
                    CommonController.deleteOldImage(key);
                }
            }
        }
        return toAjax(garbageService.updateById(tDayDisinfectionGarbage));
    }
    /**
     * 启用/作废按钮(id,delFlag)
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:edit')")
    @Log(title = "学校食堂日管控-日常消毒-垃圾区域消毒", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayDisinfectionGarbage tDayDisinfectionGarbage)
    {
        return toAjax(garbageService.updateById(tDayDisinfectionGarbage));
    }

    /**
     * 删除学校食堂日管控-日常消毒-垃圾区域消毒
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:remove')")
    @Log(title = "学校食堂日管控-日常消毒-垃圾区域消毒", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(garbageService.deleteTDayDisinfectionGarbageByIds(ids));
    }
}
