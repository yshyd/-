package com.fyzs.web.entity;

import lombok.Data;

@Data
public class WeeklySummaryResponse {
//    private EmployeeCheckStats employeeCheck;
//    private RoutineInspectionStats routineInspection;
//    private QuickCheckStats quickCheck;
//    private RandomInspectionStats randomInspection;
//    private TablewareDisinfectionStats tablewareDisinfection;
//    private EquipmentDisinfectionStats equipmentDisinfection;
//    private GarbageDisinfectionStats garbageDisinfection;
//    private StorageWarehouseStats storageWarehouse;
//    private EquipmentFacilityStats equipmentFacility;
//    private PlaceCheckStats placeCheck;
//    private ProductionProcessStats productionProcess;
//    private FoodRecipseStats foodRecipse;
//    private NumberDinersStats numberDiners;
//    private PostGarbageStats postGarbage;
//    private AlarmStats alarm;
}