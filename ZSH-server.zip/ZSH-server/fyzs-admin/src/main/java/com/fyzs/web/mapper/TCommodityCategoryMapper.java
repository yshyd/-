package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCommodityCategory;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 商品分类Mapper接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
@org.apache.ibatis.annotations.Mapper
public interface TCommodityCategoryMapper  extends BaseMapper<TCommodityCategory>
{
    /**
     * 查询商品分类
     * 
     * @param id 商品分类主键
     * @return 商品分类
     */
    public TCommodityCategory selectTCommodityCategoryById(Long id);

    /**
     * 查询商品分类列表
     * 
     * @param tCommodityCategory 商品分类
     * @return 商品分类集合
     */
    public List<TCommodityCategory> selectTCommodityCategoryList(TCommodityCategory tCommodityCategory);

    /**
     * 新增商品分类
     * 
     * @param tCommodityCategory 商品分类
     * @return 结果
     */
    public int insertTCommodityCategory(TCommodityCategory tCommodityCategory);

    /**
     * 修改商品分类
     * 
     * @param tCommodityCategory 商品分类
     * @return 结果
     */
    public int updateTCommodityCategory(TCommodityCategory tCommodityCategory);

    /**
     * 删除商品分类
     * 
     * @param id 商品分类主键
     * @return 结果
     */
    public int deleteTCommodityCategoryById(Long id);

    /**
     * 批量删除商品分类
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCommodityCategoryByIds(Long[] ids);
}
