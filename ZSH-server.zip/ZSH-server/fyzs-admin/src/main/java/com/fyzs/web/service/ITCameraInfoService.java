package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.entity.vo.AreaDeptTreeVO;
import com.fyzs.web.entity.TCameraInfo;
import com.fyzs.web.entity.dto.TCameraInfoDTO;
import com.fyzs.web.entity.query.TCameraInfoQuery;

/**
 * 设备管理-摄像头管理Service接口
 * 
 * @author ysh
 * @date 2025-12-17
 */
public interface ITCameraInfoService extends IService<TCameraInfo>
{
    /**
     * 查询设备管理-摄像头管理
     * 
     * @param id 设备管理-摄像头管理主键
     * @return 设备管理-摄像头管理
     */
    public TCameraInfoQuery selectTCameraInfoById(Long id);

    /**
     * 查询设备管理-摄像头管理列表
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 设备管理-摄像头管理集合
     */
    public List<TCameraInfoQuery> selectTCameraInfoList(TCameraInfoQuery tCameraInfo);

    /**
     * 查询摄像头数量
     * @param tCameraInfo
     * @return
     */
    public List<TCameraInfoQuery> selectTCameraInfoCount(TCameraInfoQuery tCameraInfo);

    /**
     * 新增设备管理-摄像头管理
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 结果
     */
    public int insertTCameraInfo(TCameraInfoDTO tCameraInfo);

    /**
     * 修改设备管理-摄像头管理
     * 
     * @param tCameraInfo 设备管理-摄像头管理
     * @return 结果
     */
    public int updateTCameraInfo(TCameraInfoDTO tCameraInfo);

    /**
     * 批量删除设备管理-摄像头管理
     * 
     * @param ids 需要删除的设备管理-摄像头管理主键集合
     * @return 结果
     */
    public int deleteTCameraInfoByIds(Long[] ids);

    /**
     * 删除设备管理-摄像头管理信息
     * 
     * @param id 设备管理-摄像头管理主键
     * @return 结果
     */
    public int deleteTCameraInfoById(Long id);

    List<AreaDeptTreeVO> areaDataTree();
}
