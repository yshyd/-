package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TDevice;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TDeviceDTO extends TDevice {

    @Schema(description = "批量操作id")
    private Long[] ids;
}
