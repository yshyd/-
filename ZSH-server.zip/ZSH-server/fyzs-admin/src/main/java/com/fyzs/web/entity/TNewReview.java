package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 盘点对象 t_new_review
 *
 * @author ysh
 * @date 2025-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_review")
public class TNewReview implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 部门ID */
        @Schema(description = "部门ID")
        @Excel(name = "部门ID")
        private Long deptId;

        /** 仓库ID */
        @Schema(description = "仓库ID")
        @Excel(name = "仓库ID")
        private Long warehouseId;

        /** 对应批次库存ID */
        @Schema(description = "对应批次库存ID")
        @Excel(name = "对应批次库存ID")
        private Long inventoryId;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 批次 */
        @Schema(description = "批次")
        @Excel(name = "批次")
        private String batch;

        /** 盘点前数量 */
        @Schema(description = "盘点前数量")
        @Excel(name = "盘点前数量")
        private BigDecimal beforeNumber;

        /** 盘点后数量 */
        @Schema(description = "盘点后数量")
        @Excel(name = "盘点后数量")
        private BigDecimal afterNumber;

        /** 0盘盈1盘亏 */
        @Schema(description = "0盘盈1盘亏")
        @Excel(name = "0盘盈1盘亏")
        private Integer type;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
