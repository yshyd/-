package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.dto.TCalendarInfoDTO;
import com.fyzs.web.entity.query.TCalendarInfoQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCalendarInfo;
import com.fyzs.web.service.ITCalendarInfoService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

import static jdk.nashorn.internal.runtime.regexp.joni.Config.log;

/**
 * 食堂运营配置Controller
 * 
 * @author ysh
 * @date 2025-10-25
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/info")
public class TCalendarInfoController extends BaseController
{

    private final ITCalendarInfoService tCalendarInfoService;

    /**
     * 查询食堂运营配置列表
     */
    //@PreAuthorize("@ss.hasPermi('web:info:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCalendarInfoQuery tCalendarInfo)
    {
        startPage();
        List<TCalendarInfoQuery> list = tCalendarInfoService.selectTCalendarInfoList(tCalendarInfo);
        return getDataTable(list);
    }

//    /**
//     * 导出食堂运营配置列表
//     */
//    //@PreAuthorize("@ss.hasPermi('web:info:export')")
//    @Log(title = "食堂运营配置", businessType = BusinessType.EXPORT)
//    @PostMapping("/export")
//    public void export(HttpServletResponse response, TCalendarInfo tCalendarInfo)
//    {
//        List<TCalendarInfo> list = tCalendarInfoService.selectTCalendarInfoList(tCalendarInfo);
//        ExcelUtil<TCalendarInfo> util = new ExcelUtil<TCalendarInfo>(TCalendarInfo.class);
//        util.exportExcel(response, list, "食堂运营配置数据");
//    }

    /**
     * 获取食堂运营配置详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:info:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCalendarInfoService.selectTCalendarInfoById(id));
    }

    /**
     * 批量新增
     * @param dto
     * @return
     */
    @PostMapping("/batchSave")
    public AjaxResult batchSave(@RequestBody TCalendarInfoDTO dto) {
        try {
            tCalendarInfoService.batchSave(dto);
            return AjaxResult.success("批量保存成功");
        } catch (Exception e) {

            return AjaxResult.error("批量保存失败：" + e.getMessage());
        }
    }

    /**
     * 新增食堂运营配置
     */
    //@PreAuthorize("@ss.hasPermi('web:info:add')")
    @Log(title = "食堂运营配置", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCalendarInfo tCalendarInfo)
    {
        tCalendarInfo.setDelFlag("0");
        return toAjax(tCalendarInfoService.save(tCalendarInfo));
    }

    /**
     * 修改食堂运营配置
     */
    //@PreAuthorize("@ss.hasPermi('web:info:edit')")
    @Log(title = "食堂运营配置", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCalendarInfo tCalendarInfo)
    {
        TCalendarInfo info = tCalendarInfoService.getOne(new LambdaQueryWrapper<TCalendarInfo>()
                .eq(TCalendarInfo::getDeptId, tCalendarInfo.getDeptId())
                .eq(TCalendarInfo::getDate, tCalendarInfo.getDate())
                .ne(TCalendarInfo::getId, tCalendarInfo.getId()));
        if (ObjectUtils.isNotEmpty( info)){
            return AjaxResult.error("已存在相同主体和日期的配置，请勿重复修改");
        }
        return toAjax(tCalendarInfoService.updateById(tCalendarInfo));
    }

    /**
     * 删除食堂运营配置
     */
    //@PreAuthorize("@ss.hasPermi('web:info:remove')")
    @Log(title = "食堂运营配置", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCalendarInfoService.deleteTCalendarInfoByIds(ids));
    }
}
