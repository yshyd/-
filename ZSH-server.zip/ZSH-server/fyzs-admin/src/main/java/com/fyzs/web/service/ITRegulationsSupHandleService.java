package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TRegulationsSupHandle;

/**
 * 违法违规监管部门地方催办信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITRegulationsSupHandleService extends IService<TRegulationsSupHandle>
{
    /**
     * 查询违法违规监管部门地方催办信息
     * 
     * @param id 违法违规监管部门地方催办信息主键
     * @return 违法违规监管部门地方催办信息
     */
    public TRegulationsSupHandle selectTRegulationsSupHandleById(Long id);

    /**
     * 查询违法违规监管部门地方催办信息列表
     * 
     * @param tRegulationsSupHandle 违法违规监管部门地方催办信息
     * @return 违法违规监管部门地方催办信息集合
     */
    public List<TRegulationsSupHandle> selectTRegulationsSupHandleList(TRegulationsSupHandle tRegulationsSupHandle);

    /**
     * 新增违法违规监管部门地方催办信息
     * 
     * @param tRegulationsSupHandle 违法违规监管部门地方催办信息
     * @return 结果
     */
    public int insertTRegulationsSupHandle(TRegulationsSupHandle tRegulationsSupHandle);

    /**
     * 修改违法违规监管部门地方催办信息
     * 
     * @param tRegulationsSupHandle 违法违规监管部门地方催办信息
     * @return 结果
     */
    public int updateTRegulationsSupHandle(TRegulationsSupHandle tRegulationsSupHandle);

    /**
     * 批量删除违法违规监管部门地方催办信息
     * 
     * @param ids 需要删除的违法违规监管部门地方催办信息主键集合
     * @return 结果
     */
    public int deleteTRegulationsSupHandleByIds(Long[] ids);

    /**
     * 删除违法违规监管部门地方催办信息信息
     * 
     * @param id 违法违规监管部门地方催办信息主键
     * @return 结果
     */
    public int deleteTRegulationsSupHandleById(Long id);
}
