package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayNumberDiners;
import com.fyzs.web.entity.query.TDayNumberDinersQuery;

/**
 * 食安监管-日管控-日常就餐-就餐人数Service接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
public interface ITDayNumberDinersService extends IService<TDayNumberDiners>
{
    /**
     * 查询食安监管-日管控-日常就餐-就餐人数
     * 
     * @param id 食安监管-日管控-日常就餐-就餐人数主键
     * @return 食安监管-日管控-日常就餐-就餐人数
     */
    public TDayNumberDinersQuery selectTDayNumberDinersById(Long id);

    /**
     * 查询食安监管-日管控-日常就餐-就餐人数列表
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 食安监管-日管控-日常就餐-就餐人数集合
     */
    public List<TDayNumberDinersQuery> selectTDayNumberDinersList(TDayNumberDinersQuery tDayNumberDiners);

    /**
     * 新增食安监管-日管控-日常就餐-就餐人数
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 结果
     */
    public int insertTDayNumberDiners(TDayNumberDiners tDayNumberDiners);

    /**
     * 修改食安监管-日管控-日常就餐-就餐人数
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 结果
     */
    public int updateTDayNumberDiners(TDayNumberDiners tDayNumberDiners);

    /**
     * 批量删除食安监管-日管控-日常就餐-就餐人数
     * 
     * @param ids 需要删除的食安监管-日管控-日常就餐-就餐人数主键集合
     * @return 结果
     */
    public int deleteTDayNumberDinersByIds(Long[] ids);

    /**
     * 删除食安监管-日管控-日常就餐-就餐人数信息
     * 
     * @param id 食安监管-日管控-日常就餐-就餐人数主键
     * @return 结果
     */
    public int deleteTDayNumberDinersById(Long id);
}
