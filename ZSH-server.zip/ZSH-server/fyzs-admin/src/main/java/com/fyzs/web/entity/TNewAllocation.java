package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 库间调拨记录对象 t_new_allocation
 *
 * @author ysh
 * @date 2025-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_allocation")
public class TNewAllocation implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 源仓库ID */
        @Schema(description = "源仓库ID")
        @Excel(name = "源仓库ID")
        private Long sourceWarehouseId;

        /** 源仓库名称 */
        @Schema(description = "源仓库名称")
        @Excel(name = "源仓库名称")
        private String sourceWarehouseName;

        /** 目标仓库ID */
        @Schema(description = "目标仓库ID")
        @Excel(name = "目标仓库ID")
        private Long toWarehouseId;

        /** 目标仓库名称 */
        @Schema(description = "目标仓库名称")
        @Excel(name = "目标仓库名称")
        private String toWarehouseName;

        /** 批次库存ID */
        @Schema(description = "批次库存ID")
        @Excel(name = "批次库存ID")
        private Long inventoryId;

        /** 验收记录ID */
        @Schema(description = "验收记录ID")
        @Excel(name = "验收记录ID")
        private Long accttanceId;

        /** 供应商ID */
        @Schema(description = "供应商ID")
        @Excel(name = "供应商ID")
        private Long supplerId;

        /** 采购ID */
        @Schema(description = "采购ID")
        @Excel(name = "采购ID")
        private Long procurementId;

        /** 采购单号 */
        @Schema(description = "采购单号")
        @Excel(name = "采购单号")
        private String procurementNum;

        /** 源商品ID */
        @Schema(description = "源商品ID")
        @Excel(name = "源商品ID")
        private Long commodityId;

        /** 源商品批次 */
        @Schema(description = "源商品批次")
        @Excel(name = "源商品批次")
        private String batch;

        /** 调拨数量 */
        @Schema(description = "调拨数量")
        @Excel(name = "调拨数量")
        private BigDecimal number;

        /** 源商品生产日期(验收时必填) */
        @Schema(description = "源商品生产日期(验收时必填)")
        @Excel(name = "源商品生产日期(验收时必填)")
        private String productionDate;

        /** 源商品保质期数量(验收时必填) */
        @Schema(description = "源商品保质期数量(验收时必填)")
        @Excel(name = "源商品保质期数量(验收时必填)")
        private Integer shelfLifeNumber;

        /** 源商品保质期类型(0天，1月)，验收时必填 */
        @Schema(description = "源商品保质期类型(0天，1月)，验收时必填")
        @Excel(name = "源商品保质期类型(0天，1月)，验收时必填")
        private Integer shelfLifeType;

        /** 源商品保质期到期日期(验收时计算) */
        @Schema(description = "源商品保质期到期日期(验收时计算)")
        @Excel(name = "源商品保质期到期日期(验收时计算)")
        private String endDate;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
