package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCameraInspectionRecord;
import com.fyzs.web.entity.query.TCameraInspectionRecordQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 设备巡检记录信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TCameraInspectionRecordMapper  extends BaseMapper<TCameraInspectionRecord>
{
    /**
     * 查询设备巡检记录信息
     * 
     * @param id 设备巡检记录信息主键
     * @return 设备巡检记录信息
     */
    public TCameraInspectionRecord selectTCameraInspectionRecordById(Long id);

    /**
     * 查询设备巡检记录信息列表
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 设备巡检记录信息集合
     */
    public List<TCameraInspectionRecordQuery> selectTCameraInspectionRecordList(TCameraInspectionRecordQuery tCameraInspectionRecord);

    /**
     * 新增设备巡检记录信息
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 结果
     */
    public int insertTCameraInspectionRecord(TCameraInspectionRecord tCameraInspectionRecord);

    /**
     * 修改设备巡检记录信息
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 结果
     */
    public int updateTCameraInspectionRecord(TCameraInspectionRecord tCameraInspectionRecord);

    /**
     * 删除设备巡检记录信息
     * 
     * @param id 设备巡检记录信息主键
     * @return 结果
     */
    public int deleteTCameraInspectionRecordById(Long id);

    /**
     * 批量删除设备巡检记录信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraInspectionRecordByIds(Long[] ids);
}
