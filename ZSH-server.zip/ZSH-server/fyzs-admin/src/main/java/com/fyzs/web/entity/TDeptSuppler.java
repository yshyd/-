package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 供应商对象 t_dept_suppler
 *
 * @author ysh
 * @date 2025-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_dept_suppler")
public class TDeptSuppler implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     *
     */
    @Schema(description = "")
    private Long id;

    /**
     * 主体id
     */
    @Schema(description = "主体id")
    @Excel(name = "主体id")
    private Long deptId;

    /**
     * 供应商名称
     */
    @Schema(description = "供应商名称")
    @Excel(name = "供应商名称")
    private String name;

    /**
     * 供应商简称
     */
    @Schema(description = "供应商简称")
    @Excel(name = "供应商简称")
    private String abbreviation;

    /**
     * 供应商区域id
     */
    @Schema(description = "供应商区域id")
    @Excel(name = "供应商区域id")
    private Long areaId;

    /**
     * 供应商地址
     */
    @Schema(description = "供应商地址")
    @Excel(name = "供应商地址")
    private String address;

    /**
     * 供应商联系人
     */
    @Schema(description = "供应商联系人")
    @Excel(name = "供应商联系人")
    private String contactPerson;

    /**
     * 供应商联系电话
     */
    @Schema(description = "供应商联系电话")
    @Excel(name = "供应商联系电话")
    private String contactPhone;

    /**
     * 采购方式(0:统招统采,1:自购)
     */
    @Schema(description = "采购方式(0:统招统采,1:自购)")
    @Excel(name = "采购方式(0:统招统采,1:自购)")
    private Integer purchaseType;

    /**
     * 证件类型(0身份证1营业执照)
     */
    @Schema(description = "证件类型(0身份证1营业执照)")
    @Excel(name = "证件类型(0身份证1营业执照)")
    private Integer typeDocument;

    /**
     * (营业执照号或身份证号)
     */
    @Schema(description = "(营业执照号或身份证号)")
    @Excel(name = "(营业执照号或身份证号)")
    private String businessCode;

    /**
     * 营业执照/身份证正面照片
     */
    @Schema(description = "营业执照/身份证正面照片")
    @Excel(name = "营业执照/身份证正面照片")
    private String frontOfBusinessLicense;

    /**
     * 营业执照/身份证背面照片
     */
    @Schema(description = "营业执照/身份证背面照片")
    @Excel(name = "营业执照/身份证背面照片")
    private String backOfBusinessLicense;


    /**
     * 采购合同限5个文件
     */
    @Schema(description = "采购合同限5个文件")
    @Excel(name = "采购合同限5个文件")
    private String procurementContract;

    /**
     * 供应商收款账户
     */
    @Schema(description = "供应商收款账户")
    @Excel(name = "供应商收款账户")
    private String bankCard;

    /**
     * 供应商收款账号开户行
     */
    @Schema(description = "供应商收款账号开户行")
    @Excel(name = "供应商收款账号开户行")
    private String receivingAccountBank;

    /**
     * 有效(0有效、1无效)启动和禁用
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "有效(0有效、1无效)启动和禁用")
    private Integer delFlag;

    /**
     * 创建人id
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人id")
    @Excel(name = "创建人id")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

}
