package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常检查-日常快检对象 t_day_quick_check
 *
 * @author ysh
 * @date 2025-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_quick_check")
public class TDayQuickCheck implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 仓库ID */
        @Schema(description = "仓库ID")
        @Excel(name = "仓库ID")
        private Long warehouseId;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 商品名称 */
        @Schema(description = "商品名称")
        @Excel(name = "商品名称")
        private String commodityName;

        /** 商品编码 */
        @Schema(description = "商品编码")
        @Excel(name = "商品编码")
        private String commodityCode;

        /** 商品批次 */
        @Schema(description = "商品批次")
        @Excel(name = "商品批次")
        private String batch;

        /** 快检类型：0农药残留，1黄曲霉毒素B1，2新鲜度，3瘦肉精(克伦特罗)，4瘦肉精(莱克多巴胺)，5瘦肉精(沙丁胺醇)，6注水肉，7病害肉，8过氧化值，9酸价，10三聚氰胺，11吊白块，12二氧化硫，13甲醛，14铝，15洁净度，16亚硝酸盐 */
        @Schema(description = "快检类型：0农药残留，1黄曲霉毒素B1，2新鲜度，3瘦肉精(克伦特罗)，4瘦肉精(莱克多巴胺)，5瘦肉精(沙丁胺醇)，6注水肉，7病害肉，8过氧化值，9酸价，10三聚氰胺，11吊白块，12二氧化硫，13甲醛，14铝，15洁净度，16亚硝酸盐")
        @Excel(name = "快检类型：0农药残留，1黄曲霉毒素B1，2新鲜度，3瘦肉精(克伦特罗)，4瘦肉精(莱克多巴胺)，5瘦肉精(沙丁胺醇)，6注水肉，7病害肉，8过氧化值，9酸价，10三聚氰胺，11吊白块，12二氧化硫，13甲醛，14铝，15洁净度，16亚硝酸盐")
        private Integer quickCheckType;

        /** 检测值 */
        @Schema(description = "检测值")
        @Excel(name = "检测值")
        private String quickCheckValue;

        /** 检测结果0正常1异常 */
        @Schema(description = "检测结果0正常1异常")
        @Excel(name = "检测结果0正常1异常")
        private Integer quickCheckResult;

        /** 备注 */
        @Schema(description = "备注")
        @Excel(name = "备注")
        private String remarks;

        /** 快检拍照图片，逗号分割，最多3张 */
        @Schema(description = "快检拍照图片，逗号分割，最多3张")
        @Excel(name = "快检拍照图片，逗号分割，最多3张")
        private String img;

        /** 快检人 */
        @Schema(description = "快检人")
        @Excel(name = "快检人")
        private String quickCheckUser;

        /** 快检时间 */
        @Schema(description = "快检时间")
        @Excel(name = "快检时间")
        private String quickCheckTime;

        /** 数据来源0软件上报1设备上报 */
        @Schema(description = "数据来源0软件上报1设备上报")
        @Excel(name = "数据来源0软件上报1设备上报")
        private Integer source;

        /** 上报数据的设备序列号，数据来源是设备上报时必填 */
        @Schema(description = "上报数据的设备序列号，数据来源是设备上报时必填")
        @Excel(name = "上报数据的设备序列号，数据来源是设备上报时必填")
        private String deviceSerial;

        /** 删除表示：0有效1已删除 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "删除表示：0有效1已删除")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
