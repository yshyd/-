package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TProcurementOrder;
import com.fyzs.web.entity.dto.TProcurementOrderDTO;
import com.fyzs.web.entity.query.TProcurementOrderQuery;
import com.fyzs.web.entity.vo.TProcurementOrderVO;

/**
 * 商品采购单主Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITProcurementOrderService extends IService<TProcurementOrder>
{
    /**
     * 查询商品采购单主
     * 
     * @param id 商品采购单主主键
     * @return 商品采购单主
     */
    public TProcurementOrderVO selectTProcurementOrderById(Long id);

    /**
     * 查询商品采购单主列表
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 商品采购单主集合
     */
    public List<TProcurementOrderQuery> selectTProcurementOrderList(TProcurementOrderQuery tProcurementOrder);

    /**
     * 新增商品采购单主
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 结果
     */
    public int insertTProcurementOrder(TProcurementOrder tProcurementOrder);

    /**
     * 修改商品采购单主
     * 
     * @param tProcurementOrder 商品采购单主
     * @return 结果
     */
    public int updateTProcurementOrder(TProcurementOrder tProcurementOrder);

    /**
     * 批量删除商品采购单主
     * 
     * @param ids 需要删除的商品采购单主主键集合
     * @return 结果
     */
    public int deleteTProcurementOrderByIds(Long[] ids);

    /**
     * 删除商品采购单主信息
     * 
     * @param id 商品采购单主主键
     * @return 结果
     */
    public int deleteTProcurementOrderById(Long id);

    int order(TProcurementOrderDTO dto);

    int amend(TProcurementOrderDTO dto);


    int confirm(Long id);
}
