package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TThStatus;
import com.fyzs.web.service.ITThStatusService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 温湿度监测报警仪实时温湿度Controller
 * 
 * @author ysh
 * @date 2026-08-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/th/status")
public class TThStatusController extends BaseController
{

    private final ITThStatusService tThStatusService;

    /**
     * 查询温湿度监测报警仪实时温湿度列表
     */
    //@PreAuthorize("@ss.hasPermi('web:status:list')")
    @GetMapping("/list")
    public TableDataInfo list(TThStatus tThStatus)
    {
        startPage();
        List<TThStatus> list = tThStatusService.selectTThStatusList(tThStatus);
        return getDataTable(list);
    }

    /**
     * 导出温湿度监测报警仪实时温湿度列表
     */
    //@PreAuthorize("@ss.hasPermi('web:status:export')")
    @Log(title = "温湿度监测报警仪实时温湿度", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TThStatus tThStatus)
    {
        List<TThStatus> list = tThStatusService.selectTThStatusList(tThStatus);
        ExcelUtil<TThStatus> util = new ExcelUtil<TThStatus>(TThStatus.class);
        util.exportExcel(response, list, "温湿度监测报警仪实时温湿度数据");
    }

    /**
     * 获取温湿度监测报警仪实时温湿度详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:status:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tThStatusService.selectTThStatusById(id));
    }

    /**
     * 新增温湿度监测报警仪实时温湿度
     */
    //@PreAuthorize("@ss.hasPermi('web:status:add')")
    @Log(title = "温湿度监测报警仪实时温湿度", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TThStatus tThStatus)
    {
        return toAjax(tThStatusService.save(tThStatus));
    }

    /**
     * 修改温湿度监测报警仪实时温湿度
     */
    //@PreAuthorize("@ss.hasPermi('web:status:edit')")
    @Log(title = "温湿度监测报警仪实时温湿度", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TThStatus tThStatus)
    {
        return toAjax(tThStatusService.updateById(tThStatus));
    }

    /**
     * 删除温湿度监测报警仪实时温湿度
     */
    //@PreAuthorize("@ss.hasPermi('web:status:remove')")
    @Log(title = "温湿度监测报警仪实时温湿度", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tThStatusService.deleteTThStatusByIds(ids));
    }
}
