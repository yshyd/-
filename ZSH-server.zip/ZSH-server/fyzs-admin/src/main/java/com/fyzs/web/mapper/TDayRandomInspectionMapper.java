package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayRandomInspection;
import com.fyzs.web.entity.query.TDayRandomInspectionQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常检查-日常抽检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-19
 */
@Mapper
public interface TDayRandomInspectionMapper  extends BaseMapper<TDayRandomInspection>
{
    /**
     * 查询学校食堂日管控-日常检查-日常抽检
     * 
     * @param id 学校食堂日管控-日常检查-日常抽检主键
     * @return 学校食堂日管控-日常检查-日常抽检
     */
    public TDayRandomInspectionQuery selectTDayRandomInspectionById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-日常抽检列表
     *
     * @return 学校食堂日管控-日常检查-日常抽检集合
     */
    public List<TDayRandomInspectionQuery> selectTDayRandomInspectionList(TDayRandomInspectionQuery query);

    /**
     * 新增学校食堂日管控-日常检查-日常抽检
     * 
     * @param tDayRandomInspection 学校食堂日管控-日常检查-日常抽检
     * @return 结果
     */
    public int insertTDayRandomInspection(TDayRandomInspection tDayRandomInspection);

    /**
     * 修改学校食堂日管控-日常检查-日常抽检
     * 
     * @param tDayRandomInspection 学校食堂日管控-日常检查-日常抽检
     * @return 结果
     */
    public int updateTDayRandomInspection(TDayRandomInspection tDayRandomInspection);

    /**
     * 删除学校食堂日管控-日常检查-日常抽检
     * 
     * @param id 学校食堂日管控-日常检查-日常抽检主键
     * @return 结果
     */
    public int deleteTDayRandomInspectionById(Long id);

    /**
     * 批量删除学校食堂日管控-日常检查-日常抽检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayRandomInspectionByIds(Long[] ids);

    int countValidRandomInspections(@Param("startDate") Date startDate,
                                    @Param("endDate") Date endDate,
                                    @Param("deptIds") List<Long> deptIds);

    int countNormalRandomInspections(@Param("startDate") Date startDate,
                                     @Param("endDate") Date endDate,
                                     @Param("deptIds") List<Long> deptIds);

    int countAbnormalRandomInspections(@Param("startDate") Date startDate,
                                       @Param("endDate") Date endDate,
                                       @Param("deptIds") List<Long> deptIds);
}
