package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCameraOpenLive;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 明厨亮灶三方接入信息Mapper接口
 * 
 * @author ysh
 * @date 2025-12-17
 */
@org.apache.ibatis.annotations.Mapper
public interface TCameraOpenLiveMapper  extends BaseMapper<TCameraOpenLive>
{
    /**
     * 查询明厨亮灶三方接入信息
     * 
     * @param id 明厨亮灶三方接入信息主键
     * @return 明厨亮灶三方接入信息
     */
    public TCameraOpenLive selectTCameraOpenLiveById(Long id);

    /**
     * 查询明厨亮灶三方接入信息列表
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 明厨亮灶三方接入信息集合
     */
    public List<TCameraOpenLive> selectTCameraOpenLiveList(TCameraOpenLive tCameraOpenLive);

    /**
     * 新增明厨亮灶三方接入信息
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 结果
     */
    public int insertTCameraOpenLive(TCameraOpenLive tCameraOpenLive);

    /**
     * 修改明厨亮灶三方接入信息
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 结果
     */
    public int updateTCameraOpenLive(TCameraOpenLive tCameraOpenLive);

    /**
     * 删除明厨亮灶三方接入信息
     * 
     * @param id 明厨亮灶三方接入信息主键
     * @return 结果
     */
    public int deleteTCameraOpenLiveById(Long id);

    /**
     * 批量删除明厨亮灶三方接入信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraOpenLiveByIds(Long[] ids);
}
