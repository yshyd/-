package com.fyzs.web.service.impl;

import com.alibaba.druid.sql.dialect.ads.visitor.AdsOutputVisitor;
import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.common.core.domain.entity.SysRole;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.system.domain.vo.SysAreaDataVO;
import com.fyzs.system.mapper.SysDeptMapper;
import com.fyzs.system.mapper.SysRoleMapper;
import com.fyzs.system.service.ISysAreaService;
import com.fyzs.system.service.ISysDeptService;
import com.fyzs.web.entity.TCalendarInfo;
import com.fyzs.web.entity.dto.FoodSampleDTO;
import com.fyzs.web.entity.dto.SummaryItemDTO;
import com.fyzs.web.entity.query.SummaryQuery;
import com.fyzs.web.entity.query.TCalendarInfoQuery;
import com.fyzs.web.mapper.*;
import com.fyzs.web.service.ICollectService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class ICollectServiceImpl implements ICollectService {

    private final ExecutorService executorService = Executors.newFixedThreadPool(
            Runtime.getRuntime().availableProcessors()
    );


    private final TDayRoutineInspectionMapper routineInspectionMapper;//常规日检Mapper接口
    private final TDayQuickCheckMapper quickCheckMapper;//日常快检Mapper接口
    private final TDayRandomInspectionMapper randomInspectionMapper;//日常抽检Mapper接口
    private final TDayDisinfectionTablewareMapper tablewareDisinfectionMapper;//餐饮具消毒Mapper接口
    private final TDayDisinfectionEquipmentMapper equipmentDisinfectionMapper;//设备设施消毒Mapper接口
    private final TDayDisinfectionGarbageMapper garbageDisinfectionMapper;//垃圾区域消毒Mapper接口
    private final TDayStorageWarehouseMapper storageInspectionMapper;//库房贮藏巡检Mapper接口
    private final TDayEquipmentAndFacilitieMapper facilityInspectionMapper;//设备设施巡检Mapper接口
    private final TDayPlaceCheckMapper environmentInspectionMapper;//场所环境卫生巡检Mapper接口
    private final TDayProductionProcessMapper processInspectionMapper;//食品加工制作过程Mapper接口
    private final TFoodRecipseMapper foodMenuMapper;//食堂菜谱、留样、试尝、陪餐信息Mapper接口
    private final TDayNumberDinersMapper dinerCountMapper;//就餐人数Mapper接口
    private final TDayPostGarbageMapper kitchenWasteMapper;//餐厨垃圾Mapper接口
    private final TPersonCheckMapper personCheckMapper; // 员工日检表
    private final TCanteenPractitionersMapper practitionersMapper; // 工勤人员表
    private final TCalendarInfoMapper calendarInfoMapper;// 食堂运营配置Mapper接口

    private final TWeekTableMapper weekTableMapper;//周排查表

    private final ISysAreaService sysAreaService;

    private final ISysDeptService deptService;

    private final SysRoleMapper roleMapper;
    private final SysDeptMapper deptMapper;

    @Override
    public Map<String, Object> getWeeklySummary(SummaryQuery query) {
        // 确保 endDate 是当天的 23:59:59
        if (ObjectUtils.isNotEmpty(query.getEndDate())){
            normalizeDateRange(query);
        }


        //左侧树选中节点，那么就是这个节点包含的所有主体，如果没有选中就是当前用户权限内所有主体
        if (ObjectUtils.isEmpty(query.getDeptIds())) {
            // 获取当前登录用户的所有角色
            List<SysRole> sysRoles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());

            // 判断是否为系统管理员
            boolean isSystemAdmin = sysRoles.stream()
                    .anyMatch(role -> "admin".equals(role.getRoleKey()));

            List<Long> deptIds = new ArrayList<>();

            if (isSystemAdmin) {
                // 系统管理员权限，查询所有有效的主体
                deptIds = deptService.selectAllValidDepts();
            } else {
                // 其他权限，合并该用户下所有权限对应的主体
                for (SysRole role : sysRoles) {
                    List<Long> roleDepts = deptService.selectDeptListByRoleId(role.getRoleId());
                    deptIds.addAll(roleDepts);
                }
                // 去重
                deptIds = deptIds.stream().distinct().collect(Collectors.toList());
            }
            // 过滤出标签为"学校食堂"的主体
            if (!deptIds.isEmpty()) {
                List<SysDept> depts = deptMapper.selectBatchIdsList(deptIds);
                deptIds = depts.stream()
                        .filter(dept -> "4".equals(dept.getDeptLevel())) // 4代表学校食堂标签
                        .map(SysDept::getDeptId)
                        .collect(Collectors.toList());
            }
            query.setDeptIds(deptIds);
        }


        Map<String, Object> result = new LinkedHashMap<>();
        List<Callable<Map.Entry<String, Object>>> tasks = new ArrayList<>();

        // 添加所有模块的统计任务

        //员工日检表
        tasks.add(() -> new AbstractMap.SimpleEntry<>("employeeDailyCheck", getEmployeeDailyCheckSummary(query)));
        //常规日检表
        tasks.add(() -> new AbstractMap.SimpleEntry<>("routineInspection", getRoutineInspectionSummary(query)));
        //日常快检表
        tasks.add(() -> new AbstractMap.SimpleEntry<>("quickCheck", getQuickCheckSummary(query)));
        //日常抽检表
        tasks.add(() -> new AbstractMap.SimpleEntry<>("randomInspection", getRandomInspectionSummary(query)));
        //餐饮具消毒
        tasks.add(() -> new AbstractMap.SimpleEntry<>("tablewareDisinfection", getTablewareDisinfectionSummary(query)));
        //场所设备消毒
        tasks.add(() -> new AbstractMap.SimpleEntry<>("equipmentDisinfection", getEquipmentDisinfectionSummary(query)));
        //垃圾消毒
        tasks.add(() -> new AbstractMap.SimpleEntry<>("garbageDisinfection", getGarbageDisinfectionSummary(query)));
        //库房贮藏巡检
        tasks.add(() -> new AbstractMap.SimpleEntry<>("storageInspection", getStorageInspectionSummary(query)));
        //设备设施巡检
        tasks.add(() -> new AbstractMap.SimpleEntry<>("facilityInspection", getFacilityInspectionSummary(query)));
        //场所环境巡检
        tasks.add(() -> new AbstractMap.SimpleEntry<>("environmentInspection", getEnvironmentInspectionSummary(query)));
        //食品加工制作过程巡检
        tasks.add(() -> new AbstractMap.SimpleEntry<>("processInspection", getFoodProcessInspectionSummary(query)));
        //每日食谱
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodMenu", getFoodMenuSummary(query)));
        //日常留样
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodSample", getFoodSampleSummary(query)));
        //日常试尝
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodTasting", getFoodTastingSummary(query)));
        //就餐人数
        tasks.add(() -> new AbstractMap.SimpleEntry<>("dinerCount", getDinerCountSummary(query)));
        //餐厨垃圾
        tasks.add(() -> new AbstractMap.SimpleEntry<>("kitchenWaste", getKitchenWasteSummary(query)));

        try {
            List<Future<Map.Entry<String, Object>>> futures = executorService.invokeAll(tasks);
            BigDecimal synthesisScore = BigDecimal.ZERO; // 初始化综合得分
            for (Future<Map.Entry<String, Object>> future : futures) {
                try {
                    Map.Entry<String, Object> entry = future.get();
                    result.put(entry.getKey(), entry.getValue());

                    // 如果返回的是 SummaryItemDTO 或其子类，则累加 finalScore
                    if (entry.getValue() instanceof SummaryItemDTO) {
                        SummaryItemDTO item = (SummaryItemDTO) entry.getValue();
                        if (item.getFinalScore() != null) {
                            synthesisScore = synthesisScore.add(item.getFinalScore());
                        }
                    }
                    // 特殊处理 FoodSampleDTO（继承自 SummaryItemDTO）
                    else if (entry.getValue() instanceof FoodSampleDTO) {
                        FoodSampleDTO item = (FoodSampleDTO) entry.getValue();
                        if (item.getFinalScore() != null) {
                            synthesisScore = synthesisScore.add(item.getFinalScore());
                        }
                    }
                } catch (Exception e) {
                    log.error("处理周总结失败", e);
                }
            }
            // 将综合得分保留3位小数并加入结果
            result.put("synthesisScore", synthesisScore.setScale(3, BigDecimal.ROUND_HALF_UP));

            return result;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("周总结生成中断", e);
        }
    }

    /**
     * 月度总结
     * @param query
     * @return
     */
    @Override
    public Map<String, Object> getMonthSummary(SummaryQuery query) {
        // 确保 endDate 是当天的 23:59:59
        if (ObjectUtils.isNotEmpty(query.getEndDate())){
            normalizeDateRange(query);
        }


        // 左侧树选中节点，那么就是这个节点包含的所有主体，如果没有选中就是当前用户权限内所有主体
        if (ObjectUtils.isEmpty(query.getDeptIds())) {
            List<SysRole> sysRoles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
            boolean isSystemAdmin = sysRoles.stream()
                    .anyMatch(role -> "admin".equals(role.getRoleKey()));

            List<Long> deptIds = new ArrayList<>();
            if (isSystemAdmin) {
                deptIds = deptService.selectAllValidDepts();
            } else {
                for (SysRole role : sysRoles) {
                    List<Long> roleDepts = deptService.selectDeptListByRoleId(role.getRoleId());
                    deptIds.addAll(roleDepts);
                }
                deptIds = deptIds.stream().distinct().collect(Collectors.toList());
            }
            // 过滤出标签为"学校食堂"的主体
            if (!deptIds.isEmpty()) {
                List<SysDept> depts = deptMapper.selectBatchIdsList(deptIds);
                deptIds = depts.stream()
                        .filter(dept -> "4".equals(dept.getDeptLevel())) // 4代表学校食堂标签
                        .map(SysDept::getDeptId)
                        .collect(Collectors.toList());
            }
            query.setDeptIds(deptIds);
        }

        Map<String, Object> result = new LinkedHashMap<>();
        List<Callable<Map.Entry<String, Object>>> tasks = new ArrayList<>();

        // 添加原有模块的任务（与周汇总一致）
        tasks.add(() -> new AbstractMap.SimpleEntry<>("employeeDailyCheck", getEmployeeDailyCheckSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("routineInspection", getRoutineInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("quickCheck", getQuickCheckSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("randomInspection", getRandomInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("tablewareDisinfection", getTablewareDisinfectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("equipmentDisinfection", getEquipmentDisinfectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("garbageDisinfection", getGarbageDisinfectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("storageInspection", getStorageInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("facilityInspection", getFacilityInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("environmentInspection", getEnvironmentInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("processInspection", getFoodProcessInspectionSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodMenu", getFoodMenuSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodSample", getFoodSampleSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("foodTasting", getFoodTastingSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("dinerCount", getDinerCountSummary(query)));
        tasks.add(() -> new AbstractMap.SimpleEntry<>("kitchenWaste", getKitchenWasteSummary(query)));

        // ===================== 新增：周排查模块 =====================
        tasks.add(() -> new AbstractMap.SimpleEntry<>("weeklyCheck", getWeeklyCheckSummary(query)));

        try {
            List<Future<Map.Entry<String, Object>>> futures = executorService.invokeAll(tasks);
            BigDecimal synthesisScore = BigDecimal.ZERO; // 初始化综合得分
            for (Future<Map.Entry<String, Object>> future : futures) {
                try {
                    Map.Entry<String, Object> entry = future.get();
                    result.put(entry.getKey(), entry.getValue());

                    // 如果返回的是 SummaryItemDTO 或其子类，则累加 finalScore
                    if (entry.getValue() instanceof SummaryItemDTO) {
                        SummaryItemDTO item = (SummaryItemDTO) entry.getValue();
                        if (item.getFinalScore() != null) {
                            synthesisScore = synthesisScore.add(item.getFinalScore());
                        }
                    }
                    // 特殊处理 FoodSampleDTO（继承自 SummaryItemDTO）
                    else if (entry.getValue() instanceof FoodSampleDTO) {
                        FoodSampleDTO item = (FoodSampleDTO) entry.getValue();
                        if (item.getFinalScore() != null) {
                            synthesisScore = synthesisScore.add(item.getFinalScore());
                        }
                    }
                } catch (Exception e) {
                    log.error("处理月度总结失败", e);
                }
            }
            // 将综合得分保留3位小数并加入结果
            result.put("synthesisScore", synthesisScore.setScale(3, BigDecimal.ROUND_HALF_UP));
            return result;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("月度总结生成中断", e);
        }
    }

    /**
     * 规范化日期范围：将 endDate 设置为当天的 23:59:59
     */
    private void normalizeDateRange(SummaryQuery query) {
        if (query.getEndDate() != null) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(query.getEndDate());
            calendar.set(Calendar.HOUR_OF_DAY, 23);
            calendar.set(Calendar.MINUTE, 59);
            calendar.set(Calendar.SECOND, 59);
            calendar.set(Calendar.MILLISECOND, 0);
            query.setEndDate(calendar.getTime());
        }
    }

    // ===================== 周排查模块 =====================
    /**
     * 周排查模块统计
     * @param query 查询条件
     * @return SummaryItemDTO
     */
    @Override
    public SummaryItemDTO getWeeklyCheckSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("周排查");
        // 设置初始分值：总分4分(执行2分+合格2分)
        summary.setInitialScores(2.0, 2.0);

        // 1. 应做：这段时间内每一周运营的主体数量叠加（只要该周有至少一天在本月内）
        int shouldDo = calculateWeeklyCheckShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 2. 已做：这段时间内每一周运营且至少完成一次有效周排查的主体数量叠加
        int done = weekTableMapper.countValidWeeklyChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 3. 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 4. 正常：有效周排查记录中整体结果正常的数量
        int normal = weekTableMapper.countNormalWeeklyChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 5. 异常：有效周排查记录中整体结果异常的数量
        int abnormal = weekTableMapper.countAbnormalWeeklyChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();

        return summary;
    }


    // ===================== 员工日检表 =====================
    @Override
    public SummaryItemDTO getEmployeeDailyCheckSummary(SummaryQuery query) throws ParseException {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("员工日检表");
        // 设置初始分值：总分8分(执行4分+合格4分)
        summary.setInitialScores(4.0, 4.0);
        // 修改应做数量计算逻辑：按天统计每个主体下未请假工勤人员的应检次数
        int shouldDo = calculateEmployeeDailyCheckShouldDo(query);
        summary.setShouldDo(shouldDo);
        // 1. 先查询 getDeptIds 下面的所有工勤人员 ID
        List<Long> personIds = practitionersMapper.selectPractitionerIdsByDeptIds(query.getDeptIds());


        // 2. 用工勤人员 ID 去查时间范围内的数据统计（同一工勤人员在同一天有多条数据只算 1 次）
        int done = 0;
        int normal = 0;
        int abnormal = 0;
        if (personIds != null && !personIds.isEmpty()) {
            // 已做数量 = 实际完成的日检记录数（按人员同一天去重）
            done = personCheckMapper.countCompletedChecksWithPersonIds(query.getStartDate(), query.getEndDate(), personIds);

            // 正常数量 = 检查结果正常的记录总数（同一工勤人员一天的多条数据也分别计数）
            normal = personCheckMapper.countNormalChecksWithPersonIds(query.getStartDate(), query.getEndDate(), personIds);

            // 异常数量 = 检查结果异常的记录总数（同一工勤人员一天有多条数据也分别计数）
            abnormal = personCheckMapper.countAbnormalChecksWithPersonIds(query.getStartDate(), query.getEndDate(), personIds);
        }
        summary.setDone(done);
        // 未做数量 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));
        // 异常数量 = 已做 - 正常
        summary.setAbnormal(abnormal);
        // 正常数量
        summary.setNormal(normal);
        // 计算执行率和合格率
        summary.calculateRates();
        // 计算得分
        summary.calculateScores();
        return summary;
    }

    /**
     * 计算员工日检应做数量：按天统计每个主体下未请假且需要日检的工勤人员应检次数
     */
    private int calculateEmployeeDailyCheckShouldDo(SummaryQuery query) throws ParseException {
        // 获取日期范围内的所有日期
        List<Date> dates = getAllDatesBetween(query.getStartDate(), query.getEndDate());
        System.out.println("日期范围:"+ dates);
        int totalShouldDo = 0;

        // 对每一天，统计每个主体下未请假且需要日检的工勤人员应检次数
        for (Date date : dates) {
            System.out.println("日期:"+ date);
            // 获取每个主体当日的餐次配置数（参考calculateShouldDo方法中的逻辑）
            Map<Long, Integer> mealSettingMap = getMealSettingsForDate(date, query.getDeptIds());

            // 获取每个主体未请假且需要日检的工勤人员数量
            Map<Long, Integer> activeStaffMap = getActiveStaffCountForDate(date, query.getDeptIds());

            // 计算当日应检总数
            for (Map.Entry<Long, Integer> entry : mealSettingMap.entrySet()) {
                Long deptId = entry.getKey();
                Integer mealTimes = entry.getValue();
                Integer activeStaffCount = activeStaffMap.getOrDefault(deptId, 0);

                // 当日该主体应检次数 = 未请假且需要日检的工勤人员数 × 当日餐次配置数
                totalShouldDo += activeStaffCount * mealTimes;
            }
        }
        System.out.println("员工日检应做数量: " + totalShouldDo);
        return totalShouldDo;
    }


    /**
     * 获取指定日期各主体的餐次配置数（改进版）
     * 参考calculateShouldDo方法中的逻辑判断主体是否运营
     */
    private Map<Long, Integer> getMealSettingsForDate(Date date, List<Long> deptIds) throws ParseException {
        Map<Long, Integer> mealSettingMap = new HashMap<>();

        if (deptIds == null || deptIds.isEmpty()) {
            return mealSettingMap;
        }

        // 获取该日期各主体的运营配置
        TCalendarInfoQuery tCalendarInfoQuery = new TCalendarInfoQuery();
        tCalendarInfoQuery.setDeptIds(deptIds);
        tCalendarInfoQuery.setDelFlag("0");
        tCalendarInfoQuery.setStartTime(date);
        tCalendarInfoQuery.setEndTime(date);

        List<TCalendarInfoQuery> calendarInfos = calendarInfoMapper.selectTCalendarInfoList(tCalendarInfoQuery);

        // 构建主体ID到配置信息的映射
        Map<Long, TCalendarInfo> configMap = new HashMap<>();
        for (TCalendarInfo info : calendarInfos) {
            configMap.put(info.getDeptId(), info);
        }

        // 对每个主体判断运营情况和餐次数量
        for (Long deptId : deptIds) {
            int mealCount = 0;

            // 如果该日期有配置数据，则根据配置判断运营餐次
            if (configMap.containsKey(deptId)) {
                TCalendarInfo info = configMap.get(deptId);
                if (info.getBreakfast() != null && info.getBreakfast() == 1 ) {
                    mealCount = 1;
                }
                if (info.getLunch() != null && info.getLunch() == 1) {
                    mealCount = 1;
                }
                if (info.getDinner() != null && info.getDinner() == 1) {
                    mealCount = 1;
                }
            }
            // 如果该日期没有配置数据，默认为三餐运营（根据业务实际情况调整）
            else {
                mealCount = 1; // 默认三餐
            }

            mealSettingMap.put(deptId, mealCount);
        }

        return mealSettingMap;
    }

    /**
     * 获取指定日期各主体未请假且需要日检的工勤人员数量
     */
    private Map<Long, Integer> getActiveStaffCountForDate(Date date, List<Long> deptIds) {
        Map<Long, Integer> activeStaffMap = new HashMap<>();
        // 创建结束时间（当天23:59:59）
        Calendar endOfDay = Calendar.getInstance();
        endOfDay.setTime(date);
        endOfDay.set(Calendar.HOUR_OF_DAY, 23);
        endOfDay.set(Calendar.MINUTE, 59);
        endOfDay.set(Calendar.SECOND, 59);
        endOfDay.set(Calendar.MILLISECOND, 999);
        Date endDate = endOfDay.getTime();
        // 查询指定日期各主体未请假且需要日检的工勤人员数量
        List<Map<String, Object>> results = personCheckMapper.getActiveStaffCountForDate(date, endDate,deptIds);

        for (Map<String, Object> result : results) {
            Long deptId = ((Number) result.get("deptId")).longValue();
            Integer staffCount = ((Number) result.get("staffCount")).intValue();
            activeStaffMap.put(deptId, staffCount);
        }

        return activeStaffMap;
    }


    // ===================== 常规日检表 =====================
    @Override
    public SummaryItemDTO getRoutineInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("常规日检表");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效日检的主体数量累加
        int done = routineInspectionMapper.countValidRoutineInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效日检记录中结果正常的数量
        int normal = routineInspectionMapper.countNormalRoutineInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效日检记录中结果异常的数量
        int abnormal = routineInspectionMapper.countAbnormalRoutineInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }

    /**
     * 计算常规日检应做数量：按天统计实际运营的主体数量
     */
    private int calculateRoutineInspectionShouldDo(SummaryQuery query) {
        // 获取日期范围内的所有日期
        List<Date> dates = getAllDatesBetween(query.getStartDate(), query.getEndDate());
        int totalShouldDo = 0;

        // 对每一天，统计有菜谱记录的主体数量
        for (Date date : dates) {
            int dailyCount = foodMenuMapper.countEntitiesWithMenuByDate(date, query.getDeptIds());
            totalShouldDo += dailyCount;
        }

        return totalShouldDo;
    }

    // ===================== 日常快检表 =====================
    @Override
    public SummaryItemDTO getQuickCheckSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("日常快检表");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效快检的主体数量累加
        int done = quickCheckMapper.countValidQuickChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效快检记录中结果正常的数量
        int normal = quickCheckMapper.countNormalQuickChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效快检记录中结果异常的数量
        int abnormal = quickCheckMapper.countAbnormalQuickChecks(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();

        return summary;
    }

    // ===================== 日常抽检表 =====================
    @Override
    public SummaryItemDTO getRandomInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("日常抽检表");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);
        System.out.println("开始时间"+query.getStartDate());
        System.out.println("结束时间"+query.getEndDate());
        // 已做: 每一天至少完成一次有效抽检的主体数量累加
        int done = randomInspectionMapper.countValidRandomInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效抽检记录中结果正常的数量
        int normal = randomInspectionMapper.countNormalRandomInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效抽检记录中结果异常的数量
        int abnormal = randomInspectionMapper.countAbnormalRandomInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 餐饮具消毒 =====================
    @Override
    public SummaryItemDTO getTablewareDisinfectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("餐饮具消毒");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效餐饮具消毒的主体数量累加
        int done = tablewareDisinfectionMapper.countValidDisinfections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 场所设备消毒 =====================
    @Override
    public SummaryItemDTO getEquipmentDisinfectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("场所设备消毒");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效场所设备消毒的主体数量累加
        int done = equipmentDisinfectionMapper.countValidDisinfections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 垃圾消毒 =====================
    @Override
    public SummaryItemDTO getGarbageDisinfectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("垃圾消毒");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效垃圾消毒的主体数量累加
        int done = garbageDisinfectionMapper.countValidDisinfections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }

    // ===================== 库房贮藏巡检 =====================
    @Override
    public SummaryItemDTO getStorageInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("库房贮藏巡检");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效库房贮藏巡检的主体数量累加
        int done = storageInspectionMapper.countValidInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效库房贮藏巡检记录中结果达标的数量
        int normal = storageInspectionMapper.countNormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效库房贮藏巡检记录中结果不达标的数量
        int abnormal = storageInspectionMapper.countAbnormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 设备设施巡检 =====================
    @Override
    public SummaryItemDTO getFacilityInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("设备设施巡检");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效设备设施巡检的主体数量累加
        int done = facilityInspectionMapper.countValidInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效设备设施巡检记录中整体结果正常的数量
        int normal = facilityInspectionMapper.countNormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效设备设施巡检记录中整体结果异常的数量
        int abnormal = facilityInspectionMapper.countAbnormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }

    // ===================== 场所环境巡检 =====================
    @Override
    public SummaryItemDTO getEnvironmentInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("场所环境巡检");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天至少完成一次有效场所环境巡检的主体数量累加
        int done = environmentInspectionMapper.countValidInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效场所环境巡检记录中整体结果正常的数量
        int normal = environmentInspectionMapper.countNormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效场所环境巡检记录中整体结果异常的数量
        int abnormal = environmentInspectionMapper.countAbnormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 食品加工制作过程巡检 =====================
    @Override
    public SummaryItemDTO getFoodProcessInspectionSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("食品加工制作过程巡检");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应做: 每一天运营的主体数量累加（只要主体在当天运营，不论运营几餐，都应至少做一次巡检）
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天运营的主体且至少完成一次有效加工过程巡检的数量累加
        int done = processInspectionMapper.countValidInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 正常: 有效加工过程巡检记录中整体结果正常的数量
        int normal = processInspectionMapper.countNormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normal);

        // 异常: 有效加工过程巡检记录中整体结果异常的数量
        int abnormal = processInspectionMapper.countAbnormalInspections(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setAbnormal(abnormal);

        // 计算执行率和合格率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }

    /**
     *
     * 修改逻辑：
     * 1. 如果主体在查询时间范围内没有任何运营配置数据，则认为该主体在此期间每天都运营,进行累加
     * 2. 如果在查询时间范围内每天都有数据，则根据具体配置判断是否运营,进行累加
     * 3. 混合情况：部分日期有数据（需判断是否供应），部分日期无数据（默认运营）
     */
    private int calculateShouldDo(SummaryQuery query) {
        List<Long> deptIds = query.getDeptIds();
        if (deptIds == null || deptIds.isEmpty()) {
            return 0;
        }

        Date startDate = query.getStartDate();
        Date endDate = query.getEndDate();
        int totalShouldDo = 0;

        // 获取日期范围内的所有日期
        List<Date> dates = getAllDatesBetween(startDate, endDate);

        // 对每个主体分别计算运营天数
        for (Long deptId : deptIds) {
            // 获取该主体在时间范围内的运营配置数据
            Map<String, TCalendarInfo> configMap = new HashMap<>();
            TCalendarInfoQuery tCalendarInfoQuery = new TCalendarInfoQuery();
            tCalendarInfoQuery.setDeptId(deptId);
            tCalendarInfoQuery.setDelFlag("0");
            tCalendarInfoQuery.setStartTime(startDate);
            tCalendarInfoQuery.setEndTime(endDate);
            List<TCalendarInfoQuery> calendarInfos = calendarInfoMapper.selectTCalendarInfoList(tCalendarInfoQuery);

            // 构建日期映射：日期字符串 -> 配置信息
            for (TCalendarInfo info : calendarInfos) {
                configMap.put(info.getDate(), info);
            }

            // 对每一天，判断该主体是否运营
            for (Date date : dates) {
                String dateString = new java.text.SimpleDateFormat("yyyy-MM-dd").format(date);

                // 如果该日期有配置数据，则根据配置判断是否运营
                if (configMap.containsKey(dateString)) {
                    TCalendarInfo info = configMap.get(dateString);
                    boolean isOperating = (info.getBreakfast() != null && info.getBreakfast() == 1) ||
                            (info.getLunch() != null && info.getLunch() == 1) ||
                            (info.getDinner() != null && info.getDinner() == 1);
                    if (isOperating) {
                        totalShouldDo++;
                    }
                }
                // 如果该日期没有配置数据，则默认为运营状态
                else {
                    totalShouldDo++;
                }
            }
        }

        return totalShouldDo;
    }


    @Override
    public SummaryItemDTO getFoodMenuSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("每日食谱");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 主体数量*天数
        // 1. 计算开始时间和结束时间之间的天数
        long daysBetween = (query.getEndDate().getTime() - query.getStartDate().getTime()) / (24 * 60 * 60 * 1000) + 1;

        // 2. 获取 getDeptIds 的数量
        int deptCount = query.getDeptIds() != null ? query.getDeptIds().size() : 0;

        // 3. 应做 = getDeptIds 的数量 × 天数
        int shouldDo = deptCount * (int) daysBetween;
        summary.setShouldDo(shouldDo);

        // 已做: 在应做范围内，确实录入了菜谱记录的餐次数量
        int done = foodMenuMapper.countMenusWithRecipes(
                query.getStartDate(),
                query.getEndDate(),
                query.getDeptIds()
        );
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 日常留样 =====================
    @Override
    public FoodSampleDTO getFoodSampleSummary(SummaryQuery query) {
        FoodSampleDTO summary = new FoodSampleDTO();
        summary.setModuleName("日常留样");
        // 设置初始分值：总分8分(执行4分+合格4分)
        summary.setInitialScores(4.0, 4.0);
        // 应留样: 时间范围内所有主体对应的有效菜谱
        int shouldSample = foodMenuMapper.countValidMenus(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setShouldSample(shouldSample);

        // 已留样: 时间范围内所有主体对应的有效菜谱且做了留样的数量
        int sampled = foodMenuMapper.countSampledMenus(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setSampled(sampled);

        // 未留样: 应留样 - 已留样
        summary.setNotSampled(Math.max(0, shouldSample - sampled));

        // 已销样: 上面已留样范围内找出已经销样的所有菜谱数量
        int destroyed = foodMenuMapper.countDestroyedSamples(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDestroyed(destroyed);

        // 正常销样: 上面已销样范围内留样时间超48小时
        int normalDestroyed = foodMenuMapper.countNormalDestroyedSamples(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormalDestroyed(normalDestroyed);

        // 提前销样: 上面已销样 - 上面正常销样
        summary.setEarlyDestroyed(Math.max(0, destroyed - normalDestroyed));

        // 计算留样率
        summary.calculateRates();

        // 计算销样相关比率
        summary.calculateSampleRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 日常试尝 =====================
    @Override
    public SummaryItemDTO getFoodTastingSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("日常试尝");
        // 设置初始分值：总分6分(执行3分+合格3分)
        summary.setInitialScores(3.0, 3.0);
        // 应试尝: 时间范围内所有主体对应的有效菜谱
        int shouldTaste = foodMenuMapper.countValidMenus(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setShouldDo(shouldTaste);

        // 已试尝: 时间范围内所有主体对应的有效菜谱且已经试尝
        int tasted = foodMenuMapper.countTastedMenus(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(tasted);

        // 未试尝: 应试尝 - 已试尝
        summary.setNotDone(Math.max(0, shouldTaste - tasted));

        // 试尝正常: 上面已试尝范围内的试尝结果正常的数量
        int normalTaste = foodMenuMapper.countNormalTastedMenus(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setNormal(normalTaste);

        // 试尝异常: 已试尝 - 试尝正常
        summary.setAbnormal(Math.max(0, tasted - normalTaste));

        // 计算执行率和正常率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }

    // ===================== 就餐人数 =====================
    @Override
    public SummaryItemDTO getDinerCountSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("就餐人数");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 每一天运营的主体数量累加（只要主体在当天运营，不论运营几餐，都应至少做一条就餐人数上报）
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天运营的主体且至少完成一次有效就餐人数上报的数量累加
        int done = dinerCountMapper.countValidDinerCounts(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 餐厨垃圾 =====================
    @Override
    public SummaryItemDTO getKitchenWasteSummary(SummaryQuery query) {
        SummaryItemDTO summary = new SummaryItemDTO();
        summary.setModuleName("餐厨垃圾");
        // 设置初始分值：总分6分(执行6分+合格0分)
        summary.setInitialScores(6.0, 0.0);
        // 应做: 每一天运营的主体数量累加（只要主体在当天运营，不论运营几餐，都应至少做一条餐厨垃圾上报）
        int shouldDo = calculateShouldDo(query);
        summary.setShouldDo(shouldDo);

        // 已做: 每一天运营的主体且至少完成一次有效餐厨垃圾上报的数量累加
        int done = kitchenWasteMapper.countValidRecords(query.getStartDate(), query.getEndDate(), query.getDeptIds());
        summary.setDone(done);

        // 未做 = 应做 - 已做
        summary.setNotDone(Math.max(0, shouldDo - done));

        // 计算执行率
        summary.calculateRates();

        // 计算得分
        summary.calculateScores();
        return summary;
    }


    // ===================== 辅助方法 =====================

    /**
     * 获取两个日期之间的所有日期列表
     */
    private List<Date> getAllDatesBetween(Date startDate, Date endDate) {
        List<Date> dates = new ArrayList<>();

        // 防御性检查
        if (startDate == null || endDate == null) {
            log.warn("startDate 或 endDate 为 null");
            return dates;
        }

        // 如果 startDate 晚于 endDate，交换它们
        if (startDate.after(endDate)) {
            Date temp = startDate;
            startDate = endDate;
            endDate = temp;
        }

        // 将 startDate 设置为当天的 00:00:00
        Calendar startCal = Calendar.getInstance();
        startCal.setTime(startDate);
        startCal.set(Calendar.HOUR_OF_DAY, 0);
        startCal.set(Calendar.MINUTE, 0);
        startCal.set(Calendar.SECOND, 0);
        startCal.set(Calendar.MILLISECOND, 0);

        // 将 endDate 设置为当天的 23:59:59
        Calendar endCal = Calendar.getInstance();
        endCal.setTime(endDate);
        endCal.set(Calendar.HOUR_OF_DAY, 23);
        endCal.set(Calendar.MINUTE, 59);
        endCal.set(Calendar.SECOND, 59);
        endCal.set(Calendar.MILLISECOND, 999);

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(startCal.getTime());

        while (!calendar.getTime().after(endCal.getTime())) {
            dates.add(calendar.getTime());
            calendar.add(Calendar.DAY_OF_MONTH, 1);
        }

        return dates;
    }

    /**
     * 计算周排查应做数量：按周统计实际运营的主体数量
     * 修改逻辑：
     * 1. 如果主体在周时段查询时间范围内没有任何运营配置数据，则认为该主体在运营,进行累加
     * 2. 如果在一周(周时段)查询时间范围内每天都有数据，则根据具体配置判断是否运营,有一个供应就是运营
     * 3. 混合情况：部分日期有数据（需判断是否供应），部分日期无数据（默认运营）,有一个供应就是运营
     *
     * 规则：只要这一周(周时段)这个主体运营，都不管你运营几天，也不管你运营几餐，
     * 那么都认为应该这周至少做一次周排查。因此把这段时间每一周运营的主体叠加起来的数量就是应做的数量，
     * 其实是每一周符合要求的主体数量叠加了
     */
    private int calculateWeeklyCheckShouldDo(SummaryQuery query) {
        List<Long> deptIds = query.getDeptIds();
        if (deptIds == null || deptIds.isEmpty()) {
            return 0;
        }

        Date startDate = query.getStartDate();
        Date endDate = query.getEndDate();
        int totalShouldDo = 0;

        // 获取所有可能的周（从startDate到endDate之间的所有周）
        Set<Date> weekStartDates = new HashSet<>();
        Calendar cal = Calendar.getInstance();
        cal.setTime(startDate);

        // 生成所有周的起始日（每周一）
        while (!cal.getTime().after(endDate)) {
            // 当前日期是周一吗？如果不是，跳到本周一
            int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
            if (dayOfWeek != Calendar.MONDAY) {
                cal.add(Calendar.DAY_OF_MONTH, Calendar.MONDAY - dayOfWeek);
            }

            Date weekStart = cal.getTime();
            Date weekEnd = addDays(weekStart, 6); // 周日

            // 判断该周是否与 [startDate, endDate] 有交集
            if (dateOverlap(weekStart, weekEnd, startDate, endDate)) {
                weekStartDates.add(weekStart);
            }

            // 下一周
            cal.add(Calendar.DAY_OF_MONTH, 7);
        }

        // 对每个主体分别计算在各周是否运营
        for (Long deptId : deptIds) {
            // 获取该主体在时间范围内的运营配置数据
            Map<String, TCalendarInfo> configMap = new HashMap<>();
            TCalendarInfoQuery tCalendarInfoQuery = new TCalendarInfoQuery();
            tCalendarInfoQuery.setDeptId(deptId);
            tCalendarInfoQuery.setDelFlag("0");
            tCalendarInfoQuery.setStartTime(startDate);
            tCalendarInfoQuery.setEndTime(endDate);
            List<TCalendarInfoQuery> calendarInfos = calendarInfoMapper.selectTCalendarInfoList(tCalendarInfoQuery);

            // 构建日期映射：日期字符串 -> 配置信息
            for (TCalendarInfo info : calendarInfos) {
                configMap.put(info.getDate(), info);
            }

            // 对每一周，判断该主体是否运营
            for (Date weekStart : weekStartDates) {
                Date weekEnd = addDays(weekStart, 6);

                // 确定实际检查范围（取周范围和查询范围的交集）
                Date actualStart = weekStart.before(startDate) ? startDate : weekStart;
                Date actualEnd = weekEnd.after(endDate) ? endDate : weekEnd;

                boolean isOperatingInWeek = false;

                // 检查该周内是否有运营日
                Calendar weekCal = Calendar.getInstance();
                weekCal.setTime(actualStart);

                while (!weekCal.getTime().after(actualEnd)) {
                    String dateString = new java.text.SimpleDateFormat("yyyy-MM-dd").format(weekCal.getTime());

                    // 如果该日期有配置数据，则根据配置判断是否运营
                    if (configMap.containsKey(dateString)) {
                        TCalendarInfo info = configMap.get(dateString);
                        boolean isOperating = (info.getBreakfast() != null && info.getBreakfast() == 1) ||
                                (info.getLunch() != null && info.getLunch() == 1) ||
                                (info.getDinner() != null && info.getDinner() == 1);
                        if (isOperating) {
                            isOperatingInWeek = true;
                            break; // 只要有一天运营即可
                        }
                    }
                    // 如果该日期没有配置数据，则默认为运营状态
                    else {
                        isOperatingInWeek = true;
                        break; // 默认运营
                    }

                    weekCal.add(Calendar.DAY_OF_MONTH, 1);
                }

                // 如果该主体在该周运营，则计入应做数量
                if (isOperatingInWeek) {
                    totalShouldDo++;
                }
            }
        }

        return totalShouldDo;
    }


    /**
     * 判断两个日期区间是否有交集
     */
    private boolean dateOverlap(Date start1, Date end1, Date start2, Date end2) {
        return start1.compareTo(end2) <= 0 && end1.compareTo(start2) >= 0;
    }

    /**
     * 给日期加上指定天数
     */
    private Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, days);
        return cal.getTime();
    }


}

