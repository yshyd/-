package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TDeptSupplerQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDeptSuppler;
import com.fyzs.web.service.ITDeptSupplerService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 供应商Controller
 * 
 * @author ysh
 * @date 2025-10-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/suppler")
public class TDeptSupplerController extends BaseController
{

    private final ITDeptSupplerService tDeptSupplerService;

    /**
     * 查询供应商列表
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDeptSupplerQuery tDeptSuppler)
    {
        startPage();
        List<TDeptSupplerQuery> list = tDeptSupplerService.selectTDeptSupplerList(tDeptSuppler);
        return getDataTable(list);
    }


    /**
     * 下拉供应商列表
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TDeptSupplerQuery tDeptSuppler)
    {
        List<TDeptSupplerQuery> list = tDeptSupplerService.selectTDeptSupplerList(tDeptSuppler);
        return getDataTable(list);
    }

    /**
     * 导出供应商列表
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:export')")
    @Log(title = "供应商", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDeptSupplerQuery tDeptSuppler)
    {
        List<TDeptSupplerQuery> list = tDeptSupplerService.selectTDeptSupplerList(tDeptSuppler);
        ExcelUtil<TDeptSupplerQuery> util = new ExcelUtil<TDeptSupplerQuery>(TDeptSupplerQuery.class);
        util.exportExcel(response, list, "供应商数据");
    }

    /**
     * 获取供应商详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDeptSupplerService.selectTDeptSupplerById(id));
    }

    /**
     * 新增供应商
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:add')")
    @Log(title = "供应商", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDeptSuppler tDeptSuppler)
    {

        return toAjax(tDeptSupplerService.save(tDeptSuppler));
    }

    /**
     * 修改供应商
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:edit')")
    @Log(title = "供应商", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDeptSuppler tDeptSuppler)
    {
        return toAjax(tDeptSupplerService.updateTDeptSuppler(tDeptSuppler));
    }

    /**
     * 删除供应商
     */
    //@PreAuthorize("@ss.hasPermi('web:suppler:remove')")
    @Log(title = "供应商", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDeptSupplerService.deleteTDeptSupplerByIds(ids));
    }
}
