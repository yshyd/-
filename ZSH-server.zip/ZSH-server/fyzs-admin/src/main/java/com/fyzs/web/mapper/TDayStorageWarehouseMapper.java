package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayStorageWarehouse;
import com.fyzs.web.entity.query.TDayStorageWarehouseQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常巡检-库房贮藏巡检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@org.apache.ibatis.annotations.Mapper
public interface TDayStorageWarehouseMapper  extends BaseMapper<TDayStorageWarehouse>
{
    /**
     * 查询学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param id 学校食堂日管控-日常巡检-库房贮藏巡检主键
     * @return 学校食堂日管控-日常巡检-库房贮藏巡检
     */
    public TDayStorageWarehouseQuery selectTDayStorageWarehouseById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-库房贮藏巡检列表
     *
     * @return 学校食堂日管控-日常巡检-库房贮藏巡检集合
     */
    public List<TDayStorageWarehouseQuery> selectTDayStorageWarehouseList(TDayStorageWarehouseQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param tDayStorageWarehouse 学校食堂日管控-日常巡检-库房贮藏巡检
     * @return 结果
     */
    public int insertTDayStorageWarehouse(TDayStorageWarehouse tDayStorageWarehouse);

    /**
     * 修改学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param tDayStorageWarehouse 学校食堂日管控-日常巡检-库房贮藏巡检
     * @return 结果
     */
    public int updateTDayStorageWarehouse(TDayStorageWarehouse tDayStorageWarehouse);

    /**
     * 删除学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param id 学校食堂日管控-日常巡检-库房贮藏巡检主键
     * @return 结果
     */
    public int deleteTDayStorageWarehouseById(Long id);

    /**
     * 批量删除学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayStorageWarehouseByIds(Long[] ids);

    int countValidInspections(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    int countNormalInspections(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    int countAbnormalInspections(@Param("startDate") Date startDate,
                                 @Param("endDate") Date endDate,
                                 @Param("deptIds") List<Long> deptIds);
}
