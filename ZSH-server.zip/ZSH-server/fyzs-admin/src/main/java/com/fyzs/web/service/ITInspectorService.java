package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TInspector;
import com.fyzs.web.entity.query.TInspectorQuery;

/**
 * 督察记录Service接口
 * 
 * @author ysh
 * @date 2025-12-02
 */
public interface ITInspectorService extends IService<TInspector>
{
    /**
     * 查询督察记录
     * 
     * @param id 督察记录主键
     * @return 督察记录
     */
    public TInspectorQuery selectTInspectorById(Long id);

    /**
     * 查询督察记录列表
     * 
     * @param tInspector 督察记录
     * @return 督察记录集合
     */
    public List<TInspectorQuery> selectTInspectorList(TInspectorQuery tInspector);

    /**
     * 新增督察记录
     * 
     * @param tInspector 督察记录
     * @return 结果
     */
    public int insertTInspector(TInspector tInspector);

    /**
     * 修改督察记录
     * 
     * @param tInspector 督察记录
     * @return 结果
     */
    public int updateTInspector(TInspector tInspector);

    /**
     * 批量删除督察记录
     * 
     * @param ids 需要删除的督察记录主键集合
     * @return 结果
     */
    public int deleteTInspectorByIds(Long[] ids);

    /**
     * 删除督察记录信息
     * 
     * @param id 督察记录主键
     * @return 结果
     */
    public int deleteTInspectorById(Long id);

    int cancel(TInspector tInspector);
}
