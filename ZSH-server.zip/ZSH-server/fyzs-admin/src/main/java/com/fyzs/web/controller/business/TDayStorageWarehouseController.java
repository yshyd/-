package com.fyzs.web.controller.business;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TDayStorageWarehouseQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayStorageWarehouse;
import com.fyzs.web.service.ITDayStorageWarehouseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常巡检-库房贮藏巡检Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/storage/warehouse")
public class TDayStorageWarehouseController extends BaseController
{

    private final ITDayStorageWarehouseService warehouseService;

    private final ITAlarmService alarmService;

    /**
     * 查询学校食堂日管控-日常巡检-库房贮藏巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayStorageWarehouseQuery query)
    {
        startPage();
        List<TDayStorageWarehouseQuery> list = warehouseService.selectTDayStorageWarehouseList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常巡检-库房贮藏巡检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:export')")
    @Log(title = "学校食堂日管控-日常巡检-库房贮藏巡检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayStorageWarehouseQuery query)
    {
        List<TDayStorageWarehouseQuery> list = warehouseService.selectTDayStorageWarehouseList(query);
        ExcelUtil<TDayStorageWarehouseQuery> util = new ExcelUtil<TDayStorageWarehouseQuery>(TDayStorageWarehouseQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常巡检-库房贮藏巡检数据");
    }

    /**
     * 获取学校食堂日管控-日常巡检-库房贮藏巡检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(warehouseService.selectTDayStorageWarehouseById(id));
    }

    /**
     * 新增学校食堂日管控-日常巡检-库房贮藏巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:add')")
    @Log(title = "学校食堂日管控-日常巡检-库房贮藏巡检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayStorageWarehouse tDayStorageWarehouse)
    {
        return toAjax(warehouseService.insertTDayStorageWarehouse(tDayStorageWarehouse));
    }

    /**
     * 修改学校食堂日管控-日常巡检-库房贮藏巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:edit')")
    @Log(title = "学校食堂日管控-日常巡检-库房贮藏巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayStorageWarehouse tDayStorageWarehouse)
    {
        return toAjax(warehouseService.updateTDayStorageWarehouse(tDayStorageWarehouse));
    }

    /**
     * 启用/作废(id,delFlag)
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:edit')")
    @Log(title = "学校食堂日管控-日常巡检-库房贮藏巡检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayStorageWarehouse tDayStorageWarehouse)
    {

        return toAjax(warehouseService.cancel(tDayStorageWarehouse));
    }

    /**
     * 删除学校食堂日管控-日常巡检-库房贮藏巡检
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:remove')")
    @Log(title = "学校食堂日管控-日常巡检-库房贮藏巡检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(warehouseService.deleteTDayStorageWarehouseByIds(ids));
    }
}
