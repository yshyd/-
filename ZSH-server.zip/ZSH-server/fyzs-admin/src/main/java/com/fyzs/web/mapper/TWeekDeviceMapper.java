package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TWeekDevice;
import com.fyzs.web.entity.query.TWeekDeviceQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 学校食堂周排查-设备设施运行风险排查Mapper接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
@Mapper
public interface TWeekDeviceMapper  extends BaseMapper<TWeekDevice>
{
    /**
     * 查询学校食堂周排查-设备设施运行风险排查
     * 
     * @param id 学校食堂周排查-设备设施运行风险排查主键
     * @return 学校食堂周排查-设备设施运行风险排查
     */
    public TWeekDeviceQuery selectTWeekDeviceById(Long id);

    /**
     * 查询学校食堂周排查-设备设施运行风险排查列表
     * 
     * @param tWeekDevice 学校食堂周排查-设备设施运行风险排查
     * @return 学校食堂周排查-设备设施运行风险排查集合
     */
    public List<TWeekDeviceQuery> selectTWeekDeviceList(TWeekDeviceQuery tWeekDevice);

    /**
     * 新增学校食堂周排查-设备设施运行风险排查
     * 
     * @param tWeekDevice 学校食堂周排查-设备设施运行风险排查
     * @return 结果
     */
    public int insertTWeekDevice(TWeekDevice tWeekDevice);

    /**
     * 修改学校食堂周排查-设备设施运行风险排查
     * 
     * @param tWeekDevice 学校食堂周排查-设备设施运行风险排查
     * @return 结果
     */
    public int updateTWeekDevice(TWeekDevice tWeekDevice);

    /**
     * 删除学校食堂周排查-设备设施运行风险排查
     * 
     * @param id 学校食堂周排查-设备设施运行风险排查主键
     * @return 结果
     */
    public int deleteTWeekDeviceById(Long id);

    /**
     * 批量删除学校食堂周排查-设备设施运行风险排查
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTWeekDeviceByIds(Long[] ids);
}
