package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 温湿度监测报警仪实时温湿度对象 t_th_status
 *
 * @author ysh
 * @date 2026-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_th_status")
public class TThStatus implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 在线状态 */
        @Schema(description = "在线状态 0-在线，1-离线")
        @Excel(name = "在线状态 0-在线，1-离线")
        private Integer onlineTatus;

        /** 对应t_device中的serial_number */
        @Schema(description = "对应t_device中的serial_number")
        @Excel(name = "对应t_device中的serial_number")
        private String serialNumber;

        /** 实时温度(℃) */
        @Schema(description = "实时温度(℃)")
        @Excel(name = "实时温度(℃)")
        private String temperature;

        /** 实时湿度(%RH) */
        @Schema(description = "实时湿度(%RH)")
        @Excel(name = "实时湿度(%RH)")
        private String humidity;

        /** 更新时间(当前系统时间) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "更新时间(当前系统时间)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "更新时间(当前系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
