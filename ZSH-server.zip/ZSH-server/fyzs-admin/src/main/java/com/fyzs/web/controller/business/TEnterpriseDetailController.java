package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.fyzs.system.domain.TEnterpriseDetail;
import com.fyzs.system.domain.query.TEnterpriseDetailQuery;
import com.fyzs.system.service.ITEnterpriseDetailService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;

import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 企业详细信息Controller
 * 
 * @author ysh
 * @date 2025-10-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/enterprise")
public class TEnterpriseDetailController extends BaseController
{
    private  final ITEnterpriseDetailService tEnterpriseDetailService;

    /**
     * 查询企业详细信息列表
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:list')")
    @GetMapping("/list")
    public TableDataInfo list(TEnterpriseDetailQuery tEnterpriseDetail)
    {
        startPage();
        List<TEnterpriseDetailQuery> list = tEnterpriseDetailService.selectTEnterpriseDetailList(tEnterpriseDetail);
        return getDataTable(list);
    }

    /**
     * 导出企业详细信息列表
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:export')")
    @Log(title = "企业详细信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TEnterpriseDetailQuery tEnterpriseDetail)
    {
        List<TEnterpriseDetailQuery> list = tEnterpriseDetailService.selectTEnterpriseDetailList(tEnterpriseDetail);
        ExcelUtil<TEnterpriseDetailQuery> util = new ExcelUtil<TEnterpriseDetailQuery>(TEnterpriseDetailQuery.class);
        util.exportExcel(response, list, "企业详细信息数据");
    }

    /**
     * 获取企业详细信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tEnterpriseDetailService.selectTEnterpriseDetailById(id));
    }

    /**
     * 获取企业详细信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:query')")
    @GetMapping(value = "/info/{deptId}")
    public AjaxResult getDeptInfo(@PathVariable("deptId") Long deptId)
    {
        LambdaQueryWrapper<TEnterpriseDetail> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(TEnterpriseDetail::getDeptId, deptId);
        return success(tEnterpriseDetailService.getOne(queryWrapper));
    }

    /**
     * 新增企业详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:add')")
    @Log(title = "企业详细信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TEnterpriseDetail tEnterpriseDetail)
    {
        return toAjax(tEnterpriseDetailService.save(tEnterpriseDetail));
    }

    /**
     * 修改企业详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:edit')")
    @Log(title = "企业详细信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TEnterpriseDetail tEnterpriseDetail)
    {
        return toAjax(tEnterpriseDetailService.updateById(tEnterpriseDetail));
    }

    /**
     * 删除企业详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:detail:remove')")
    @Log(title = "企业详细信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tEnterpriseDetailService.deleteTEnterpriseDetailByIds(ids));
    }
}
