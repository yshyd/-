package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 可视化视频监控实时调用信息对象 t_camera_live
 *
 * @author ysh
 * @date 2025-10-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_live")
public class TCameraLive implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    @Schema(description = "管理t_camera的id")
    private Long cameraId;

    /**
     * 关联可视化视频监控设备基本信息表监控设备编码
     */
    @Schema(description = "关联可视化视频监控设备基本信息表监控设备编码")
    @Excel(name = "关联可视化视频监控设备基本信息表监控设备编码")
    private String devId;

    /**
     * 关联可视化视频监控设备基本信息表监控设备业务编码。
     */
    @Schema(description = "关联可视化视频监控设备基本信息表监控设备业务编码。")
    @Excel(name = "关联可视化视频监控设备基本信息表监控设备业务编码。")
    private String bissId;

    /**
     * 在线监控视频地址
     */
    @Schema(description = "在线监控视频地址")
    @Excel(name = "在线监控视频地址")
    private String videoUel;

    /**
     * 在线监控地址子码流
     */
    @Schema(description = "在线监控地址子码流")
    @Excel(name = "在线监控地址子码流")
    private String videoUelItem;

    /**
     * rtmp在线监控地址主码流
     */
    @Schema(description = "rtmp在线监控地址主码流")
    @Excel(name = "rtmp在线监控地址主码流")
    private String rtmpUel;

    /**
     * rtmp在线监控地址子码流
     */
    @Schema(description = "rtmp在线监控地址子码流")
    @Excel(name = "rtmp在线监控地址子码流")
    private String ttmpUelItm;

    /**
     * 创建人ID
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人ID")
    @Excel(name = "创建人ID")
    private Long createUser;

    /**
     * 创建人
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人")
    @Excel(name = "创建人")
    private String createName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date createDate;

    /**
     * 修改人ID
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人ID")
    @Excel(name = "修改人ID")
    private Long updateUser;

    /**
     * 修改人
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人")
    @Excel(name = "修改人")
    private String updateName;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date updateDate;

    /**
     * 0启用1禁用
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "0启用1禁用")
    private Long delFlag;

}
