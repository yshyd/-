package com.fyzs.web.entity.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fyzs.web.entity.TFoodRecipse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

@EqualsAndHashCode(callSuper = true)
@Data
public class TFoodRecipseDTO extends TFoodRecipse {

    /**
     * 一周的开始时间
     */
    @JsonIgnore
    private String startTime;

    /**
     * 一周的结束时间
     */
    @JsonIgnore
    private String endTime;

    /**
     * 时间
     */
    @JsonIgnore
    private Date releaseTime;

    /**
     * 菜谱集合
     */
    @Schema(description = "菜谱集合")
    private String foodNames;

}
