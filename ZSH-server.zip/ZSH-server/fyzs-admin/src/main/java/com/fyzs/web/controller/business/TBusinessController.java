package com.fyzs.web.controller.business;

import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.page.TableDataInfo;
import com.fyzs.web.entity.TBusiness;
import com.fyzs.web.entity.query.TBusinessQuery;
import com.fyzs.web.entity.query.TCalendarInfoQuery;
import com.fyzs.web.entity.vo.TBusinessVO;
import com.fyzs.web.service.ITBusinessService;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 核算Controller
 *
 * @author ysh
 * @date 2025-10-31
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/business")
public class TBusinessController extends BaseController {

    private final ITBusinessService businessService ;

    /**
     * 查询主体下核算的列表
     */
    @RequestMapping("/list")
    public TableDataInfo list(TBusinessQuery businessQuery ){
        startPage();
        List<TBusinessQuery> list = businessService.selectBusinessList(businessQuery);
        return getDataTable(list);
    }

    /**
     * 详情列表
     */
    @RequestMapping("/detailList")
    public TableDataInfo detailList(TBusinessQuery businessQuery ){
        startPage();
        List<TBusinessVO> list = businessService.selectBusinessDetailList(businessQuery);
        return getDataTable(list);
    }
}
