package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 主体商品库对象 t_dept_commodity
 *
 * @author ysh
 * @date 2025-10-31
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_dept_commodity")
public class TDeptCommodity implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 主键id */
    @Schema(description = "主键id")
    private Long id;

    /** 主体id */
    @Schema(description = "主体id")
    @Excel(name = "主体id")
    private Long deptId;

    /** 商品id(对应系统商品库) */
    @Schema(description = "商品id(对应系统商品库)")
    @Excel(name = "商品id(对应系统商品库)")
    private Long commodityId;

    /** 统一计量单位 */
    @Schema(description = "统一计量单位")
    @Excel(name = "统一计量单位")
    private String purchaUnit;

    /** 库存上限 */
    @Schema(description = "库存上限")
    @Excel(name = "库存上限")
    private BigDecimal up;

    /** 库存下限 */
    @Schema(description = "库存下限")
    @Excel(name = "库存下限")
    private BigDecimal low;

    /** 是否即入即出：0是、1否 */
    @Schema(description = "是否即入即出：0是、1否")
    private Integer enterAndExit;

    /** 是否有效【1无效，0有效】 */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "是否有效【1无效，0有效】")
    private Integer delFlag;

    /** 创建日期 */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建日期", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /** 创建人id */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人id")
    @Excel(name = "创建人id")
    private Long createUser;

    /** 修改时间 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

    /** 修改人id */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /** 创建人 */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人")
    @Excel(name = "创建人")
    private String createName;

    /** 修改人 */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人")
    @Excel(name = "修改人")
    private String updateName;

}
