package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class EducationDistribution {
    @Schema(description = "小学以下")
    private int primary;           // 小学以下
    @Schema(description = "初中")
    private int juniorHigh;        // 初中
    @Schema(description = "高中")
    private int seniorHigh;        // 高中
    @Schema(description = "专科")
    private int college;           // 专科
    @Schema(description = "本科")
    private int bachelor;          // 本科
    @Schema(description = "硕士（研究生）")
    private int master;            // 硕士（研究生）
    @Schema(description = "博士")
    private int doctor;            // 博士
    @Schema(description = "占比")
    private double primaryRatio;
    @Schema(description = "占比")
    private double juniorHighRatio;
    @Schema(description = "占比")
    private double seniorHighRatio;
    @Schema(description = "占比")
    private double collegeRatio;
    @Schema(description = "占比")
    private double bachelorRatio;
    @Schema(description = "占比")
    private double masterRatio;
    @Schema(description = "占比")
    private double doctorRatio;
}
