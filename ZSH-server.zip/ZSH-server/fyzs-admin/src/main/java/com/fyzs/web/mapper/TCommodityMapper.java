package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCommodity;
import com.fyzs.web.entity.query.TCommodityQuery;
import com.fyzs.web.entity.query.TDeptCommodityQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 系统标准商品库Mapper接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
@Mapper
public interface TCommodityMapper  extends BaseMapper<TCommodity>
{
    /**
     * 查询系统标准商品库
     * 
     * @param id 系统标准商品库主键
     * @return 系统标准商品库
     */
    public TCommodityQuery selectTCommodityById(Long id);

    /**
     * 查询系统标准商品库列表
     * 
     * @param tCommodity 系统标准商品库
     * @return 系统标准商品库集合
     */
    public List<TCommodityQuery> selectTCommodityList(TCommodityQuery tCommodity);

    /**
     * 新增系统标准商品库
     * 
     * @param tCommodity 系统标准商品库
     * @return 结果
     */
    public int insertTCommodity(TCommodity tCommodity);

    /**
     * 修改系统标准商品库
     * 
     * @param tCommodity 系统标准商品库
     * @return 结果
     */
    public int updateTCommodity(TCommodity tCommodity);

    /**
     * 删除系统标准商品库
     * 
     * @param id 系统标准商品库主键
     * @return 结果
     */
    public int deleteTCommodityById(Long id);

    /**
     * 批量删除系统标准商品库
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCommodityByIds(Long[] ids);

    Integer selectMaxSequence();

    /**
     * 查询不在指定主体下的商品列表（有效商品且不在该主体下）
     *
     * @param excludeCommodityIds 需要排除的商品 ID 列表（该主体下已存在的商品）
     * @param query 查询条件
     * @return 商品列表
     */
    List<TCommodity> selectNotInDeptCommodityList(@Param("excludeCommodityIds") List<Long> excludeCommodityIds, @Param("query") TDeptCommodityQuery query);
}
