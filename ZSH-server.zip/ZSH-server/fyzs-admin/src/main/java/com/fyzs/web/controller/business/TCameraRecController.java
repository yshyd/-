package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraRec;
import com.fyzs.web.service.ITCameraRecService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 可视化视频监控回放信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/rec")
public class TCameraRecController extends BaseController
{

    private final ITCameraRecService tCameraRecService;

    /**
     * 查询可视化视频监控回放信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraRec tCameraRec)
    {
        startPage();
        List<TCameraRec> list = tCameraRecService.selectTCameraRecList(tCameraRec);
        return getDataTable(list);
    }

    /**
     * 导出可视化视频监控回放信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:export')")
    @Log(title = "可视化视频监控回放信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraRec tCameraRec)
    {
        List<TCameraRec> list = tCameraRecService.selectTCameraRecList(tCameraRec);
        ExcelUtil<TCameraRec> util = new ExcelUtil<TCameraRec>(TCameraRec.class);
        util.exportExcel(response, list, "可视化视频监控回放信息数据");
    }

    /**
     * 获取可视化视频监控回放信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraRecService.selectTCameraRecById(id));
    }

    /**
     * 新增可视化视频监控回放信息
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:add')")
    @Log(title = "可视化视频监控回放信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraRec tCameraRec)
    {
        return toAjax(tCameraRecService.save(tCameraRec));
    }

    /**
     * 修改可视化视频监控回放信息
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:edit')")
    @Log(title = "可视化视频监控回放信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraRec tCameraRec)
    {
        return toAjax(tCameraRecService.updateById(tCameraRec));
    }

    /**
     * 删除可视化视频监控回放信息
     */
    //@PreAuthorize("@ss.hasPermi('web:rec:remove')")
    @Log(title = "可视化视频监控回放信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraRecService.deleteTCameraRecByIds(ids));
    }
}
