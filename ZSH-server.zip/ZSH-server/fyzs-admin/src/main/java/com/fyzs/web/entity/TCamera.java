package com.fyzs.web.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 可视化视频监控设备基本信息对象 t_camera
 *
 * @author ysh
 * @date 2025-12-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera")
public class TCamera implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 市局监控平台设备编码，每一台设备都有一个唯一码,用于数据关联和后期数据更新 */
        @Schema(description = "市局监控平台设备编码，每一台设备都有一个唯一码,用于数据关联和后期数据更新")
        @Excel(name = "市局监控平台设备编码，每一台设备都有一个唯一码,用于数据关联和后期数据更新")
        private String devId;

        /** 点位名称/设备名称 (一般是监控关键环节+顺序号01) */
        @Schema(description = "点位名称/设备名称 (一般是监控关键环节+顺序号01)")
        @Excel(name = "点位名称/设备名称 (一般是监控关键环节+顺序号01)")
        private String bissName;

        /** 点位业务编码(按照规则生成) */
        @Schema(description = "点位业务编码(按照规则生成)")
        @Excel(name = "点位业务编码(按照规则生成)")
        private String bissId;

        /** 对应得的许可证编号 */
        @Schema(description = "对应得的许可证编号")
        @Excel(name = "对应得的许可证编号")
        private String permitNo;

        /** 食品许可证类型1、食品生产许可证2、食品经营许可证 */
        @Schema(description = "食品许可证类型1、食品生产许可证2、食品经营许可证")
        @Excel(name = "食品许可证类型1、食品生产许可证2、食品经营许可证")
        private String permitType;

        /** 食品类别，参考文件 */
        @Schema(description = "食品类别，参考文件")
        @Excel(name = "食品类别，参考文件")
        private String proFoodType;

        /** 品经营主体业态 */
        @Schema(description = "品经营主体业态")
        @Excel(name = "品经营主体业态")
        private String entityStatus;

        /** 0：非AI，1：AI 指的是摄像头本身是否具备AI识别功能 */
        @Schema(description = "0：非AI，1：AI 指的是摄像头本身是否具备AI识别功能")
        @Excel(name = "0：非AI，1：AI 指的是摄像头本身是否具备AI识别功能")
        private String aiSign;

        /** 详见6.15监控环节 */
        @Schema(description = "详见6.15监控环节")
        @Excel(name = "详见6.15监控环节")
        private String monitorName;

        /** 排序(必传) */
        @Schema(description = "排序(必传)")
        @Excel(name = "排序(必传)")
        private Long sort;

        /** 建设类型：0平台自建1平台收管2三方对接 */
        @Schema(description = "建设类型：0平台自建1平台收管2三方对接")
        @Excel(name = "建设类型：0平台自建1平台收管2三方对接")
        private Integer type;

        /** 0未停用 1已停用 */
        @Schema(description = "0未停用 1已停用")
        @Excel(name = "0未停用 1已停用")
        private String devStatus;

        /** 要求支持回放天数最小值 */
        @Schema(description = "要求支持回放天数最小值")
        @Excel(name = "要求支持回放天数最小值")
        private Integer requirementsRecNumber;

        /** 摄像头连接状态0未连接1已连接 */
        @Schema(description = "摄像头连接状态0未连接1已连接")
        @Excel(name = "摄像头连接状态0未连接1已连接")
        private Integer status;

        /** 业务类型 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务 */
        @Schema(description = "业务类型 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务")
        @Excel(name = "业务类型 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务")
        private String businessType;

        /** 食品类别名称 */
        @Schema(description = "食品类别名称")
        @Excel(name = "食品类别名称")
        private String foodType;

        /** 食品类别代码 */
        @Schema(description = "食品类别代码")
        @Excel(name = "食品类别代码")
        private String foodCode;

        /** 关键监控环节名称 */
        @Schema(description = "关键监控环节名称")
        @Excel(name = "关键监控环节名称")
        private String linksName;

        /** 关键监控环节代码 */
        @Schema(description = "关键监控环节代码")
        @Excel(name = "关键监控环节代码")
        private String linksCode;

        /** 安装位置 */
        @Schema(description = "安装位置")
        @Excel(name = "安装位置")
        private String location;

        /** 摄像头安装要求 */
        @Schema(description = "摄像头安装要求")
        @Excel(name = "摄像头安装要求")
        private String installationRequirements;

        /** 需要监管的不规范情形 */
        @Schema(description = "需要监管的不规范情形")
        @Excel(name = "需要监管的不规范情形")
        private String regulationsType;

        /** 违法违规代码 */
        @Schema(description = "违法违规代码")
        @Excel(name = "违法违规代码")
        private String regulationsCode;

}
