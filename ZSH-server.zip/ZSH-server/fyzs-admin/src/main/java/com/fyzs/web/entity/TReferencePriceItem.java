package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食材标准参考价发布记录主对象 t_reference_price_item
 *
 * @author ysh
 * @date 2025-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_reference_price_item")
public class TReferencePriceItem implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 价格记录ID */
        @Schema(description = "价格记录ID")
        @Excel(name = "价格记录ID")
        private Long referenceId;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 价格执行开始日期 */
        @Schema(description = "价格执行开始日期")
        @Excel(name = "价格执行开始日期")
        private String startDate;

        /** 价格执行结束日期 */
        @Schema(description = "价格执行结束日期")
        @Excel(name = "价格执行结束日期")
        private String endDate;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 商品编码 */
        @Schema(description = "商品编码")
        @Excel(name = "商品编码")
        private String commodityCode;

        /** 单价 */
        @Schema(description = "单价")
        @Excel(name = "单价")
        private BigDecimal price;

        /** 发布人 */
        @Schema(description = "发布人")
        @Excel(name = "发布人")
        private String publisher;

        /** 发布时间 */
        @Schema(description = "发布时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "发布时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date publisherTime;

        /** 状态：0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "状态：0有效1作废")
        private Integer delFlag;

        /** 操作人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人ID(对应sys_user)")
        @Excel(name = "操作人ID(对应sys_user)")
        private Long createUser;

        /** 操作人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人姓名(对应sys_user)")
        @Excel(name = "操作人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 操作时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "操作时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
