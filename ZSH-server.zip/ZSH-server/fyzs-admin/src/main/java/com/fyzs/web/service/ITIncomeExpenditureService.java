package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TIncomeExpenditure;
import com.fyzs.web.entity.query.TIncomeExpenditureEarlyQuery;
import com.fyzs.web.entity.query.TIncomeExpenditureQuery;

/**
 * 采购管理-经费管理-收支管理Service接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
public interface ITIncomeExpenditureService extends IService<TIncomeExpenditure>
{
    /**
     * 查询采购管理-经费管理-收支管理
     * 
     * @param id 采购管理-经费管理-收支管理主键
     * @return 采购管理-经费管理-收支管理
     */
    public TIncomeExpenditureQuery selectTIncomeExpenditureById(Long id);

    /**
     * 查询采购管理-经费管理-收支管理列表
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 采购管理-经费管理-收支管理集合
     */
    public List<TIncomeExpenditureQuery> selectTIncomeExpenditureList(TIncomeExpenditureQuery tIncomeExpenditure);

    /**
     * 新增采购管理-经费管理-收支管理
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 结果
     */
    public int insertTIncomeExpenditure(TIncomeExpenditure tIncomeExpenditure);

    /**
     * 修改采购管理-经费管理-收支管理
     * 
     * @param tIncomeExpenditure 采购管理-经费管理-收支管理
     * @return 结果
     */
    public int updateTIncomeExpenditure(TIncomeExpenditure tIncomeExpenditure);

    /**
     * 批量删除采购管理-经费管理-收支管理
     * 
     * @param ids 需要删除的采购管理-经费管理-收支管理主键集合
     * @return 结果
     */
    public int deleteTIncomeExpenditureByIds(Long[] ids);

    /**
     * 删除采购管理-经费管理-收支管理信息
     * 
     * @param id 采购管理-经费管理-收支管理主键
     * @return 结果
     */
    public int deleteTIncomeExpenditureById(Long id);

    List<TIncomeExpenditureEarlyQuery> balanceList(TIncomeExpenditureEarlyQuery query);
}
