package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 留样柜柜门状态对象 t_door_status
 *
 * @author ysh
 * @date 2026-01-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_door_status")
public class TDoorStatus implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 留样柜设备序列号 */
        @Schema(description = "留样柜设备序列号")
        @Excel(name = "留样柜设备序列号")
        private String serailNumber;

        /** 柜门1留样时间，空代表未留样 */
        @Schema(description = "柜门1留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门1留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorOneTime;

        /** 柜门2留样时间，空代表未留样 */
        @Schema(description = "柜门2留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门2留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorTwoTime;

        /** 柜门3留样时间，空代表未留样 */
        @Schema(description = "柜门3留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门3留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorThreeTime;

        /** 柜门4留样时间，空代表未留样 */
        @Schema(description = "柜门4留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门4留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorFourTime;

        /** 柜门5留样时间，空代表未留样 */
        @Schema(description = "柜门5留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门5留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorFiveTime;

        /** 柜门6留样时间，空代表未留样 */
        @Schema(description = "柜门6留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门6留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorSixTime;

        /** 柜门7留样时间，空代表未留样 */
        @Schema(description = "柜门7留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门7留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorSevenTime;

        /** 柜门8留样时间，空代表未留样 */
        @Schema(description = "柜门8留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门8留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorEightTime;

        /** 柜门9留样时间，空代表未留样 */
        @Schema(description = "柜门9留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门9留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorNineTime;

        /** 柜门10留样时间，空代表未留样 */
        @Schema(description = "柜门10留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门10留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorTenTime;

        /** 柜门11留样时间，空代表未留样 */
        @Schema(description = "柜门11留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门11留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorElevenTime;

        /** 柜门12留样时间，空代表未留样 */
        @Schema(description = "柜门12留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门12留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorTwelveTime;

        /** 柜门13留样时间，空代表未留样 */
        @Schema(description = "柜门13留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门13留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorThirteenTime;

        /** 柜门14留样时间，空代表未留样 */
        @Schema(description = "柜门14留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门14留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorFourteenTime;

        /** 柜门15留样时间，空代表未留样 */
        @Schema(description = "柜门15留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门15留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorFifteenTime;

        /** 柜门16留样时间，空代表未留样 */
        @Schema(description = "柜门16留样时间，空代表未留样")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "柜门16留样时间，空代表未留样", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date doorSixteenTime;

        /** 柜门1留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门1留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门1留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorOneType;

        /** 柜门2留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门2留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门2留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorTwoType;

        /** 柜门3留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门3留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门3留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorThreeType;

        /** 柜门4留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门4留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门4留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorFourType;

        /** 柜门5留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门5留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门5留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorFiveType;

        /** 柜门6留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门6留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门6留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorSixType;

        /** 柜门7留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门7留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门7留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorSevenType;

        /** 柜门8留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门8留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门8留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorEightType;

        /** 柜门9留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门9留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门9留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorNineType;

        /** 柜门10留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门10留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门10留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorTenType;

        /** 柜门11留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门11留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门11留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorElevenType;

        /** 柜门12留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门12留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门12留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorTwelveType;

        /** 柜门13留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门13留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门13留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorThirteenType;

        /** 柜门14留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门14留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门14留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorFourteenType;

        /** 柜门15留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门15留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门15留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorFifteenType;

        /** 柜门16留样餐次：0未留样，1早餐、2午餐、3晚餐 */
        @Schema(description = "柜门16留样餐次：0未留样，1早餐、2午餐、3晚餐")
        @Excel(name = "柜门16留样餐次：0未留样，1早餐、2午餐、3晚餐")
        private Integer doorSixteenType;

        /** 设备温度 */
        @Schema(description = "设备温度")
        @Excel(name = "设备温度")
        private BigDecimal temperature;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
