package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TReferencePriceDTO;
import com.fyzs.web.entity.query.TReferencePriceQuery;
import com.fyzs.web.service.ITReferencePriceItemService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TReferencePrice;
import com.fyzs.web.service.ITReferencePriceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食材标准参考价发布记录主Controller
 * 
 * @author ysh
 * @date 2025-11-24
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/reference/price")
public class TReferencePriceController extends BaseController
{

    private final ITReferencePriceService tReferencePriceService;

    private final ITReferencePriceItemService itemService;

    /**
     * 查询食材标准参考价发布记录主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:price:list')")
    @GetMapping("/list")
    public TableDataInfo list(TReferencePriceQuery tReferencePrice)
    {
        startPage();
        List<TReferencePriceQuery> list = tReferencePriceService.selectTReferencePriceList(tReferencePrice);
        return getDataTable(list);
    }

    /**
     * 导出食材标准参考价发布记录主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:price:export')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TReferencePriceQuery tReferencePrice)
    {
        List<TReferencePriceQuery> list = tReferencePriceService.selectTReferencePriceList(tReferencePrice);
        ExcelUtil<TReferencePriceQuery> util = new ExcelUtil<TReferencePriceQuery>(TReferencePriceQuery.class);
        util.exportExcel(response, list, "食材标准参考价发布记录主数据");
    }

    /**
     * 获取食材标准参考价发布记录主详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:price:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tReferencePriceService.selectTReferencePriceById(id));
    }

    /**
     * 新增食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:price:add')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TReferencePriceDTO tReferencePrice)
    {
        return toAjax(tReferencePriceService.insertTReferencePrice(tReferencePrice));
    }

    /**
     * 修改食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:price:edit')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TReferencePriceDTO tReferencePrice)
    {
        return toAjax(tReferencePriceService.updateTReferencePrice(tReferencePrice));
    }

    /**
     * 启用/禁用 食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:price:edit')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.UPDATE)
    @PutMapping("/enable")
    public AjaxResult enable(@RequestBody TReferencePrice tReferencePrice){

        return toAjax(tReferencePriceService.enable(tReferencePrice));
    }

    /**
     * 删除食材标准参考价发布记录主
     */
    //@PreAuthorize("@ss.hasPermi('web:price:remove')")
    @Log(title = "食材标准参考价发布记录主", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tReferencePriceService.deleteTReferencePriceByIds(ids));
    }
}
