package com.fyzs.web.mapper;

import com.fyzs.web.entity.dto.RoleDeptsDTO;
import com.fyzs.web.entity.vo.RoleDeptsVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CollectMapper {
    List<RoleDeptsVO> getDeptIds(RoleDeptsDTO roleDeptsDTO);
}
