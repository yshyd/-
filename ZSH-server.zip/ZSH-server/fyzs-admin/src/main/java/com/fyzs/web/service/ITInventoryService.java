package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TInventory;
import com.fyzs.web.entity.query.TInventoryQuery;
import com.fyzs.web.entity.vo.TInventoryExportVO;

/**
 * 商品批次库存Service接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
public interface ITInventoryService extends IService<TInventory>
{
    /**
     * 查询商品批次库存
     * 
     * @param id 商品批次库存主键
     * @return 商品批次库存
     */
    public TInventory selectTInventoryById(Long id);

    /**
     * 查询商品批次库存列表
     * 
     * @param tInventory 商品批次库存
     * @return 商品批次库存集合
     */
    public List<TInventoryQuery> selectTInventoryList(TInventoryQuery tInventory);

    /**
     * 根据筛选条件查询全部库存导出数据，并按商品汇总库存数量
     *
     * @param tInventory 库存筛选条件
     * @return 商品库存汇总集合
     */
    public List<TInventoryExportVO> selectTInventoryExportList(TInventoryQuery tInventory);

    /**
     * 新增商品批次库存
     * 
     * @param tInventory 商品批次库存
     * @return 结果
     */
    public int insertTInventory(TInventoryQuery tInventory);

    /**
     * 修改商品批次库存
     * 
     * @param tInventory 商品批次库存
     * @return 结果
     */
    public int updateTInventory(TInventory tInventory);

    /**
     * 批量删除商品批次库存
     * 
     * @param ids 需要删除的商品批次库存主键集合
     * @return 结果
     */
    public int deleteTInventoryByIds(Long[] ids);

    /**
     * 删除商品批次库存信息
     * 
     * @param id 商品批次库存主键
     * @return 结果
     */
    public int deleteTInventoryById(Long id);

    List<TInventoryQuery> pullList(TInventoryQuery tInventory);

    List<TInventoryQuery> warnList(TInventoryQuery tInventory);
}
