package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TWeekSupplierRisk;
import com.fyzs.web.entity.query.TWeekSupplierRiskQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 学校食堂周排查-供应商风险排查Mapper接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
@org.apache.ibatis.annotations.Mapper
public interface TWeekSupplierRiskMapper  extends BaseMapper<TWeekSupplierRisk>
{
    /**
     * 查询学校食堂周排查-供应商风险排查
     * 
     * @param id 学校食堂周排查-供应商风险排查主键
     * @return 学校食堂周排查-供应商风险排查
     */
    public TWeekSupplierRiskQuery selectTWeekSupplierRiskById(Long id);

    /**
     * 查询学校食堂周排查-供应商风险排查列表
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 学校食堂周排查-供应商风险排查集合
     */
    public List<TWeekSupplierRiskQuery> selectTWeekSupplierRiskList(TWeekSupplierRiskQuery tWeekSupplierRisk);

    /**
     * 新增学校食堂周排查-供应商风险排查
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 结果
     */
    public int insertTWeekSupplierRisk(TWeekSupplierRisk tWeekSupplierRisk);

    /**
     * 修改学校食堂周排查-供应商风险排查
     * 
     * @param tWeekSupplierRisk 学校食堂周排查-供应商风险排查
     * @return 结果
     */
    public int updateTWeekSupplierRisk(TWeekSupplierRisk tWeekSupplierRisk);

    /**
     * 删除学校食堂周排查-供应商风险排查
     * 
     * @param id 学校食堂周排查-供应商风险排查主键
     * @return 结果
     */
    public int deleteTWeekSupplierRiskById(Long id);

    /**
     * 批量删除学校食堂周排查-供应商风险排查
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTWeekSupplierRiskByIds(Long[] ids);
}
