package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 退货记录对象 t_new_procurement_return
 *
 * @author ysh
 * @date 2025-11-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_procurement_return")
public class TNewProcurementReturn implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 仓库ID */
        @Schema(description = "仓库ID")
        @Excel(name = "仓库ID")
        private Long warehouseId;

        /** 批次库存ID */
        @Schema(description = "批次库存ID")
        @Excel(name = "批次库存ID")
        private Long inventoryId;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 供应商ID */
        @Schema(description = "供应商ID")
        @Excel(name = "供应商ID")
        private Long supplerId;

        /** 采购ID */
        @Schema(description = "采购ID")
        @Excel(name = "采购ID")
        private Long procurementId;

        /** 采购单号 */
        @Schema(description = "采购单号")
        @Excel(name = "采购单号")
        private String procurementNum;

        /** 验收记录ID */
        @Schema(description = "验收记录ID")
        @Excel(name = "验收记录ID")
        private Long acceptanceId;

        /** 验收时间(用于结算定价) */
        @Schema(description = "验收时间(用于结算定价)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "验收时间(用于结算定价)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date acceptanceTime;

        /** 批次 */
        @Schema(description = "批次")
        @Excel(name = "批次")
        private String batch;

        /** 退货数量(按照采购单位计量，也是结算的数据) */
        @Schema(description = "退货数量(按照采购单位计量，也是结算的数据)")
        @Excel(name = "退货数量(按照采购单位计量，也是结算的数据)")
        private BigDecimal returnNum;

        /** 单价：结算的时候是必须要填充 */
        @Schema(description = "单价：结算的时候是必须要填充")
        @Excel(name = "单价：结算的时候是必须要填充")
        private BigDecimal price;

        /** 合计：确认结算的时候要填写 */
        @Schema(description = "合计：确认结算的时候要填写")
        @Excel(name = "合计：确认结算的时候要填写")
        private BigDecimal totalPrice;

        /** 状态：-1已撤销、0待结算、1已结算 */
        @Schema(description = "状态：-1已撤销、0待结算、1已结算")
        @Excel(name = "状态：-1已撤销、0待结算、1已结算")
        private Integer status;

        /** 结算人(结算的时候必填) */
        @Schema(description = "结算人(结算的时候必填)")
        @Excel(name = "结算人(结算的时候必填)")
        private Long settlementId;

        /** 结算人姓名(结算的时候必填) */
        @Schema(description = "结算人姓名(结算的时候必填)")
        @Excel(name = "结算人姓名(结算的时候必填)")
        private String settlementName;

        /** 结算时间(结算的时候必填) */
        @Schema(description = "结算时间(结算的时候必填)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "结算时间(结算的时候必填)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date settlementDate;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
