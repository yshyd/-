package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食堂人员请假信息管理对象 t_leave
 *
 * @author ysh
 * @date 2025-10-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_leave")
public class TLeave implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 对应主体id
     */
    @Schema(description = "对应主体id")
    @Excel(name = "对应主体id")
    private Long deptId;

    /**
     * 日期
     */
    @Schema(description = "开始日期")
    @Excel(name = "开始日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startDate;

    @Schema(description = "结束日期")
    @Excel(name = "结束日期")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endDate;

    /**
     * 人员id
     */
    @Schema(description = "人员id")
    @Excel(name = "人员id")
    private Long personId;

    @Schema(description = "人员名称")
    private String personName;

    /**
     * 创建人ID
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人ID")
    @Excel(name = "创建人ID")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /**
     * 删除标识(0有效1无效)
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "删除标识(0有效1无效)")
    private String delFlag ;
}
