package com.fyzs.web.controller.large;

import com.fyzs.web.entity.PageResult;
import com.fyzs.web.entity.query.SummaryQuery;
import com.fyzs.web.entity.query.TAlarmQuery;
import com.fyzs.web.entity.vo.*;
import com.fyzs.web.service.IFigureLargeService;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Collections;
import java.util.List;

/**
 * 数字大屏
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/figure/large")
public class FigureLargeController {

    private final IFigureLargeService figureLargeService;


    /**
     * 主体相关配置信息
     */
    @GetMapping("/statistics")
    public ResponseEntity<StatisticsResponseVO> getStatistics(SummaryQuery query) {
        return ResponseEntity.ok(figureLargeService.getStatistics(query));
    }

    /**
     * 学校数据下沉页
     */
    @GetMapping("/schoolDataDown")
    public ResponseEntity<PageResult<SchoolDataDownVO>> getSchoolDataDown(@RequestParam(defaultValue = "1") Integer pageNum,
                                                                          @RequestParam(defaultValue = "10") Integer pageSize, SchoolDataDownVO query) {
        PageResult<SchoolDataDownVO> result = figureLargeService.getSchoolDataDown(pageNum, pageSize, query);
        return ResponseEntity.ok(result);
    }

    /**
     * 食堂数据下沉
     */
    @GetMapping("/canteenDataDown")
    public ResponseEntity<PageResult<CanteenDataDownVO>> getCanteenDataDown(@RequestParam(defaultValue = "1") Integer pageNum,
                                                                            @RequestParam(defaultValue = "10") Integer pageSize, CanteenDataDownVO query) {
        PageResult<CanteenDataDownVO> result = figureLargeService.getCanteenDataDown(pageNum, pageSize, query);
        return ResponseEntity.ok(result);
    }

    /**
     * 从业人员数据下沉
     */
    @GetMapping("/practitionerDataDown")
    public ResponseEntity<PageResult<PractitionerDataDownVO>> getPractitionerDataDown(@RequestParam(defaultValue = "1") Integer pageNum,
                                                                                      @RequestParam(defaultValue = "10") Integer pageSize,
                                                                                      PractitionerDataDownVO query) {
        PageResult<PractitionerDataDownVO> result = figureLargeService.getPractitionerDataDown(pageNum, pageSize, query);
        return ResponseEntity.ok(result);
    }

    /**
     * 供应商数据下沉
     */
    @GetMapping("/supplierDataDown")
    public ResponseEntity<PageResult<SupplierDataDownVO>> getSupplierDataDown(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            SupplierDataDownVO query) {

        PageResult<SupplierDataDownVO> result = figureLargeService.getSupplierDataDown(pageNum, pageSize, query);
        return ResponseEntity.ok(result);
    }


    /**
     * 食安排名
     */
    @GetMapping("/securityRanking")
    public ResponseEntity<List<SecurityRankingVO>> getSecurityRanking(SummaryQuery query) {

        List<SecurityRankingVO> rankingList = figureLargeService.getSecurityRanking(query);

        if (rankingList.isEmpty()) {
            return ResponseEntity.ok(Collections.singletonList(new SecurityRankingVO("暂无数据", 0.0, null, null, null)));
        }
        return ResponseEntity.ok(rankingList);
    }

    /**
     * 地图主体信息
     */
    @GetMapping("/map")
    public ResponseEntity<List<MapVO>> getMap(SummaryQuery query) {
        List<MapVO> result = figureLargeService.getMap(query);
        return ResponseEntity.ok(result);
    }


    /**
     * 实时管控
     */

    @GetMapping("/realtimeControl")
    public ResponseEntity<List<RealTimeControlItemVO>> getRealTimeControl(SummaryQuery query) throws ParseException {
        List<RealTimeControlItemVO> result = figureLargeService.getRealTimeControl(query);
//        if (result.isEmpty()) {
//            return ResponseEntity.ok(Collections.singletonList(new RealTimeControlItemVO("暂无数据", BigDecimal.ZERO)));
//        }
        return ResponseEntity.ok(result);
    }

    /**
     * 预警统计
     */
    @GetMapping("/alarmStatistics")
    public ResponseEntity<List<AlarmStatisticsVO>> getAlarmStatistics(SummaryQuery query) {
        List<AlarmStatisticsVO> result = figureLargeService.getAlarmStatistics(query);
        return ResponseEntity.ok(result);
    }

    /**
     * 预警统计详情页 - 按预警类型查询详细预警列表
     */
    @GetMapping("/alarmDetails")
    public ResponseEntity<PageResult<TAlarmQuery>> getAlarmDetails(@RequestParam(defaultValue = "1") Integer pageNum,
                                                                   @RequestParam(defaultValue = "10") Integer pageSize,
                                                                   TAlarmQuery query) {
        PageResult<TAlarmQuery> alarms = figureLargeService.getAlarmDetails(pageNum, pageSize, query);
        return ResponseEntity.ok(alarms);
    }

    /**
     * 预警信息管理
     */
    @GetMapping("/alarm")
    public ResponseEntity<List<TAlarmQuery>> getAlarm(SummaryQuery query) {
        List<TAlarmQuery> alarms = figureLargeService.getAlarm(query);
        return ResponseEntity.ok(alarms);
    }

    /**
     * 供应链大数据分析
     */
    @GetMapping("/supplyChainAnalysis")
    public ResponseEntity<List<SupplyChainAnalysisVO>> getSupplyChainAnalysis(SummaryQuery query) {
        List<SupplyChainAnalysisVO> result = figureLargeService.getSupplyChainAnalysis(query);
        return ResponseEntity.ok(result);
    }

    /**
     * 餐饮入口率数据分析
     */
    @GetMapping("/dinerRateAnalysis")
    public ResponseEntity<List<DinerRateAnalysisVO>> getDinerRateAnalysis(SummaryQuery query) {
        List<DinerRateAnalysisVO> result = figureLargeService.getDinerRateAnalysis(query);
        return ResponseEntity.ok(result);
    }

    /**
     * 食材索票索证情况
     */
    @GetMapping("/invoiceStatus")
    public ResponseEntity<InvoiceStatusVO> getInvoiceStatus(SummaryQuery query) {
        InvoiceStatusVO result = figureLargeService.getInvoiceStatus(query);
        return ResponseEntity.ok(result);
    }

    /**
     * 食材索票索证是否上传下沉
     */
    @GetMapping("/invoiceUploadedDown")
    public ResponseEntity<PageResult<InvoiceUploadedVO>> getInvoiceUploadedDown(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @ModelAttribute InvoiceUploadedVO query) {

        PageResult<InvoiceUploadedVO> result = figureLargeService.getInvoiceUploadedDown(pageNum, pageSize, query);
        return ResponseEntity.ok(result);
    }


}
