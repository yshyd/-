package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂周排查-周排查对象 t_week_table
 *
 * @author ysh
 * @date 2025-11-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_week_table")
public class TWeekTable implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体名称 */
        @Schema(description = "主体名称")
        @Excel(name = "主体名称")
        private Long deptId;

        /** 年度 */
        @Schema(description = "年度")
        @Excel(name = "年度")
        private Long year;

        /** 周度(这一年第多少周) */
        @Schema(description = "周度(这一年第多少周)")
        @Excel(name = "周度(这一年第多少周)")
        private Long week;

        /** 作用开始日期，格式：2025-11-24 */
        @Schema(description = "作用开始日期，格式：2025-11-24")
        @Excel(name = "作用开始日期，格式：2025-11-24")
        private String startDate;

        /** 作用结束日期，格式：2025-11-30 */
        @Schema(description = "作用结束日期，格式：2025-11-30")
        @Excel(name = "作用结束日期，格式：2025-11-30")
        private String endDate;

        /** 证照有效性：检查《食品经营许可证》是否在有效期内，并悬挂在醒目位置0是1否 */
        @Schema(description = "证照有效性：检查《食品经营许可证》是否在有效期内，并悬挂在醒目位置0是1否")
        @Excel(name = "证照有效性：检查《食品经营许可证》是否在有效期内，并悬挂在醒目位置0是1否")
        private Integer isCertificates;

        /** 人员健康证：抽查从业人员健康证明，确保所有人员持有效健康证上岗 0达标1不达标 */
        @Schema(description = "人员健康证：抽查从业人员健康证明，确保所有人员持有效健康证上岗 0达标1不达标")
        @Excel(name = "人员健康证：抽查从业人员健康证明，确保所有人员持有效健康证上岗 0达标1不达标")
        private Integer isHealthCertificate;

        /** 制度与记录：检查食品安全管理制度是否健全，日常记录（如进货查验、晨检、消毒等）是否完整、连续、真实。 0是1否 */
        @Schema(description = "制度与记录：检查食品安全管理制度是否健全，日常记录（如进货查验、晨检、消毒等）是否完整、连续、真实。 0是1否")
        @Excel(name = "制度与记录：检查食品安全管理制度是否健全，日常记录", readConverterExp = "如=进货查验、晨检、消毒等")
        private Integer isSystemsEcords;

        /** 每日晨检：检查本周晨检记录，是否有员工因生病（如腹泻、皮肤感染、发烧等）被调离岗位。 0否1是 */
        @Schema(description = "每日晨检：检查本周晨检记录，是否有员工因生病（如腹泻、皮肤感染、发烧等）被调离岗位。 0否1是")
        @Excel(name = "每日晨检：检查本周晨检记录，是否有员工因生病", readConverterExp = "如=腹泻、皮肤感染、发烧等")
        private Integer isMorningCheck;

        /** 个人卫生：现场抽查从业人员个人卫生，包括工作服是否洁净、指甲是否修剪、是否佩戴首饰、操作前是否规范洗手等。 0是1否 */
        @Schema(description = "个人卫生：现场抽查从业人员个人卫生，包括工作服是否洁净、指甲是否修剪、是否佩戴首饰、操作前是否规范洗手等。 0是1否")
        @Excel(name = "个人卫生：现场抽查从业人员个人卫生，包括工作服是否洁净、指甲是否修剪、是否佩戴首饰、操作前是否规范洗手等。 0是1否")
        private Integer isPersonalHygiene;

        /** 行为规范：检查在食品处理区内是否有吸烟、饮食等违规行为。 0否1是 */
        @Schema(description = "行为规范：检查在食品处理区内是否有吸烟、饮食等违规行为。 0否1是")
        @Excel(name = "行为规范：检查在食品处理区内是否有吸烟、饮食等违规行为。 0否1是")
        private Integer isCodeConduct;

        /** 进货查验：随机抽查本周部分食材的进货凭证、供应商资质、产品合格证明文件（尤其是肉类检疫合格证）。 0合格1不合格 */
        @Schema(description = "进货查验：随机抽查本周部分食材的进货凭证、供应商资质、产品合格证明文件（尤其是肉类检疫合格证）。 0合格1不合格")
        @Excel(name = "进货查验：随机抽查本周部分食材的进货凭证、供应商资质、产品合格证明文件", readConverterExp = "尤=其是肉类检疫合格证")
        private Integer isIncomingGoodsInspection;

        /** 原料质量：检查库存食品原料，是否有腐败变质、霉变生虫、超过保质期或感官性状异常的情况。 0否1是 */
        @Schema(description = "原料质量：检查库存食品原料，是否有腐败变质、霉变生虫、超过保质期或感官性状异常的情况。 0否1是")
        @Excel(name = "原料质量：检查库存食品原料，是否有腐败变质、霉变生虫、超过保质期或感官性状异常的情况。 0否1是")
        private Integer isRawMaterialQuality;

        /** 分区分类：原料、半成品、成品是否分开存放，避免交叉污染。 0是1否 */
        @Schema(description = "分区分类：原料、半成品、成品是否分开存放，避免交叉污染。 0是1否")
        @Excel(name = "分区分类：原料、半成品、成品是否分开存放，避免交叉污染。 0是1否")
        private Integer isZoningClassification;

        /** 温度控制：冷藏（0-8℃）、冷冻（-18℃以下）设备温度是否达标，并定期除霜。 0是1否 */
        @Schema(description = "温度控制：冷藏（0-8℃）、冷冻（-18℃以下）设备温度是否达标，并定期除霜。 0是1否")
        @Excel(name = "温度控制：冷藏", readConverterExp = "0=-8℃")
        private Integer isTemperatureControl;

        /** 离地离墙：食品是否按规定离地10cm以上、离墙10cm以上存放。 0是1否 */
        @Schema(description = "离地离墙：食品是否按规定离地10cm以上、离墙10cm以上存放。 0是1否")
        @Excel(name = "离地离墙：食品是否按规定离地10cm以上、离墙10cm以上存放。 0是1否")
        private Integer isGroundWalls;

        /** 标签标识：冷藏、冷冻及散装食品是否有标签，标明品名、生产日期/批号、使用时限等。 0是1否 */
        @Schema(description = "标签标识：冷藏、冷冻及散装食品是否有标签，标明品名、生产日期/批号、使用时限等。 0是1否")
        @Excel(name = "标签标识：冷藏、冷冻及散装食品是否有标签，标明品名、生产日期/批号、使用时限等。 0是1否")
        private Integer isLabelIdentification;

        /** 交叉污染：检查生熟食品的刀具、砧板、容器是否分开使用、存放并有明显标识。 0是1否 */
        @Schema(description = "交叉污染：检查生熟食品的刀具、砧板、容器是否分开使用、存放并有明显标识。 0是1否")
        @Excel(name = "交叉污染：检查生熟食品的刀具、砧板、容器是否分开使用、存放并有明显标识。 0是1否")
        private Integer isContamination;

        /** 食材处理：检查待加工食材是否新鲜，是否存在使用腐败变质原料的情况。 0否1是 */
        @Schema(description = "食材处理：检查待加工食材是否新鲜，是否存在使用腐败变质原料的情况。 0否1是")
        @Excel(name = "食材处理：检查待加工食材是否新鲜，是否存在使用腐败变质原料的情况。 0否1是")
        private Integer isFoodIngredientProcessing;

        /** 烹饪温度：检查中心温度测量记录，确保烧熟煮透（中心温度通常要求达到70℃以上）。 0达标1不达标 */
        @Schema(description = "烹饪温度：检查中心温度测量记录，确保烧熟煮透（中心温度通常要求达到70℃以上）。 0达标1不达标")
        @Excel(name = "烹饪温度：检查中心温度测量记录，确保烧熟煮透", readConverterExp = "中=心温度通常要求达到70℃以上")
        private Integer isCookingTemperature;

        /** 食品添加剂：检查是否使用非法添加物，食品添加剂是否做到“五专”管理（专人负责、专柜存放、专用台账、专用计量工具、专用标识）。 0达标1不达标 */
        @Schema(description = "食品添加剂：检查是否使用非法添加物，食品添加剂是否做到“五专”管理（专人负责、专柜存放、专用台账、专用计量工具、专用标识）。 0达标1不达标")
        @Excel(name = "食品添加剂：检查是否使用非法添加物，食品添加剂是否做到“五专”管理", readConverterExp = "专=人负责、专柜存放、专用台账、专用计量工具、专用标识")
        private Integer isFoodAdditive;

        /** 清洗流程：检查餐具是否按“一刮、二洗、三冲、四消毒、五保洁”流程处理。 0是1否 */
        @Schema(description = "清洗流程：检查餐具是否按“一刮、二洗、三冲、四消毒、五保洁”流程处理。 0是1否")
        @Excel(name = "清洗流程：检查餐具是否按“一刮、二洗、三冲、四消毒、五保洁”流程处理。 0是1否")
        private Integer isCleaningProcess;

        /** 消毒效果：检查消毒设备（如消毒柜）是否正常运行，温度和时长是否达标。化学消毒的，消毒液浓度是否合格。 0是1否 */
        @Schema(description = "消毒效果：检查消毒设备（如消毒柜）是否正常运行，温度和时长是否达标。化学消毒的，消毒液浓度是否合格。 0是1否")
        @Excel(name = "消毒效果：检查消毒设备", readConverterExp = "如=消毒柜")
        private Integer isDisinfectionEffect;

        /** 保洁状况：检查消毒后的餐具是否存放在专用的、洁净的密闭保洁柜内，是否干净无水渍。 0是1否 */
        @Schema(description = "保洁状况：检查消毒后的餐具是否存放在专用的、洁净的密闭保洁柜内，是否干净无水渍。 0是1否")
        @Excel(name = "保洁状况：检查消毒后的餐具是否存放在专用的、洁净的密闭保洁柜内，是否干净无水渍。 0是1否")
        private Integer isCleaningCondition;

        /** 环境卫生：检查地面、墙壁、天花板是否清洁、无霉斑、无积垢。 0达标1不达标 */
        @Schema(description = "环境卫生：检查地面、墙壁、天花板是否清洁、无霉斑、无积垢。 0达标1不达标")
        @Excel(name = "环境卫生：检查地面、墙壁、天花板是否清洁、无霉斑、无积垢。 0达标1不达标")
        private Integer isEnvironmentalHygiene;

        /** 设施设备：检查冷藏冷冻设备、排烟通风设施、灶具等是否正常运行、清洁卫生。 0是1否 */
        @Schema(description = "设施设备：检查冷藏冷冻设备、排烟通风设施、灶具等是否正常运行、清洁卫生。 0是1否")
        @Excel(name = "设施设备：检查冷藏冷冻设备、排烟通风设施、灶具等是否正常运行、清洁卫生。 0是1否")
        private Integer isFacilitiesEquipment;

        /** 三防设施：检查防蝇、防鼠、防尘设施（如纱窗、挡鼠板、风幕机）是否完好有效。 0是1否 */
        @Schema(description = "三防设施：检查防蝇、防鼠、防尘设施（如纱窗、挡鼠板、风幕机）是否完好有效。 0是1否")
        @Excel(name = "三防设施：检查防蝇、防鼠、防尘设施", readConverterExp = "如=纱窗、挡鼠板、风幕机")
        private Integer isThreeProofFacilities;

        /** 垃圾处理：检查餐厨垃圾是否及时清理，垃圾桶是否加盖、外观清洁。 0是1否 */
        @Schema(description = "垃圾处理：检查餐厨垃圾是否及时清理，垃圾桶是否加盖、外观清洁。 0是1否")
        @Excel(name = "垃圾处理：检查餐厨垃圾是否及时清理，垃圾桶是否加盖、外观清洁。 0是1否")
        private Integer isGarbageDisposal;

        /** 留样规范性：检查留样柜是否专用、上锁，留样容器是否消毒。 0是1否 */
        @Schema(description = "留样规范性：检查留样柜是否专用、上锁，留样容器是否消毒。 0是1否")
        @Excel(name = "留样规范性：检查留样柜是否专用、上锁，留样容器是否消毒。 0是1否")
        private Integer isStandardizationSampleRetention;

        /** 留样记录：核对留样记录，确保每餐次、每个品种都留样，留样量不少于125克，留样时间不少于48小时 0达标1不达标。 */
        @Schema(description = "留样记录：核对留样记录，确保每餐次、每个品种都留样，留样量不少于125克，留样时间不少于48小时 0达标1不达标。")
        @Excel(name = "留样记录：核对留样记录，确保每餐次、每个品种都留样，留样量不少于125克，留样时间不少于48小时 0达标1不达标。")
        private Integer isSampleRetentionRecord;

        /** 标签信息：检查留样标签是否完整，包含菜名、留样日期、餐次、留样人等信息。 0是1否 */
        @Schema(description = "标签信息：检查留样标签是否完整，包含菜名、留样日期、餐次、留样人等信息。 0是1否")
        @Excel(name = "标签信息：检查留样标签是否完整，包含菜名、留样日期、餐次、留样人等信息。 0是1否")
        private Integer isLabelInformation;

        /** 协议与台账：检查是否与有资质的餐厨垃圾回收单位签订合同，并建立处置台账。 0是1否 */
        @Schema(description = "协议与台账：检查是否与有资质的餐厨垃圾回收单位签订合同，并建立处置台账。 0是1否")
        @Excel(name = "协议与台账：检查是否与有资质的餐厨垃圾回收单位签订合同，并建立处置台账。 0是1否")
        private Integer isAgreementsLedgers;

        /** 分类与存放：检查废弃物是否分类存放，存放容器是否清洁、加盖。 0是1否 */
        @Schema(description = "分类与存放：检查废弃物是否分类存放，存放容器是否清洁、加盖。 0是1否")
        @Excel(name = "分类与存放：检查废弃物是否分类存放，存放容器是否清洁、加盖。 0是1否")
        private Integer isClassificationStorage;

        /** 整改追踪：重点检查上周排查发现的问题是否已按要求完成整改，并验证整改效果。 0是1否 */
        @Schema(description = "整改追踪：重点检查上周排查发现的问题是否已按要求完成整改，并验证整改效果。 0是1否")
        @Excel(name = "整改追踪：重点检查上周排查发现的问题是否已按要求完成整改，并验证整改效果。 0是1否")
        private Integer isRectificationTracking;

        /** 培训记录：检查本周是否组织了食品安全知识培训或考核，内容是否针对实际风险点。 0是1否 */
        @Schema(description = "培训记录：检查本周是否组织了食品安全知识培训或考核，内容是否针对实际风险点。 0是1否")
        @Excel(name = "培训记录：检查本周是否组织了食品安全知识培训或考核，内容是否针对实际风险点。 0是1否")
        private Integer isTrainingRecord;

        /** 整体达标情况0达标1不达标 */
        @Schema(description = "整体达标情况0达标1不达标")
        @Excel(name = "整体达标情况0达标1不达标")
        private Integer result;

        /** 不达标处置说明，整体不达标必填，500字内 */
        @Schema(description = "不达标处置说明，整体不达标必填，500字内")
        @Excel(name = "不达标处置说明，整体不达标必填，500字内")
        private String remarks;

        /** 排查人 */
        @Schema(description = "排查人")
        @Excel(name = "排查人")
        private String searchPeople;

        /** 排查时间 */
        @Schema(description = "排查时间")
        @Excel(name = "排查时间")
        private String searchTime;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
