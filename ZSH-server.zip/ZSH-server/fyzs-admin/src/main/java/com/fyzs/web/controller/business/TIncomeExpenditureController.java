package com.fyzs.web.controller.business;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TIncomeExpenditureEarlyQuery;
import com.fyzs.web.entity.query.TIncomeExpenditureQuery;
import com.fyzs.web.entity.query.TNewProcurementAcceptanceQuery;
import com.fyzs.web.service.ITNewProcurementAcceptanceService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TIncomeExpenditure;
import com.fyzs.web.service.ITIncomeExpenditureService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 采购管理-经费管理-收支管理Controller
 * 
 * @author ysh
 * @date 2025-11-24
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/expenditure")
public class TIncomeExpenditureController extends BaseController
{

    private final ITIncomeExpenditureService tIncomeExpenditureService;

    private final ITNewProcurementAcceptanceService tNewProcurementAcceptanceService;

    /**
     * 查询采购管理-经费管理-收支管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:list')")
    @GetMapping("/list")
    public TableDataInfo list(TIncomeExpenditureQuery tIncomeExpenditure)
    {
        startPage();
        List<TIncomeExpenditureQuery> list = tIncomeExpenditureService.selectTIncomeExpenditureList(tIncomeExpenditure);
        return getDataTable(list);
    }

    /**
     * 导出采购管理-经费管理-收支管理列表
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:export')")
    @Log(title = "采购管理-经费管理-收支管理", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TIncomeExpenditureQuery tIncomeExpenditure)
    {
        List<TIncomeExpenditureQuery> list = tIncomeExpenditureService.selectTIncomeExpenditureList(tIncomeExpenditure);
        ExcelUtil<TIncomeExpenditureQuery> util = new ExcelUtil<TIncomeExpenditureQuery>(TIncomeExpenditureQuery.class);
        util.exportExcel(response, list, "采购管理-经费管理-收支管理数据");
    }

    /**
     * 收支平衡预警管理
     */
    @GetMapping("/balance")
    public TableDataInfo balance(TIncomeExpenditureEarlyQuery query) {

        startPage();
        List<TIncomeExpenditureEarlyQuery> list = tIncomeExpenditureService.balanceList(query);
        return  getDataTable(list);
    }


    /**
     * 获取采购管理-经费管理-收支管理详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tIncomeExpenditureService.selectTIncomeExpenditureById(id));
    }

    /**
     * 新增采购管理-经费管理-收支管理
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:add')")
    @Log(title = "采购管理-经费管理-收支管理", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TIncomeExpenditure tIncomeExpenditure)
    {
        return toAjax(tIncomeExpenditureService.insertTIncomeExpenditure(tIncomeExpenditure));
    }

    /**
     * 修改采购管理-经费管理-收支管理
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:edit')")
    @Log(title = "采购管理-经费管理-收支管理", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TIncomeExpenditure tIncomeExpenditure)
    {
        return toAjax(tIncomeExpenditureService.updateTIncomeExpenditure(tIncomeExpenditure));
    }

    /**
     * 启用/禁用
     */
    @Log(title = "采购管理-经费管理-收支管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus(@RequestBody TIncomeExpenditure tIncomeExpenditure) {
        return toAjax(tIncomeExpenditureService.updateById(tIncomeExpenditure));
    }

    /**
     * 删除采购管理-经费管理-收支管理
     */
    //@PreAuthorize("@ss.hasPermi('web:expenditure:remove')")
    @Log(title = "采购管理-经费管理-收支管理", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tIncomeExpenditureService.deleteTIncomeExpenditureByIds(ids));
    }
}
