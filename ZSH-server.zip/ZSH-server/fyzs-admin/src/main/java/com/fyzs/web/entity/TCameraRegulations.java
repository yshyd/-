package com.fyzs.web.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 违法违规行为识别信息对象 t_camera_regulations
 *
 * @author ysh
 * @date 2025-10-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_regulations")
public class TCameraRegulations implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 对应主体ID */
        @Schema(description = "对应主体ID")
        @Excel(name = "对应主体ID")
        private Long deptId;

        /** 关联可视化视频监控设备基本信息表监控设备编码 */
        @Schema(description = "关联可视化视频监控设备基本信息表监控设备编码")
        @Excel(name = "关联可视化视频监控设备基本信息表监控设备编码")
        private String devId;

        /** 企业统一社会信用代码/注册号 */
        @Schema(description = "企业统一社会信用代码/注册号")
        @Excel(name = "企业统一社会信用代码/注册号")
        private String unisCid;

        /** 违法违规类型(参考文件6.11) */
        @Schema(description = "违法违规类型(参考文件6.11)")
        @Excel(name = "违法违规类型(参考文件6.11)")
        private String riskTypeCode;

        /** 违法违规问题详情描述 */
        @Schema(description = "违法违规问题详情描述")
        @Excel(name = "违法违规问题详情描述")
        private String riskTypeMemo;

        /** 识别时间 */
        @Schema(description = "识别时间")
        @Excel(name = "识别时间")
        private String identifyTime;

        /** 监管处理责任人所在单位。 */
        @Schema(description = "监管处理责任人所在单位。")
        @Excel(name = "监管处理责任人所在单位。")
        private String pespPersonUnit;

        /** 监管处理责任人 */
        @Schema(description = "监管处理责任人")
        @Excel(name = "监管处理责任人")
        private String pespPerson;

        /** 企业问题整改责任人 */
        @Schema(description = "企业问题整改责任人")
        @Excel(name = "企业问题整改责任人")
        private String solvePerson;

        /** 处理状态：0未处置1已处置 */
        @Schema(description = "处理状态：0未处置1已处置")
        @Excel(name = "处理状态：0未处置1已处置")
        private String status;

}
