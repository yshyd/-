package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TRegulationsSelfHandle;
import com.fyzs.web.service.ITRegulationsSelfHandleService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规处置信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/self/handle")
public class TRegulationsSelfHandleController extends BaseController
{

    private final ITRegulationsSelfHandleService tRegulationsSelfHandleService;

    /**
     * 查询违法违规处置信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:list')")
    @GetMapping("/list")
    public TableDataInfo list(TRegulationsSelfHandle tRegulationsSelfHandle)
    {
        startPage();
        List<TRegulationsSelfHandle> list = tRegulationsSelfHandleService.selectTRegulationsSelfHandleList(tRegulationsSelfHandle);
        return getDataTable(list);
    }

    /**
     * 导出违法违规处置信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:export')")
    @Log(title = "违法违规处置信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TRegulationsSelfHandle tRegulationsSelfHandle)
    {
        List<TRegulationsSelfHandle> list = tRegulationsSelfHandleService.selectTRegulationsSelfHandleList(tRegulationsSelfHandle);
        ExcelUtil<TRegulationsSelfHandle> util = new ExcelUtil<TRegulationsSelfHandle>(TRegulationsSelfHandle.class);
        util.exportExcel(response, list, "违法违规处置信息数据");
    }

    /**
     * 获取违法违规处置信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tRegulationsSelfHandleService.selectTRegulationsSelfHandleById(id));
    }

    /**
     * 新增违法违规处置信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:add')")
    @Log(title = "违法违规处置信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TRegulationsSelfHandle tRegulationsSelfHandle)
    {
        return toAjax(tRegulationsSelfHandleService.save(tRegulationsSelfHandle));
    }

    /**
     * 修改违法违规处置信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:edit')")
    @Log(title = "违法违规处置信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TRegulationsSelfHandle tRegulationsSelfHandle)
    {
        return toAjax(tRegulationsSelfHandleService.updateById(tRegulationsSelfHandle));
    }

    /**
     * 删除违法违规处置信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:remove')")
    @Log(title = "违法违规处置信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tRegulationsSelfHandleService.deleteTRegulationsSelfHandleByIds(ids));
    }
}
