package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TReferencePriceItem;
import com.fyzs.web.entity.query.TReferencePriceItemQuery;

/**
 * 食材标准参考价发布记录主Service接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
public interface ITReferencePriceItemService extends IService<TReferencePriceItem>
{
    /**
     * 查询食材标准参考价发布记录主
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 食材标准参考价发布记录主
     */
    public TReferencePriceItemQuery selectTReferencePriceItemById(Long id);

    /**
     * 查询食材标准参考价发布记录主列表
     * 
     * @param tReferencePriceItem 食材标准参考价发布记录主
     * @return 食材标准参考价发布记录主集合
     */
    public List<TReferencePriceItemQuery> selectTReferencePriceItemList(TReferencePriceItemQuery tReferencePriceItem);

    /**
     * 新增食材标准参考价发布记录主
     * 
     * @param tReferencePriceItem 食材标准参考价发布记录主
     * @return 结果
     */
    public int insertTReferencePriceItem(TReferencePriceItem tReferencePriceItem);

    /**
     * 修改食材标准参考价发布记录主
     * 
     * @param tReferencePriceItem 食材标准参考价发布记录主
     * @return 结果
     */
    public int updateTReferencePriceItem(TReferencePriceItem tReferencePriceItem);

    /**
     * 批量删除食材标准参考价发布记录主
     * 
     * @param ids 需要删除的食材标准参考价发布记录主主键集合
     * @return 结果
     */
    public int deleteTReferencePriceItemByIds(Long[] ids);

    /**
     * 删除食材标准参考价发布记录主信息
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 结果
     */
    public int deleteTReferencePriceItemById(Long id);
}
