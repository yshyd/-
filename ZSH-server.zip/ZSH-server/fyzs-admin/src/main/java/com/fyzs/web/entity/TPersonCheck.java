package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食堂人员日检对象 t_person_check
 *
 * @author ysh
 * @date 2025-11-19
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_person_check")
public class TPersonCheck implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 主体id
     */
    @Schema(description = "主体id")
    private Long deptId;

    /**
     * 对应食堂人员id
     */
    @Schema(description = "对应食堂人员id")
    private Long personId;

    /**
     * 类型1晨检、2午检、3晚检
     */
    @Schema(description = "类型1晨检、2午检、3晚检")
    @Excel(name = "类型1晨检、2午检、3晚检")
    private String type;

    /**
     * 检查时间
     */
    @Schema(description = "检查时间")
    @Excel(name = "检查时间")
    private String date;

    /**
     * 体温
     */
    @Schema(description = "体温")
    @Excel(name = "体温")
    private String temperature;

    /**
     * 指甲是否过长0否1是
     */
    @Schema(description = "指甲是否过长0否1是")
    @Excel(name = "指甲是否过长0否1是")
    private String isNails;

    /**
     * 是否有涂改指甲油0否1是
     */
    @Schema(description = "是否有涂改指甲油0否1是")
    @Excel(name = "是否有涂改指甲油0否1是")
    private String isNailPolish;

    /**
     * 是否发热0否1是
     */
    @Schema(description = "是否发热0否1是")
    @Excel(name = "是否发热0否1是")
    private String isHighTemperature;

    /**
     * 是否佩戴戒指等饰品饰物0否1是
     */
    @Schema(description = "是否佩戴戒指等饰品饰物0否1是")
    @Excel(name = "是否佩戴戒指等饰品饰物0否1是")
    private String isRing;

    /**
     * 手部是否存在异物0否1是
     */
    @Schema(description = "手部是否存在异物0否1是")
    @Excel(name = "手部是否存在异物0否1是")
    private String isForeignObject;

    /**
     * 着装是否规范0规范、1不规范
     */
    @Schema(description = "着装是否规范0规范、1不规范")
    @Excel(name = "着装是否规范0规范、1不规范")
    private String isDressCode;

    /**
     * 手心图片地址
     */
    @Schema(description = "手心图片地址")
    @Excel(name = "手心图片地址")
    private String palmImg;

    /**
     * 手背图片地址
     */
    @Schema(description = "手背图片地址")
    @Excel(name = "手背图片地址")
    private String backImg;

    /**
     * 全身着装图片地址
     */
    @Schema(description = "全身着装图片地址")
    @Excel(name = "全身着装图片地址")
    private String dressCodeIng;

    /**
     * 异常情况处置说明(存在发热、指甲过长、指甲油、佩戴饰品饰物、存在异物、着装不规范任意一个的情况下必填、限制1000个字符内)
     */
    @Schema(description = "异常情况处置说明(存在发热、指甲过长、指甲油、佩戴饰品饰物、存在异物、着装不规范任意一个的情况下必填、限制1000个字符内)")
    @Excel(name = "异常情况处置说明(存在发热、指甲过长、指甲油、佩戴饰品饰物、存在异物、着装不规范任意一个的情况下必填、限制1000个字符内)")
    private String handlingResult;

    /**
     * 整体情况0正常1异常
     */
    @Schema(description = "整体情况0正常1异常")
    @Excel(name = "整体情况0正常1异常")
    private Integer result;

    /**
     * 0有效1作废
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "0有效1作废")
    private Integer delFlag;

    /**
     * 创建人ID关联sys_user(软件系统上报必传)
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人ID关联sys_user(软件系统上报必传)")
    @Excel(name = "创建人ID关联sys_user(软件系统上报必传)")
    private Long createUser;

    /**
     * 创建人姓名(软件系统上报必传)
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名(软件系统上报必传)")
    @Excel(name = "创建人姓名(软件系统上报必传)")
    private String createName;

    /**
     * 修改人id关联sys_user(软件系统修改必传)
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id关联sys_user(软件系统修改必传)")
    @Excel(name = "修改人id关联sys_user(软件系统修改必传)")
    private Long updateUser;

    /**
     * 修改人名称(软件系统修改必传)
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称(软件系统修改必传)")
    @Excel(name = "修改人名称(软件系统修改必传)")
    private String updateName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date createDate;

    /**
     * 修改时间(修改必传)
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间(修改必传)")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "修改时间(修改必传)", width = 30, dateFormat = "yyyy-MM-dd")
    private Date updateDate;

    /**
     * 设备序列号(设备检查上报必传)
     */
    @Schema(description = "设备序列号(设备检查上报必传)")
    @Excel(name = "设备序列号(设备检查上报必传)")
    private String serialNumber;

    /**
     * 数据来源0软件系统、1硬件设备
     */
    @Schema(description = "数据来源0软件系统、1硬件设备")
    @Excel(name = "数据来源0软件系统、1硬件设备")
    private String source;

}
