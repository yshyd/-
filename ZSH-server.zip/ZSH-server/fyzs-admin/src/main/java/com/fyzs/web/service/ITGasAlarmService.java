package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TGasAlarm;
import com.fyzs.web.entity.query.TGasAlarmQuery;

/**
 * 可燃气体监测报警仪告警记录Service接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
public interface ITGasAlarmService extends IService<TGasAlarm>
{
    /**
     * 查询可燃气体监测报警仪告警记录
     * 
     * @param id 可燃气体监测报警仪告警记录主键
     * @return 可燃气体监测报警仪告警记录
     */
    public TGasAlarm selectTGasAlarmById(Long id);

    /**
     * 查询可燃气体监测报警仪告警记录列表
     * 
     * @param tGasAlarm 可燃气体监测报警仪告警记录
     * @return 可燃气体监测报警仪告警记录集合
     */
    public List<TGasAlarmQuery> selectTGasAlarmList(TGasAlarmQuery tGasAlarm);

    /**
     * 新增可燃气体监测报警仪告警记录
     * 
     * @param tGasAlarm 可燃气体监测报警仪告警记录
     * @return 结果
     */
    public int insertTGasAlarm(TGasAlarm tGasAlarm);

    /**
     * 修改可燃气体监测报警仪告警记录
     * 
     * @param tGasAlarm 可燃气体监测报警仪告警记录
     * @return 结果
     */
    public int updateTGasAlarm(TGasAlarm tGasAlarm);

    /**
     * 批量删除可燃气体监测报警仪告警记录
     * 
     * @param ids 需要删除的可燃气体监测报警仪告警记录主键集合
     * @return 结果
     */
    public int deleteTGasAlarmByIds(Long[] ids);

    /**
     * 删除可燃气体监测报警仪告警记录信息
     * 
     * @param id 可燃气体监测报警仪告警记录主键
     * @return 结果
     */
    public int deleteTGasAlarmById(Long id);
}
