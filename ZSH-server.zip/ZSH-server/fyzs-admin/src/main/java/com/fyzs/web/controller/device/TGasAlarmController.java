package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TGasAlarmQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TGasAlarm;
import com.fyzs.web.service.ITGasAlarmService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 可燃气体监测报警仪告警记录Controller
 * 
 * @author ysh
 * @date 2026-08-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/alarm")
public class TGasAlarmController extends BaseController
{

    private final ITGasAlarmService tGasAlarmService;

    /**
     * 查询可燃气体监测报警仪告警记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:list')")
    @GetMapping("/gas/list")
    public TableDataInfo list(TGasAlarmQuery tGasAlarm)
    {
        startPage();
        List<TGasAlarmQuery> list = tGasAlarmService.selectTGasAlarmList(tGasAlarm);
        return getDataTable(list);
    }

    /**
     * 导出可燃气体监测报警仪告警记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:export')")
    @Log(title = "可燃气体监测报警仪告警记录", businessType = BusinessType.EXPORT)
    @PostMapping("/gas/export")
    public void export(HttpServletResponse response, TGasAlarmQuery tGasAlarm)
    {
        List<TGasAlarmQuery> list = tGasAlarmService.selectTGasAlarmList(tGasAlarm);
        ExcelUtil<TGasAlarmQuery> util = new ExcelUtil<TGasAlarmQuery>(TGasAlarmQuery.class);
        util.exportExcel(response, list, "可燃气体监测报警仪告警记录数据");
    }

    /**
     * 获取可燃气体监测报警仪告警记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:query')")
    @GetMapping(value = "/gas/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tGasAlarmService.selectTGasAlarmById(id));
    }

    /**
     * 新增可燃气体监测报警仪告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:add')")
    @Log(title = "可燃气体监测报警仪告警记录", businessType = BusinessType.INSERT)
    @PostMapping("/gas/addAlarm")
    public AjaxResult add(@RequestBody TGasAlarm tGasAlarm)
    {
        return toAjax(tGasAlarmService.save(tGasAlarm));
    }

    /**
     * 修改可燃气体监测报警仪告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:edit')")
    @Log(title = "可燃气体监测报警仪告警记录", businessType = BusinessType.UPDATE)
    @PutMapping("/gas/editAlarm")
    public AjaxResult edit(@RequestBody TGasAlarm tGasAlarm)
    {
        return toAjax(tGasAlarmService.updateById(tGasAlarm));
    }

    /**
     * 删除可燃气体监测报警仪告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:remove')")
    @Log(title = "可燃气体监测报警仪告警记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/gas/delete/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tGasAlarmService.deleteTGasAlarmByIds(ids));
    }
}
