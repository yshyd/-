package com.fyzs.web.entity;

import lombok.Data;

@Data
public class WeeklyStats {
    private Long shouldDo; // 应做数量
    private Long done; // 已做数量
    private Long notDone; // 未做数量
    private Long normal; // 正常数量
    private Long abnormal; // 异常数量
    private Double executionRate; // 执行率
    private Double passRate; // 合格率
}