package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 价格管理对象 t_commodity_price
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_commodity_price")
public class TCommodityPrice implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        @NotNull(message = "主体id不能为空")
        private Long deptId;

        /** 供应商id */
        @Schema(description = "供应商id")
        @Excel(name = "供应商id")
        @NotNull(message = "供应商id不能为空")
        private Long supperId;

        /** 商品id */
        @Schema(description = "商品id")
        @Excel(name = "商品id")
        @NotNull(message = "商品id不能为空")
        private Long commodityId;

        /** 单价 */
        @Schema(description = "单价")
        @Excel(name = "单价")
        @NotNull(message = "单价不能为空")
        private BigDecimal price;

        /** 作用日期 */
        @Schema(description = "作用日期")
        @Excel(name = "作用日期")
        @NotNull(message = "作用日期不能为空")
        private String date;

        /** 调价开始时间 */
        @Schema(description = "调价开始时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "调价开始时间", width = 30, dateFormat = "yyyy-MM-dd")
        @NotNull(message = "调价开始时间不能为空")
        private Date startTime;

        /** 调价结束时间 */
        @Schema(description = "调价结束时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "调价结束时间", width = 30, dateFormat = "yyyy-MM-dd")
        @NotNull(message = "调价结束时间不能为空")
        private Date endTime;

        /** 0有效1无效(对应启用和禁用) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1无效(对应启用和禁用)")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
