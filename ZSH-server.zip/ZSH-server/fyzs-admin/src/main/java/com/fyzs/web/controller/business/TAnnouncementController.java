package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TAnnouncementDTO;
import com.fyzs.web.entity.query.TAnnouncementQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TAnnouncement;
import com.fyzs.web.service.ITAnnouncementService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 公告发布Controller
 * 
 * @author ysh
 * @date 2025-12-04
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/announcement")
public class TAnnouncementController extends BaseController
{

    private final ITAnnouncementService tAnnouncementService;

    /**
     * 查询公告发布列表
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAnnouncementQuery tAnnouncement)
    {
        startPage();
        List<TAnnouncementQuery> list = tAnnouncementService.selectTAnnouncementList(tAnnouncement);
        return getDataTable(list);
    }

    /**
     * 公告查阅
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:list')")
    @GetMapping("/look/list")
    public TableDataInfo lookList(TAnnouncementQuery tAnnouncement)
    {
        startPage();
        List<TAnnouncementQuery> list = tAnnouncementService.lookList(tAnnouncement);
        return getDataTable(list);
    }


    /**
     * 导出公告发布列表
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:export')")
    @Log(title = "公告发布", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TAnnouncementQuery tAnnouncement)
    {
        List<TAnnouncementQuery> list = tAnnouncementService.selectTAnnouncementList(tAnnouncement);
        ExcelUtil<TAnnouncementQuery> util = new ExcelUtil<TAnnouncementQuery>(TAnnouncementQuery.class);
        util.exportExcel(response, list, "公告发布数据");
    }

    /**
     * 获取公告发布详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tAnnouncementService.selectTAnnouncementById(id));
    }

    /**
     * 新增公告发布
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:add')")
    @Log(title = "公告发布", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TAnnouncementDTO tAnnouncement)
    {
        return toAjax(tAnnouncementService.insertTAnnouncement(tAnnouncement));
    }

    /**
     * 修改公告发布
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:edit')")
    @Log(title = "公告发布", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TAnnouncementDTO tAnnouncement)
    {
        return toAjax(tAnnouncementService.updateTAnnouncement(tAnnouncement));
    }

    /**
     * 启用/禁用
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:edit')")
    @Log(title = "公告发布", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TAnnouncementDTO tAnnouncement)
    {
        return toAjax(tAnnouncementService.updateById(tAnnouncement));
    }



    /**
     * 删除公告发布
     */
    //@PreAuthorize("@ss.hasPermi('web:announcement:remove')")
    @Log(title = "公告发布", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tAnnouncementService.deleteTAnnouncementByIds(ids));
    }
}
