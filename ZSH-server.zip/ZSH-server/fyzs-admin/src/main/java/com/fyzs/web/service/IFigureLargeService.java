package com.fyzs.web.service;

import com.fyzs.web.entity.PageResult;
import com.fyzs.web.entity.query.SummaryQuery;
import com.fyzs.web.entity.query.TAlarmQuery;
import com.fyzs.web.entity.vo.*;

import java.text.ParseException;
import java.util.List;

public interface IFigureLargeService {
    StatisticsResponseVO getStatistics(SummaryQuery query);

    List<SecurityRankingVO> getSecurityRanking(SummaryQuery query);

    List<RealTimeControlItemVO> getRealTimeControl(SummaryQuery query) throws ParseException;

    List<AlarmStatisticsVO> getAlarmStatistics(SummaryQuery query);

    PageResult<TAlarmQuery> getAlarmDetails(Integer pageNum, Integer pageSize, TAlarmQuery query);

    List<TAlarmQuery> getAlarm(SummaryQuery query);

    List<SupplyChainAnalysisVO> getSupplyChainAnalysis(SummaryQuery query);

    List<DinerRateAnalysisVO> getDinerRateAnalysis(SummaryQuery query);

    PageResult<SchoolDataDownVO> getSchoolDataDown(Integer pageNum, Integer pageSize,SchoolDataDownVO query);

    PageResult<CanteenDataDownVO> getCanteenDataDown(Integer pageNum, Integer pageSize,CanteenDataDownVO query);

    PageResult<PractitionerDataDownVO> getPractitionerDataDown(Integer pageNum, Integer pageSize,PractitionerDataDownVO query);

    PageResult<SupplierDataDownVO> getSupplierDataDown(Integer pageNum, Integer pageSize, SupplierDataDownVO query);

    InvoiceStatusVO getInvoiceStatus(SummaryQuery query);

    PageResult<InvoiceUploadedVO> getInvoiceUploadedDown(Integer pageNum, Integer pageSize, InvoiceUploadedVO query);

    List<MapVO> getMap(SummaryQuery query);
}
