package com.fyzs.web.controller.system;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.core.domain.model.RegisterBody;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.framework.web.service.SysRegisterService;
import com.fyzs.system.service.ISysConfigService;

/**
 * 注册验证
 * 
 * @author ysh
 */
@RestController
@AllArgsConstructor
public class SysRegisterController extends BaseController
{
    private  final SysRegisterService registerService;

    private  final ISysConfigService configService;

    @PostMapping("/register")
    public AjaxResult register(@RequestBody RegisterBody user)
    {
        if (!("true".equals(configService.selectConfigByKey("sys.account.registerUser"))))
        {
            return error("当前系统没有开启注册功能！");
        }
        String msg = registerService.register(user);
        return StringUtils.isEmpty(msg) ? success() : error(msg);
    }
}
