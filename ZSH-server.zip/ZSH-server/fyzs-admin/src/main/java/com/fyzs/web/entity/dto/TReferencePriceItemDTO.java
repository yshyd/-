package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TReferencePriceItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TReferencePriceItemDTO extends TReferencePriceItem {
}
