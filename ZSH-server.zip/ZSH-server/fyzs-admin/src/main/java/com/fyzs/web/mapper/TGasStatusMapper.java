package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TGasStatus;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 可燃气体监测报警仪实时状态Mapper接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
@Mapper
public interface TGasStatusMapper  extends BaseMapper<TGasStatus>
{
    /**
     * 查询可燃气体监测报警仪实时状态
     * 
     * @param id 可燃气体监测报警仪实时状态主键
     * @return 可燃气体监测报警仪实时状态
     */
    public TGasStatus selectTGasStatusById(Long id);

    /**
     * 查询可燃气体监测报警仪实时状态列表
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 可燃气体监测报警仪实时状态集合
     */
    public List<TGasStatus> selectTGasStatusList(TGasStatus tGasStatus);

    /**
     * 新增可燃气体监测报警仪实时状态
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 结果
     */
    public int insertTGasStatus(TGasStatus tGasStatus);

    /**
     * 修改可燃气体监测报警仪实时状态
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 结果
     */
    public int updateTGasStatus(TGasStatus tGasStatus);

    /**
     * 删除可燃气体监测报警仪实时状态
     * 
     * @param id 可燃气体监测报警仪实时状态主键
     * @return 结果
     */
    public int deleteTGasStatusById(Long id);

    /**
     * 批量删除可燃气体监测报警仪实时状态
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTGasStatusByIds(Long[] ids);
}
