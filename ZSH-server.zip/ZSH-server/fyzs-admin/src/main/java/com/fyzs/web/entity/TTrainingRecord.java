package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 工勤人员培训记录对象 t_training_record
 *
 * @author ysh
 * @date 2025-12-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_training_record")
public class TTrainingRecord implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 培训级别：0校级1区县级2市级3省级4其他 */
        @Schema(description = "培训级别：0校级1区县级2市级3省级4其他")
        @Excel(name = "培训级别：0校级1区县级2市级3省级4其他")
        private Integer trainLevel;

        /** 培训开始时间：年月日时分 */
        @Schema(description = "培训开始时间：年月日时分")
        @Excel(name = "培训开始时间：年月日时分")
        private String trainStart;

        /** 培训结束时间：年月日时分 */
        @Schema(description = "培训结束时间：年月日时分")
        @Excel(name = "培训结束时间：年月日时分")
        private String trainEnd;

        /** 培训时长分钟 */
        @Schema(description = "培训时长分钟")
        @Excel(name = "培训时长分钟")
        private Long trainTime;

        /** 培训主题 */
        @Schema(description = "培训主题")
        @Excel(name = "培训主题")
        private String trainTitle;

        /** 培训内容 */
        @Schema(description = "培训内容")
        @Excel(name = "培训内容")
        private String trainContent;

        /** 登记人 */
        @Schema(description = "登记人")
        @Excel(name = "登记人")
        private String registrantPerson;

        /** 登记时间(年月日时分) */
        @Schema(description = "登记时间(年月日时分)")
        @Excel(name = "登记时间(年月日时分)")
        private String registrantTime;

        /** 参培人员ID */
        @Schema(description = "参培人员ID")
        @Excel(name = "参培人员ID")
        private Long trainPersonId;

        /** 参培人员姓名 */
        @Schema(description = "参培人员姓名")
        @Excel(name = "参培人员姓名")
        private String trainPersonName;

        /** 状态0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "状态0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
