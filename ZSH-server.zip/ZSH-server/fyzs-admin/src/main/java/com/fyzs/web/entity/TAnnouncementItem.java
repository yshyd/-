package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 公告查阅对象 t_announcement_item
 *
 * @author ysh
 * @date 2025-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_announcement_item")
public class TAnnouncementItem implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 公告ID */
        @Schema(description = "公告ID")
        @Excel(name = "公告ID")
        private Long announcementId;

        /** 查阅主体ID */
        @Schema(description = "查阅主体ID")
        @Excel(name = "查阅主体ID")
        private Long deptId;

        /** 状态：0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "状态：0有效1作废")
        private Integer delFlag;

        /** 发布人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "发布人id")
        @Excel(name = "发布人id")
        private Long createUser;

        /** 发布人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "发布人姓名")
        @Excel(name = "发布人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
