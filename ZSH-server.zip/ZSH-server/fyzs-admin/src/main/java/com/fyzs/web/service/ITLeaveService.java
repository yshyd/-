package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TLeave;
import com.fyzs.web.entity.query.TLeaveQuery;

/**
 * 食堂人员请假信息管理Service接口
 * 
 * @author ysh
 * @date 2025-10-26
 */
public interface ITLeaveService extends IService<TLeave>
{
    /**
     * 查询食堂人员请假信息管理
     * 
     * @param id 食堂人员请假信息管理主键
     * @return 食堂人员请假信息管理
     */
    public TLeave selectTLeaveById(Long id);

    /**
     * 查询食堂人员请假信息管理列表
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 食堂人员请假信息管理集合
     */
    public List<TLeaveQuery> selectTLeaveList(TLeaveQuery tLeave);

    /**
     * 新增食堂人员请假信息管理
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 结果
     */
    public int insertTLeave(TLeave tLeave);

    /**
     * 修改食堂人员请假信息管理
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 结果
     */
    public int updateTLeave(TLeave tLeave);

    /**
     * 批量删除食堂人员请假信息管理
     * 
     * @param ids 需要删除的食堂人员请假信息管理主键集合
     * @return 结果
     */
    public int deleteTLeaveByIds(Long[] ids);

    /**
     * 删除食堂人员请假信息管理信息
     * 
     * @param id 食堂人员请假信息管理主键
     * @return 结果
     */
    public int deleteTLeaveById(Long id);

}
