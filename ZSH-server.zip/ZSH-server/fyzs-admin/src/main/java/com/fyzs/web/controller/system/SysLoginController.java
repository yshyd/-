package com.fyzs.web.controller.system;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.system.service.ISysDeptService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.constant.Constants;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.core.domain.entity.SysMenu;
import com.fyzs.common.core.domain.entity.SysUser;
import com.fyzs.common.core.domain.model.LoginBody;
import com.fyzs.common.core.domain.model.LoginUser;
import com.fyzs.common.core.text.Convert;
import com.fyzs.common.utils.DateUtils;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.framework.web.service.SysLoginService;
import com.fyzs.framework.web.service.SysPermissionService;
import com.fyzs.framework.web.service.TokenService;
import com.fyzs.system.service.ISysConfigService;
import com.fyzs.system.service.ISysMenuService;

/**
 * 登录验证
 * 
 * @author ysh
 */
@RestController
@AllArgsConstructor
public class SysLoginController
{
    private  final SysLoginService loginService;

    private  final ISysMenuService menuService;

    private  final SysPermissionService permissionService;

    private  final TokenService tokenService;

    private  final ISysConfigService configService;

    private  final ISysDeptService deptService;
    /**
     * 登录方法
     * 
     * @param loginBody 登录信息
     * @return 结果
     */
    @PostMapping("/login")
    public AjaxResult login(@RequestBody LoginBody loginBody)
    {
        AjaxResult ajax = AjaxResult.success();
        // 生成令牌
        String token = loginService.login(loginBody.getUsername(), loginBody.getPassword(), loginBody.getCode(),
                loginBody.getUuid());
        ajax.put(Constants.TOKEN, token);
        return ajax;
    }

    /**
     * 获取用户信息
     * 
     * @return 用户信息
     */
    @GetMapping("getInfo")
    public AjaxResult getInfo()
    {
        LoginUser loginUser = SecurityUtils.getLoginUser();
        SysUser user = loginUser.getUser();
        if (ObjectUtils.isNotEmpty(user.getDeptId())) {
            SysDept sysDept = deptService.selectDeptById(user.getDeptId());
            user.setAreaId(sysDept.getAreaId()==null?1L:sysDept.getAreaId());
            user.setAreaName(sysDept.getAreaName());
            user.setAreaCode(sysDept.getAreaCode());
            if (sysDept != null && StringUtils.isNotEmpty(sysDept.getIsParticipate())) {
                // 判断 isParticipate 是否包含 "05"
                String[] types = sysDept.getIsParticipate().split(",");
                boolean contains05 = Arrays.asList(types).contains("05");
                user.setIsSubject(contains05 ? 1 : 0);
            } else {
                user.setIsSubject(0);
            }
        }

        // 角色集合
        Set<String> roles = permissionService.getRolePermission(user);
        // 权限集合
        Set<String> permissions = permissionService.getMenuPermission(user);
        if (!loginUser.getPermissions().equals(permissions))
        {
            loginUser.setPermissions(permissions);
            tokenService.refreshToken(loginUser);
        }
        AjaxResult ajax = AjaxResult.success();
        ajax.put("user", user);
        ajax.put("roles", roles);
        ajax.put("permissions", permissions);
        ajax.put("isDefaultModifyPwd", initPasswordIsModify(user.getPwdUpdateDate()));
        ajax.put("isPasswordExpired", passwordIsExpiration(user.getPwdUpdateDate()));
        return ajax;
    }

    /**
     * 获取路由信息
     * 
     * @return 路由信息
     */
    @GetMapping("getRouters")
    public AjaxResult getRouters()
    {
        Long userId = SecurityUtils.getUserId();
        List<SysMenu> menus = menuService.selectMenuTreeByUserId(userId);
        return AjaxResult.success(menuService.buildMenus(menus));
    }
    
    // 检查初始密码是否提醒修改
    public boolean initPasswordIsModify(Date pwdUpdateDate)
    {
        Integer initPasswordModify = Convert.toInt(configService.selectConfigByKey("sys.account.initPasswordModify"));
        return initPasswordModify != null && initPasswordModify == 1 && pwdUpdateDate == null;
    }

    // 检查密码是否过期
    public boolean passwordIsExpiration(Date pwdUpdateDate)
    {
        Integer passwordValidateDays = Convert.toInt(configService.selectConfigByKey("sys.account.passwordValidateDays"));
        if (passwordValidateDays != null && passwordValidateDays > 0)
        {
            if (StringUtils.isNull(pwdUpdateDate))
            {
                // 如果从未修改过初始密码，直接提醒过期
                return true;
            }
            Date nowDate = DateUtils.getNowDate();
            return DateUtils.differentDaysByMillisecond(nowDate, pwdUpdateDate) > passwordValidateDays;
        }
        return false;
    }
}
