package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.entity.dto.CustomCameraDTO;
import com.fyzs.web.entity.dto.TCameraDTO;
import com.fyzs.web.entity.query.TCameraQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCamera;
import com.fyzs.web.service.ITCameraService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 可视化视频监控设备基本信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/camera")
public class TCameraController extends BaseController
{

    private final ITCameraService tCameraService;

    /**
     * 查询可视化视频监控设备基本信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCamera tCamera)
    {
        startPage();
        List<TCamera> list = tCameraService.selectTCameraList(tCamera);
        return getDataTable(list);
    }
    /**
     * 查询可视化视频监控设备基本信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:list')")
    @GetMapping("/relevance/list")
    public TableDataInfo relevanceList(TCameraQuery tCamera)
    {
        startPage();
        List<TCameraQuery> list = tCameraService.relevanceList(tCamera);
        return getDataTable(list);
    }
    /**
     * 导出可视化视频监控设备基本信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:export')")
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCamera tCamera)
    {
        List<TCamera> list = tCameraService.selectTCameraList(tCamera);
        ExcelUtil<TCamera> util = new ExcelUtil<TCamera>(TCamera.class);
        util.exportExcel(response, list, "可视化视频监控设备基本信息数据");
    }

    /**
     * 获取可视化视频监控设备基本信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraService.selectTCameraById(id));
    }

    /**
     * 查看关联详情
     */
    @GetMapping("/getRelationInfo/{id}")
    public AjaxResult getRelationInfo(@PathVariable("id") Long id){
        if (ObjectUtils.isEmpty( id)){
            return error("主键id未传");
        }
        return success(tCameraService.getRelationInfo(id));
    }

    /****
     * 新增摄像头信息(add)
     */
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.INSERT)
    @PostMapping("/addCamera")
    public AjaxResult addCamera(@RequestBody TCameraDTO dto)
    {
        return toAjax(tCameraService.addCamera(dto));
    }


    /**
     * 自定义新增
     */
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.INSERT)
    @PostMapping("/custom/addCamera")
    public AjaxResult customAddCamera(@RequestBody CustomCameraDTO tCamera)
    {
        return toAjax(tCameraService.insertTCamera(tCamera));
    }

    /**
     * 新增可视化视频监控设备基本信息
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:add')")
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCamera tCamera)
    {
        return toAjax(tCameraService.save(tCamera));
    }

    /**
     * 修改可视化视频监控设备基本信息
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:edit')")
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCamera tCamera)
    {
        return toAjax(tCameraService.updateById(tCamera));
    }

    /**
     * 修改
     */
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.UPDATE)
    @PutMapping("/update")
    public AjaxResult update(@RequestBody CustomCameraDTO tCamera){
        return toAjax(tCameraService.updateCamera(tCamera));
    }

    /**
     * 删除可视化视频监控设备基本信息
     */
    //@PreAuthorize("@ss.hasPermi('web:camera:remove')")
    @Log(title = "可视化视频监控设备基本信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraService.deleteTCameraByIds(ids));
    }

    /**
     * 区域主体权限树(带数量)
     */
    @GetMapping("/areaDataTree")
    public AjaxResult areaDataTree(SysAreaDTO sysArea) {
        return success(tCameraService.areaDataTree(sysArea));
    }
}
