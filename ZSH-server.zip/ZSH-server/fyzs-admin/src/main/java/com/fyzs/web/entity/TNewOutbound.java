package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 出库记录对象 t_new_outbound
 *
 * @author ysh
 * @date 2025-10-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_outbound")
public class TNewOutbound implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 仓库id */
        @Schema(description = "仓库id")
        @Excel(name = "仓库id")
        private Long warehouseId;

        /** 对应的库存记录ID */
        @Schema(description = "对应的库存记录ID")
        @Excel(name = "对应的库存记录ID")
        private Long inventoryId;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 批次 */
        @Schema(description = "批次")
        @Excel(name = "批次")
        private String batch;

        /** 出库单类型：0验收后立即出库1领用出库2调拨出库3盘亏出库4退货出库 */
        @Schema(description = "出库单类型：0验收后立即出库1领用出库2调拨出库3盘亏出库4退货出库")
        @Excel(name = "出库单类型：0验收后立即出库1领用出库2调拨出库3盘亏出库4退货出库")
        private Integer type;

        /** 出库数量 */
        @Schema(description = "出库数量")
        @Excel(name = "出库数量")
        private BigDecimal outNumber;

        /** 退回数量 */
        private BigDecimal returnNumber;

        /** 出库人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "出库人id")
        @Excel(name = "出库人id")
        private Long createUser;

        /** 出库人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "出库人姓名")
        @Excel(name = "出库人姓名")
        private String createName;

        /** 领用人姓名 */
        @Schema(description = "领用人姓名")
        @Excel(name = "领用人姓名")
        private String recipientName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 出库时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "出库时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "出库时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
