package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 设备基础信息对象 t_device
 *
 * @author ysh
 * @date 2025-12-09
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_device")
public class TDevice implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 设备序列号(全局唯一) */
        @Schema(description = "设备序列号(全局唯一)")
        @Excel(name = "设备序列号(全局唯一)")
        private String serialNumber;

        /** 型号 */
        @Schema(description = "型号")
        @Excel(name = "型号")
        private String model;

        /** 品牌 */
        @Schema(description = "品牌")
        @Excel(name = "品牌")
        private String brand;

        /** 设备类型：0留样柜、1晨检仪、2快检仪、3电子秤、4AI分析处理器、5公示机、6留样仪、7智能空气消毒净化机、8智能温湿度监测报警仪、9智能可燃气体监测报警仪 */
        @Schema(description = "设备类型：0留样柜、1晨检仪、2快检仪、3电子秤、4AI分析处理器、5公示机、6留样仪、7智能空气消毒净化机、8智能温湿度监测报警仪、9智能可燃气体监测报警仪")
        @Excel(name = "设备类型：0留样柜、1晨检仪、2快检仪、3电子秤、4AI分析处理器、5公示机、6留样仪、7智能空气消毒净化机、8智能温湿度监测报警仪、9智能可燃气体监测报警仪")
        private Integer type;

        /** 建设单位：默认(平台统建) */
        @Schema(description = "建设单位：默认(平台统建)")
        @Excel(name = "建设单位：默认(平台统建)")
        private String constructionUnit;

        /** 建设单位联系人 */
        @Schema(description = "建设单位联系人")
        @Excel(name = "建设单位联系人")
        private String constructionUnitUser;

        /** 建设单位联系人电话 */
        @Schema(description = "建设单位联系人电话")
        @Excel(name = "建设单位联系人电话")
        private String constructionUnitPhone;

        /** 设备图片，最多支持5张 */
        @Schema(description = "设备图片，最多支持5张")
        @Excel(name = "设备图片，最多支持5张")
        private String img;

        /** 设备状态：0有效1禁用 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "设备状态：0有效1禁用")
        private Long delFlag;

        /** 心跳时间 */
        @Schema(description = "心跳时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "心跳时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date heartTime;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
