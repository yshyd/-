package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayProductionProcess;
import com.fyzs.web.entity.query.TDayProductionProcessQuery;

/**
 * 学校食堂日管控-日常巡检-食品加工制作过程巡检Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayProductionProcessService extends IService<TDayProductionProcess>
{
    /**
     * 查询学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param id 学校食堂日管控-日常巡检-食品加工制作过程巡检主键
     * @return 学校食堂日管控-日常巡检-食品加工制作过程巡检
     */
    public TDayProductionProcessQuery selectTDayProductionProcessById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-食品加工制作过程巡检列表
     * 
     * @param query 学校食堂日管控-日常巡检-食品加工制作过程巡检
     * @return 学校食堂日管控-日常巡检-食品加工制作过程巡检集合
     */
    public List<TDayProductionProcessQuery> selectTDayProductionProcessList(TDayProductionProcessQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param tDayProductionProcess 学校食堂日管控-日常巡检-食品加工制作过程巡检
     * @return 结果
     */
    public int insertTDayProductionProcess(TDayProductionProcess tDayProductionProcess);

    /**
     * 修改学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param tDayProductionProcess 学校食堂日管控-日常巡检-食品加工制作过程巡检
     * @return 结果
     */
    public int updateTDayProductionProcess(TDayProductionProcess tDayProductionProcess);

    /**
     * 批量删除学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param ids 需要删除的学校食堂日管控-日常巡检-食品加工制作过程巡检主键集合
     * @return 结果
     */
    public int deleteTDayProductionProcessByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常巡检-食品加工制作过程巡检信息
     * 
     * @param id 学校食堂日管控-日常巡检-食品加工制作过程巡检主键
     * @return 结果
     */
    public int deleteTDayProductionProcessById(Long id);

    int cancel(TDayProductionProcess tDayProductionProcess);
}
