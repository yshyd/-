package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TAnnouncementItemQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TAnnouncementItem;
import com.fyzs.web.service.ITAnnouncementItemService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 公告查阅Controller
 * 
 * @author ysh
 * @date 2025-12-04
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/announcement/item")
public class TAnnouncementItemController extends BaseController
{

    private final ITAnnouncementItemService tAnnouncementItemService;

    /**
     * 查询公告查阅列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAnnouncementItemQuery tAnnouncementItem)
    {
        startPage();
        List<TAnnouncementItemQuery> list = tAnnouncementItemService.selectTAnnouncementItemList(tAnnouncementItem);
        return getDataTable(list);
    }

    /**
     * 导出公告查阅列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:export')")
    @Log(title = "公告查阅", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TAnnouncementItemQuery tAnnouncementItem)
    {
        List<TAnnouncementItemQuery> list = tAnnouncementItemService.selectTAnnouncementItemList(tAnnouncementItem);
        ExcelUtil<TAnnouncementItemQuery> util = new ExcelUtil<TAnnouncementItemQuery>(TAnnouncementItemQuery.class);
        util.exportExcel(response, list, "公告查阅数据");
    }

    /**
     * 获取公告查阅详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:item:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tAnnouncementItemService.selectTAnnouncementItemById(id));
    }

    /**
     * 新增公告查阅
     */
    //@PreAuthorize("@ss.hasPermi('web:item:add')")
    @Log(title = "公告查阅", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TAnnouncementItem tAnnouncementItem)
    {
        return toAjax(tAnnouncementItemService.save(tAnnouncementItem));
    }

    /**
     * 修改公告查阅
     */
    //@PreAuthorize("@ss.hasPermi('web:item:edit')")
    @Log(title = "公告查阅", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TAnnouncementItem tAnnouncementItem)
    {
        return toAjax(tAnnouncementItemService.updateById(tAnnouncementItem));
    }

    /**
     * 删除公告查阅
     */
    //@PreAuthorize("@ss.hasPermi('web:item:remove')")
    @Log(title = "公告查阅", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tAnnouncementItemService.deleteTAnnouncementItemByIds(ids));
    }
}
