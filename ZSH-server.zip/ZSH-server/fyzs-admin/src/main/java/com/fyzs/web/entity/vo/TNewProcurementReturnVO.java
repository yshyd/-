package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TNewProcurementReturn;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewProcurementReturnVO extends TNewProcurementReturn {



    @Schema(description = "仓库名称")
    @Excel(name = "仓库名称")
    private String warehouseName;

    @Schema(description = "供应商名称")
    @Excel(name = "供应商名称")
    private String supplerName;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;
    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 单位 */
    @Schema(description = "单位")
    @Excel(name = "单位")
    private String purchaUnit;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    /** 采购量 */
    @Schema(description = "采购量")
    @Excel(name = "采购量")
    private BigDecimal number;

}
