package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TAlarmQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.service.ITAlarmService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 预警信息Controller
 * 
 * @author ysh
 * @date 2025-11-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/alarm")
public class TAlarmController extends BaseController
{

    private final ITAlarmService tAlarmService;

    /**
     * 查询预警信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAlarmQuery query)
    {
        startPage();
        List<TAlarmQuery> list = tAlarmService.selectTAlarmList(query);
        return getDataTable(list);
    }

    /**
     * 导出预警信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:export')")
    @Log(title = "预警信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TAlarmQuery tAlarm)
    {
        List<TAlarmQuery> list = tAlarmService.selectTAlarmList(tAlarm);
        ExcelUtil<TAlarmQuery> util = new ExcelUtil<TAlarmQuery>(TAlarmQuery.class);
        util.exportExcel(response, list, "预警信息数据");
    }

    /**
     * 获取预警信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tAlarmService.selectTAlarmById(id));
    }

    /**
     * 批量处置(批量以及单个)
     */
    @PostMapping("/batchDispose")
    public AjaxResult batchDispose(@RequestBody List<TAlarm> list) {
        return success(tAlarmService.batchDispose(list));
    }


    /**
     * 新增预警信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:add')")
    @Log(title = "预警信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TAlarm tAlarm)
    {
        return toAjax(tAlarmService.save(tAlarm));
    }

    /**
     * 修改预警信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:edit')")
    @Log(title = "预警信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TAlarm tAlarm)
    {
        return toAjax(tAlarmService.updateById(tAlarm));
    }

    /**
     * 删除预警信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:remove')")
    @Log(title = "预警信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tAlarmService.deleteTAlarmByIds(ids));
    }
}
