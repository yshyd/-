package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraRegulationsVideo;

/**
 * 违法违规识别视频固证文件存储信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraRegulationsVideoService extends IService<TCameraRegulationsVideo>
{
    /**
     * 查询违法违规识别视频固证文件存储信息
     * 
     * @param id 违法违规识别视频固证文件存储信息主键
     * @return 违法违规识别视频固证文件存储信息
     */
    public TCameraRegulationsVideo selectTCameraRegulationsVideoById(Long id);

    /**
     * 查询违法违规识别视频固证文件存储信息列表
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 违法违规识别视频固证文件存储信息集合
     */
    public List<TCameraRegulationsVideo> selectTCameraRegulationsVideoList(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 新增违法违规识别视频固证文件存储信息
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 结果
     */
    public int insertTCameraRegulationsVideo(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 修改违法违规识别视频固证文件存储信息
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 结果
     */
    public int updateTCameraRegulationsVideo(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 批量删除违法违规识别视频固证文件存储信息
     * 
     * @param ids 需要删除的违法违规识别视频固证文件存储信息主键集合
     * @return 结果
     */
    public int deleteTCameraRegulationsVideoByIds(Long[] ids);

    /**
     * 删除违法违规识别视频固证文件存储信息信息
     * 
     * @param id 违法违规识别视频固证文件存储信息主键
     * @return 结果
     */
    public int deleteTCameraRegulationsVideoById(Long id);
}
