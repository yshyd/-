package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TWeekChemicalsQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWeekChemicals;
import com.fyzs.web.service.ITWeekChemicalsService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂周排查-化学品风险排查Controller
 * 
 * @author ysh
 * @date 2025-11-27
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/week/chemicals")
public class TWeekChemicalsController extends BaseController
{

    private final ITWeekChemicalsService tWeekChemicalsService;

    /**
     * 查询学校食堂周排查-化学品风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWeekChemicalsQuery tWeekChemicals)
    {
        startPage();
        List<TWeekChemicalsQuery> list = tWeekChemicalsService.selectTWeekChemicalsList(tWeekChemicals);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂周排查-化学品风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:export')")
    @Log(title = "学校食堂周排查-化学品风险排查", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWeekChemicalsQuery tWeekChemicals)
    {
        List<TWeekChemicalsQuery> list = tWeekChemicalsService.selectTWeekChemicalsList(tWeekChemicals);
        ExcelUtil<TWeekChemicalsQuery> util = new ExcelUtil<TWeekChemicalsQuery>(TWeekChemicalsQuery.class);
        util.exportExcel(response, list, "学校食堂周排查-化学品风险排查数据");
    }

    /**
     * 获取学校食堂周排查-化学品风险排查详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tWeekChemicalsService.selectTWeekChemicalsById(id));
    }

    /**
     * 新增学校食堂周排查-化学品风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:add')")
    @Log(title = "学校食堂周排查-化学品风险排查", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWeekChemicals tWeekChemicals)
    {
        return toAjax(tWeekChemicalsService.insertTWeekChemicals(tWeekChemicals));
    }

    /**
     * 修改学校食堂周排查-化学品风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:edit')")
    @Log(title = "学校食堂周排查-化学品风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWeekChemicals tWeekChemicals)
    {
        return toAjax(tWeekChemicalsService.updateTWeekChemicals(tWeekChemicals));
    }

    /**
     * 启用/禁用学校食堂周排查-化学品风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:edit')")
    @Log(title = "学校食堂周排查-化学品风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TWeekChemicals tWeekChemicals)
    {
        return toAjax(tWeekChemicalsService.cancel(tWeekChemicals));
    }

    /**
     * 删除学校食堂周排查-化学品风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:chemicals:remove')")
    @Log(title = "学校食堂周排查-化学品风险排查", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tWeekChemicalsService.deleteTWeekChemicalsByIds(ids));
    }
}
