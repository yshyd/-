package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TRecipseOperationQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TRecipseOperation;
import com.fyzs.web.service.ITRecipseOperationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)Controller
 * 
 * @author ysh
 * @date 2025-11-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/recipe/operation")
public class TRecipseOperationController extends BaseController
{

    private final ITRecipseOperationService tRecipseOperationService;

    /**
     * 查询食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:list')")
    @GetMapping("/list")
    public TableDataInfo list(TRecipseOperationQuery query)
    {
        startPage();
        List<TRecipseOperationQuery> list = tRecipseOperationService.selectTRecipseOperationList(query);
        return getDataTable(list);
    }
    /**
     * 查询食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pull(TRecipseOperationQuery query)
    {

        List<TRecipseOperationQuery> list = tRecipseOperationService.selectTRecipseOperationList(query);
        return getDataTable(list);
    }
    /**
     * 导出食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:export')")
    @Log(title = "食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TRecipseOperationQuery query)
    {
        List<TRecipseOperationQuery> list = tRecipseOperationService.selectTRecipseOperationList(query);
        ExcelUtil<TRecipseOperationQuery> util = new ExcelUtil<TRecipseOperationQuery>(TRecipseOperationQuery.class);
        util.exportExcel(response, list, "食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)数据");
    }

    /**
     * 获取食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tRecipseOperationService.selectTRecipseOperationById(id));
    }

    /**
     * 新增食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:add')")
    @Log(title = "食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TRecipseOperation tRecipseOperation)
    {
        return toAjax(tRecipseOperationService.save(tRecipseOperation));
    }

    /**
     * 修改食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:edit')")
    @Log(title = "食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TRecipseOperation tRecipseOperation)
    {
        return toAjax(tRecipseOperationService.updateById(tRecipseOperation));
    }

    /**
     * 删除食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:remove')")
    @Log(title = "食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tRecipseOperationService.deleteTRecipseOperationByIds(ids));
    }
}
