package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TSchoolInformationQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TSchoolInformation;
import com.fyzs.web.service.ITSchoolInformationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校信息档案Controller
 * 
 * @author ysh
 * @date 2025-12-08
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/school/information")
public class TSchoolInformationController extends BaseController
{

    private final ITSchoolInformationService tSchoolInformationService;

    /**
     * 查询学校信息档案列表
     */
    //@PreAuthorize("@ss.hasPermi('web:information:list')")
    @GetMapping("/list")
    public TableDataInfo list(TSchoolInformationQuery tSchoolInformation)
    {
        startPage();
        List<TSchoolInformationQuery> list = tSchoolInformationService.selectTSchoolInformationList(tSchoolInformation);
        return getDataTable(list);
    }

    /**
     * 导出学校信息档案列表
     */
    //@PreAuthorize("@ss.hasPermi('web:information:export')")
    @Log(title = "学校信息档案", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TSchoolInformationQuery tSchoolInformation)
    {
        List<TSchoolInformationQuery> list = tSchoolInformationService.selectTSchoolInformationList(tSchoolInformation);
        ExcelUtil<TSchoolInformationQuery> util = new ExcelUtil<TSchoolInformationQuery>(TSchoolInformationQuery.class);
        util.exportExcel(response, list, "学校信息档案数据");
    }

    /**
     * 获取学校信息档案详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:information:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tSchoolInformationService.selectTSchoolInformationById(id));
    }

    /**
     * 新增学校信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:add')")
    @Log(title = "学校信息档案", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TSchoolInformation tSchoolInformation)
    {
        //判断没有就新增,有就修改
        TSchoolInformation one = tSchoolInformationService.getOne(new LambdaQueryWrapper<>(TSchoolInformation.class)
                .eq(TSchoolInformation::getDeptId, tSchoolInformation.getDeptId())
                .eq(TSchoolInformation::getAreaId, tSchoolInformation.getAreaId())
        );
        tSchoolInformation.setDelFlag(0);
        if (!ObjectUtils.isEmpty( one)){
            tSchoolInformation.setId(one.getId());
            return toAjax(tSchoolInformationService.updateById(tSchoolInformation));
        }
        return toAjax(tSchoolInformationService.save(tSchoolInformation));
    }

    /**
     * 修改学校信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:edit')")
    @Log(title = "学校信息档案", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TSchoolInformation tSchoolInformation)
    {
        return toAjax(tSchoolInformationService.updateById(tSchoolInformation));
    }

    /**
     * 删除学校信息档案
     */
    //@PreAuthorize("@ss.hasPermi('web:information:remove')")
    @Log(title = "学校信息档案", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tSchoolInformationService.deleteTSchoolInformationByIds(ids));
    }
}
