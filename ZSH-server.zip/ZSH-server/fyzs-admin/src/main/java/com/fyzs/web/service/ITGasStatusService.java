package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TGasStatus;

/**
 * 可燃气体监测报警仪实时状态Service接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
public interface ITGasStatusService extends IService<TGasStatus>
{
    /**
     * 查询可燃气体监测报警仪实时状态
     * 
     * @param id 可燃气体监测报警仪实时状态主键
     * @return 可燃气体监测报警仪实时状态
     */
    public TGasStatus selectTGasStatusById(Long id);

    /**
     * 查询可燃气体监测报警仪实时状态列表
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 可燃气体监测报警仪实时状态集合
     */
    public List<TGasStatus> selectTGasStatusList(TGasStatus tGasStatus);

    /**
     * 新增可燃气体监测报警仪实时状态
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 结果
     */
    public int insertTGasStatus(TGasStatus tGasStatus);

    /**
     * 修改可燃气体监测报警仪实时状态
     * 
     * @param tGasStatus 可燃气体监测报警仪实时状态
     * @return 结果
     */
    public int updateTGasStatus(TGasStatus tGasStatus);

    /**
     * 批量删除可燃气体监测报警仪实时状态
     * 
     * @param ids 需要删除的可燃气体监测报警仪实时状态主键集合
     * @return 结果
     */
    public int deleteTGasStatusByIds(Long[] ids);

    /**
     * 删除可燃气体监测报警仪实时状态信息
     * 
     * @param id 可燃气体监测报警仪实时状态主键
     * @return 结果
     */
    public int deleteTGasStatusById(Long id);
}
