package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TCameraInfo;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCameraInfoDTO extends TCameraInfo {

    @Schema(description = "明厨亮灶三方接入信息表")
    private List<TCameraOpenLiveDTO> tCameraOpenLive;

}
