package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 温湿度检测仪的告警记录对象 t_th_alarm
 *
 * @author ysh
 * @date 2026-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_th_alarm")
public class TThAlarm implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 设备序列号对应t_device中serial_number */
        @Schema(description = "设备序列号对应t_device中serial_number")
        @Excel(name = "设备序列号对应t_device中serial_number")
        private String serialNumber;

        /** 告警类型、事件类型（HT 高温报警，LT 低温报警，HH 高湿报警，LH 低湿报警） */
        @Schema(description = "告警类型、事件类型（HT 高温报警，LT 低温报警，HH 高湿报警，LH 低湿报警）")
        @Excel(name = "告警类型、事件类型", readConverterExp = "H=T,高=温报警，LT,低=温报警，HH,高=湿报警，LH,低=湿报警")
        private String type;

        /** 报警时间(插入报警时系统时间) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "报警时间(插入报警时系统时间)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "报警时间(插入报警时系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

}
