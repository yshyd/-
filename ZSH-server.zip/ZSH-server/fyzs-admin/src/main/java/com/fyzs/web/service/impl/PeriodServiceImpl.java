// PeriodServiceImpl.java (修改后的完整实现)
package com.fyzs.web.service.impl;

import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.system.mapper.SysDeptMapper;
import com.fyzs.system.mapper.SysRoleDeptMapper;
import com.fyzs.system.service.ISysDeptService;
import com.fyzs.web.entity.dto.RoleDeptsDTO;
import com.fyzs.web.entity.query.TCanteenPractitionersQuery;
import com.fyzs.web.entity.query.TNewOutboundQuery;
import com.fyzs.web.entity.query.TSchoolInformationQuery;
import com.fyzs.web.entity.vo.*;
import com.fyzs.web.mapper.TCanteenPractitionersMapper;
import com.fyzs.web.mapper.TNewOutboundMapper;
import com.fyzs.web.mapper.TSchoolInformationMapper;
import com.fyzs.web.service.PeriodService;
import com.fyzs.web.utils.RoleDeptsUtils;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.util.ReflectionUtils;
import org.springframework.stereotype.Service;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
@Slf4j
public class PeriodServiceImpl implements PeriodService {

    private final TSchoolInformationMapper schoolInformationMapper;
    private final TNewOutboundMapper outboundMapper;
    private final SysDeptMapper deptMapper;
    private final ISysDeptService deptService;
    private final SysRoleDeptMapper sysRoleDeptMapper;

    private final TCanteenPractitionersMapper practitionerMapper;

    @Override
    public FoodConsumptionAnalysisVO analyzeFoodConsumption(Date startDate, Date endDate, Long deptId, Long areaId) {
        // 获取当前登录用户信息
        Long userId = SecurityUtils.getUserId();
        boolean isAdmin = userId.equals(1L);

        // 1. 获取用户有权限的部门 ID 列表（管理员返回 null 表示无限制）
        List<Long> authDeptIds = isAdmin ? null : sysRoleDeptMapper.selectAuthDeptIdsByUserIdWithDeptType(userId, null);

        // 2. 获取符合条件的学校列表（根据权限过滤）
        List<TSchoolInformationQuery> schools = getValidSchoolsWithPermission(deptId, areaId, authDeptIds, isAdmin);
        long schoolCount = schools.size();

        if (schoolCount == 0) {
            return createEmptyResult(startDate, endDate);
        }

        // 3. 提取学校 ID 列表
        List<Long> deptIds = schools.stream()
                .map(TSchoolInformationQuery::getDeptId)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        // 4. 查询出库记录
        List<TNewOutboundQuery> outbounds = getOutbounds(deptIds, startDate, endDate);

        // 5. 按商品分类统计总量
        Map<String, BigDecimal> categoryTotals = calculateCategoryTotals(outbounds);

        // 6. 计算人均消耗量
        Map<String, BigDecimal> perCapitaConsumptions = calculatePerCapitaConsumptions(categoryTotals, schoolCount);

        // 7. 获取学校名称列表
        List<String> schoolNames = schools.stream()
                .map(TSchoolInformationQuery::getDeptName)
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        // 8. 构造返回结果
        FoodConsumptionAnalysisVO result = new FoodConsumptionAnalysisVO();
        result.setSchoolCount(schoolCount);
        result.setSchoolNames(schoolNames);
        result.setCategoryTotals(categoryTotals);
        result.setPerCapitaConsumptions(perCapitaConsumptions);
        result.setStartDate(new SimpleDateFormat("yyyy-MM-dd").format(startDate));
        result.setEndDate(new SimpleDateFormat("yyyy-MM-dd").format(endDate));

        return result;
    }
    /**
     * 根据权限获取有效的学校信息
     * @param deptId 部门 ID（可选）
     * @param areaId 区域 ID（可选）
     * @param authDeptIds 用户有权限的部门 ID 列表（管理员为 null）
     * @param isAdmin 是否为管理员
     * @return 有效的学校列表
     */
    private List<TSchoolInformationQuery> getValidSchoolsWithPermission(Long deptId, Long areaId, List<Long> authDeptIds, boolean isAdmin) {
        TSchoolInformationQuery query = new TSchoolInformationQuery();

        // 根据不同参数组合确定查询条件
        if (deptId != null) {
            // 如果指定了 deptId，则只查询该学校
            query.setDeptId(deptId);
        } else if (areaId != null) {
            // 如果指定了 areaId，则查询该区域下的所有学校
            query.setAreaId(areaId);
        }

        // 查询提交了就餐人数的学校（number 字段不为空）
        List<TSchoolInformationQuery> allSchools = schoolInformationMapper.selectTSchoolInformationList(query);

        // 过滤掉没有提交就餐人数的学校
        List<TSchoolInformationQuery> validSchools = allSchools.stream()
                .filter(school -> school.getNumber() != null && school.getNumber() > 0)
                .collect(Collectors.toList());

        // 如果是管理员，直接返回所有有效学校
        if (isAdmin || authDeptIds == null) {
            return validSchools;
        }

        // 非管理员，过滤出有权限的学校
        return validSchools.stream()
                .filter(school -> authDeptIds.contains(school.getDeptId()))
                .collect(Collectors.toList());
    }
    /**
     * 获取有效的学校信息
     * @param deptId 部门ID（可选）
     * @param areaId 区域ID（可选）
     * @return 有效的学校列表
     */
    private List<TSchoolInformationQuery> getValidSchools(Long deptId, Long areaId) {
        TSchoolInformationQuery query = new TSchoolInformationQuery();

        // 根据不同参数组合确定查询条件
        if (deptId != null) {
            // 如果指定了deptId，则只查询该学校
            query.setDeptId(deptId);
        } else if (areaId != null) {
            // 如果指定了areaId，则查询该区域下的所有学校
            query.setAreaId(areaId);
        }

        // 查询提交了就餐人数的学校（number字段不为空）
        List<TSchoolInformationQuery> allSchools = schoolInformationMapper.selectTSchoolInformationList(query);

        // 过滤掉没有提交就餐人数的学校
        return allSchools.stream()
                .filter(school -> school.getNumber() != null && school.getNumber() > 0)
                .collect(Collectors.toList());
    }

    /**
     * 查询出库记录
     * @param deptIds 学校部门ID列表
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 出库记录列表
     */
    private List<TNewOutboundQuery> getOutbounds(List<Long> deptIds, Date startDate, Date endDate) {
        TNewOutboundQuery query = new TNewOutboundQuery();
        // 设置部门ID数组
        if (!deptIds.isEmpty()) {
            query.setDeptIds(deptIds);
        }
        // 设置时间范围
        query.setStartTime(startDate);
        query.setEndTime(endDate);

        return outboundMapper.getOutbounds(query);
    }

    /**
     * 按商品分类统计总量
     * @param outbounds 出库记录列表
     * @return 分类总量映射
     */
    private Map<String, BigDecimal> calculateCategoryTotals(List<TNewOutboundQuery> outbounds) {
        Map<String, BigDecimal> categoryTotals = new HashMap<>();

        for (TNewOutboundQuery outbound : outbounds) {
            // 使用商品名称作为分类，如果需要更精确的分类可以关联商品分类表
            String categoryName = outbound.getCategoryName() != null ? outbound.getCategoryName() : "未知分类";
            BigDecimal outNumber = outbound.getOutNumber() != null ? outbound.getOutNumber() : BigDecimal.ZERO;

            BigDecimal currentTotal = categoryTotals.getOrDefault(categoryName, BigDecimal.ZERO);
            categoryTotals.put(categoryName, currentTotal.add(outNumber));
        }

        return categoryTotals;
    }

    /**
     * 计算人均消耗量
     * @param categoryTotals 分类总量
     * @param schoolCount 学校数量
     * @return 人均消耗量映射
     */
    private Map<String, BigDecimal> calculatePerCapitaConsumptions(Map<String, BigDecimal> categoryTotals, long schoolCount) {
        Map<String, BigDecimal> perCapitaConsumptions = new HashMap<>();

        BigDecimal schoolCountDecimal = new BigDecimal(schoolCount);

        for (Map.Entry<String, BigDecimal> entry : categoryTotals.entrySet()) {
            String categoryName = entry.getKey();
            BigDecimal total = entry.getValue();

            // 人均消耗 = 总消耗量 / 学校数量，保留两位小数
            BigDecimal perCapita = total.divide(schoolCountDecimal, 2, RoundingMode.HALF_UP);
            perCapitaConsumptions.put(categoryName, perCapita);
        }

        return perCapitaConsumptions;
    }

    /**
     * 创建空结果
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 空的分析结果
     */
    private FoodConsumptionAnalysisVO createEmptyResult(Date startDate, Date endDate) {
        FoodConsumptionAnalysisVO result = new FoodConsumptionAnalysisVO();
        result.setSchoolCount(0L);
        result.setSchoolNames(new ArrayList<>());
        result.setCategoryTotals(new HashMap<>());
        result.setPerCapitaConsumptions(new HashMap<>());
        result.setStartDate(new SimpleDateFormat("yyyy-MM-dd").format(startDate));
        result.setEndDate(new SimpleDateFormat("yyyy-MM-dd").format(endDate));
        return result;
    }

    @Override
    public PractitionerAnalysisVO analyzePractitioners(Long deptId, Long areaId) {
        // 获取当前登录用户信息
        Long userId = SecurityUtils.getUserId();
        boolean isAdmin = userId.equals(1L);

        // 1. 首先获取用户有权限的部门 ID 列表
        // 注意：管理员返回 null 表示无限制，非管理员返回实际权限部门列表
        List<Long> authDeptIds = isAdmin ? null : sysRoleDeptMapper.selectAuthDeptIdsByUserIdWithDeptType(userId, null);

        // 2. 根据不同参数组合确定最终查询的部门 ID 列表
        List<Long> finalDeptIds;

        if (deptId != null) {
            // 指定了部门 ID：查询该部门及其所有下级部门
            // 如果是管理员或者该部门在权限范围内，则允许查询
            if (isAdmin || authDeptIds == null || authDeptIds.contains(deptId)) {
                // 查询该部门及其所有子部门
                List<SysDept> childrenDepts = deptMapper.selectChildrenDeptById(deptId);
                finalDeptIds = new ArrayList<>();
                finalDeptIds.add(deptId); // 添加当前部门
                for (SysDept dept : childrenDepts) {
                    // 非管理员需要过滤没有权限的部门
                    if (!isAdmin && authDeptIds != null && !authDeptIds.contains(dept.getDeptId())) {
                        continue;
                    }
                    finalDeptIds.add(dept.getDeptId());
                }
            } else {
                finalDeptIds = new ArrayList<>();
            }
        } else if (areaId != null) {
            // 指定了区域 ID：查询该区域下的部门
            // 查询该区域下的所有部门
            SysDept queryDept = new SysDept();
            queryDept.setAreaId(areaId);
            queryDept.setStatus("0"); // 只查询正常状态的部门
            List<SysDept> areaDepts = deptMapper.selectDeptList(queryDept);

            // 如果是管理员，直接使用该区域下的所有部门；否则过滤出有权限的部门
            if (isAdmin || authDeptIds == null) {
                finalDeptIds = areaDepts.stream()
                        .map(SysDept::getDeptId)
                        .collect(Collectors.toList());
            } else {
                finalDeptIds = areaDepts.stream()
                        .filter(d -> authDeptIds.contains(d.getDeptId()))
                        .map(SysDept::getDeptId)
                        .collect(Collectors.toList());
            }
        } else {
            // 未指定区域和部门：使用用户有权限的所有部门
            if (isAdmin || authDeptIds == null) {
                // 管理员不限制部门，查询所有
                finalDeptIds = new ArrayList<>();
            } else {
                finalDeptIds = authDeptIds;
            }
        }

        // 3. 构建查询条件
        TCanteenPractitionersQuery query = new TCanteenPractitionersQuery();
        query.setDeptIds(finalDeptIds);

        List<TCanteenPractitionersQuery> list = practitionerMapper.getPractitionerDataDown(query);
        int total = list.size();

        PractitionerAnalysisVO vo = new PractitionerAnalysisVO();

        // 性别分布
        vo.setGenderDistribution(calculateGenderDistribution(list, total));

        // 人员分布
        vo.setPositionDistributions(calculatePositionDistribution(list, total));

        // 健康证状态
        vo.setHealthCertificateStatus(calculateHealthStatus(list, total));

        // 年龄分布
        vo.setAgeDistribution(calculateAgeDistribution(list, total));

        // 学历分布
        vo.setEducationDistribution(calculateEducationDistribution(list, total));

        // 工龄分布
        vo.setWorkExperienceDistribution(calculateWorkExperienceDistribution(list, total));

        return vo;
    }





    /**
     * 计算性别分布
     */
    private GenderDistribution calculateGenderDistribution(List<TCanteenPractitionersQuery> list, int total) {
        GenderDistribution gd = new GenderDistribution();
        int maleCount = 0;
        int femaleCount = 0;

        for (TCanteenPractitionersQuery p : list) {
            if ("1".equals(p.getSex())) {
                maleCount++;
            } else if ("0".equals(p.getSex())) {
                femaleCount++;
            }
        }

        // 设置人数
        gd.setMaleCount(maleCount);
        gd.setFemaleCount(femaleCount);

        // 设置比例（避免除零）
        if (total > 0) {
            double maleRatio = (double) maleCount / total;
            double femaleRatio = (double) femaleCount / total;

            // 保留两位小数
            maleRatio = Math.round(maleRatio * 100.0) / 100.0;
            femaleRatio = Math.round(femaleRatio * 100.0) / 100.0;

            gd.setMaleRatio(maleRatio);
            gd.setFemaleRatio(femaleRatio);
        }

        return gd;
    }


    /**
     * 计算主体人员分布（按人数降序排列）
     */
    private List<PositionDistribution> calculatePositionDistribution(List<TCanteenPractitionersQuery> list, int total) {
        // 按 deptName 分组并统计人数
        Map<String, Integer> deptCountMap = list.stream()
                .collect(Collectors.groupingBy(
                        TCanteenPractitionersQuery::getDeptName,
                        Collectors.summingInt(p -> 1)
                ));

        // 转换为 PositionDistribution 列表，并按人数降序排序
        return deptCountMap.entrySet().stream()
                .map(entry -> {
                    PositionDistribution pd = new PositionDistribution();
                    pd.setDeptName(entry.getKey());
                    pd.setCount(entry.getValue());
                    return pd;
                })
                .sorted(Comparator.comparing(PositionDistribution::getCount).reversed())
                .collect(Collectors.toList());
    }

    /**
     * 计算健康证状态
     */
    private HealthCertificateStatus calculateHealthStatus(List<TCanteenPractitionersQuery> list, int total) {
        HealthCertificateStatus hcs = new HealthCertificateStatus();
        int valid = 0;
        int invalid = 0;

        for (TCanteenPractitionersQuery p : list) {
            if (isHealthCertificateValid(p)) {
                valid++;
            } else {
                invalid++;
            }
        }

        hcs.setValidCount(valid);
        hcs.setInvalidCount(invalid);

        if (total > 0) {
            double validRatio = (double) valid / total;
            double invalidRatio = (double) invalid / total;

            // 保留两位小数
            validRatio = Math.round(validRatio * 100.0) / 100.0;
            invalidRatio = Math.round(invalidRatio * 100.0) / 100.0;

            hcs.setValidRatio(validRatio);
            hcs.setInvalidRatio(invalidRatio);
        }
        return hcs;
    }

    private boolean isHealthCertificateValid(TCanteenPractitionersQuery p) {
        // 健康证未上传或结束日期为空，则视为无效
        if (p.getHealthCertificateEnd() == null || p.getHealthCertificateEnd().trim().isEmpty()) {
            return false;
        }

        Date now = new Date();
        try {
            Date end = new SimpleDateFormat("yyyy-MM-dd").parse(p.getHealthCertificateEnd());
            return end.after(now);
        } catch (Exception e) {
            log.warn("解析健康证结束日期失败: {}", p.getHealthCertificateEnd(), e);
            return false;
        }
    }



    /**
     * 计算年龄分布（根据身份证号计算真实年龄）
     */
    private AgeDistribution calculateAgeDistribution(List<TCanteenPractitionersQuery> list, int total) {
        AgeDistribution ad = new AgeDistribution();
        int under25 = 0, twentyFiveTo35 = 0, thirtySixTo45 = 0, over45 = 0;

        for (TCanteenPractitionersQuery p : list) {
            String idCard = p.getIdCard();
            if (idCard == null || idCard.length() < 18) {
                continue; // 身份证为空或长度不足，跳过
            }

            try {
                // 提取出生年份（身份证第 7-10 位）
                String birthYearStr = idCard.substring(6, 10);
                int birthYear = Integer.parseInt(birthYearStr);

                // 当前年份
                int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                int age = currentYear - birthYear;

                if (age < 25) {
                    under25++;
                } else if (age < 36) {
                    twentyFiveTo35++;
                } else if (age < 46) {
                    thirtySixTo45++;
                } else if (age <= 55) {
                    over45++;
                }
            } catch (Exception e) {
                log.warn("解析身份证失败：{}", idCard, e);
                continue;
            }
        }

        // 设置人数
        ad.setUnder25Count(under25);
        ad.setTwentyFiveTo35Count(twentyFiveTo35);
        ad.setThirtySixTo45Count(thirtySixTo45);
        ad.setOver45Count(over45);

        // 设置比例
        if (total > 0) {
            ad.setUnder25Ratio(Math.round((double) under25 / total * 100.0) / 100.0);
            ad.setTwentyFiveTo35Ratio(Math.round((double) twentyFiveTo35 / total * 100.0) / 100.0);
            ad.setThirtySixTo45Ratio(Math.round((double) thirtySixTo45 / total * 100.0) / 100.0);
            ad.setOver45Ratio(Math.round((double) over45 / total * 100.0) / 100.0);
        }

        return ad;
    }




    /**
     * 计算学历分布
     */
    private EducationDistribution calculateEducationDistribution(List<TCanteenPractitionersQuery> list, int total) {
        EducationDistribution ed = new EducationDistribution();
        Map<String, Integer> map = new HashMap<>();

        for (TCanteenPractitionersQuery p : list) {
            String edu = p.getEducation();
            if (edu == null || edu.trim().isEmpty()) {
                continue;
            }
            map.merge(edu, 1, Integer::sum);
        }

        // 根据数据库定义映射学历
        // 0:文盲，1:小学 -> primary(小学以下)
        // 2:初中 -> juniorHigh
        // 3:高中 -> seniorHigh
        // 4:专科 -> college
        // 5:本科 -> bachelor
        // 6:硕士 -> master
        // 7:博士 -> doctor
        ed.setPrimary(map.getOrDefault("0", 0) + map.getOrDefault("1", 0));  // 文盲 + 小学
        ed.setJuniorHigh(map.getOrDefault("2", 0));       // 初中
        ed.setSeniorHigh(map.getOrDefault("3", 0));       // 高中
        ed.setCollege(map.getOrDefault("4", 0));          // 专科
        ed.setBachelor(map.getOrDefault("5", 0));         // 本科
        ed.setMaster(map.getOrDefault("6", 0));           // 硕士
        ed.setDoctor(map.getOrDefault("7", 0));           // 博士

        // 直接设置比例，不使用反射
        if (total > 0) {
            ed.setPrimaryRatio(Math.round((double) ed.getPrimary() / total * 100.0) / 100.0);
            ed.setJuniorHighRatio(Math.round((double) ed.getJuniorHigh() / total * 100.0) / 100.0);
            ed.setSeniorHighRatio(Math.round((double) ed.getSeniorHigh() / total * 100.0) / 100.0);
            ed.setCollegeRatio(Math.round((double) ed.getCollege() / total * 100.0) / 100.0);
            ed.setBachelorRatio(Math.round((double) ed.getBachelor() / total * 100.0) / 100.0);
            ed.setMasterRatio(Math.round((double) ed.getMaster() / total * 100.0) / 100.0);
            ed.setDoctorRatio(Math.round((double) ed.getDoctor() / total * 100.0) / 100.0);
        }

        return ed;
    }



    /**
     * 计算工龄分布（按入职时间推算）
     */
    private WorkExperienceDistribution calculateWorkExperienceDistribution(List<TCanteenPractitionersQuery> list, int total) {
        WorkExperienceDistribution wd = new WorkExperienceDistribution();
        int lessThanOneYear = 0;      // 1 年以下
        int oneToThreeYears = 0;      // 1-3 年
        int threeToFiveYears = 0;     // 3-5 年
        int fiveToTenYears = 0;       // 5-10 年
        int overTenYears = 0;         // 10 年以上

        for (TCanteenPractitionersQuery p : list) {
            Date entryTime = p.getEntryTime();
            if (entryTime == null) {
                continue; // 入职时间为空，跳过
            }

            long days = (new Date().getTime() - entryTime.getTime()) / (24 * 60 * 60 * 1000);
            double years = days / 365.25;

            if (years < 1) {
                lessThanOneYear++;
            } else if (years < 3) {
                oneToThreeYears++;
            } else if (years < 5) {
                threeToFiveYears++;
            } else if (years < 10) {
                fiveToTenYears++;
            } else {
                overTenYears++;
            }
        }

        // 设置人数
        wd.setLessThanOneYear(lessThanOneYear);
        wd.setOneToThreeYears(oneToThreeYears);
        wd.setThreeToFiveYears(threeToFiveYears);
        wd.setFiveToTenYears(fiveToTenYears);
        wd.setOverTenYears(overTenYears);

        // 设置比例
        if (total > 0) {
            wd.setLessThanOneyearRatio(Math.round((double) lessThanOneYear / total * 100.0) / 100.0);
            wd.setOneToTwoYearsRatio(Math.round((double) oneToThreeYears / total * 100.0) / 100.0);
            wd.setThreeToFiveYearsRatio(Math.round((double) threeToFiveYears / total * 100.0) / 100.0);
            wd.setFiveToTenYearsRatio(Math.round((double) fiveToTenYears / total * 100.0) / 100.0);
            wd.setOverTenyearsRatio(Math.round((double) overTenYears / total * 100.0) / 100.0);
        }

        return wd;
    }



    /**
     * 设置比例（避免除以零）
     */
    private void setRatio(Object obj, int... counts) {
        int total = Arrays.stream(counts).sum();
        if (total == 0) return;

        double ratio = 1.0 / total;
        Class<?> clazz = obj.getClass();

        for (int i = 0; i < counts.length; i++) {
            String fieldName = "ratio" + (i + 1);
            try {
                Field field = clazz.getDeclaredField(fieldName);
                field.setAccessible(true);
                field.set(obj, counts[i] * ratio);
            } catch (NoSuchFieldException | IllegalAccessException e) {
                log.warn("无法设置字段: {}", fieldName);
            }
        }
    }


    private void setRatio(Object obj, int a, int b, int c, int d, int e, int f, int g, int total) {
        if (total == 0) return;

        // 使用 BigDecimal 进计算，保留两位小数
        BigDecimal ratio = new BigDecimal(1).divide(new BigDecimal(total), 2, RoundingMode.HALF_UP);

        Class<?> clazz = obj.getClass();

        try {
            // 手动映射每个字段
            Field[] fields = clazz.getDeclaredFields();
            Map<String, Integer> valueMap = new HashMap<>();
            valueMap.put("primaryRatio", a);
            valueMap.put("juniorHighRatio", b);
            valueMap.put("seniorhighRatio", c);
            valueMap.put("collegeRatio", d);
            valueMap.put("bachelorratio", e);
            valueMap.put("masterRatio", f);
            valueMap.put("doctorratio", g);

            for (Field field : fields) {
                if (field.getType() == Double.class && field.getName().endsWith("ratio")) {
                    field.setAccessible(true);
                    Integer val = valueMap.get(field.getName());
                    if (val != null) {
                        // 使用 BigDecimal 计算比例，保留两位小数
                        BigDecimal ratioValue = new BigDecimal(val).multiply(ratio);
                        field.set(obj, ratioValue.doubleValue());
                    }
                }
            }
        } catch (IllegalAccessException error) {
            log.warn("set比例失败", error);
        }
    }



}
