package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TNewProcurementWarehouseDTO;
import com.fyzs.web.entity.query.TNewProcurementWarehouseQuery;
import com.fyzs.web.entity.vo.TNewProcurementWarehouseExportVO;
import com.fyzs.web.utils.BatchNoGeneratorUtil;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewProcurementWarehouse;
import com.fyzs.web.service.ITNewProcurementWarehouseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 入库记录Controller
 * 
 * @author ysh
 * @date 2025-10-30
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/procurement/warehouse")
public class TNewProcurementWarehouseController extends BaseController
{

    private final ITNewProcurementWarehouseService warehouseService;

    /**
     * 查询入库记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewProcurementWarehouseQuery tNewProcurementWarehouse)
    {
        startPage();
        List<TNewProcurementWarehouseQuery> list = warehouseService.selectTNewProcurementWarehouseList(tNewProcurementWarehouse);
        return getDataTable(list);
    }

    /**
     * 导出入库记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:export')")
    @Log(title = "入库记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewProcurementWarehouseQuery tNewProcurementWarehouse)
    {
        List<TNewProcurementWarehouseExportVO> list = warehouseService.selectTNewProcurementWarehouseExportList(tNewProcurementWarehouse);
        ExcelUtil<TNewProcurementWarehouseExportVO> util = new ExcelUtil<TNewProcurementWarehouseExportVO>(TNewProcurementWarehouseExportVO.class);
        util.exportExcel(response, list, "入库记录数据");
    }

    /**
     * 获取入库记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(warehouseService.selectTNewProcurementWarehouseById(id));
    }
    /**
     * 入库操作
     */
    @PostMapping("/confirm")
    public AjaxResult warehouse(@RequestBody TNewProcurementWarehouseDTO dto) {
        return AjaxResult.success(warehouseService.warehouse(dto));
    }

    /**
     * 退领入库操作
     */
    @PostMapping("/return")
    public AjaxResult returnWarehouse(@RequestBody TNewProcurementWarehouseDTO dto) {
        return AjaxResult.success(warehouseService.returnWarehouse(dto));
    }

    /**
     * 新增入库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:add')")
    @Log(title = "入库记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewProcurementWarehouse tNewProcurementWarehouse)
    {
        String code = BatchNoGeneratorUtil.generateBatchNo();
        tNewProcurementWarehouse.setBatch(code);
        return toAjax(warehouseService.save(tNewProcurementWarehouse));
    }

    /**
     * 修改入库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:edit')")
    @Log(title = "入库记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewProcurementWarehouse tNewProcurementWarehouse)
    {
        return toAjax(warehouseService.updateById(tNewProcurementWarehouse));
    }

    /**
     * 删除入库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:remove')")
    @Log(title = "入库记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(warehouseService.deleteTNewProcurementWarehouseByIds(ids));
    }
}
