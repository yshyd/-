package com.fyzs.web.entity.query;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class TAcceptanceQuery {

    /**  */
    @Schema(description = "")
    private Long id;

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体id")
    private Long deptId;


    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "阈值")
    private Integer threshold;


    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;
    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;



    /** 单价：结算的时候要填充 */
    @Schema(description = "单价：结算的时候要填充")
    @Excel(name = "单价：结算的时候要填充")
    private BigDecimal price;

    /** 参考价格 */
    @Schema(description = "参考价格")
    @Excel(name = "参考价格")
    private BigDecimal referencePrice;


    /** 合计：确认结算的时候要填写 */
    @Schema(description = "合计：确认结算的时候要填写")
    @Excel(name = "合计：确认结算的时候要填写")
    private BigDecimal totalPrice;

    /** 结算状态：0待结算、1已结算 */
    @Schema(description = "结算状态：0待结算、1已结算")
    @Excel(name = "结算状态：0待结算、1已结算")
    private Integer status;


    /** 结算人(结算的时候必填) */
    @Schema(description = "结算人(结算的时候必填)")
    @Excel(name = "结算人(结算的时候必填)")
    private Long settlementId;

    /** 结算人姓名(结算的时候必填) */
    @Schema(description = "结算人姓名(结算的时候必填)")
    @Excel(name = "结算人姓名(结算的时候必填)")
    private String settlementName;

    /** 结算时间(结算的时候必填) */
    @Schema(description = "结算时间(结算的时候必填)")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "结算时间(结算的时候必填)", width = 30, dateFormat = "yyyy-MM-dd")
    private Date settlementDate;

    @Schema(description = "预警类型")
    @Excel(name = "预警类型")
    private String warningType;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;

}
