package com.fyzs.web.entity.vo;


import com.fyzs.common.annotation.Excel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
public class TNewProcurementVO {

    /** 采购单号 */
    @Schema(description = "采购单号")
    @Excel(name = "单号", sort = 1)
    private String procurementNum;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称", sort = 2)
    private String deptName;

    @Schema(description = "供应商名称")
    @Excel(name = "供应商", sort = 3)
    private String supplerName;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称", sort = 4)
    private String commodityName;

    /** 商品编码 */
    @Schema(description = "商品编码")
    @Excel(name = "商品编码", sort = 5)
    private String commodityCode;

    /** 采购量 */
    @Schema(description = "采购量")
    @Excel(name = "采购量", sort = 6)
    private BigDecimal number;

    /** 统一计量单位 */
    @Schema(description = "统一计量单位")
    @Excel(name = "单位", sort = 7)
    private String purchaUnit;

    /** 到货日期 */
    @Schema(description = "到货日期")
    @Excel(name = "到货日期", sort = 8)
    private String date;

    /** 采购时间 */
    @Schema(description = "采购时间")
    @Excel(name = "采购时间", sort = 9, width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;
}
