package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TWeekTableQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWeekTable;
import com.fyzs.web.service.ITWeekTableService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂周排查-周排查Controller
 *
 * @author ysh
 * @date 2025-11-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/week/table")
public class TWeekTableController extends BaseController {

    private final ITWeekTableService tWeekTableService;

    /**
     * 查询学校食堂周排查-周排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:table:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWeekTableQuery tWeekTable) {
        startPage();
        List<TWeekTableQuery> list = tWeekTableService.selectTWeekTableList(tWeekTable);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂周排查-周排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:table:export')")
    @Log(title = "学校食堂周排查-周排查", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWeekTableQuery tWeekTable) {
        List<TWeekTableQuery> list = tWeekTableService.selectTWeekTableList(tWeekTable);
        ExcelUtil<TWeekTableQuery> util = new ExcelUtil<TWeekTableQuery>(TWeekTableQuery.class);
        util.exportExcel(response, list, "学校食堂周排查-周排查数据");
    }

    /**
     * 获取学校食堂周排查-周排查详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:table:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(tWeekTableService.selectTWeekTableById(id));
    }

    /**
     * 新增学校食堂周排查-周排查
     */
    //@PreAuthorize("@ss.hasPermi('web:table:add')")
    @Log(title = "学校食堂周排查-周排查", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWeekTable tWeekTable) {
        return toAjax(tWeekTableService.insertTWeekTable(tWeekTable));
    }

    /**
     * 修改学校食堂周排查-周排查
     */
    //@PreAuthorize("@ss.hasPermi('web:table:edit')")
    @Log(title = "学校食堂周排查-周排查", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWeekTable tWeekTable) {
        return toAjax(tWeekTableService.updateTWeekTable(tWeekTable));
    }
    /**
     * 启用/禁用学校食堂周排查-周排查
     */
    //@PreAuthorize("@ss.hasPermi('web:table:edit')")
    @Log(title = "学校食堂周排查-周排查", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TWeekTable tWeekTable) {
        return toAjax(tWeekTableService.cancel(tWeekTable));
    }



    /**
     * 删除学校食堂周排查-周排查
     */
    //@PreAuthorize("@ss.hasPermi('web:table:remove')")
    @Log(title = "学校食堂周排查-周排查", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tWeekTableService.deleteTWeekTableByIds(ids));
    }
}
