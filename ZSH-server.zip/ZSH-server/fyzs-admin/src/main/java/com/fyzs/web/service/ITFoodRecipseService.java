package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.entity.TFoodRecipse;
import com.fyzs.web.entity.dto.TFoodRecipseDTO;
import com.fyzs.web.entity.query.TFoodRecipseQuery;
import com.fyzs.web.entity.vo.TFoodRecipseVO;

/**
 * 食堂菜谱、留样、试尝、陪餐信息Service接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
public interface ITFoodRecipseService extends IService<TFoodRecipse>
{
    /**
     * 查询食堂菜谱、留样、试尝、陪餐信息
     * 
     * @param id 食堂菜谱、留样、试尝、陪餐信息主键
     * @return 食堂菜谱、留样、试尝、陪餐信息
     */
    public TFoodRecipseQuery selectTFoodRecipseById(Long id);

    /**
     * 查询食堂菜谱、留样、试尝、陪餐信息列表
     *
     * @return 食堂菜谱、留样、试尝、陪餐信息集合
     */
    public List<TFoodRecipseQuery> selectTFoodRecipseList(TFoodRecipseQuery query);

    /**
     * 根据查询条件导出全部食堂菜谱留样数据（不分页）
     */
    public List<TFoodRecipseQuery> selectTFoodRecipseExportList(TFoodRecipseQuery query);

    /**
     * 新增食堂菜谱、留样、试尝、陪餐信息
     * 
     * @param tFoodRecipse 食堂菜谱、留样、试尝、陪餐信息
     * @return 结果
     */
    public int insertTFoodRecipse(TFoodRecipse tFoodRecipse);

    /**
     * 修改食堂菜谱、留样、试尝、陪餐信息
     * 
     * @param tFoodRecipse 食堂菜谱、留样、试尝、陪餐信息
     * @return 结果
     */
    public int updateTFoodRecipse(TFoodRecipse tFoodRecipse);

    /**
     * 批量删除食堂菜谱、留样、试尝、陪餐信息
     * 
     * @param ids 需要删除的食堂菜谱、留样、试尝、陪餐信息主键集合
     * @return 结果
     */
    public int deleteTFoodRecipseByIds(Long[] ids);

    /**
     * 删除食堂菜谱、留样、试尝、陪餐信息信息
     * 
     * @param id 食堂菜谱、留样、试尝、陪餐信息主键
     * @return 结果
     */
    public int deleteTFoodRecipseById(Long id);

    int batchTry(List<TFoodRecipse> tFoodRecipses);

    int batchUpdate(List<TFoodRecipse> tFoodRecipses);

    int batchMeal(List<TFoodRecipse> tFoodRecipses);

    int batchUpdateMeal(List<TFoodRecipse> tFoodRecipses);

    int batchUpdateDelFlag(List<TFoodRecipse> tFoodRecipses);

    int sample(TFoodRecipse tFoodRecipses);

    int updateSample(TFoodRecipse tFoodRecipses);

    int cancelSample(TFoodRecipse tFoodRecipses);

    int updateCancelSample(TFoodRecipse tFoodRecipses);

    int batchSample(List<TFoodRecipse> tFoodRecipses);

    List<TFoodRecipseVO> batchManage(TFoodRecipseDTO dto);

    int manageUpdate(TFoodRecipseDTO tFoodRecipses);

    int batchTryNew(TFoodRecipse tFoodRecipse);

    int batchUpdateNew(TFoodRecipse tFoodRecipse);

    int batchMealNew(TFoodRecipse tFoodRecipse);

    int batchUpdateMealNew(TFoodRecipse tFoodRecipse);

    int batchSampleNew(TFoodRecipse tFoodRecipse);

    int judgeSample(TFoodRecipse tFoodRecipse);
}
