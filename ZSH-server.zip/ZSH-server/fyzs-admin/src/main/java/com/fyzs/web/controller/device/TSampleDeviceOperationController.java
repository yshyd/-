package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TSampleDeviceOperationQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TSampleDeviceOperation;
import com.fyzs.web.service.ITSampleDeviceOperationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 留样柜操作日志Controller
 * 
 * @author ysh
 * @date 2025-12-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/sample/operation")
public class TSampleDeviceOperationController extends BaseController
{

    private final ITSampleDeviceOperationService tSampleDeviceOperationService;

    /**
     * 查询留样柜操作日志列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:list')")
    @GetMapping("/list")
    public TableDataInfo list(TSampleDeviceOperationQuery tSampleDeviceOperation)
    {
        startPage();
        List<TSampleDeviceOperationQuery> list = tSampleDeviceOperationService.selectTSampleDeviceOperationList(tSampleDeviceOperation);
        return getDataTable(list);
    }

    /**
     * 导出留样柜操作日志列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:export')")
    @Log(title = "留样柜操作日志", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TSampleDeviceOperationQuery tSampleDeviceOperation)
    {
        List<TSampleDeviceOperationQuery> list = tSampleDeviceOperationService.selectTSampleDeviceOperationList(tSampleDeviceOperation);
        ExcelUtil<TSampleDeviceOperationQuery> util = new ExcelUtil<TSampleDeviceOperationQuery>(TSampleDeviceOperationQuery.class);
        util.exportExcel(response, list, "留样柜操作日志数据");
    }

    /**
     * 获取留样柜操作日志详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tSampleDeviceOperationService.selectTSampleDeviceOperationById(id));
    }

    /**
     * 新增留样柜操作日志
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:add')")
    @Log(title = "留样柜操作日志", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TSampleDeviceOperation tSampleDeviceOperation)
    {
        return toAjax(tSampleDeviceOperationService.save(tSampleDeviceOperation));
    }

    /**
     * 修改留样柜操作日志
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:edit')")
    @Log(title = "留样柜操作日志", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TSampleDeviceOperation tSampleDeviceOperation)
    {
        return toAjax(tSampleDeviceOperationService.updateById(tSampleDeviceOperation));
    }

    /**
     * 删除留样柜操作日志
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:remove')")
    @Log(title = "留样柜操作日志", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tSampleDeviceOperationService.deleteTSampleDeviceOperationByIds(ids));
    }
}
