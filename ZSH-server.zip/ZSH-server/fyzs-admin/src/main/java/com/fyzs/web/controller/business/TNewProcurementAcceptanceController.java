package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.toolkit.ObjectUtils;
import com.fyzs.web.entity.TNewProcurement;
import com.fyzs.web.entity.dto.TNewProcurementAcceptanceDTO;
import com.fyzs.web.entity.query.TAcceptanceQuery;
import com.fyzs.web.entity.query.TNewProcurementAcceptanceQuery;
import com.fyzs.web.service.ITNewProcurementService;
import com.fyzs.web.service.impl.TNewProcurementServiceImpl;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewProcurementAcceptance;
import com.fyzs.web.service.ITNewProcurementAcceptanceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品采购验收Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/new/acceptance")
public class TNewProcurementAcceptanceController extends BaseController
{

    private final ITNewProcurementAcceptanceService tNewProcurementAcceptanceService;

    private final ITNewProcurementService tNewProcurementService;

    /**
     * 查询商品采购验收列表
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewProcurementAcceptanceQuery tNewProcurementAcceptance)
    {
        startPage();
        List<TNewProcurementAcceptanceQuery> list = tNewProcurementAcceptanceService.selectTNewProcurementAcceptanceList(tNewProcurementAcceptance);
        return getDataTable(list);
    }

    /**
     * 导出商品采购验收列表
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:export')")
    @Log(title = "商品采购验收", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewProcurementAcceptanceQuery tNewProcurementAcceptance)
    {
        List<TNewProcurementAcceptanceQuery> list = tNewProcurementAcceptanceService.selectTNewProcurementAcceptanceExportList(tNewProcurementAcceptance);
        ExcelUtil<TNewProcurementAcceptanceQuery> util = new ExcelUtil<TNewProcurementAcceptanceQuery>(TNewProcurementAcceptanceQuery.class);
        util.exportExcel(response, list, "商品采购验收数据");
    }

    /**
     * 获取商品采购验收详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tNewProcurementAcceptanceService.selectTNewProcurementAcceptanceById(id));
    }

    /**
     * 列表详情按钮
     */
    @GetMapping("/listDetail/{id}")
    public AjaxResult listDetail(@PathVariable("id") Long id) {
        return success(tNewProcurementAcceptanceService.listDetail(id));
    }

    /**
     * 入库按钮以及入库即出库按钮
     */
    @Log(title = "商品采购验收", businessType = BusinessType.UPDATE)
    @PutMapping("/warehoused")
    public AjaxResult warehoused(@RequestBody TNewProcurementAcceptanceDTO dto){
        return toAjax(tNewProcurementAcceptanceService.warehoused(dto));
    }

    /**
     * 批量查询价格
     */
    @PostMapping("/queryPrice")
    public AjaxResult queryPrice(@RequestBody Long[] ids){
        return success(tNewProcurementAcceptanceService.queryPrice(ids));
    }

    /**
     * 批量结算
     */
    @Log(title = "商品采购验收", businessType = BusinessType.UPDATE)
    @PutMapping("/settlement")
    public AjaxResult settlement(@RequestBody List<TNewProcurementAcceptanceDTO> dtos){
        return toAjax(tNewProcurementAcceptanceService.settlement(dtos));
    }




    /**
     * 新增商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:add')")
    @Log(title = "商品采购验收", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewProcurementAcceptance tNewProcurementAcceptance)
    {

        TNewProcurement procurement = tNewProcurementService.getOne(
                new com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper<>(TNewProcurement.class)
                        .eq(TNewProcurement::getProcurementNum, tNewProcurementAcceptance.getProcurementNum()));

        if (ObjectUtils.isEmpty(procurement)) {
            return error("采购单不存在");
        }

        if (procurement.getStatus() != 0) {
            return error("该采购单已验收,无法重新验收,请刷新页面!");
        }

        return toAjax(tNewProcurementAcceptanceService.save(tNewProcurementAcceptance));
    }

    /**
     * 修改商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:edit')")
    @Log(title = "商品采购验收", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewProcurementAcceptance tNewProcurementAcceptance)
    {
        return toAjax(tNewProcurementAcceptanceService.updateById(tNewProcurementAcceptance));
    }

    /**
     * 结算价格异常预警列表
     */
    @GetMapping("/settlementWarning")
    public TableDataInfo settlementWarning(TAcceptanceQuery query) {
        startPage();
        List<TAcceptanceQuery> list = tNewProcurementAcceptanceService.settlementWarning(query);
        return getDataTable(list);
    }

    /**
     * 删除商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:remove')")
    @Log(title = "商品采购验收", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tNewProcurementAcceptanceService.deleteTNewProcurementAcceptanceByIds(ids));
    }
}
