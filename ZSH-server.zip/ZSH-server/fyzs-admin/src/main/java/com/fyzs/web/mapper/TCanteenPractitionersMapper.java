package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCanteenPractitioners;
import com.fyzs.web.entity.query.TCanteenPractitionersQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 食堂人员基础信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-26
 */
@Mapper
public interface TCanteenPractitionersMapper  extends BaseMapper<TCanteenPractitioners>
{
    /**
     * 查询食堂人员基础信息
     * 
     * @param id 食堂人员基础信息主键
     * @return 食堂人员基础信息
     */
    public TCanteenPractitioners selectTCanteenPractitionersById(Long id);

    /**
     * 查询食堂人员基础信息列表
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 食堂人员基础信息集合
     */
    public List<TCanteenPractitionersQuery> selectTCanteenPractitionersList(TCanteenPractitionersQuery tCanteenPractitioners);

    /**
     * 新增食堂人员基础信息
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 结果
     */
    public int insertTCanteenPractitioners(TCanteenPractitioners tCanteenPractitioners);

    /**
     * 修改食堂人员基础信息
     * 
     * @param tCanteenPractitioners 食堂人员基础信息
     * @return 结果
     */
    public int updateTCanteenPractitioners(TCanteenPractitioners tCanteenPractitioners);

    /**
     * 删除食堂人员基础信息
     * 
     * @param id 食堂人员基础信息主键
     * @return 结果
     */
    public int deleteTCanteenPractitionersById(Long id);

    /**
     * 批量删除食堂人员基础信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCanteenPractitionersByIds(Long[] ids);

    List<TCanteenPractitionersQuery> getPractitionerDataDown(TCanteenPractitionersQuery practitionersQuery);

    int countValidSuppliers(TCanteenPractitionersQuery practitionersQuery);

    /**
     * 查询指定部门下的所有工勤人员 ID 列表
     * @param deptIds 部门 ID 列表
     * @return 工勤人员 ID 列表
     */
    List<Long> selectPractitionerIdsByDeptIds(@Param("deptIds") List<Long> deptIds);

}
