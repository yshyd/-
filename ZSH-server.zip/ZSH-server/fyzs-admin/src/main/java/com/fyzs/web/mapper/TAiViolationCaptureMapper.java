package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TAiViolationCapture;
import com.fyzs.web.entity.query.TAiViolationCaptureQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * AI违规抓拍Mapper接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
@Mapper
public interface TAiViolationCaptureMapper  extends BaseMapper<TAiViolationCapture>
{
    /**
     * 查询AI违规抓拍
     * 
     * @param id AI违规抓拍主键
     * @return AI违规抓拍
     */
    public TAiViolationCaptureQuery selectTAiViolationCaptureById(Long id);

    /**
     * 查询AI违规抓拍列表
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return AI违规抓拍集合
     */
    public List<TAiViolationCaptureQuery> selectTAiViolationCaptureList(TAiViolationCaptureQuery tAiViolationCapture);

    /**
     * 新增AI违规抓拍
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return 结果
     */
    public int insertTAiViolationCapture(TAiViolationCapture tAiViolationCapture);

    /**
     * 修改AI违规抓拍
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return 结果
     */
    public int updateTAiViolationCapture(TAiViolationCapture tAiViolationCapture);

    /**
     * 删除AI违规抓拍
     * 
     * @param id AI违规抓拍主键
     * @return 结果
     */
    public int deleteTAiViolationCaptureById(Long id);

    /**
     * 批量删除AI违规抓拍
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTAiViolationCaptureByIds(Long[] ids);
}
