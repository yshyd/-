package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TProcurementAcceptance;

/**
 * 商品采购验收Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITProcurementAcceptanceService extends IService<TProcurementAcceptance>
{
    /**
     * 查询商品采购验收
     * 
     * @param id 商品采购验收主键
     * @return 商品采购验收
     */
    public TProcurementAcceptance selectTProcurementAcceptanceById(Long id);

    /**
     * 查询商品采购验收列表
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 商品采购验收集合
     */
    public List<TProcurementAcceptance> selectTProcurementAcceptanceList(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 新增商品采购验收
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int insertTProcurementAcceptance(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 修改商品采购验收
     * 
     * @param tProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int updateTProcurementAcceptance(TProcurementAcceptance tProcurementAcceptance);

    /**
     * 批量删除商品采购验收
     * 
     * @param ids 需要删除的商品采购验收主键集合
     * @return 结果
     */
    public int deleteTProcurementAcceptanceByIds(Long[] ids);

    /**
     * 删除商品采购验收信息
     * 
     * @param id 商品采购验收主键
     * @return 结果
     */
    public int deleteTProcurementAcceptanceById(Long id);
}
