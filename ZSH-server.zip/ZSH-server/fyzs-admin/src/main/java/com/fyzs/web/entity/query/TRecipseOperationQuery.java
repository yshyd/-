package com.fyzs.web.entity.query;

import com.fyzs.web.entity.TRecipseOperation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TRecipseOperationQuery extends TRecipseOperation {

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
