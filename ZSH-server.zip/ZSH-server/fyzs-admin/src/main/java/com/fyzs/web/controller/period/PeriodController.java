package com.fyzs.web.controller.period;

import com.fyzs.web.entity.vo.FoodConsumptionAnalysisVO;
import com.fyzs.web.entity.vo.PractitionerAnalysisVO;
import com.fyzs.web.service.PeriodService;
import lombok.AllArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

/**
 * 大数据分析模块
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/period")
public class PeriodController {

    private final PeriodService periodService;

    /**
     * 食材消耗大数据分析
     *
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @param deptId    学校部门ID（可选）
     * @param areaId    区域ID（可选）
     * @return 食材消耗分析结果
     */
    @GetMapping("/foodConsumption")
    public ResponseEntity<FoodConsumptionAnalysisVO> analyzeFoodConsumption(
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date startDate,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date endDate,
            @RequestParam(required = false) Long deptId,
            @RequestParam(required = false) Long areaId) {

        if (startDate.after(endDate)) {
            throw new IllegalArgumentException("开始日期不能晚于结束日期");
        }

        FoodConsumptionAnalysisVO result = periodService.analyzeFoodConsumption(startDate, endDate, deptId, areaId);
        return ResponseEntity.ok(result);
    }

    /**
     * 工勤人员大数据分析
     */
    @GetMapping("/practitionerAnalysis")
    public ResponseEntity<PractitionerAnalysisVO> analyzePractitioners(
            @RequestParam(required = false) Long deptId,
            @RequestParam(required = false) Long areaId) {

        PractitionerAnalysisVO result = periodService.analyzePractitioners(deptId, areaId);
        return ResponseEntity.ok(result);
    }
}
