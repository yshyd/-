package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TLeave;
import com.fyzs.web.entity.query.TLeaveQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 食堂人员请假信息管理Mapper接口
 * 
 * @author ysh
 * @date 2025-10-26
 */
@Mapper
public interface TLeaveMapper  extends BaseMapper<TLeave>
{
    /**
     * 查询食堂人员请假信息管理
     * 
     * @param id 食堂人员请假信息管理主键
     * @return 食堂人员请假信息管理
     */
    public TLeave selectTLeaveById(Long id);

    /**
     * 查询食堂人员请假信息管理列表
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 食堂人员请假信息管理集合
     */
    public List<TLeaveQuery> selectTLeaveList(TLeaveQuery tLeave);

    /**
     * 新增食堂人员请假信息管理
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 结果
     */
    public int insertTLeave(TLeave tLeave);

    /**
     * 修改食堂人员请假信息管理
     * 
     * @param tLeave 食堂人员请假信息管理
     * @return 结果
     */
    public int updateTLeave(TLeave tLeave);

    /**
     * 删除食堂人员请假信息管理
     * 
     * @param id 食堂人员请假信息管理主键
     * @return 结果
     */
    public int deleteTLeaveById(Long id);

    /**
     * 批量删除食堂人员请假信息管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTLeaveByIds(Long[] ids);
}
