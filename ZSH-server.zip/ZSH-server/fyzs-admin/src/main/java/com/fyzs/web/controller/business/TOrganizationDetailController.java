package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.common.utils.ImageURL;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.system.domain.TFoodBusinessLicense;
import com.fyzs.system.domain.TOrganizationDetail;
import com.fyzs.system.domain.query.TOrganizationDetailQuery;
import com.fyzs.system.service.ITOrganizationDetailService;
import com.fyzs.web.controller.common.CommonController;
import lombok.AllArgsConstructor;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;

import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 组织机构基本信息Controller
 * 
 * @author ysh
 * @date 2025-10-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/organization")
public class TOrganizationDetailController extends BaseController
{

    private final ITOrganizationDetailService tOrganizationDetailService;

    /**
     * 查询组织机构基本信息列表
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:list')")
    @GetMapping("/list")
    public TableDataInfo list(TOrganizationDetailQuery tOrganizationDetail)
    {
        startPage();
        List<TOrganizationDetailQuery> list = tOrganizationDetailService.selectTOrganizationDetailList(tOrganizationDetail);
        return getDataTable(list);
    }

    /**
     * 导出组织机构基本信息列表
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:export')")
    @Log(title = "组织机构基本信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TOrganizationDetailQuery tOrganizationDetail)
    {
        List<TOrganizationDetailQuery> list = tOrganizationDetailService.selectTOrganizationDetailList(tOrganizationDetail);
        ExcelUtil<TOrganizationDetailQuery> util = new ExcelUtil<TOrganizationDetailQuery>(TOrganizationDetailQuery.class);
        util.exportExcel(response, list, "组织机构基本信息数据");
    }

    /**
     * 获取组织机构基本信息详细信息
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tOrganizationDetailService.selectTOrganizationDetailById(id));
    }

    /**
     * 获取组织机构基本信息详细信息
     */
    //@PreAuthohorize("@ss.hasPermi('system:detail:query')")
    @GetMapping(value = "/info/{deptId}")
    public AjaxResult getDeptInfo(@PathVariable("deptId") Long deptId)
    {

        LambdaQueryWrapper<TOrganizationDetail> queryWrapper = new LambdaQueryWrapper<>();
        queryWrapper.eq(TOrganizationDetail::getDeptId, deptId);

        return success(tOrganizationDetailService.getOne(queryWrapper));
    }


    /**
     * 新增组织机构基本信息
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:add')")
    @Log(title = "组织机构基本信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TOrganizationDetail tOrganizationDetail)
    {
        TOrganizationDetail one = tOrganizationDetailService.getOne(new LambdaQueryWrapper<>(TOrganizationDetail.class)
                .eq(TOrganizationDetail::getDeptId, tOrganizationDetail.getDeptId())
        );
        if (!ObjectUtils.isEmpty( one)){
            tOrganizationDetail.setId(one.getId());
            return toAjax(tOrganizationDetailService.updateById(tOrganizationDetail));
        }
        return toAjax(tOrganizationDetailService.save(tOrganizationDetail));
    }

    /**
     * 修改组织机构基本信息
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:edit')")
    @Log(title = "组织机构基本信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TOrganizationDetail tOrganizationDetail)
    {
        // 先查询原记录
        TOrganizationDetail existingLicense = tOrganizationDetailService.getById(tOrganizationDetail.getId());
        if (org.apache.commons.lang3.ObjectUtils.isNotEmpty(existingLicense)) {
            // 处理图片字段 - 假设实体中有 licenseImg 字段
            if (StringUtils.isNotEmpty(existingLicense.getImg())) {
                // 如果修改后的图片为空或者与原图片不同，则删除原图片
                if (StringUtils.isEmpty(tOrganizationDetail.getImg()) ||
                        !existingLicense.getImg().equals(tOrganizationDetail.getImg())) {
                    String[] originalImages = existingLicense.getImg().split(",");
                    for (String imageUrl : originalImages) {
                        String key = ImageURL.extractKeyFromUrl(imageUrl.trim());
                        if (org.apache.commons.lang3.StringUtils.isNotBlank(key)) {
                            CommonController.deleteOldImage(key);
                        }
                    }
                }
            }
        }

        return toAjax(tOrganizationDetailService.updateById(tOrganizationDetail));
    }

    /**
     * 删除组织机构基本信息
     */
  //@PreAuthohorize("@ss.hasPermi('system:detail:remove')")
    @Log(title = "组织机构基本信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tOrganizationDetailService.deleteTOrganizationDetailByIds(ids));
    }
}
