package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TWeekSupplierRiskQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWeekSupplierRisk;
import com.fyzs.web.service.ITWeekSupplierRiskService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂周排查-供应商风险排查Controller
 * 
 * @author ysh
 * @date 2025-11-27
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/supplier/risk")
public class TWeekSupplierRiskController extends BaseController
{

    private final ITWeekSupplierRiskService tWeekSupplierRiskService;

    /**
     * 查询学校食堂周排查-供应商风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWeekSupplierRiskQuery tWeekSupplierRisk)
    {
        startPage();
        List<TWeekSupplierRiskQuery> list = tWeekSupplierRiskService.selectTWeekSupplierRiskList(tWeekSupplierRisk);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂周排查-供应商风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:export')")
    @Log(title = "学校食堂周排查-供应商风险排查", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWeekSupplierRiskQuery tWeekSupplierRisk)
    {
        List<TWeekSupplierRiskQuery> list = tWeekSupplierRiskService.selectTWeekSupplierRiskList(tWeekSupplierRisk);
        ExcelUtil<TWeekSupplierRiskQuery> util = new ExcelUtil<TWeekSupplierRiskQuery>(TWeekSupplierRiskQuery.class);
        util.exportExcel(response, list, "学校食堂周排查-供应商风险排查数据");
    }

    /**
     * 获取学校食堂周排查-供应商风险排查详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tWeekSupplierRiskService.selectTWeekSupplierRiskById(id));
    }

    /**
     * 新增学校食堂周排查-供应商风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:add')")
    @Log(title = "学校食堂周排查-供应商风险排查", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWeekSupplierRisk tWeekSupplierRisk)
    {
        return toAjax(tWeekSupplierRiskService.insertTWeekSupplierRisk(tWeekSupplierRisk));
    }

    /**
     * 修改学校食堂周排查-供应商风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:edit')")
    @Log(title = "学校食堂周排查-供应商风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWeekSupplierRisk tWeekSupplierRisk)
    {
        return toAjax(tWeekSupplierRiskService.updateTWeekSupplierRisk(tWeekSupplierRisk));
    }

    /**
     * 启用/禁用学校食堂周排查-供应商风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:edit')")
    @Log(title = "学校食堂周排查-供应商风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TWeekSupplierRisk tWeekSupplierRisk)
    {
        return toAjax(tWeekSupplierRiskService.cancel(tWeekSupplierRisk));
    }

    /**
     * 删除学校食堂周排查-供应商风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:risk:remove')")
    @Log(title = "学校食堂周排查-供应商风险排查", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tWeekSupplierRiskService.deleteTWeekSupplierRiskByIds(ids));
    }
}
