package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常巡检-库房贮藏巡检对象 t_day_storage_warehouse
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_storage_warehouse")
public class TDayStorageWarehouse implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 货物贮存是否达标 1、分区存放如：主食库，副食库，冷藏库，冷冻库等分区存放 2、严禁混放，如清洁剂、杀虫剂、个人物品和食品混放 3、严禁存放过期食材 4、生熟分开，严禁将生食、半成品、熟食混放 任何一项不满足这里都是否 0是1否 */
        @Schema(description = "货物贮存是否达标 1、分区存放如：主食库，副食库，冷藏库，冷冻库等分区存放 2、严禁混放，如清洁剂、杀虫剂、个人物品和食品混放 3、严禁存放过期食材 4、生熟分开，严禁将生食、半成品、熟食混放 任何一项不满足这里都是否 0是1否")
        @Excel(name = "货物贮存是否达标 1、分区存放如：主食库，副食库，冷藏库，冷冻库等分区存放 2、严禁混放，如清洁剂、杀虫剂、个人物品和食品混放 3、严禁存放过期食材 4、生熟分开，严禁将生食、半成品、熟食混放 任何一项不满足这里都是否 0是1否")
        private Integer storageZones;

        /** 库房环境是否达标： 1、温度，湿度是否在标准范围内. 2、地面、货架、垫板是否干净整洁，无污渍，无积水，无食物残渣 3、虫害迹象，检查墙角、货架底部、门口有无老鼠粪便、蟑螂、虫卵、飞虫？ 4、挡鼠、灭鼠、灭蝇等设备器材是否齐全并能正常工作。 任何一项不达标这里都应该填否 0是1否 */
        @Schema(description = "库房环境是否达标1、温度，湿度是否在标准范围内2、地面、货架、垫板是否干净整洁，无污渍，无积水，无食物残3、虫害迹象，检查墙角、货架底部、门口有无老鼠粪便、蟑螂、虫卵、飞虫4、挡鼠、灭鼠、灭蝇等设备器材是否齐全并能正常工作任何一项不达标这里都应该填0是1否")
        @Excel(name = "库房环境是否达标：1、温度，湿度是否在标准范围内.2、地面、货架、垫板是否干净整洁，无污渍，无积水，无食物残渣3、虫害迹象，检查墙角、货架底部、门口有无老鼠粪便、蟑螂、虫卵、飞虫？4、挡鼠、灭鼠、灭蝇等设备器材是否齐全并能正常工作。任何一项不达标这里都应该填否0是1否")
        private Integer warehouseEnvironment;

        /** 食材质量是否达标： 1、严禁存在过期食材 2、严禁存在霉变、包装破损，胀气、腐烂、异味的食材 3、严禁存在受潮、结块的食材 出现任何一项这里都是否 0是1否 */
        @Schema(description = "食材质量是否达标： 1、严禁存在过期食材 2、严禁存在霉变、包装破损，胀气、腐烂、异味的食材 3、严禁存在受潮、结块的食材 出现任何一项这里都是否 0是1否")
        @Excel(name = "食材质量是否达标： 1、严禁存在过期食材 2、严禁存在霉变、包装破损，胀气、腐烂、异味的食材 3、严禁存在受潮、结块的食材 出现任何一项这里都是否 0是1否")
        private Integer qualityIngredients;

        /** 库房设施设备是否达标： 1、货架、垫板是否稳固，无锈蚀、无污渍 2、冷藏、冷冻设备工况是否正常 出现任何一项都是否 0是1否 */
        @Schema(description = "库房设施设备是否达标： 1、货架、垫板是否稳固，无锈蚀、无污渍 2、冷藏、冷冻设备工况是否正常 出现任何一项都是否 0是1否")
        @Excel(name = "库房设施设备是否达标： 1、货架、垫板是否稳固，无锈蚀、无污渍 2、冷藏、冷冻设备工况是否正常 出现任何一项都是否 0是1否")
        private Integer warehouseDevice;

        /** 现场拍照(逗号分割，限制4张) */
        @Schema(description = "现场拍照(逗号分割，限制4张)")
        @Excel(name = "现场拍照(逗号分割，限制4张)")
        private String img;

        /** 整体是否达标：0达标1不达标 以上任何一项异常(也就是为1)，此项都为1 */
        @Schema(description = "整体是否达标：0达标1不达标 以上任何一项异常(也就是为1)，此项都为1")
        @Excel(name = "整体是否达标：0达标1不达标 以上任何一项异常(也就是为1)，此项都为1")
        private Integer isAbnormal;

        /** 异常处置说明，限1000个字符 当整体出现异常时必填 */
        @Schema(description = "异常处置说明，限1000个字符 当整体出现异常时必填")
        @Excel(name = "异常处置说明，限1000个字符 当整体出现异常时必填")
        private String abnormalHandleRemarks;

        /** 巡检人 */
        @Schema(description = "巡检人")
        @Excel(name = "巡检人")
        private String inspectionUser;

        /** 巡检时间，年月日时分(格式：2025-05-05 08:40) */
        @Schema(description = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        @Excel(name = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        private String inspectionDate;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID(对应sys_user)")
        @Excel(name = "创建人ID(对应sys_user)")
        private Long createUser;

        /** 创建人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名(对应sys_user)")
        @Excel(name = "创建人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
