package com.fyzs.web.controller.vidicon;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.utils.EzvizAddressUtil;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 萤石云控制器
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/ysy")
public class YSYController {

    private final EzvizAddressUtil ezvizAddressUtil;

    @GetMapping("/getAccessToken")
    public AjaxResult getAccessToken(){
        String accessToken = ezvizAddressUtil.getAccessToken();
        return AjaxResult.success(accessToken);
    }

}
