package com.fyzs.web.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.Date;

/**
 * 预警信息对象 t_alarm
 *
 * @author ysh
 * @date 2025-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_alarm")
public class TAlarmTim implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 业务数据ID，根据不同的预警类型，指向的时不同的表 提前销样、试尝异常指向t_food_recipse 快检异常指向t_day_quick_check */
        @Schema(description = "业务数据ID，根据不同的预警类型，指向的时不同的表 提前销样、试尝异常指向t_food_recipse 快检异常指向t_day_quick_check")
        @Excel(name = "业务数据ID，根据不同的预警类型，指向的时不同的表 提前销样、试尝异常指向t_food_recipse 快检异常指向t_day_quick_check")
        private Long businessId;

        /** 预警类型：0提前销样、1试尝异常、2快检异常、3抽检异常、4库房贮藏巡检异常、5设备设施巡检异常、6环境卫生巡检异常、7食品加工制作过程巡检异常、8验收异常、9结算价格偏高、
         * 10供应商周排查异常、11设备设施周排查运行异常、12化学品使用存在异常、13文件完整性存在异常、14周排查异常、15员工早检异常、16员工午检异常、17员工晚检异常、18常规日检异常、19督察发现问题、
         * 20无有效经营许可证预警、21无有效健康证预警，22供应商资质无效预警、23即将过期食材预警(15天)、24已过期食材预警、25未录菜谱预警、26未留样预警、27未陪餐预警、28未试尝预警、29员工未日检异常、
         * 30未上报餐饮具消毒预警、31未上报设备设施消毒预警、32未上报垃圾消毒预警、33未上报库房贮藏巡检预警、34未上报设备设施巡检预警、35未上报场所环境卫生巡检预警,36未上报食品加工制作过程巡检异常
         37未上报餐厨垃圾处置预警，38口罩预警，39帽子预警、40厨师服预警、41老鼠预警、42吸烟预警*/
        @Schema(description = "预警类型：0提前销样、1试尝异常、2快检异常、3抽检异常、4库房贮藏巡检异常、5设备设施巡检异常、6环境卫生巡检异常、7食品加工制作过程巡检异常、8验收异常、9结算价格偏高、" +
                "10供应商周排查异常、11设备设施周排查运行异常、12化学品使用存在异常、13文件完整性存在异常、14周排查异常、15员工早检异常、16员工午检异常、17员工晚检异常、18常规日检异常、19督察发现问题、" +
                "20无有效经营许可证预警、21无有效健康证预警，22供应商资质无效预警、23即将过期食材预警(15天)、24已过期食材预警、25未录菜谱预警、26未留样预警、27未陪餐预警、28未试尝预警、29员工未日检异常、" +
                "30未上报餐饮具消毒预警、31未上报设备设施消毒预警、32未上报垃圾消毒预警、33未上报库房贮藏巡检预警、34未上报设备设施巡检预警、35未上报场所环境卫生巡检预警,36未上报食品加工制作过程巡检异常" +
                "37未上报餐厨垃圾处置预警，38口罩预警，39帽子预警、40厨师服预警、41老鼠预警、42吸烟预警")
        @Excel(name = "预警类型：0提前销样、1试尝异常、2快检异常、3抽检异常、4库房贮藏巡检异常、5设备设施巡检异常、6环境卫生巡检异常、7食品加工制作过程巡检异常、8验收异常、9结算价格偏高、" +
                "10供应商周排查异常、11设备设施周排查运行异常、12化学品使用存在异常、13文件完整性存在异常、14周排查异常、15员工早检异常、16员工午检异常、17员工晚检异常、18常规日检异常、19督察发现问题、" +
                "20无有效经营许可证预警、21无有效健康证预警，22供应商资质无效预警、23即将过期食材预警(15天)、24已过期食材预警、25未录菜谱预警、26未留样预警、27未陪餐预警、28未试尝预警、29员工未日检异常、" +
                "30未上报餐饮具消毒预警、31未上报设备设施消毒预警、32未上报垃圾消毒预警、33未上报库房贮藏巡检预警、34未上报设备设施巡检预警、35未上报场所环境卫生巡检预警,36未上报食品加工制作过程巡检异常" +
                "37未上报餐厨垃圾处置预警，38口罩预警，39帽子预警、40厨师服预警、41老鼠预警、42吸烟预警")
        private String type;

        /** 预警内容 */
        @Schema(description = "预警内容")
        @Excel(name = "预警内容")
        private String content;

        /** 处置状态：0未处置1已处置 */
        @Schema(description = "处置状态：0未处置1已处置")
        @Excel(name = "处置状态：0未处置1已处置")
        private Integer delState;

        /** 处置人 */
        @Schema(description = "处置人")
        @Excel(name = "处置人")
        private String delName;

        /** 异常处置说明：处置时必填300字内 */
        @Schema(description = "异常处置说明：处置时必填300字内")
        @Excel(name = "异常处置说明：处置时必填300字内")
        private String delRemarks;

        /** 处置时间 */
        @Schema(description = "处置时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "处置时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date delTime;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人ID(对应sys_user) */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "创建人ID(对应sys_user)")
        @Excel(name = "创建人ID(对应sys_user)")
        private Long createUser;

        /** 创建人姓名(对应sys_user) */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "创建人姓名(对应sys_user)")
        @Excel(name = "创建人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 操作时间 */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "操作时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "操作时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.DEFAULT)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
