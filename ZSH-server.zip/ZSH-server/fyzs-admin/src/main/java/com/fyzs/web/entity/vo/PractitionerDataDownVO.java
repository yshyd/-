package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PractitionerDataDownVO {
    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "人员姓名")
    private String name;
    /** 性别 0女 1男 */
    @Schema(description = "性别")
    private String sex;

    @Schema(description = "学历")
    private String education;

    @Schema(description = "身份证正面照片")
    private String idCardFrontImg;

    @Schema(description = "身份证背面照片")
    private String idCardBackImg;

    @Schema(description = "健康证照片")
    private String healthCertificateImg;

    @Schema(description = "食品安全培训合格证照片")
    private String foodSafetyTrainingImg;

}
