package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 采购管理-经费管理-收支管理对象 t_income_expenditure
 *
 * @author ysh
 * @date 2025-11-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_income_expenditure")
public class TIncomeExpenditure implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 年度 */
        @Schema(description = "年度")
        @Excel(name = "年度")
        private Integer annual;

        /** 类型：0上学期1下学期 */
        @Schema(description = "类型：0上学期1下学期")
        @Excel(name = "类型：0上学期1下学期")
        private Integer type;

        /** 收支：0收入1支出 */
        @Schema(description = "收入：0收入1支出")
        @Excel(name = "收入：0收入1支出")
        private Integer isIncome;

        /** 开始日期：格式-年月日 */
        @Schema(description = "开始日期：格式-年月日")
        @Excel(name = "开始日期：格式-年月日")
        private String startTime;

        /** 结束日期：格式-年月日 */
        @Schema(description = "结束日期：格式-年月日")
        @Excel(name = "结束日期：格式-年月日")
        private String endTime;

        /** 总收入金额(元) */
        @Schema(description = "总收入金额(元)")
        @Excel(name = "总收入金额(元)")
        private BigDecimal amount;

        /** 总支持金额(元) */
        @Schema(description = "总支持金额(元)")
        @Excel(name = "总支持金额(元)")
        private BigDecimal expenditure;

        /** 收入附件证明(限制10张、img、pdf、word) */
        @Schema(description = "收入附件证明(限制10张、img、pdf、word)")
        @Excel(name = "收入附件证明(限制10张、img、pdf、word)")
        private String amountFilePath;

        /** 支出附件证明(限制10张、img、pdf、word) */
        @Schema(description = "支出附件证明(限制10张、img、pdf、word)")
        @Excel(name = "支出附件证明(限制10张、img、pdf、word)")
        private String expenditureFilePath;

        /** 上报人 */
        @Schema(description = "上报人")
        @Excel(name = "上报人")
        private String reporter;

        /** 上报时间：格式-年月日时分 */
        @Schema(description = "上报时间：格式-年月日时分")
        @Excel(name = "上报时间：格式-年月日时分")
        private String reporterTime;

        /** 收入说明(限制500) */
        @Schema(description = "收入说明(限制500)")
        @Excel(name = "收入说明(限制500)")
        private String amountRemarks;

        /** 支持说明(限制500) */
        @Schema(description = "支持说明(限制500)")
        @Excel(name = "支持说明(限制500)")
        private String expenditureRemarks;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 操作人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人ID(对应sys_user)")
        @Excel(name = "操作人ID(对应sys_user)")
        private Long createUser;

        /** 操作人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作人姓名(对应sys_user)")
        @Excel(name = "操作人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 操作时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "操作时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "操作时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
