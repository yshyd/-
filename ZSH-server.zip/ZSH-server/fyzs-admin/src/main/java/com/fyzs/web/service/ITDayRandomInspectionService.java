package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayRandomInspection;
import com.fyzs.web.entity.query.TDayRandomInspectionQuery;

/**
 * 学校食堂日管控-日常检查-日常抽检Service接口
 * 
 * @author ysh
 * @date 2025-11-19
 */
public interface ITDayRandomInspectionService extends IService<TDayRandomInspection>
{
    /**
     * 查询学校食堂日管控-日常检查-日常抽检
     * 
     * @param id 学校食堂日管控-日常检查-日常抽检主键
     * @return 学校食堂日管控-日常检查-日常抽检
     */
    public TDayRandomInspectionQuery selectTDayRandomInspectionById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-日常抽检列表
     *
     * @return 学校食堂日管控-日常检查-日常抽检集合
     */
    public List<TDayRandomInspectionQuery> selectTDayRandomInspectionList(TDayRandomInspectionQuery query);

    /**
     * 新增学校食堂日管控-日常检查-日常抽检
     * 
     * @param tDayRandomInspection 学校食堂日管控-日常检查-日常抽检
     * @return 结果
     */
    public int insertTDayRandomInspection(TDayRandomInspection tDayRandomInspection);

    /**
     * 修改学校食堂日管控-日常检查-日常抽检
     * 
     * @param tDayRandomInspection 学校食堂日管控-日常检查-日常抽检
     * @return 结果
     */
    public int updateTDayRandomInspection(TDayRandomInspection tDayRandomInspection);

    /**
     * 批量删除学校食堂日管控-日常检查-日常抽检
     * 
     * @param ids 需要删除的学校食堂日管控-日常检查-日常抽检主键集合
     * @return 结果
     */
    public int deleteTDayRandomInspectionByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常检查-日常抽检信息
     * 
     * @param id 学校食堂日管控-日常检查-日常抽检主键
     * @return 结果
     */
    public int deleteTDayRandomInspectionById(Long id);

    int cancel(TDayRandomInspection randomInspection);
}
