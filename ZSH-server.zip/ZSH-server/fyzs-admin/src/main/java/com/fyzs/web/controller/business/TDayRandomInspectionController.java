package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TDayRandomInspectionQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayRandomInspection;
import com.fyzs.web.service.ITDayRandomInspectionService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常检查-日常抽检Controller
 * 
 * @author ysh
 * @date 2025-11-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/random/inspection")
public class TDayRandomInspectionController extends BaseController
{

    private final ITDayRandomInspectionService randomInspectionService;

    private final ITAlarmService alarmService;


    /**
     * 查询学校食堂日管控-日常检查-日常抽检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayRandomInspectionQuery query)
    {
        startPage();
        List<TDayRandomInspectionQuery> list = randomInspectionService.selectTDayRandomInspectionList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常检查-日常抽检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:export')")
    @Log(title = "学校食堂日管控-日常检查-日常抽检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayRandomInspectionQuery query)
    {
        List<TDayRandomInspectionQuery> list = randomInspectionService.selectTDayRandomInspectionList(query);
        ExcelUtil<TDayRandomInspectionQuery> util = new ExcelUtil<TDayRandomInspectionQuery>(TDayRandomInspectionQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常检查-日常抽检数据");
    }

    /**
     * 获取学校食堂日管控-日常检查-日常抽检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(randomInspectionService.selectTDayRandomInspectionById(id));
    }

    /**
     * 新增学校食堂日管控-日常检查-日常抽检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:add')")
    @Log(title = "学校食堂日管控-日常检查-日常抽检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayRandomInspection randomInspection)
    {
        return toAjax(randomInspectionService.insertTDayRandomInspection(randomInspection));
    }

    /**
     * 修改学校食堂日管控-日常检查-日常抽检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:edit')")
    @Log(title = "学校食堂日管控-日常检查-日常抽检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayRandomInspection randomInspection)
    {
        return toAjax(randomInspectionService.updateTDayRandomInspection(randomInspection));
    }

    /**
     * 作废按钮
     */
    @Log(title = "学校食堂日管控-日常检查-日常抽检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayRandomInspection randomInspection){
        return toAjax(randomInspectionService.cancel(randomInspection));
    }


    /**
     * 删除学校食堂日管控-日常检查-日常抽检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:remove')")
    @Log(title = "学校食堂日管控-日常检查-日常抽检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(randomInspectionService.deleteTDayRandomInspectionByIds(ids));
    }
}
