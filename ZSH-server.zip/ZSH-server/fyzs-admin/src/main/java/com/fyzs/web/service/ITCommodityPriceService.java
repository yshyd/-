package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCommodityPrice;
import com.fyzs.web.entity.query.TCommodityPriceQuery;

/**
 * 价格管理Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITCommodityPriceService extends IService<TCommodityPrice>
{
    /**
     * 查询价格管理
     * 
     * @param id 价格管理主键
     * @return 价格管理
     */
    public TCommodityPriceQuery selectTCommodityPriceById(Long id);

    /**
     * 查询价格管理列表
     * 
     * @param tCommodityPrice 价格管理
     * @return 价格管理集合
     */
    public List<TCommodityPriceQuery> selectTCommodityPriceList(TCommodityPriceQuery tCommodityPrice);

    /**
     * 新增价格管理
     * 
     * @param tCommodityPrice 价格管理
     * @return 结果
     */
    public int insertTCommodityPrice(TCommodityPrice tCommodityPrice);

    /**
     * 修改价格管理
     * 
     * @param tCommodityPrice 价格管理
     * @return 结果
     */
    public int updateTCommodityPrice(TCommodityPrice tCommodityPrice);

    /**
     * 批量删除价格管理
     * 
     * @param ids 需要删除的价格管理主键集合
     * @return 结果
     */
    public int deleteTCommodityPriceByIds(Long[] ids);

    /**
     * 删除价格管理信息
     * 
     * @param id 价格管理主键
     * @return 结果
     */
    public int deleteTCommodityPriceById(Long id);

    boolean batchPublish(Long[] ids, String delFlag);
}
