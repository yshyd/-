package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TWeekFileQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWeekFile;
import com.fyzs.web.service.ITWeekFileService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂周排查-文件是否有缺失Controller
 * 
 * @author ysh
 * @date 2025-11-27
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/week/file")
public class TWeekFileController extends BaseController
{

    private final ITWeekFileService tWeekFileService;

    /**
     * 查询学校食堂周排查-文件是否有缺失列表
     */
    //@PreAuthorize("@ss.hasPermi('web:file:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWeekFileQuery tWeekFile)
    {
        startPage();
        List<TWeekFileQuery> list = tWeekFileService.selectTWeekFileList(tWeekFile);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂周排查-文件是否有缺失列表
     */
    //@PreAuthorize("@ss.hasPermi('web:file:export')")
    @Log(title = "学校食堂周排查-文件是否有缺失", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWeekFileQuery tWeekFile)
    {
        List<TWeekFileQuery> list = tWeekFileService.selectTWeekFileList(tWeekFile);
        ExcelUtil<TWeekFileQuery> util = new ExcelUtil<TWeekFileQuery>(TWeekFileQuery.class);
        util.exportExcel(response, list, "学校食堂周排查-文件是否有缺失数据");
    }

    /**
     * 获取学校食堂周排查-文件是否有缺失详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:file:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tWeekFileService.selectTWeekFileById(id));
    }

    /**
     * 新增学校食堂周排查-文件是否有缺失
     */
    //@PreAuthorize("@ss.hasPermi('web:file:add')")
    @Log(title = "学校食堂周排查-文件是否有缺失", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWeekFile tWeekFile)
    {
        return toAjax(tWeekFileService.insertTWeekFile(tWeekFile));
    }

    /**
     * 修改学校食堂周排查-文件是否有缺失
     */
    //@PreAuthorize("@ss.hasPermi('web:file:edit')")
    @Log(title = "学校食堂周排查-文件是否有缺失", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWeekFile tWeekFile)
    {
        return toAjax(tWeekFileService.updateTWeekFile(tWeekFile));
    }

    /**
     * 启用/停用学校食堂周排查-文件是否有缺失
     */
    //@PreAuthorize("@ss.hasPermi('web:file:edit')")
    @Log(title = "学校食堂周排查-文件是否有缺失", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TWeekFile tWeekFile)
    {
        return toAjax(tWeekFileService.cancel(tWeekFile));
    }

    /**
     * 删除学校食堂周排查-文件是否有缺失
     */
    //@PreAuthorize("@ss.hasPermi('web:file:remove')")
    @Log(title = "学校食堂周排查-文件是否有缺失", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tWeekFileService.deleteTWeekFileByIds(ids));
    }
}
