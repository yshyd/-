package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TCameraInspectionRecordQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraInspectionRecord;
import com.fyzs.web.service.ITCameraInspectionRecordService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 设备巡检记录信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/record")
public class TCameraInspectionRecordController extends BaseController
{

    private final ITCameraInspectionRecordService tCameraInspectionRecordService;

    /**
     * 查询设备巡检记录信息列表
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraInspectionRecordQuery query)
    {
        startPage();
        List<TCameraInspectionRecordQuery> list = tCameraInspectionRecordService.selectTCameraInspectionRecordList(query);
        return getDataTable(list);
    }

    /**
     * 导出设备巡检记录信息列表
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:export')")
    @Log(title = "设备巡检记录信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraInspectionRecordQuery query)
    {
        List<TCameraInspectionRecordQuery> list = tCameraInspectionRecordService.selectTCameraInspectionRecordList(query);
        ExcelUtil<TCameraInspectionRecordQuery> util = new ExcelUtil<TCameraInspectionRecordQuery>(TCameraInspectionRecordQuery.class);
        util.exportExcel(response, list, "设备巡检记录信息数据");
    }

    /**
     * 获取设备巡检记录信息详细信息
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraInspectionRecordService.selectTCameraInspectionRecordById(id));
    }

    /**
     * 新增设备巡检记录信息
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:add')")
    @Log(title = "设备巡检记录信息", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TCameraInspectionRecord tCameraInspectionRecord)
    {
        return toAjax(tCameraInspectionRecordService.insertTCameraInspectionRecord(tCameraInspectionRecord));
    }

    /**
     * 修改设备巡检记录信息
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:edit')")
    @Log(title = "设备巡检记录信息", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TCameraInspectionRecord tCameraInspectionRecord)
    {
        return toAjax(tCameraInspectionRecordService.updateTCameraInspectionRecord(tCameraInspectionRecord));
    }

    /**
     * 删除设备巡检记录信息
     */
    //@PreAAuthorize("@ss.hasPermi('web:record:remove')")
    @Log(title = "设备巡检记录信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraInspectionRecordService.deleteTCameraInspectionRecordByIds(ids));
    }
}
