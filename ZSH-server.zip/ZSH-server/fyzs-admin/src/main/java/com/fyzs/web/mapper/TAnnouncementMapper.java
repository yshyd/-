package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TAnnouncement;
import com.fyzs.web.entity.query.TAnnouncementQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 公告发布Mapper接口
 * 
 * @author ysh
 * @date 2025-12-04
 */
@Mapper
public interface TAnnouncementMapper  extends BaseMapper<TAnnouncement>
{
    /**
     * 查询公告发布
     * 
     * @param id 公告发布主键
     * @return 公告发布
     */
    public TAnnouncementQuery selectTAnnouncementById(Long id);

    /**
     * 查询公告发布列表
     * 
     * @param tAnnouncement 公告发布
     * @return 公告发布集合
     */
    public List<TAnnouncementQuery> selectTAnnouncementList(TAnnouncementQuery tAnnouncement);

    /**
     * 新增公告发布
     * 
     * @param tAnnouncement 公告发布
     * @return 结果
     */
    public int insertTAnnouncement(TAnnouncement tAnnouncement);

    /**
     * 修改公告发布
     * 
     * @param tAnnouncement 公告发布
     * @return 结果
     */
    public int updateTAnnouncement(TAnnouncement tAnnouncement);

    /**
     * 删除公告发布
     * 
     * @param id 公告发布主键
     * @return 结果
     */
    public int deleteTAnnouncementById(Long id);

    /**
     * 批量删除公告发布
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTAnnouncementByIds(Long[] ids);

    List<TAnnouncementQuery> getList(@Param("announcementIds")List<Long> announcementIds);

    List<TAnnouncementQuery> selectTAnnouncementAndLookList(TAnnouncementQuery tAnnouncement);
}
