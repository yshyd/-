package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.system.domain.query.TPrePackagedQuery;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.system.domain.TPrePackaged;
import com.fyzs.system.service.ITPrePackagedService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 仅销售预包装食品备案信息Controller
 * 
 * @author ysh
 * @date 2025-10-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/packaged")
public class TPrePackagedController extends BaseController
{
    
    private final ITPrePackagedService tPrePackagedService;

    /**
     * 查询仅销售预包装食品备案信息列表
     */
    //@PreAutho("@ss.hasPermi('system:packaged:list')")
    @GetMapping("/list")
    public TableDataInfo list(TPrePackagedQuery tPrePackaged)
    {
        startPage();
        List<TPrePackagedQuery> list = tPrePackagedService.selectTPrePackagedList(tPrePackaged);
        return getDataTable(list);
    }

    /**
     * 导出仅销售预包装食品备案信息列表
     */
    //@PreAutho("@ss.hasPermi('system:packaged:export')")
    @Log(title = "仅销售预包装食品备案信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TPrePackagedQuery tPrePackaged)
    {
        List<TPrePackagedQuery> list = tPrePackagedService.selectTPrePackagedList(tPrePackaged);
        ExcelUtil<TPrePackagedQuery> util = new ExcelUtil<TPrePackagedQuery>(TPrePackagedQuery.class);
        util.exportExcel(response, list, "仅销售预包装食品备案信息数据");
    }

    /**
     * 获取仅销售预包装食品备案信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:packaged:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tPrePackagedService.selectTPrePackagedById(id));
    }

    /**
     * 获取仅销售预包装食品备案信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:packaged:query')")
    @GetMapping(value = "/info/{deptId}")
    public AjaxResult getDeptInfo(@PathVariable("deptId") Long deptId)
    {
        return success(tPrePackagedService.getOne(new LambdaQueryWrapper<>(TPrePackaged.class).eq(TPrePackaged::getDeptId, deptId)));
    }

    /**
     * 新增仅销售预包装食品备案信息
     */
    //@PreAutho("@ss.hasPermi('system:packaged:add')")
    @Log(title = "仅销售预包装食品备案信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TPrePackaged tPrePackaged)
    {
        return toAjax(tPrePackagedService.save(tPrePackaged));
    }

    /**
     * 修改仅销售预包装食品备案信息
     */
    //@PreAutho("@ss.hasPermi('system:packaged:edit')")
    @Log(title = "仅销售预包装食品备案信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TPrePackaged tPrePackaged)
    {
        return toAjax(tPrePackagedService.updateById(tPrePackaged));
    }

    /**
     * 删除仅销售预包装食品备案信息
     */
    //@PreAutho("@ss.hasPermi('system:packaged:remove')")
    @Log(title = "仅销售预包装食品备案信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tPrePackagedService.deleteTPrePackagedByIds(ids));
    }
}
