package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TNewProcurementQuery;
import com.fyzs.web.entity.vo.TNewProcurementVO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewProcurement;
import com.fyzs.web.service.ITNewProcurementService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品采购Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/new/procurement")
public class TNewProcurementController extends BaseController
{

    private final ITNewProcurementService tNewProcurementService;

    /**
     * 查询商品采购列表
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewProcurementQuery tNewProcurement)
    {
        startPage();
        List<TNewProcurementQuery> list = tNewProcurementService.selectTNewProcurementList(tNewProcurement);
        return getDataTable(list);
    }

    /**
     * 导出商品采购列表
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:export')")
    @Log(title = "商品采购", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewProcurementQuery tNewProcurement)
    {
        List<TNewProcurementVO> list = tNewProcurementService.selectExportList(tNewProcurement);
        ExcelUtil<TNewProcurementVO> util = new ExcelUtil<TNewProcurementVO>(TNewProcurementVO.class);
        util.exportExcel(response, list, "商品采购数据");
    }

    /**
     * 获取商品采购详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tNewProcurementService.selectTNewProcurementById(id));
    }

    /**
     * 采购下单
     */

    @Log(title = "商品采购", businessType = BusinessType.INSERT)
    @PostMapping("/place")
    public AjaxResult place(@RequestBody TNewProcurement tNewProcurement){
        return toAjax(tNewProcurementService.place(tNewProcurement));
    }

    /**
     * 新增商品采购
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:add')")
    @Log(title = "商品采购", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewProcurement tNewProcurement)
    {
        return toAjax(tNewProcurementService.save(tNewProcurement));
    }

    /**
     * 修改商品采购
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:edit')")
    @Log(title = "商品采购", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewProcurement tNewProcurement)
    {
        return toAjax(tNewProcurementService.updateById(tNewProcurement));
    }

    /**
     * 删除商品采购
     */
    //@PreAuthorize("@ss.hasPermi('web:procurement:remove')")
    @Log(title = "商品采购", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tNewProcurementService.deleteTNewProcurementByIds(ids));
    }
}
