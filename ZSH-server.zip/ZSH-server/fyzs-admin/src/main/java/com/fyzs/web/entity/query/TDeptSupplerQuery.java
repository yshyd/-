package com.fyzs.web.entity.query;

import com.fyzs.web.entity.TDeptSuppler;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TDeptSupplerQuery extends TDeptSuppler {

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "区域名称")
    private String areaName;

    @Schema(description = "全区域名称")
    private String fullAreaName;

    private List<Long> deptIds;       // 选中的组织ID列表

    private int offset;
    private int limit;


}
