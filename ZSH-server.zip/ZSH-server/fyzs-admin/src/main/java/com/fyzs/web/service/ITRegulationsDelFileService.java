package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TRegulationsDelFile;

/**
 * 违法违规处置证明文件存储信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITRegulationsDelFileService extends IService<TRegulationsDelFile>
{
    /**
     * 查询违法违规处置证明文件存储信息
     * 
     * @param id 违法违规处置证明文件存储信息主键
     * @return 违法违规处置证明文件存储信息
     */
    public TRegulationsDelFile selectTRegulationsDelFileById(Long id);

    /**
     * 查询违法违规处置证明文件存储信息列表
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 违法违规处置证明文件存储信息集合
     */
    public List<TRegulationsDelFile> selectTRegulationsDelFileList(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 新增违法违规处置证明文件存储信息
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 结果
     */
    public int insertTRegulationsDelFile(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 修改违法违规处置证明文件存储信息
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 结果
     */
    public int updateTRegulationsDelFile(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 批量删除违法违规处置证明文件存储信息
     * 
     * @param ids 需要删除的违法违规处置证明文件存储信息主键集合
     * @return 结果
     */
    public int deleteTRegulationsDelFileByIds(Long[] ids);

    /**
     * 删除违法违规处置证明文件存储信息信息
     * 
     * @param id 违法违规处置证明文件存储信息主键
     * @return 结果
     */
    public int deleteTRegulationsDelFileById(Long id);
}
