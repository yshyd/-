package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TDeptCommodity;
import com.fyzs.web.entity.query.TDeptCommodityQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 主体商品库Mapper接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
@org.apache.ibatis.annotations.Mapper
public interface TDeptCommodityMapper  extends BaseMapper<TDeptCommodity>
{
    /**
     * 查询主体商品库
     * 
     * @param id 主体商品库主键
     * @return 主体商品库
     */
    public TDeptCommodity selectTDeptCommodityById(Long id);

    /**
     * 查询主体商品库列表
     * 
     * @param tDeptCommodity 主体商品库
     * @return 主体商品库集合
     */
    public List<TDeptCommodityQuery> selectTDeptCommodityList(TDeptCommodityQuery tDeptCommodity);

    /**
     * 新增主体商品库
     * 
     * @param tDeptCommodity 主体商品库
     * @return 结果
     */
    public int insertTDeptCommodity(TDeptCommodity tDeptCommodity);

    /**
     * 修改主体商品库
     * 
     * @param tDeptCommodity 主体商品库
     * @return 结果
     */
    public int updateTDeptCommodity(TDeptCommodity tDeptCommodity);

    /**
     * 删除主体商品库
     * 
     * @param id 主体商品库主键
     * @return 结果
     */
    public int deleteTDeptCommodityById(Long id);

    /**
     * 批量删除主体商品库
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDeptCommodityByIds(Long[] ids);

    /**
     * 根据主体 ID 查询已关联的商品 ID 列表
     *
     * @param deptId 主体 ID
     * @return 商品 ID 列表
     */
    List<Long> selectCommodityIdsByDeptId(@Param("deptId") Long deptId);

    List<TDeptCommodityQuery> selectOneselfList(TDeptCommodityQuery tDeptCommodity);
}
