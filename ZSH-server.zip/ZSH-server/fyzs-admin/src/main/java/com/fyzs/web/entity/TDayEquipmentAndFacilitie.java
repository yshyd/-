package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常巡检-设备设施巡检对象 t_day_equipment_and_facilitie
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_equipment_and_facilitie")
public class TDayEquipmentAndFacilitie implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 挡鼠板、纱窗、防蝇灯、风幕机等是否正常使用，无破损 0是1否 */
        @Schema(description = "挡鼠板、纱窗、防蝇灯、风幕机等是否正常使用，无破损 0是1否")
        @Excel(name = "挡鼠板、纱窗、防蝇灯、风幕机等是否正常使用，无破损 0是1否")
        private Integer isMouse;

        /** 冰箱、冰柜运行是否正常，结霜厚度是否合理 冷藏柜：温度是否≤8℃（建议0-8℃） 冷冻柜：温度是否≤-12℃ 留样冰箱：专用留样冰箱温度是否正常（通常0-8℃），且未存放其他物品 0是1否 */
        @Schema(description = "冰箱、冰柜运行是否正常，结霜厚度是否合理 冷藏柜：温度是否≤8℃（建议0-8℃） 冷冻柜：温度是否≤-12℃ 留样冰箱：专用留样冰箱温度是否正常（通常0-8℃），且未存放其他物品0是1否")
        @Excel(name = "冰箱、冰柜运行是否正常，结霜厚度是否合理 冷藏柜：温度是否≤8℃", readConverterExp = "建=议0-8℃")
        private Integer isRefrigerator;

        /** 油烟机、排风扇是否运转正常，表面清洁 0是1否 */
        @Schema(description = "油烟机、排风扇是否运转正常，表面清洁 0是1否")
        @Excel(name = "油烟机、排风扇是否运转正常，表面清洁 0是1否")
        private Integer isRangeHood;

        /** 现场拍照，照片中需呈现上述设备设施(逗号分割，限制3张) */
        @Schema(description = "现场拍照，照片中需呈现上述设备设施(逗号分割，限制3张)")
        @Excel(name = "现场拍照，照片中需呈现上述设备设施(逗号分割，限制3张)")
        private String img;

        /** 整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1 */
        @Schema(description = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        @Excel(name = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        private Integer isAbnormal;

        /** 异常处置说明，限1000个字符 当整体出现异常时必填 */
        @Schema(description = "异常处置说明，限1000个字符 当整体出现异常时必填")
        @Excel(name = "异常处置说明，限1000个字符 当整体出现异常时必填")
        private String abnormalHandleRemarks;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 巡检人 */
        @Schema(description = "巡检人")
        @Excel(name = "巡检人")
        private String inspectionUser;

        /** 巡检时间，年月日时分(格式：2025-05-05 08:40) */
        @Schema(description = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        @Excel(name = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        private String inspectionDate;

        /** 巡检人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人ID(对应sys_user)")
        @Excel(name = "巡检人ID(对应sys_user)")
        private Long createUser;

        /** 巡检人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人姓名(对应sys_user)")
        @Excel(name = "巡检人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
