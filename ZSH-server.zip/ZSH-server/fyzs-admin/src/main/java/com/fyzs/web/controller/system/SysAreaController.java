package com.fyzs.web.controller.system;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.common.core.domain.entity.vo.AreaDeptTreeVO;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.system.domain.vo.SysAreaVO;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.system.domain.SysArea;
import com.fyzs.system.service.ISysAreaService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 行政区域Controller
 * 
 * @author ysh
 * @date 2025-10-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/system/area")
public class SysAreaController extends BaseController
{
    private  final ISysAreaService sysAreaService;

    /**
     * 查询行政区域列表
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:list')")
    @GetMapping("/list")
    public TableDataInfo list(SysArea sysArea)
    {
        startPage();
        List<SysArea> list = sysAreaService.selectSysAreaList(sysArea);
        return getDataTable(list);
    }

    /**
     * 导出行政区域列表
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:export')")
    @Log(title = "行政区域", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, SysArea sysArea)
    {
        List<SysArea> list = sysAreaService.selectSysAreaList(sysArea);
        ExcelUtil<SysArea> util = new ExcelUtil<SysArea>(SysArea.class);
        util.exportExcel(response, list, "行政区域数据");
    }

    /**
     * 获取行政区域详细信息
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:query')")
    @GetMapping(value = "/{areaId}")
    public AjaxResult getInfo(@PathVariable("areaId") Long areaId)
    {
        return success(sysAreaService.selectSysAreaByAreaId(areaId));
    }

    /**
     * 新增行政区域
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:add')")
    @Log(title = "行政区域", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody SysArea sysArea)
    {
        return toAjax(sysAreaService.insertSysArea(sysArea));
    }

    /**
     * 修改行政区域
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:edit')")
    @Log(title = "行政区域", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody SysArea sysArea)
    {
        return toAjax(sysAreaService.updateSysArea(sysArea));
    }

    /**
     * 删除行政区域
     */
  //  @PreAuthorize("@ss.hasPermi('system:area:remove')")
    @Log(title = "行政区域", businessType = BusinessType.DELETE)
	@DeleteMapping("/{areaIds}")
    public AjaxResult remove(@PathVariable Long[] areaIds)
    {
        return toAjax(sysAreaService.deleteSysAreaByAreaIds(areaIds));
    }

    /**
     * 获取地区树
     * @return
     */
    @ApiOperation("获取地区树")
    @GetMapping("/treeSelect")
    public AjaxResult treeSelect(SysArea sysArea)
    {
        sysArea.setStatus("0");
        return success(sysAreaService.buildOrgTreeSelect(sysArea));
    }

    /**
     * 获取区域主体信息树形结构
     */
    @ApiOperation("获取区域主体信息树形结构")
    @GetMapping("/areaDeptTree")
    public AjaxResult getAreaDeptTree(SysArea sysArea) {
        return success(sysAreaService.buildAreaDeptTree(sysArea));
    }

    @GetMapping("/treeWithAuth")
    public AjaxResult getAreaDeptTreeWithAuth(@RequestParam(required = false) Long deptType) {
        Long userId = SecurityUtils.getUserId();
        List<AreaDeptTreeVO> tree = sysAreaService.buildAreaDeptTreeWithAuth(userId,deptType);
        return AjaxResult.success(tree);
    }

    /**
     * 获取区域主体信息树形结构(权限)
     */
    @ApiOperation("获取区域主体信息树形结构(权限)")
    @GetMapping("/areaDataTree")
    public AjaxResult areaDataTree(SysAreaDTO sysArea) {
        return success(sysAreaService.areaDataTree(sysArea));
    }
}
