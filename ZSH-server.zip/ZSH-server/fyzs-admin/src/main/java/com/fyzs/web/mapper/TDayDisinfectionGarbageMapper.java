package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayDisinfectionGarbage;
import com.fyzs.web.entity.query.TDayDisinfectionGarbageQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常消毒-垃圾区域消毒Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@org.apache.ibatis.annotations.Mapper
public interface TDayDisinfectionGarbageMapper  extends BaseMapper<TDayDisinfectionGarbage>
{
    /**
     * 查询学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param id 学校食堂日管控-日常消毒-垃圾区域消毒主键
     * @return 学校食堂日管控-日常消毒-垃圾区域消毒
     */
    public TDayDisinfectionGarbageQuery selectTDayDisinfectionGarbageById(Long id);

    /**
     * 查询学校食堂日管控-日常消毒-垃圾区域消毒列表
     *
     * @return 学校食堂日管控-日常消毒-垃圾区域消毒集合
     */
    public List<TDayDisinfectionGarbageQuery> selectTDayDisinfectionGarbageList(TDayDisinfectionGarbageQuery query);

    /**
     * 新增学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param tDayDisinfectionGarbage 学校食堂日管控-日常消毒-垃圾区域消毒
     * @return 结果
     */
    public int insertTDayDisinfectionGarbage(TDayDisinfectionGarbage tDayDisinfectionGarbage);

    /**
     * 修改学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param tDayDisinfectionGarbage 学校食堂日管控-日常消毒-垃圾区域消毒
     * @return 结果
     */
    public int updateTDayDisinfectionGarbage(TDayDisinfectionGarbage tDayDisinfectionGarbage);

    /**
     * 删除学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param id 学校食堂日管控-日常消毒-垃圾区域消毒主键
     * @return 结果
     */
    public int deleteTDayDisinfectionGarbageById(Long id);

    /**
     * 批量删除学校食堂日管控-日常消毒-垃圾区域消毒
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayDisinfectionGarbageByIds(Long[] ids);

    int countValidDisinfections(@Param("startDate") Date startDate,
                                @Param("endDate") Date endDate,
                                @Param("deptIds") List<Long> deptIds);
}
