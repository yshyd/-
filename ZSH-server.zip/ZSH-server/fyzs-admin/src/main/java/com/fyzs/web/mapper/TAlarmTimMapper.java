package com.fyzs.web.mapper;

import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.TAlarmTim;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface TAlarmTimMapper {

    /**
     * 定时任务专用插入方法，不触发自动填充
     *
     * @param tAlarm 预警信息
     * @return 结果
     */
    int insertTAlarmForSchedule(TAlarmTim tAlarm);
}
