package com.fyzs.web.entity.dto;

import lombok.Data;

@Data
public class DeptCameraCountDTO {
    private Long deptId;
    private Integer count;
}
