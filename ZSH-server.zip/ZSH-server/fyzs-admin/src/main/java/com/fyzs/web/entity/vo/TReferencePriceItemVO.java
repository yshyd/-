package com.fyzs.web.entity.vo;

import com.fyzs.web.entity.TReferencePriceItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TReferencePriceItemVO extends TReferencePriceItem {
}
