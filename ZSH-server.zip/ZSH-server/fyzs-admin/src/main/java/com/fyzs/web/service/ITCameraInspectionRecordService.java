package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraInspectionRecord;
import com.fyzs.web.entity.query.TCameraInspectionRecordQuery;


/**
 * 设备巡检记录信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraInspectionRecordService extends IService<TCameraInspectionRecord>
{
    /**
     * 查询设备巡检记录信息
     * 
     * @param id 设备巡检记录信息主键
     * @return 设备巡检记录信息
     */
    public TCameraInspectionRecord selectTCameraInspectionRecordById(Long id);

    /**
     * 查询设备巡检记录信息列表
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 设备巡检记录信息集合
     */
    public List<TCameraInspectionRecordQuery> selectTCameraInspectionRecordList(TCameraInspectionRecordQuery tCameraInspectionRecord);

    /**
     * 新增设备巡检记录信息
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 结果
     */
    public int insertTCameraInspectionRecord(TCameraInspectionRecord tCameraInspectionRecord);

    /**
     * 修改设备巡检记录信息
     * 
     * @param tCameraInspectionRecord 设备巡检记录信息
     * @return 结果
     */
    public int updateTCameraInspectionRecord(TCameraInspectionRecord tCameraInspectionRecord);

    /**
     * 批量删除设备巡检记录信息
     * 
     * @param ids 需要删除的设备巡检记录信息主键集合
     * @return 结果
     */
    public int deleteTCameraInspectionRecordByIds(Long[] ids);

    /**
     * 删除设备巡检记录信息信息
     * 
     * @param id 设备巡检记录信息主键
     * @return 结果
     */
    public int deleteTCameraInspectionRecordById(Long id);
}
