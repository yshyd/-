package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TWarehouseQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWarehouse;
import com.fyzs.web.service.ITWarehouseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 仓库信息Controller
 * 
 * @author ysh
 * @date 2025-10-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/warehouse")
public class TWarehouseController extends BaseController
{

    private final ITWarehouseService tWarehouseService;

    /**
     * 查询仓库信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWarehouseQuery tWarehouse)
    {
        startPage();
        List<TWarehouseQuery> list = tWarehouseService.selectTWarehouseList(tWarehouse);
        return getDataTable(list);
    }

    /**
     * 下拉列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TWarehouseQuery tWarehouse)
    {
        List<TWarehouseQuery> list = tWarehouseService.selectTWarehouseList(tWarehouse);
        return getDataTable(list);
    }

    /**
     * 导出仓库信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:export')")
    @Log(title = "仓库信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWarehouseQuery tWarehouse)
    {
        List<TWarehouseQuery> list = tWarehouseService.selectTWarehouseList(tWarehouse);
        ExcelUtil<TWarehouseQuery> util = new ExcelUtil<TWarehouseQuery>(TWarehouseQuery.class);
        util.exportExcel(response, list, "仓库信息数据");
    }

    /**
     * 获取仓库信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tWarehouseService.selectTWarehouseById(id));
    }

    /**
     * 新增仓库信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:add')")
    @Log(title = "仓库信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWarehouse tWarehouse)
    {
        TWarehouse one = tWarehouseService.getOne(new LambdaQueryWrapper<>(TWarehouse.class)
                .eq(TWarehouse::getDeptId, tWarehouse.getDeptId())
                .eq(TWarehouse::getWarehouseName, tWarehouse.getWarehouseName())
        );
        if (ObjectUtils.isNotEmpty( one)){
            return error("仓库名称已存在");
        }
        tWarehouse.setDelFlag(0);
        return toAjax(tWarehouseService.save(tWarehouse));
    }

    /**
     * 修改仓库信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:edit')")
    @Log(title = "仓库信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWarehouse tWarehouse)
    {
        TWarehouse one = tWarehouseService.getOne(new LambdaQueryWrapper<>(TWarehouse.class)
                .eq(TWarehouse::getDeptId, tWarehouse.getDeptId())
                .eq(TWarehouse::getWarehouseName, tWarehouse.getWarehouseName())
                .ne(TWarehouse::getId, tWarehouse.getId())
        );
        if (ObjectUtils.isNotEmpty( one)){
            return error("仓库名称已存在");
        }
        return toAjax(tWarehouseService.updateById(tWarehouse));
    }

    /**
     * 删除仓库信息
     */
    //@PreAuthorize("@ss.hasPermi('web:warehouse:remove')")
    @Log(title = "仓库信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tWarehouseService.deleteTWarehouseByIds(ids));
    }
}
