package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TDeptSuppler;
import com.fyzs.web.entity.query.TDeptSupplerQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 供应商Mapper接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
@Mapper
public interface TDeptSupplerMapper  extends BaseMapper<TDeptSuppler>
{
    /**
     * 查询供应商
     * 
     * @param id 供应商主键
     * @return 供应商
     */
    public TDeptSuppler selectTDeptSupplerById(Long id);

    /**
     * 查询供应商列表
     * 
     * @param tDeptSuppler 供应商
     * @return 供应商集合
     */
    public List<TDeptSupplerQuery> selectTDeptSupplerList(TDeptSupplerQuery tDeptSuppler);

    /**
     * 新增供应商
     * 
     * @param tDeptSuppler 供应商
     * @return 结果
     */
    public int insertTDeptSuppler(TDeptSuppler tDeptSuppler);

    /**
     * 修改供应商
     * 
     * @param tDeptSuppler 供应商
     * @return 结果
     */
    public int updateTDeptSuppler(TDeptSuppler tDeptSuppler);

    /**
     * 删除供应商
     * 
     * @param id 供应商主键
     * @return 结果
     */
    public int deleteTDeptSupplerById(Long id);

    /**
     * 批量删除供应商
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDeptSupplerByIds(Long[] ids);

    /**
     * 查询权限范围内有效的供应商
     */
    List<TDeptSuppler> selectValidSupplersByDeptIds(@Param("deptIds") List<Long> deptIds);

    /**
     * 统计某供应商在指定主体范围内的覆盖数量
     */
    Integer countSchoolsBySupplierAndDeptIds(@Param("supplerId") Long supplerId, @Param("deptIds") List<Long> deptIds);

    // TDeptSupplerMapper.java
    int countValidSuppliers(TDeptSupplerQuery query);

    List<TDeptSuppler> selectValidSupplersByDeptIdsAndCondition(TDeptSupplerQuery query);

}
