package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraRegulationsImg;
import com.fyzs.web.service.ITCameraRegulationsImgService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规识别图片固证文件存储信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/reg/img")
public class TCameraRegulationsImgController extends BaseController
{

    private final ITCameraRegulationsImgService tCameraRegulationsImgService;

    /**
     * 查询违法违规识别图片固证文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:img:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraRegulationsImg tCameraRegulationsImg)
    {
        startPage();
        List<TCameraRegulationsImg> list = tCameraRegulationsImgService.selectTCameraRegulationsImgList(tCameraRegulationsImg);
        return getDataTable(list);
    }

    /**
     * 导出违法违规识别图片固证文件存储信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:img:export')")
    @Log(title = "违法违规识别图片固证文件存储信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraRegulationsImg tCameraRegulationsImg)
    {
        List<TCameraRegulationsImg> list = tCameraRegulationsImgService.selectTCameraRegulationsImgList(tCameraRegulationsImg);
        ExcelUtil<TCameraRegulationsImg> util = new ExcelUtil<TCameraRegulationsImg>(TCameraRegulationsImg.class);
        util.exportExcel(response, list, "违法违规识别图片固证文件存储信息数据");
    }

    /**
     * 获取违法违规识别图片固证文件存储信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:img:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraRegulationsImgService.selectTCameraRegulationsImgById(id));
    }

    /**
     * 新增违法违规识别图片固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:img:add')")
    @Log(title = "违法违规识别图片固证文件存储信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraRegulationsImg tCameraRegulationsImg)
    {
        return toAjax(tCameraRegulationsImgService.save(tCameraRegulationsImg));
    }

    /**
     * 修改违法违规识别图片固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:img:edit')")
    @Log(title = "违法违规识别图片固证文件存储信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraRegulationsImg tCameraRegulationsImg)
    {
        return toAjax(tCameraRegulationsImgService.updateById(tCameraRegulationsImg));
    }

    /**
     * 删除违法违规识别图片固证文件存储信息
     */
    //@PreAuthorize("@ss.hasPermi('web:img:remove')")
    @Log(title = "违法违规识别图片固证文件存储信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraRegulationsImgService.deleteTCameraRegulationsImgByIds(ids));
    }
}
