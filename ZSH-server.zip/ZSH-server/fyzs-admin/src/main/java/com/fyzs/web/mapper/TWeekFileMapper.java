package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TWeekFile;
import com.fyzs.web.entity.query.TWeekFileQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 学校食堂周排查-文件是否有缺失Mapper接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
@Mapper
public interface TWeekFileMapper  extends BaseMapper<TWeekFile>
{
    /**
     * 查询学校食堂周排查-文件是否有缺失
     * 
     * @param id 学校食堂周排查-文件是否有缺失主键
     * @return 学校食堂周排查-文件是否有缺失
     */
    public TWeekFileQuery selectTWeekFileById(Long id);

    /**
     * 查询学校食堂周排查-文件是否有缺失列表
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 学校食堂周排查-文件是否有缺失集合
     */
    public List<TWeekFileQuery> selectTWeekFileList(TWeekFile tWeekFile);

    /**
     * 新增学校食堂周排查-文件是否有缺失
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 结果
     */
    public int insertTWeekFile(TWeekFile tWeekFile);

    /**
     * 修改学校食堂周排查-文件是否有缺失
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 结果
     */
    public int updateTWeekFile(TWeekFile tWeekFile);

    /**
     * 删除学校食堂周排查-文件是否有缺失
     * 
     * @param id 学校食堂周排查-文件是否有缺失主键
     * @return 结果
     */
    public int deleteTWeekFileById(Long id);

    /**
     * 批量删除学校食堂周排查-文件是否有缺失
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTWeekFileByIds(Long[] ids);
}
