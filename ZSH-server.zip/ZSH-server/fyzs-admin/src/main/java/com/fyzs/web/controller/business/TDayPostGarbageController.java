package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TDayPostGarbageQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayPostGarbage;
import com.fyzs.web.service.ITDayPostGarbageService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食安监管-日管控-餐厨垃圾Controller
 * 
 * @author ysh
 * @date 2025-11-20
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/garbage")
public class TDayPostGarbageController extends BaseController
{

    private final ITDayPostGarbageService garbageService;

    private final ITAlarmService alarmService;


    /**
     * 查询食安监管-日管控-餐厨垃圾列表
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayPostGarbageQuery query)
    {
        startPage();
        List<TDayPostGarbageQuery> list = garbageService.selectTDayPostGarbageList(query);
        return getDataTable(list);
    }

    /**
     * 导出食安监管-日管控-餐厨垃圾列表
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:export')")
    @Log(title = "食安监管-日管控-餐厨垃圾", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayPostGarbageQuery query)
    {
        List<TDayPostGarbageQuery> list = garbageService.selectTDayPostGarbageList(query);
        ExcelUtil<TDayPostGarbageQuery> util = new ExcelUtil<TDayPostGarbageQuery>(TDayPostGarbageQuery.class);
        util.exportExcel(response, list, "食安监管-日管控-餐厨垃圾数据");
    }

    /**
     * 获取食安监管-日管控-餐厨垃圾详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(garbageService.selectTDayPostGarbageById(id));
    }

    /**
     * 新增食安监管-日管控-餐厨垃圾
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:add')")
    @Log(title = "食安监管-日管控-餐厨垃圾", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayPostGarbage tDayPostGarbage)
    {
        tDayPostGarbage.setDelFlag(0);
        return toAjax(garbageService.save(tDayPostGarbage));
    }

    /**
     * 修改食安监管-日管控-餐厨垃圾
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:edit')")
    @Log(title = "食安监管-日管控-餐厨垃圾", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayPostGarbage tDayPostGarbage)
    {
        return toAjax(garbageService.updateTDayPostGarbage(tDayPostGarbage));
    }

    /**
     * 作废
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:edit')")
    @Log(title = "食安监管-日管控-餐厨垃圾", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayPostGarbage tDayPostGarbage)
    {
        return toAjax(garbageService.updateById(tDayPostGarbage));
    }

    /**
     * 删除食安监管-日管控-餐厨垃圾
     */
    //@PreAuthorize("@ss.hasPermi('web:garbage:remove')")
    @Log(title = "食安监管-日管控-餐厨垃圾", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(garbageService.deleteTDayPostGarbageByIds(ids));
    }
}
