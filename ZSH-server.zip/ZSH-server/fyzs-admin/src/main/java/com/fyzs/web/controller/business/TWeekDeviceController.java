package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TWeekDeviceQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TWeekDevice;
import com.fyzs.web.service.ITWeekDeviceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂周排查-设备设施运行风险排查Controller
 * 
 * @author ysh
 * @date 2025-11-27
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/week/device")
public class TWeekDeviceController extends BaseController
{

    private final ITWeekDeviceService tWeekDeviceService;

    /**
     * 查询学校食堂周排查-设备设施运行风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:device:list')")
    @GetMapping("/list")
    public TableDataInfo list(TWeekDeviceQuery tWeekDevice)
    {
        startPage();
        List<TWeekDeviceQuery> list = tWeekDeviceService.selectTWeekDeviceList(tWeekDevice);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂周排查-设备设施运行风险排查列表
     */
    //@PreAuthorize("@ss.hasPermi('web:device:export')")
    @Log(title = "学校食堂周排查-设备设施运行风险排查", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TWeekDeviceQuery tWeekDevice)
    {
        List<TWeekDeviceQuery> list = tWeekDeviceService.selectTWeekDeviceList(tWeekDevice);
        ExcelUtil<TWeekDeviceQuery> util = new ExcelUtil<TWeekDeviceQuery>(TWeekDeviceQuery.class);
        util.exportExcel(response, list, "学校食堂周排查-设备设施运行风险排查数据");
    }

    /**
     * 获取学校食堂周排查-设备设施运行风险排查详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:device:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tWeekDeviceService.selectTWeekDeviceById(id));
    }

    /**
     * 新增学校食堂周排查-设备设施运行风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:device:add')")
    @Log(title = "学校食堂周排查-设备设施运行风险排查", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TWeekDevice tWeekDevice)
    {
        return toAjax(tWeekDeviceService.insertTWeekDevice(tWeekDevice));
    }

    /**
     * 修改学校食堂周排查-设备设施运行风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:device:edit')")
    @Log(title = "学校食堂周排查-设备设施运行风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TWeekDevice tWeekDevice)
    {
        return toAjax(tWeekDeviceService.updateTWeekDevice(tWeekDevice));
    }


    /**
     * 启用/停用学校食堂周排查-设备设施运行风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:device:edit')")
    @Log(title = "学校食堂周排查-设备设施运行风险排查", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TWeekDevice tWeekDevice)
    {
        return toAjax(tWeekDeviceService.cancel(tWeekDevice));
    }

    /**
     * 删除学校食堂周排查-设备设施运行风险排查
     */
    //@PreAuthorize("@ss.hasPermi('web:device:remove')")
    @Log(title = "学校食堂周排查-设备设施运行风险排查", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tWeekDeviceService.deleteTWeekDeviceByIds(ids));
    }
}
