package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TWeekTable;
import com.fyzs.web.entity.query.TWeekTableQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂周排查-周排查Mapper接口
 * 
 * @author ysh
 * @date 2025-11-28
 */
@org.apache.ibatis.annotations.Mapper
public interface TWeekTableMapper  extends BaseMapper<TWeekTable>
{
    /**
     * 查询学校食堂周排查-周排查
     * 
     * @param id 学校食堂周排查-周排查主键
     * @return 学校食堂周排查-周排查
     */
    public TWeekTableQuery selectTWeekTableById(Long id);

    /**
     * 查询学校食堂周排查-周排查列表
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 学校食堂周排查-周排查集合
     */
    public List<TWeekTableQuery> selectTWeekTableList(TWeekTableQuery tWeekTable);

    /**
     * 新增学校食堂周排查-周排查
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 结果
     */
    public int insertTWeekTable(TWeekTable tWeekTable);

    /**
     * 修改学校食堂周排查-周排查
     * 
     * @param tWeekTable 学校食堂周排查-周排查
     * @return 结果
     */
    public int updateTWeekTable(TWeekTable tWeekTable);

    /**
     * 删除学校食堂周排查-周排查
     * 
     * @param id 学校食堂周排查-周排查主键
     * @return 结果
     */
    public int deleteTWeekTableById(Long id);

    /**
     * 批量删除学校食堂周排查-周排查
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTWeekTableByIds(Long[] ids);
    /**
     * 统计指定时间段内有效的周排查记录数（至少有一次记录）
     */
    int countValidWeeklyChecks(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    /**
     * 统计指定时间段内结果为“正常”的周排查记录数
     */
    int countNormalWeeklyChecks(@Param("startDate") Date startDate,
                                @Param("endDate") Date endDate,
                                @Param("deptIds") List<Long> deptIds);

    /**
     * 统计指定时间段内结果为“异常”的周排查记录数
     */
    int countAbnormalWeeklyChecks(@Param("startDate") Date startDate,
                                  @Param("endDate") Date endDate,
                                  @Param("deptIds") List<Long> deptIds);
}
