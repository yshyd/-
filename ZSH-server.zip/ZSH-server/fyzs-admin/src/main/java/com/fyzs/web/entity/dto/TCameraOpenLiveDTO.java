package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TCameraOpenLive;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCameraOpenLiveDTO extends TCameraOpenLive {
}
