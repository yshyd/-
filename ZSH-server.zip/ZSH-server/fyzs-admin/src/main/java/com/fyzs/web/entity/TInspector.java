package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 督察记录对象 t_inspector
 *
 * @author ysh
 * @date 2025-12-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_inspector")
public class TInspector implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体部门 */
        @Schema(description = "主体部门")
        @Excel(name = "主体部门")
        private Long deptId;

        /** 督察级别0本级1上级 */
        @Schema(description = "督察级别0本级1上级")
        @Excel(name = "督察级别0本级1上级")
        private Long level;

        /** 督察部门 */
        @Schema(description = "督察部门")
        @Excel(name = "督察部门")
        private String inspectionDepartment;

        /** 督察人员 */
        @Schema(description = "督察人员")
        @Excel(name = "督察人员")
        private String inspectionPerson;

        /** 督察时间 */
        @Schema(description = "督察时间")
        @Excel(name = "督察时间")
        private String inspectionDate;

        /** 是否发现问题0否1是 */
        @Schema(description = "是否发现问题0否1是")
        @Excel(name = "是否发现问题0否1是")
        private Integer isProblems;

        /** 督察照片，最多5张 */
        @Schema(description = "督察照片，最多5张")
        @Excel(name = "督察照片，最多5张")
        private String inspectionImg;

        /** 问题描述，最多500字，发现问题时必填 */
        @Schema(description = "问题描述，最多500字，发现问题时必填")
        @Excel(name = "问题描述，最多500字，发现问题时必填")
        private String discoverProblems;

        /** 整改时限(年月日) */
        @Schema(description = "整改时限(年月日)")
        @Excel(name = "整改时限(年月日)")
        private String rectificationTimeLimit;

        /** 整改结果：0无需整改1未整改2已整改 发现问题时默认1，没有发现问题时默认0 */
        @Schema(description = "整改结果：0无需整改1未整改2已整改 发现问题时默认1，没有发现问题时默认0")
        @Excel(name = "整改结果：0无需整改1未整改2已整改 发现问题时默认1，没有发现问题时默认0")
        private Integer rectificationResult;

        /** 整改人(变成已整改时必填) */
        @Schema(description = "整改人(变成已整改时必填)")
        @Excel(name = "整改人(变成已整改时必填)")
        private String rectificationPerson;

        /** 整改说明(变成已整改时必填) */
        @Schema(description = "整改说明(变成已整改时必填)")
        @Excel(name = "整改说明(变成已整改时必填)")
        private String rectificationRemarks;

        /** 整改时间(变成已经整改时必填) */
        @Schema(description = "整改时间(变成已经整改时必填)")
        @Excel(name = "整改时间(变成已经整改时必填)")
        private String rectificationTime;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
