package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 可燃气体监测报警仪告警记录对象 t_gas_alarm
 *
 * @author ysh
 * @date 2026-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_gas_alarm")
public class TGasAlarm implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 设备序列号对应t_device中serial_number */
        @Schema(description = "设备序列号对应t_device中serial_number")
        @Excel(name = "设备序列号对应t_device中serial_number")
        private String serialNumber;

        /** 报警类型(直接默认成：可燃气体浓度超标) */
        @Schema(description = "报警类型(直接默认成：可燃气体浓度超标)")
        @Excel(name = "报警类型(直接默认成：可燃气体浓度超标)")
        private String type;

        /** 报警时间(插入预警时系统时间) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "报警时间(插入预警时系统时间)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "报警时间(插入预警时系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

}
