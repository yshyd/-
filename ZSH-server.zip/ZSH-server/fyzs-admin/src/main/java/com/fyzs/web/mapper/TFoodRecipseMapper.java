package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fyzs.web.entity.TFoodRecipse;
import com.fyzs.web.entity.dto.TFoodRecipseDTO;
import com.fyzs.web.entity.query.TFoodRecipseQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 食堂菜谱、留样、试尝、陪餐信息Mapper接口
 *
 * @author ysh
 * @date 2025-11-18
 */
@Mapper
public interface TFoodRecipseMapper extends BaseMapper<TFoodRecipse> {
    /**
     * 查询食堂菜谱、留样、试尝、陪餐信息
     *
     * @param id 食堂菜谱、留样、试尝、陪餐信息主键
     * @return 食堂菜谱、留样、试尝、陪餐信息
     */
    public TFoodRecipseQuery selectTFoodRecipseById(Long id);

    /**
     * 查询食堂菜谱、留样、试尝、陪餐信息列表
     *
     * @return 食堂菜谱、留样、试尝、陪餐信息集合
     */
    public List<TFoodRecipseQuery> selectTFoodRecipseList(TFoodRecipseQuery query);

    /**
     * 新增食堂菜谱、留样、试尝、陪餐信息
     *
     * @param tFoodRecipse 食堂菜谱、留样、试尝、陪餐信息
     * @return 结果
     */
    public int insertTFoodRecipse(TFoodRecipse tFoodRecipse);

    /**
     * 修改食堂菜谱、留样、试尝、陪餐信息
     *
     * @param tFoodRecipse 食堂菜谱、留样、试尝、陪餐信息
     * @return 结果
     */
    public int updateTFoodRecipse(TFoodRecipse tFoodRecipse);

    /**
     * 删除食堂菜谱、留样、试尝、陪餐信息
     *
     * @param id 食堂菜谱、留样、试尝、陪餐信息主键
     * @return 结果
     */
    public int deleteTFoodRecipseById(Long id);

    /**
     * 批量删除食堂菜谱、留样、试尝、陪餐信息
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTFoodRecipseByIds(Long[] ids);

    List<TFoodRecipse> selectFoodRecipesVoList(TFoodRecipseDTO dto);


    // 统计有效餐次数量
    int countValidMealTimes(@Param("startDate") Date startDate,
                            @Param("endDate") Date endDate,
                            @Param("orgIds") List<Long> orgIds);

    // 统计有菜谱的餐次数量
    int countMenusWithRecipes(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);



    // 统计有效菜谱数量（应留样）
    int countValidMenus(@Param("startDate") Date startDate,
                        @Param("endDate") Date endDate,
                        @Param("deptIds") List<Long> deptIds);

    // 统计已留样的菜谱数量（已留样）
    int countSampledMenus(@Param("startDate") Date startDate,
                          @Param("endDate") Date endDate,
                          @Param("deptIds") List<Long> deptIds);

    // 统计已销样的菜谱数量（已销样）
    int countDestroyedSamples(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    // 统计正常销样的菜谱数量（正常销样：留样时间超过48小时）
    int countNormalDestroyedSamples(@Param("startDate") Date startDate,
                                    @Param("endDate") Date endDate,
                                    @Param("deptIds") List<Long> deptIds);


    // 统计已试尝的菜谱数量（已试尝）
    int countTastedMenus(@Param("startDate") Date startDate,
                         @Param("endDate") Date endDate,
                         @Param("deptIds") List<Long> deptIds);

    // 统计试尝结果正常的菜谱数量（试尝正常）
    int countNormalTastedMenus(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);


    /**
     * 统计指定日期有菜谱记录的主体数量
     */
    int countEntitiesWithMenuByDate(@Param("date") Date date, @Param("deptIds") List<Long> deptIds);

    // 获取指定日期各主体的餐次配置数
    List<Map<String, Object>> getMealSettingsForDate(@Param("date") Date date, @Param("deptIds") List<Long> deptIds);


}
