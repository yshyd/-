package com.fyzs.web.controller.system;

import java.util.List;

import com.fyzs.web.entity.TCameraInfo;
import com.fyzs.web.entity.TDevice;
import com.fyzs.web.entity.query.TCameraInfoQuery;
import com.fyzs.web.entity.query.TDeviceQuery;
import com.fyzs.web.service.ITCameraInfoService;
import com.fyzs.web.service.ITDeviceService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.constant.UserConstants;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.system.service.ISysDeptService;

/**
 * 部门信息
 * 
 * @author ysh
 */
@RestController
@AllArgsConstructor
@RequestMapping("/system/dept")
public class SysDeptController extends BaseController
{
    private  final ISysDeptService deptService;

    private final ITCameraInfoService cameraInfoService;

    private final ITDeviceService deviceService;

    /**
     * 获取部门列表
     */
    @PreAuthorize("@ss.hasPermi('system:dept:list')")
    @GetMapping("/list")
    public AjaxResult list(SysDept dept)
    {
        List<SysDept> depts = deptService.selectDeptList(dept);
        return success(depts);
    }

    /**
     * 查询部门列表（排除节点）
     */
    @PreAuthorize("@ss.hasPermi('system:dept:list')")
    @GetMapping("/list/exclude/{deptId}")
    public AjaxResult excludeChild(@PathVariable(value = "deptId", required = false) Long deptId)
    {
        List<SysDept> depts = deptService.selectDeptList(new SysDept());
        depts.removeIf(d -> d.getDeptId().intValue() == deptId || ArrayUtils.contains(StringUtils.split(d.getAncestors(), ","), deptId + ""));
        return success(depts);
    }

    /**
     * 根据部门编号获取详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:dept:query')")
    @GetMapping(value = "/{deptId}")
    public AjaxResult getInfo(@PathVariable Long deptId)
    {
        deptService.checkDeptDataScope(deptId);
        return success(deptService.selectDeptById(deptId));
    }

    /**
     * 新增部门
     */
    @PreAuthorize("@ss.hasPermi('system:dept:add')")
    @Log(title = "部门管理", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@Validated @RequestBody SysDept dept)
    {
        if (!deptService.checkDeptNameUnique(dept))
        {
            return error("新增部门'" + dept.getDeptName() + "'失败，部门名称已存在");
        }
        dept.setCreateBy(getUsername());
        return toAjax(deptService.insertDept(dept));
    }

    /**
     * 修改部门
     */
    @PreAuthorize("@ss.hasPermi('system:dept:edit')")
    @Log(title = "部门管理", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@Validated @RequestBody SysDept dept)
    {
        Long deptId = dept.getDeptId();
        deptService.checkDeptDataScope(deptId);
        if (!deptService.checkDeptNameUnique(dept))
        {
            return error("修改部门'" + dept.getDeptName() + "'失败，部门名称已存在");
        }
        else if (dept.getParentId().equals(deptId))
        {
            return error("修改部门'" + dept.getDeptName() + "'失败，上级部门不能是自己");
        }
        else if (StringUtils.equals(UserConstants.DEPT_DISABLE, dept.getStatus()) && deptService.selectNormalChildrenDeptById(deptId) > 0)
        {
            return error("该部门包含未停用的子部门！");
        }
        dept.setUpdateBy(getUsername());
        return toAjax(deptService.updateDept(dept));
    }

    /**
     * 删除部门
     */
    @PreAuthorize("@ss.hasPermi('system:dept:remove')")
    @Log(title = "部门管理", businessType = BusinessType.DELETE)
    @DeleteMapping("/{deptId}")
    public AjaxResult remove(@PathVariable Long deptId)
    {
        if (deptService.hasChildByDeptId(deptId))
        {
            return warn("存在下级部门,不允许删除");
        }
        if (deptService.checkDeptExistUser(deptId))
        {
            return warn("部门存在用户,不允许删除");
        }
        deptService.checkDeptDataScope(deptId);
        return toAjax(deptService.deleteDeptById(deptId));
    }

    /**
     * 获取部门下拉树列表
     */
    @GetMapping("/treeselect")
    public AjaxResult treeselect(SysDept dept)
    {
        List<SysDept> depts = deptService.selectDeptList(dept);
        return success(deptService.buildDeptTreeSelect(depts));
    }

    /**
     * 停用/启用部门
     */
//    @PreAuthorize("@ss.hasPermi('system:dept:edit')")
    @Log(title = "部门管理", businessType = BusinessType.UPDATE)
    @PutMapping("/changeStatus")
    public AjaxResult changeStatus( @RequestBody SysDept dept) {
        Long deptId = dept.getDeptId();

        if (UserConstants.DEPT_DISABLE.equals(dept.getStatus())) { // 停用操作
            return handleDeptDisable(deptId);
        } else if (UserConstants.DEPT_NORMAL.equals(dept.getStatus())) { // 启用操作
            return handleDeptEnable(deptId);
        }

        return error("无效的状态值");
    }

    /**
     * 处理部门启用逻辑
     */
    private AjaxResult handleDeptEnable(Long deptId) {
        // 检查父部门状态
        if (hasDisabledParent(deptId)) {
            return warn("父部门处于停用状态，无法启用当前部门");
        }

        return toAjax(deptService.updateDeptStatusStart(deptId, UserConstants.DEPT_NORMAL));
    }

    /**
     * 检查是否存在停用的父部门
     */
    private boolean hasDisabledParent(Long deptId) {
        SysDept currentDept = deptService.selectDeptById(deptId);
        if (currentDept == null || currentDept.getParentId() == null) {
            return false; // 没有父部门或找不到部门信息
        }

        // 获取所有祖先部门ID
        String ancestors = currentDept.getAncestors();
        if (StringUtils.isNotEmpty(ancestors)) {
            String[] ancestorIds = ancestors.split(",");
            for (String ancestorId : ancestorIds) {
                if (StringUtils.isNotEmpty(ancestorId)) {
                    SysDept ancestorDept = deptService.selectDeptById(Long.valueOf(ancestorId));
                    if (ancestorDept != null && UserConstants.DEPT_DISABLE.equals(ancestorDept.getStatus())) {
                        return true;
                    }
                }
            }
        }

        // 检查直接父部门
        SysDept parentDept = deptService.selectDeptById(currentDept.getParentId());
        if (parentDept != null && UserConstants.DEPT_DISABLE.equals(parentDept.getStatus())) {
            return true;
        }

        return false;
    }

    /**
     * 处理部门停用逻辑
     */
    private AjaxResult handleDeptDisable(Long deptId) {
        // 检查是否存在下级部门
        if (deptService.hasChildByDeptId(deptId)) {
            return warn("存在下级部门,不允许停用");
        }

        // 检查部门是否存在用户
        if (deptService.checkDeptExistUser(deptId)) {
            return warn("部门存在用户,不允许停用");
        }

        // 检查是否存在摄像头
        if (hasActiveCameras(deptId)) {
            return warn("存在摄像头,不允许停用");
        }

        // 检查是否存在设备
        if (hasActiveDevices(deptId)) {
            return warn("存在设备,不允许停用");
        }

        return toAjax(deptService.updateDeptStatus(deptId, UserConstants.DEPT_DISABLE));
    }

    /**
     * 检查部门是否存在激活的摄像头
     */
    private boolean hasActiveCameras(Long deptId) {
        TCameraInfoQuery query = new TCameraInfoQuery();
        query.setDeptId(deptId);
        query.setDelFlag(0);
        List<TCameraInfoQuery> cameras = cameraInfoService.selectTCameraInfoCount(query);
        return !cameras.isEmpty();
    }

    /**
     * 检查部门是否存在激活的设备
     */
    private boolean hasActiveDevices(Long deptId) {
        TDeviceQuery query = new TDeviceQuery();
        query.setDeptId(deptId);
        query.setDelFlag(0L);
        List<TDeviceQuery> devices = deviceService.selectTDeviceCount(query);
        return !devices.isEmpty();
    }



}
