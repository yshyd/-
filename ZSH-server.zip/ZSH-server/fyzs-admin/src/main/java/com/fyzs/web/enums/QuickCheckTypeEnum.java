package com.fyzs.web.enums;

/**
 * 快检类型枚举
 * Quick Check Type Enum
 */
public enum QuickCheckTypeEnum {

    PESTICIDE_RESIDUE(0, "农药残留"),
    AFLATOXIN_B1(1, "黄曲霉毒素B1"),
    FRESHNESS(2, "新鲜度"),
    CLenbuterol(3, "瘦肉精(克伦特罗)"),
    RACTOPAMINE(4, "瘦肉精(莱克多巴胺)"),
    SALBUTAMOL(5, "瘦肉精(沙丁胺醇)"),
    WATER_INJECTED_MEAT(6, "注水肉"),
    DISEASED_MEAT(7, "病害肉"),
    PEROXIDE_VALUE(8, "过氧化值"),
    ACID_VALUE(9, "酸价"),
    MELAMINE(10, "三聚氰胺"),
    FORMALDEHYDE_SULFOXALIC_ACID(11, "吊白块"),
    SULFUR_DIOXIDE(12, "二氧化硫"),
    FORMALDEHYDE(13, "甲醛"),
    ALUMINUM(14, "铝"),
    CLEANLINESS(15, "洁净度"),
    NITRITE(16, "亚硝酸盐");

    private final Integer code;
    private final String description;

    QuickCheckTypeEnum(Integer code, String description) {
        this.code = code;
        this.description = description;
    }

    public Integer getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }

    public static QuickCheckTypeEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        for (QuickCheckTypeEnum type : values()) {
            if (type.getCode().equals(code)) {
                return type;
            }
        }
        return null;
    }
}
