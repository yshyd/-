package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TMonitoringLinksConfig;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TMonitoringLinksConfigDTO extends TMonitoringLinksConfig {

    @Schema(description = "部门ID")
    private String deptId;

    @Schema(description = "区域id")
    private String areaId;

    @Schema(description = "配置摄像头数量")
    private Integer cameraNum;
}
