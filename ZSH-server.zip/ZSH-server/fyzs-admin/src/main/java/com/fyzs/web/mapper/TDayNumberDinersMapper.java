package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayNumberDiners;
import com.fyzs.web.entity.query.TDayNumberDinersQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 食安监管-日管控-日常就餐-就餐人数Mapper接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
@Mapper
public interface TDayNumberDinersMapper  extends BaseMapper<TDayNumberDiners>
{
    /**
     * 查询食安监管-日管控-日常就餐-就餐人数
     * 
     * @param id 食安监管-日管控-日常就餐-就餐人数主键
     * @return 食安监管-日管控-日常就餐-就餐人数
     */
    public TDayNumberDinersQuery selectTDayNumberDinersById(Long id);

    /**
     * 查询食安监管-日管控-日常就餐-就餐人数列表
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 食安监管-日管控-日常就餐-就餐人数集合
     */
    public List<TDayNumberDinersQuery> selectTDayNumberDinersList(TDayNumberDinersQuery tDayNumberDiners);

    /**
     * 新增食安监管-日管控-日常就餐-就餐人数
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 结果
     */
    public int insertTDayNumberDiners(TDayNumberDiners tDayNumberDiners);

    /**
     * 修改食安监管-日管控-日常就餐-就餐人数
     * 
     * @param tDayNumberDiners 食安监管-日管控-日常就餐-就餐人数
     * @return 结果
     */
    public int updateTDayNumberDiners(TDayNumberDiners tDayNumberDiners);

    /**
     * 删除食安监管-日管控-日常就餐-就餐人数
     * 
     * @param id 食安监管-日管控-日常就餐-就餐人数主键
     * @return 结果
     */
    public int deleteTDayNumberDinersById(Long id);

    /**
     * 批量删除食安监管-日管控-日常就餐-就餐人数
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayNumberDinersByIds(Long[] ids);

    int countValidDinerCounts(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    /**
     * 查询指定日期和主体范围内的就餐数据
     */
    List<TDayNumberDinersQuery> selectDinerDataByDateAndDeptIds(@Param("todayStart") Date todayStart,
                                                                @Param("todayEnd") Date todayEnd, @Param("deptIds") List<Long> deptIds);

}
