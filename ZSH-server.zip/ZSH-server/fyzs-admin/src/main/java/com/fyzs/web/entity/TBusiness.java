package com.fyzs.web.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Data
@EqualsAndHashCode(callSuper = false)
public class TBusiness implements Serializable {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "主体ID")
    private Long deptId;

    @Schema(description = "采购结算金额(元)")
    private BigDecimal purchaseSettlementAmount;

    @Schema(description = "退货结算金额(元)")
    private BigDecimal returnSettlementAmount;

    @Schema(description = "实际支出(元)")
    private BigDecimal actualExpenditure;

    @Schema(description = "供应商名称")
    private String supplerName;

    @Schema(description = "供应商ID")
    private Long supplerId;

    @Schema(description = "仓库名称")
    private String warehouseName;

    @Schema(description = "仓库ID")
    private Long warehouseId;

    @Schema(description = "采购单号")
    private String procurementNum;

    @Schema(description = "验收时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date acceptanceTime;

}
