package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TNewProcurementWarehouse;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewProcurementWarehouseDTO extends TNewProcurementWarehouse {

    @Schema(description = "库存ID")
    private Long inventoryId;

    @Schema(description = "出库ID")
    private Long outboundId;
}
