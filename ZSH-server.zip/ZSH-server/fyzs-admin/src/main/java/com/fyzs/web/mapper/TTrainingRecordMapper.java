package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TTrainingRecord;
import com.fyzs.web.entity.query.TTrainingRecordQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 工勤人员培训记录Mapper接口
 * 
 * @author ysh
 * @date 2025-12-02
 */
@org.apache.ibatis.annotations.Mapper
public interface TTrainingRecordMapper  extends BaseMapper<TTrainingRecord>
{
    /**
     * 查询工勤人员培训记录
     * 
     * @param id 工勤人员培训记录主键
     * @return 工勤人员培训记录
     */
    public TTrainingRecordQuery selectTTrainingRecordById(Long id);

    /**
     * 查询工勤人员培训记录列表
     * 
     * @param tTrainingRecord 工勤人员培训记录
     * @return 工勤人员培训记录集合
     */
    public List<TTrainingRecordQuery> selectTTrainingRecordList(TTrainingRecordQuery tTrainingRecord);

    /**
     * 新增工勤人员培训记录
     * 
     * @param tTrainingRecord 工勤人员培训记录
     * @return 结果
     */
    public int insertTTrainingRecord(TTrainingRecord tTrainingRecord);

    /**
     * 修改工勤人员培训记录
     * 
     * @param tTrainingRecord 工勤人员培训记录
     * @return 结果
     */
    public int updateTTrainingRecord(TTrainingRecord tTrainingRecord);

    /**
     * 删除工勤人员培训记录
     * 
     * @param id 工勤人员培训记录主键
     * @return 结果
     */
    public int deleteTTrainingRecordById(Long id);

    /**
     * 批量删除工勤人员培训记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTTrainingRecordByIds(Long[] ids);
}
