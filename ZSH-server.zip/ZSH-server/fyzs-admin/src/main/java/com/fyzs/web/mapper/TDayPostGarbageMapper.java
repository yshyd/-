package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayPostGarbage;
import com.fyzs.web.entity.query.TDayPostGarbageQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 食安监管-日管控-餐厨垃圾Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@Mapper
public interface TDayPostGarbageMapper  extends BaseMapper<TDayPostGarbage>
{
    /**
     * 查询食安监管-日管控-餐厨垃圾
     * 
     * @param id 食安监管-日管控-餐厨垃圾主键
     * @return 食安监管-日管控-餐厨垃圾
     */
    public TDayPostGarbageQuery selectTDayPostGarbageById(Long id);

    /**
     * 查询食安监管-日管控-餐厨垃圾列表
     *
     * @return 食安监管-日管控-餐厨垃圾集合
     */
    public List<TDayPostGarbageQuery> selectTDayPostGarbageList(TDayPostGarbageQuery query);

    /**
     * 新增食安监管-日管控-餐厨垃圾
     * 
     * @param tDayPostGarbage 食安监管-日管控-餐厨垃圾
     * @return 结果
     */
    public int insertTDayPostGarbage(TDayPostGarbage tDayPostGarbage);

    /**
     * 修改食安监管-日管控-餐厨垃圾
     * 
     * @param tDayPostGarbage 食安监管-日管控-餐厨垃圾
     * @return 结果
     */
    public int updateTDayPostGarbage(TDayPostGarbage tDayPostGarbage);

    /**
     * 删除食安监管-日管控-餐厨垃圾
     * 
     * @param id 食安监管-日管控-餐厨垃圾主键
     * @return 结果
     */
    public int deleteTDayPostGarbageById(Long id);

    /**
     * 批量删除食安监管-日管控-餐厨垃圾
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayPostGarbageByIds(Long[] ids);

    int countValidRecords(@Param("startDate") Date startDate,
                          @Param("endDate") Date endDate,
                          @Param("deptIds") List<Long> deptIds);
}
