package com.fyzs.web.entity.vo;

import lombok.Data;

@Data
public class InvoiceUploadedVO {
    private String deptName; // 主体名称
    private String commodityName; // 商品名称
    private String acceptanceUserName; // 验收人
    private String acceptanceDate; // 验收时间
    private String ticketsAndCertificates; // 索票索证（逗号分割的URL）
    private Integer isUpload; // 是否上传 0 上传 1未上传
}
