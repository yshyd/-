package com.fyzs.web.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fyzs.web.entity.TBusiness;
import com.fyzs.web.entity.query.TBusinessQuery;
import com.fyzs.web.entity.vo.TBusinessVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface TBusinessMapper extends BaseMapper<TBusiness> {
  
    List<TBusinessQuery> selectProcurementSummary(TBusinessQuery businessQuery);

    List<TBusinessQuery> selectReturnSummary(TBusinessQuery businessQuery);

    List<TBusinessVO> selectProcurementDetailList(TBusinessQuery businessQuery);

    List<TBusinessVO> selectReturnDetailList(TBusinessQuery businessQuery);
}
