package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;

import com.fyzs.web.entity.TNewProcurementAcceptance;
import com.fyzs.web.entity.query.TNewProcurementAcceptanceQuery;
import com.fyzs.web.entity.vo.InvoiceUploadedVO;
import com.fyzs.web.entity.vo.TNewProcurementAcceptanceVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 商品采购验收Mapper接口
 *
 * @author ysh
 * @date 2025-10-29
 */
@Mapper
public interface TNewProcurementAcceptanceMapper extends BaseMapper<TNewProcurementAcceptance> {
    /**
     * 查询商品采购验收
     *
     * @param id 商品采购验收主键
     * @return 商品采购验收
     */
    public TNewProcurementAcceptanceQuery selectTNewProcurementAcceptanceById(Long id);

    /**
     * 查询商品采购验收列表
     *
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 商品采购验收集合
     */
    public List<TNewProcurementAcceptanceQuery> selectTNewProcurementAcceptanceList(TNewProcurementAcceptanceQuery tNewProcurementAcceptance);

    /**
     * 新增商品采购验收
     *
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int insertTNewProcurementAcceptance(TNewProcurementAcceptance tNewProcurementAcceptance);

    /**
     * 修改商品采购验收
     *
     * @param tNewProcurementAcceptance 商品采购验收
     * @return 结果
     */
    public int updateTNewProcurementAcceptance(TNewProcurementAcceptance tNewProcurementAcceptance);

    /**
     * 删除商品采购验收
     *
     * @param id 商品采购验收主键
     * @return 结果
     */
    public int deleteTNewProcurementAcceptanceById(Long id);

    /**
     * 批量删除商品采购验收
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewProcurementAcceptanceByIds(Long[] ids);

    String selectMaxAcceptanceNoByDatePrefix(String datePrefix);

    TNewProcurementAcceptanceVO listDetail(Long id);

    /**
     * 根据ID列表批量查询验收记录
     *
     * @param ids 验收ID数组
     * @return 验收记录列表
     */
    List<TNewProcurementAcceptanceVO> selectByIds(@Param("ids") Long[] ids);


    int countAcceptancesByDateAndDeptIds(@Param("deptIds") List<Long> deptIds);

    int countAcceptancesWithEmptyTickets(@Param("deptIds") List<Long> deptIds);

    int countAcceptancesWithTickets(@Param("deptIds") List<Long> deptIds);


    List<InvoiceUploadedVO> selectInvoiceUploadedDown(@Param("deptIds") List<Long> deptIds,
                                                      @Param("query") InvoiceUploadedVO query);

}
