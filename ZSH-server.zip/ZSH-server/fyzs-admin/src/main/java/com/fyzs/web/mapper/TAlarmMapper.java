package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TAlarm;
import com.fyzs.web.entity.query.TAlarmQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 预警信息Mapper接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
@Mapper
public interface TAlarmMapper  extends BaseMapper<TAlarm>
{
    /**
     * 查询预警信息
     * 
     * @param id 预警信息主键
     * @return 预警信息
     */
    public TAlarmQuery selectTAlarmById(Long id);

    /**
     * 查询预警信息列表
     * 
     * @param tAlarm 预警信息
     * @return 预警信息集合
     */
    public List<TAlarmQuery> selectTAlarmList(TAlarmQuery tAlarm);

    /**
     * 新增预警信息
     * 
     * @param tAlarm 预警信息
     * @return 结果
     */
    public int insertTAlarm(TAlarm tAlarm);


    /**
     * 定时任务专用插入方法，不触发自动填充
     *
     * @param tAlarm 预警信息
     * @return 结果
     */
    int insertTAlarmForSchedule(TAlarm tAlarm);


    /**
     * 修改预警信息
     * 
     * @param tAlarm 预警信息
     * @return 结果
     */
    public int updateTAlarm(TAlarm tAlarm);

    /**
     * 删除预警信息
     * 
     * @param id 预警信息主键
     * @return 结果
     */
    public int deleteTAlarmById(Long id);

    /**
     * 批量删除预警信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTAlarmByIds(Long[] ids);

    int saveBatch(List<TAlarm> alarms);

    int updateStateByIds(@Param("existingAlarmIds") List<Long> existingAlarmIds, @Param("i") int i);

    List<TAlarmQuery> selectTAlarmListByDeptIds(TAlarmQuery tAlarmQuery);
}
