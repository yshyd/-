package com.fyzs.web.entity.vo;

import io.swagger.models.auth.In;
import lombok.Data;

@Data
public class CanteenDataDownVO {

    /** 食堂名称 */
    private String deptName;           // 食堂名称
    /** 食堂类型 0自营食堂、1外包食堂*/
    private Integer type;        // 食堂类型：自营/承包
    /** 法定代表人 */
    private String legalRepresentativeName; // 法定代表人
    /** 法定代表电话 */
    private String legalRepresentativePhone; // 法定代表电话
    /** 证件图片路径 */
    private String img;                // 证件图片路径
}
