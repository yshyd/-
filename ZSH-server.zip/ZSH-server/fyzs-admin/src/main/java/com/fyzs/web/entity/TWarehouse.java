package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 仓库信息对象 t_warehouse
 *
 * @author ysh
 * @date 2025-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_warehouse")
public class TWarehouse implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 主体id
     */
    @Schema(description = "主体id")
    @Excel(name = "主体id")
    private Long deptId;

    /**
     * 仓库名称
     */
    @Schema(description = "仓库名称")
    @Excel(name = "仓库名称")
    private String warehouseName;

    /**
     * 主体名称
     */
    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    /**
     * 区域id
     */
    @Schema(description = "区域id")
    @Excel(name = "区域id")
    private Long areaId;

    /**
     * 状态：0启用 1禁用
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "状态：0启用 1禁用")
    private Integer delFlag;

    /**
     * 创建人ID
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人ID")
    @Excel(name = "创建人ID")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

}
