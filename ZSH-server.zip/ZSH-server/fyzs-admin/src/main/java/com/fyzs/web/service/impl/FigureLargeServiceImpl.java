package com.fyzs.web.service.impl;

import com.fyzs.common.core.domain.entity.SysDept;
import com.fyzs.common.core.domain.entity.SysRole;
import com.fyzs.common.core.domain.entity.query.SysDeptQuery;
import com.fyzs.common.core.domain.entity.vo.SysDeptVO;
import com.fyzs.common.utils.SecurityUtils;
import com.fyzs.system.domain.query.TFoodBusinessLicenseQuery;
import com.fyzs.system.domain.vo.TOrganizationDetailVO;
import com.fyzs.system.mapper.*;
import com.fyzs.system.service.ISysDeptService;
import com.fyzs.web.entity.PageResult;
import com.fyzs.web.entity.TDeptSuppler;
import com.fyzs.web.entity.dto.FoodSampleDTO;
import com.fyzs.web.entity.dto.SummaryItemDTO;
import com.fyzs.web.entity.query.*;
import com.fyzs.web.entity.vo.*;
import com.fyzs.web.mapper.*;
import com.fyzs.web.mapper.TCanteenInformationMapper;
import com.fyzs.web.mapper.TSchoolInformationMapper;
import com.fyzs.web.service.ICollectService;
import com.fyzs.web.service.IFigureLargeService;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.http.client.utils.DateUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.time.DateUtils.addDays;

@Service
@AllArgsConstructor
@Slf4j
public class FigureLargeServiceImpl implements IFigureLargeService {

    private final SysRoleDeptMapper sysRoleDeptMapper;

    private final SysDeptMapper sysDeptMapper;

    private final SysRoleMapper roleMapper;

    private final TCanteenInformationMapper tCanteenInformationMapper;

    private final TCanteenPractitionersMapper tCanteenPractitionersMapper;

    private final TSchoolInformationMapper tSchoolInformationMapper;

    private final TDeptSupplerMapper tDeptSupplerMapper;

    private final ICollectService collectService;

    private final ISysDeptService deptService;

    private final TCalendarInfoMapper tCalendarInfoMapper;

    private final TAlarmMapper tAlarmMapper;

    private final TNewProcurementMapper tNewProcurementMapper;

    private final TDayNumberDinersMapper tDayNumberDinersMapper;

    private final TOrganizationDetailMapper tOrganizationDetailMapper;

    private final TFoodBusinessLicenseMapper tFoodBusinessLicenseMapper;

    private final TNewProcurementAcceptanceMapper tNewProcurementAcceptanceMapper;


    @Override
    public StatisticsResponseVO getStatistics(SummaryQuery query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            // 超级管理员：查询所有有效的主体
            authDeptIds = deptService.selectAllDepts();
        } else {
            // 普常用户：根据角色权限获取
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new StatisticsResponseVO();
        }
        // 校验并获取有效的部门ID
        List<Long> validDeptIds = sysDeptMapper.selectBatchIdsList(authDeptIds)
                .stream()
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());

        //校验学校食堂标签
        List<Long> canteenIds = sysDeptMapper.selectBatchIdsList(authDeptIds)
                .stream()
                .filter(dept -> "4".equals(dept.getDeptLevel())) // 4代表学校食堂标签
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());

        //校验学校标签
        List<Long> schoolIds = sysDeptMapper.selectBatchIdsList(authDeptIds)
                .stream()
                .filter(dept -> "1".equals(dept.getDeptLevel())) // 1代表学校标签
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());

        // 统计逻辑
        Integer schoolCount = countSchools(validDeptIds);
        Integer canteenCount = countCanteens(validDeptIds);
        Integer staffCount = countStaff(canteenIds);
        Integer diningCount = countDiningPeople(schoolIds);
        Integer supplierCount = countSuppliers(validDeptIds);

        StatisticsResponseVO response = new StatisticsResponseVO();
        response.setSchoolCount(schoolCount);
        response.setCanteenCount(canteenCount);
        response.setStaffCount(staffCount);
        response.setDiningCount(diningCount);
        response.setSupplierCount(supplierCount);

        return response;
    }

    // 1. 统计学校数量（标签为1）
    private Integer countSchools(List<Long> deptIds) {
        return sysDeptMapper.selectBatchIdsList(deptIds)
                .stream()
                .filter(dept -> "1".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus()))
                .collect(Collectors.toList())
                .size();
    }

    // 2. 统计学校食堂数量（标签为4）
    private Integer countCanteens(List<Long> deptIds) {
        return sysDeptMapper.selectBatchIdsList(deptIds)
                .stream()
                .filter(dept -> "4".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus()))
                .collect(Collectors.toList())
                .size();
    }

    // 3. 统计食堂下的有效工勤人员总数
    private Integer countStaff(List<Long> deptIds) {
        return Math.toIntExact(tCanteenPractitionersMapper.selectTCanteenPractitionersList(new TCanteenPractitionersQuery())
                .stream()
                .filter(info -> deptIds.contains(info.getDeptId()) && info.getDelFlag().equals(0))
                .count());
    }


    // 4. 统计所有学校的就餐人数总和
    private Integer countDiningPeople(List<Long> deptIds) {
        return Math.toIntExact(tSchoolInformationMapper.selectTSchoolInformationList(new TSchoolInformationQuery())
                .stream()
                .filter(info -> deptIds.contains(info.getDeptId()))
                .mapToLong(TSchoolInformationQuery::getNumber)
                .sum());
    }

    // 5. 统计有效供应商数量（按 businessCode 去重）
    private Integer countSuppliers(List<Long> deptIds) {
        return tDeptSupplerMapper.selectTDeptSupplerList(new TDeptSupplerQuery())
                .stream()
                .filter(supplier -> deptIds.contains(supplier.getDeptId()) &&
                        supplier.getDelFlag().equals(0))
                .map(TDeptSupplerQuery::getBusinessCode)
                .distinct()
                .collect(Collectors.toList())
                .size();
    }

    @Override
    public PageResult<SchoolDataDownVO> getSchoolDataDown(Integer pageNum, Integer pageSize, SchoolDataDownVO query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            // 超级管理员：查询所有有效的主体
            authDeptIds = deptService.selectAllDepts();
        } else {
            // 普常用户：根据角色权限获取
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        // 过滤出标签为"1"的学校
        List<SysDept> sysDepts = sysDeptMapper.selectBatchIdsList(authDeptIds);
        if (sysDepts.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        List<Long> deptIds = sysDepts.stream()
                .filter(dept -> "1".equals(dept.getDeptLevel()))
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());
        if (deptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        SysDeptQuery sysDeptQuery = new SysDeptQuery();
        sysDeptQuery.setDeptIds(authDeptIds);
        sysDeptQuery.setDelFlag("0"); // 有效
        sysDeptQuery.setDeptName(query.getDeptName());
        sysDeptQuery.setLeRep(query.getLeRep());
        sysDeptQuery.setPhone(query.getPhone());
        sysDeptQuery.setType(query.getType());
//        int total = sysDeptMapper.countValidSchools(sysDeptQuery);
        // 查询符合条件的学校数据
        PageHelper.startPage(pageNum, pageSize);
        List<SysDeptQuery> detailVOS = sysDeptMapper.selectSchoolDataDown(sysDeptQuery);
        if (detailVOS.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        // 转化为 SchoolDataDownVO 列表
        List<SchoolDataDownVO> result = detailVOS.stream()
                .map(detailVO -> {
                    SchoolDataDownVO schoolDataDownVO = new SchoolDataDownVO();
                    schoolDataDownVO.setDeptName(detailVO.getDeptName());
                    schoolDataDownVO.setType(detailVO.getType());
                    schoolDataDownVO.setLeRep(detailVO.getLeRep());
                    schoolDataDownVO.setPhone(detailVO.getPhone());
                    schoolDataDownVO.setImg(detailVO.getImg());
                    return schoolDataDownVO;
                })
                .collect(Collectors.toList());
        PageInfo<SchoolDataDownVO> pageInfo = new PageInfo<>(result);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }

    @Override
    public PageResult<CanteenDataDownVO> getCanteenDataDown(Integer pageNum, Integer pageSize, CanteenDataDownVO query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        // 过滤出标签为"4"的学校食堂
        List<SysDept> sysDepts = sysDeptMapper.selectBatchIdsList(authDeptIds);
        if (sysDepts.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        List<Long> deptIds = sysDepts.stream()
                .filter(dept -> "4".equals(dept.getDeptLevel()))
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());
        if (deptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        SysDeptQuery sysDeptQuery = new SysDeptQuery();
        sysDeptQuery.setDeptIds(authDeptIds);
        sysDeptQuery.setDelFlag("0"); // 有效
        sysDeptQuery.setDeptName(query.getDeptName());
        sysDeptQuery.setType(query.getType());

//        int total = sysDeptMapper.countValidCanteens(sysDeptQuery);
//
//        // 分页查询
//        int offset = (pageNum - 1) * pageSize;
//        sysDeptQuery.setOffset(offset);
//        sysDeptQuery.setLimit(pageSize);

        PageHelper.startPage(pageNum, pageSize);
        List<SysDeptQuery> sysDeptVOS = sysDeptMapper.selectCanteenDataDown(sysDeptQuery);
        if (sysDeptVOS.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        // 转化为 SchoolDataDownVO 列表
        List<CanteenDataDownVO> result = sysDeptVOS.stream()
                .map(detailVO -> {
                    CanteenDataDownVO canteenDataDownVO = new CanteenDataDownVO();
                    canteenDataDownVO.setDeptName(detailVO.getDeptName());
                    canteenDataDownVO.setType(detailVO.getType());
                    canteenDataDownVO.setLegalRepresentativeName(detailVO.getLeRep());
                    canteenDataDownVO.setLegalRepresentativePhone(detailVO.getPhone());
                    canteenDataDownVO.setImg(detailVO.getImg());
                    return canteenDataDownVO;
                })
                .collect(Collectors.toList());
        PageInfo<CanteenDataDownVO> pageInfo = new PageInfo<>(result);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }

    @Override
    public PageResult<PractitionerDataDownVO> getPractitionerDataDown(Integer pageNum, Integer pageSize, PractitionerDataDownVO query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }

        // 过滤出标签为"4"的学校食堂
        List<SysDept> sysDepts = sysDeptMapper.selectBatchIdsList(authDeptIds);
        if (sysDepts.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        List<Long> deptIds = sysDepts.stream()
                .filter(dept -> "4".equals(dept.getDeptLevel()))
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());

        if (deptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }
        TCanteenPractitionersQuery practitionersQuery = new TCanteenPractitionersQuery();
        practitionersQuery.setDeptIds(deptIds);
        practitionersQuery.setDelFlag(0);
        practitionersQuery.setName(query.getName());

//        int total = tCanteenPractitionersMapper.countValidSuppliers(practitionersQuery);
//
//        int offset = (pageNum - 1) * pageSize;
//        practitionersQuery.setOffset(offset);
//        practitionersQuery.setLimit(pageSize);
//        PageHelper.startPage(pageNum, pageSize);
        List<TCanteenPractitionersQuery> practitionerList = tCanteenPractitionersMapper.getPractitionerDataDown(practitionersQuery);

        if (practitionerList.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }

        List<PractitionerDataDownVO> result = practitionerList.stream()
                .map(practitioner -> {
                    PractitionerDataDownVO vo = new PractitionerDataDownVO();
                    vo.setDeptName(practitioner.getDeptName());
                    vo.setName(practitioner.getName());
                    vo.setSex(practitioner.getSex());
                    vo.setEducation(practitioner.getEducation());
                    vo.setIdCardFrontImg(practitioner.getIdCardFront());
                    vo.setIdCardBackImg(practitioner.getIdCardBack());
                    vo.setHealthCertificateImg(practitioner.getHealthCertificateImg());
                    vo.setFoodSafetyTrainingImg(practitioner.getHealthTrainCertificateImg());
                    return vo;
                })
                .collect(Collectors.toList());
        PageInfo<PractitionerDataDownVO> pageInfo = new PageInfo<>(result);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }


    @Override
    public PageResult<SupplierDataDownVO> getSupplierDataDown(Integer pageNum, Integer pageSize, SupplierDataDownVO query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0L);
        }

        // 构建查询条件
        TDeptSupplerQuery supplerQuery = new TDeptSupplerQuery();
        supplerQuery.setDeptIds(authDeptIds);
        supplerQuery.setDelFlag(0); // 有效
        supplerQuery.setName(query.getName());
        supplerQuery.setContactPerson(query.getContactPerson());
        supplerQuery.setContactPhone(query.getContactPhone());

//        // 查询总记录数
//        int total = tDeptSupplerMapper.countValidSuppliers(supplerQuery);
//
//        // 分页查询
//        int offset = (pageNum - 1) * pageSize;
//        supplerQuery.setOffset(offset);
//        supplerQuery.setLimit(pageSize);
        PageHelper.startPage(pageNum, pageSize);
        List<TDeptSuppler> validSuppliers = tDeptSupplerMapper.selectValidSupplersByDeptIdsAndCondition(supplerQuery);

        // 按 businessCode 去重
        Map<String, TDeptSuppler> supplierMap = validSuppliers.stream()
                .collect(Collectors.toMap(TDeptSuppler::getBusinessCode, Function.identity(), (e1, e2) -> e1));

        // 构建结果列表
        List<SupplierDataDownVO> result = new ArrayList<>();
        for (TDeptSuppler suppler : supplierMap.values()) {
            SupplierDataDownVO vo = new SupplierDataDownVO();
            vo.setName(suppler.getName());
            vo.setContactPerson(suppler.getContactPerson());
            vo.setContactPhone(suppler.getContactPhone());
            vo.setDocumentType(String.valueOf(suppler.getTypeDocument()));
            vo.setImg(suppler.getFrontOfBusinessLicense() + "," + suppler.getBackOfBusinessLicense());
            result.add(vo);
        }
        PageInfo<SupplierDataDownVO> pageInfo = new PageInfo<>(result);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }

    @Override
    public List<SecurityRankingVO> getSecurityRanking(SummaryQuery query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            // 超级管理员：查询所有有效的主体
            authDeptIds = deptService.selectAllDepts();
        } else {
            // 普常用户：根据角色权限获取
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 过滤出标签为"学校"（deptLevel="1"）的有效主体
        List<SysDept> schools = sysDeptMapper.selectBatchIdsList(authDeptIds)
                .stream()
                .filter(dept -> "1".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus() ))
                .collect(Collectors.toList());

        if (schools.isEmpty()) {
            return Collections.emptyList();
        }

        // 获取每个学校的子食堂（标签为"4"的部门）
        Map<Long, List<Long>> schoolToCanteens = new HashMap<>();
        for (SysDept school : schools) {
            List<SysDept> canteens = sysDeptMapper.selectChildrenDeptById(school.getDeptId());
            List<Long> canteenIds = canteens.stream()
                    .filter(dept -> "4".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus()))
                    .map(SysDept::getDeptId)
                    .collect(Collectors.toList());
            schoolToCanteens.put(school.getDeptId(), canteenIds);
        }
        // 3. 设置查询条件：只查当天
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date todayStart = calendar.getTime();

        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        Date todayEnd = calendar.getTime();

        // 判断哪些学校当天是运营的
        List<Long> operatingSchoolIds = new ArrayList<>();
        for (Map.Entry<Long, List<Long>> entry : schoolToCanteens.entrySet()) {
            Long schoolId = entry.getKey();
            List<Long> canteenIds = entry.getValue();

            boolean isOperating = false;
            for (Long canteenId : canteenIds) {
                // 查询该食堂当天是否有运营配置（早餐/午餐/晚餐任一为1）
                TCalendarInfoQuery tCalendarInfoQuery = new TCalendarInfoQuery();
                tCalendarInfoQuery.setDeptId(canteenId);
                tCalendarInfoQuery.setDate(query.getStartDate() == null ? String.valueOf(todayStart) : DateUtils.formatDate(query.getStartDate()));
                tCalendarInfoQuery.setDelFlag("0");

                List<TCalendarInfoQuery> infos = tCalendarInfoMapper.selectTCalendarInfoList(tCalendarInfoQuery);
                if (!infos.isEmpty()) {
                    for (TCalendarInfoQuery info : infos) {
                        if (info.getBreakfast() == 1 || info.getLunch() == 1 || info.getDinner() == 1) {
                            isOperating = true;
                            break;
                        }
                    }
                } else {
                    // 没有配置数据，则默认运营
                    isOperating = true;
                    break;
                }
            }

            if (isOperating) {
                operatingSchoolIds.add(schoolId);
            }
        }

        // 如果没有运营的学校，返回空
        if (operatingSchoolIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 计算每个运营学校的综合得分（调用周汇总接口）
        List<SecurityRankingVO> rankingList = new ArrayList<>();
        for (Long schoolId : operatingSchoolIds) {
            // 获取该学校下的所有下级主体（标签为"4"的部门）
            List<SysDept> allSubDepts = sysDeptMapper.selectChildrenDeptById(schoolId);

            // 过滤出有效的食堂（标签为"4"）
            List<Long> canteenIds = allSubDepts.stream()
                    .filter(dept -> "4".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus()))
                    .map(SysDept::getDeptId)
                    .collect(Collectors.toList());
            // 构造查询条件：只查这个学校下的食堂
            SummaryQuery schoolQuery = new SummaryQuery();
            schoolQuery.setStartDate(query.getStartDate() == null ? todayStart : query.getStartDate());
            schoolQuery.setEndDate(query.getEndDate() == null ? todayEnd : query.getEndDate());
            schoolQuery.setDeptIds(schoolToCanteens.get(schoolId));

            // 调用周汇总接口获取所有模块得分
            Map<String, Object> weeklySummary = collectService.getWeeklySummary(schoolQuery);

            // 计算总分：遍历所有模块，累加得分
            double totalScore = 0.0;
            for (Map.Entry<String, Object> entry : weeklySummary.entrySet()) {
                if (entry.getValue() instanceof SummaryItemDTO) {
                    SummaryItemDTO item = (SummaryItemDTO) entry.getValue();
                    totalScore += item.getFinalScore().doubleValue();
                } else if (entry.getValue() instanceof FoodSampleDTO) {
                    FoodSampleDTO sample = (FoodSampleDTO) entry.getValue();
                    totalScore += sample.getFinalScore().doubleValue();
                }
            }

            // 获取学校名称
            SysDept school = schools.stream()
                    .filter(d -> d.getDeptId().equals(schoolId))
                    .findFirst()
                    .orElse(null);


            if (school != null) {
                rankingList.add(new SecurityRankingVO(school.getDeptName(), totalScore, school.getDeptId(), school.getDeptLevel(),canteenIds));
            }
        }

        // 按总分降序排序，得分相同按名称升序
        rankingList.sort((a, b) -> {
            if (Double.compare(b.getTotalScore(), a.getTotalScore()) != 0) {
                return Double.compare(b.getTotalScore(), a.getTotalScore());
            }
            return a.getSchoolName().compareTo(b.getSchoolName());
        });

        return rankingList;
    }


    @Override
    public List<RealTimeControlItemVO> getRealTimeControl(SummaryQuery query) throws ParseException {
        // 1. 获取当前用户权限内的所有有效主体（标签为"4"的学校食堂）
        List<Long> deptIds = getValidSchoolCanteens(query);

        if (deptIds == null || deptIds.isEmpty()) {
            return Collections.emptyList();
        }
        query.setDeptIds(deptIds);
        // 2. 过滤出当天运营的主体（至少有一餐运营）
        List<Long> operatingDepts = getOperatingDeptsToday(query);

        if (operatingDepts.isEmpty()) {
            return createDefaultRealTimeControlData();
        }

        // 3. 设置查询条件：只查当天
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        Date todayStart = calendar.getTime();

        calendar.set(Calendar.HOUR_OF_DAY, 23);
        calendar.set(Calendar.MINUTE, 59);
        calendar.set(Calendar.SECOND, 59);
        Date todayEnd = calendar.getTime();


        query.setStartDate(todayStart);
        query.setEndDate(todayEnd);
        query.setDeptIds(operatingDepts);

        // 4. 调用 ICollectService 各模块方法获取执行率
        List<RealTimeControlItemVO> items = new ArrayList<>();
        // 员工日检
        SummaryItemDTO employee = collectService.getEmployeeDailyCheckSummary(query);
        items.add(new RealTimeControlItemVO(
                "员工日检",
                employee.getExecutionRate(),
                employee.getShouldDo(),
                employee.getDone(),
                employee.getNotDone()
        ));

        // 常规日检
        SummaryItemDTO routine = collectService.getRoutineInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "常规日检",
                routine.getExecutionRate(),
                routine.getShouldDo(),
                routine.getDone(),
                routine.getNotDone()
        ));

        // 日常快检
        SummaryItemDTO quickCheck = collectService.getQuickCheckSummary(query);
        items.add(new RealTimeControlItemVO(
                "日常快检",
                quickCheck.getExecutionRate(),
                quickCheck.getShouldDo(),
                quickCheck.getDone(),
                quickCheck.getNotDone()
        ));
        // 日常抽检
        SummaryItemDTO randomInspection = collectService.getRandomInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "日常抽检",
                randomInspection.getExecutionRate(),
                randomInspection.getShouldDo(),
                randomInspection.getDone(),
                randomInspection.getNotDone()
        ));

        // 餐饮具消毒
        SummaryItemDTO tableware = collectService.getTablewareDisinfectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "餐饮具消毒",
                tableware.getExecutionRate(),
                tableware.getShouldDo(),
                tableware.getDone(),
                tableware.getNotDone()
        ));
        // 场所设备消毒
        SummaryItemDTO equipment = collectService.getEquipmentDisinfectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "场所设备消毒",
                equipment.getExecutionRate(),
                equipment.getShouldDo(),
                equipment.getDone(),
                equipment.getNotDone()
        ));

        // 垃圾消毒
        SummaryItemDTO garbage = collectService.getGarbageDisinfectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "垃圾消毒",
                garbage.getExecutionRate(),
                garbage.getShouldDo(),
                garbage.getDone(),
                garbage.getNotDone()
        ));

        // 库房贮藏巡检
        SummaryItemDTO storage = collectService.getStorageInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "库房贮藏巡检",
                storage.getExecutionRate(),
                storage.getShouldDo(),
                storage.getDone(),
                storage.getNotDone()
        ));

        // 设备设施巡检
        SummaryItemDTO facility = collectService.getFacilityInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "食堂设施巡检",
                facility.getExecutionRate(),
                facility.getShouldDo(),
                facility.getDone(),
                facility.getNotDone()
        ));

        // 场所环境巡检
        SummaryItemDTO environment = collectService.getEnvironmentInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "场所环境巡检",
                environment.getExecutionRate(),
                environment.getShouldDo(),
                environment.getDone(),
                environment.getNotDone()
        ));
        // 食品加工制作过程巡检
        SummaryItemDTO foodProcess = collectService.getFoodProcessInspectionSummary(query);
        items.add(new RealTimeControlItemVO(
                "食品加工制作过程巡检",
                foodProcess.getExecutionRate(),
                foodProcess.getShouldDo(),
                foodProcess.getDone(),
                foodProcess.getNotDone()
        ));
        // 每日食谱
        SummaryItemDTO foodMenu = collectService.getFoodMenuSummary(query);
        items.add(new RealTimeControlItemVO(
                "每日食谱",
                foodMenu.getExecutionRate(),
                foodMenu.getShouldDo(),
                foodMenu.getDone(),
                foodMenu.getNotDone()
        ));
        // 日常留样
        FoodSampleDTO foodSampleSummary = collectService.getFoodSampleSummary(query);
        items.add(new RealTimeControlItemVO(
                "日常留样",
                foodSampleSummary.getExecutionRate(),
                foodSampleSummary.getShouldSample(),
                foodSampleSummary.getSampled(),
                foodSampleSummary.getNotSampled()
        ));
        // 日常试尝
        SummaryItemDTO foodTasting = collectService.getFoodTastingSummary(query);
        items.add(new RealTimeControlItemVO(
                "日常试尝",
                foodTasting.getExecutionRate(),
                foodTasting.getShouldDo(),
                foodTasting.getDone(),
                foodTasting.getNotDone()
        ));
        //就餐人数
        SummaryItemDTO dinerCount = collectService.getDinerCountSummary(query);
        items.add(new RealTimeControlItemVO(
                "就餐人数",
                dinerCount.getExecutionRate(),
                dinerCount.getShouldDo(),
                dinerCount.getDone(),
                dinerCount.getNotDone()
        ));
        // 餐厨垃圾
        SummaryItemDTO kitchenWaste = collectService.getKitchenWasteSummary(query);
        items.add(new RealTimeControlItemVO(
                "餐厨垃圾",
                kitchenWaste.getExecutionRate(),
                kitchenWaste.getShouldDo(),
                kitchenWaste.getDone(),
                kitchenWaste.getNotDone()
        ));

        return items;
    }


    // 新增私有方法：创建默认的实时控制数据（全为0）
    private List<RealTimeControlItemVO> createDefaultRealTimeControlData() {
        return Arrays.asList(
                new RealTimeControlItemVO("员工日检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("常规日检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("日常快检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("日常抽检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("餐饮具消毒", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("场所设备消毒", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("垃圾消毒", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("库房贮藏巡检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("食堂设施巡检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("场所环境巡检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("食品加工制作过程巡检", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("每日食谱", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("日常留样", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("日常试尝", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("就餐人数", BigDecimal.ZERO, 0, 0, 0),
                new RealTimeControlItemVO("餐厨垃圾", BigDecimal.ZERO, 0, 0, 0)
        );
    }

    private List<Long> getValidSchoolCanteens(SummaryQuery query) {
        if (ObjectUtils.isNotEmpty(query.getDeptIds())) {
            return query.getDeptIds();
        }

        // 获取当前登录用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        List<Long> deptIds = new ArrayList<>();
        if (isSystemAdmin) {
            deptIds = deptService.selectAllDepts();
        } else {
            for (SysRole role : roles) {
                List<Long> roleDepts = deptService.selectDeptListByRoleId(role.getRoleId());
                deptIds.addAll(roleDepts);
            }
            deptIds = deptIds.stream().distinct().collect(Collectors.toList());
        }

        // 过滤出标签为"4"的学校食堂
        List<SysDept> depts = sysDeptMapper.selectBatchIdsList(deptIds);
        return depts.stream()
                .filter(dept -> "4".equals(dept.getDeptLevel()))
                .map(SysDept::getDeptId)
                .collect(Collectors.toList());
    }

    private List<Long> getOperatingDeptsToday(SummaryQuery query) {
        Date today = new Date();
        String todayStr = new SimpleDateFormat("yyyy-MM-dd").format(today);

        // 获取查询的部门ID列表，如果是null则初始化为空列表避免NPE
        List<Long> deptIdsToUse = query.getDeptIds() != null ? query.getDeptIds() : new ArrayList<>();

        // 查询今天有至少一餐运营的食堂
        List<Map<String, Object>> results = tCalendarInfoMapper.selectOperatingDeptsToday(todayStr, deptIdsToUse);

        Set<Long> operatingDepts = new HashSet<>();

        // 如果查询结果为空，表示没有配置数据，默认全部运营
        if (results.isEmpty()) {
            // 返回所有有效食堂（即 query.getDeptIds()中的ID）
            operatingDepts.addAll(deptIdsToUse);
        } else {
            // 如果有数据，则只取三餐至少一餐为1的食堂
            for (Map<String, Object> row : results) {
                Object deptIdObj = row.get("deptId");
                if (deptIdObj != null && deptIdObj instanceof Number) {
                    Long deptId = ((Number) deptIdObj).longValue();
                    operatingDepts.add(deptId);
                }
            }
        }

        return new ArrayList<>(operatingDepts);
    }


    // FigureLargeServiceImpl.java
    @Override
    public List<AlarmStatisticsVO> getAlarmStatistics(SummaryQuery query) {
        // 获取当前登录用户 ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体 ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 设置查询条件
        Date todayStart = new Date();
        Date todayEnd = addDays(todayStart, 1);
        TAlarmQuery tAlarmQuery = new TAlarmQuery();
        tAlarmQuery.setStartTime(query.getStartDate() == null ? todayStart : query.getStartDate());
        tAlarmQuery.setEndTime(query.getEndDate() == null ? todayEnd : query.getEndDate());
        tAlarmQuery.setDeptIds(authDeptIds);

        // 查询所有符合条件的预警
        List<TAlarmQuery> alarms = tAlarmMapper.selectTAlarmListByDeptIds(tAlarmQuery);

        // 初始化八大类统计结果，初始值为 0
        Map<String, Integer> categoryStats = new HashMap<>();
        categoryStats.put("无证预警", 0);
        categoryStats.put("日常检查预警", 0);
        categoryStats.put("日常消毒预警", 0);
        categoryStats.put("日常巡检预警", 0);
        categoryStats.put("每日就餐预警", 0);
        categoryStats.put("食材验收预警", 0);
        categoryStats.put("AI 抓拍预警", 0);
        categoryStats.put("其他预警", 0);
        if (ObjectUtils.isNotEmpty(alarms)) {
            for (TAlarmQuery alarm : alarms) {
                String type = alarm.getType();
                int typeId = Integer.parseInt(type);

                switch (typeId) {
                    case 20:
                    case 21:
                    case 22:
                        categoryStats.put("无证预警", categoryStats.get("无证预警") + 1);
                        break;
                    case 2:
                    case 3:
                    case 15:
                    case 16:
                    case 17:
                    case 18:
                    case 29:
                        categoryStats.put("日常检查预警", categoryStats.get("日常检查预警") + 1);
                        break;
                    case 30:
                    case 31:
                    case 32:
                        categoryStats.put("日常消毒预警", categoryStats.get("日常消毒预警") + 1);
                        break;
                    case 4:
                    case 5:
                    case 6:
                    case 7:
                    case 33:
                    case 34:
                    case 35:
                    case 36:
                        categoryStats.put("日常巡检预警", categoryStats.get("日常巡检预警") + 1);
                        break;
                    case 0:
                    case 1:
                    case 25:
                    case 26:
                    case 27:
                    case 28:
                    case 37:
                        categoryStats.put("每日就餐预警", categoryStats.get("每日就餐预警") + 1);
                        break;
                    case 8:
                        categoryStats.put("食材验收预警", categoryStats.get("食材验收预警") + 1);
                        break;
                    case 38:
                    case 39:
                    case 40:
                    case 41:
                    case 42:
                        categoryStats.put("AI 抓拍预警", categoryStats.get("AI 抓拍预警") + 1);
                        break;
                    case 9:
                    case 10:
                    case 19:
                    case 23:
                    case 24:
                        categoryStats.put("其他预警", categoryStats.get("其他预警") + 1);
                        break;
                }
            }
        }

        // 转化为 VO 列表
        List<AlarmStatisticsVO> result = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : categoryStats.entrySet()) {
            result.add(new AlarmStatisticsVO(entry.getKey(), entry.getValue()));
        }

        // 按数量降序排序（数量多的排在前面）
        result.sort((a, b) -> Integer.compare(b.getCount(), a.getCount()));

        return result;
    }

    @Override
    public PageResult<TAlarmQuery> getAlarmDetails(Integer pageNum, Integer pageSize, TAlarmQuery query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0);
        }
        query.setDeptIds(query.getDeptIds() == null ? authDeptIds : query.getDeptIds());
        PageHelper.startPage(pageNum, pageSize);
        // 查询所有符合条件的预警
        List<TAlarmQuery> list = tAlarmMapper.selectTAlarmListByDeptIds(query);

        PageInfo<TAlarmQuery> pageInfo = new PageInfo<>(list);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }

    @Override
    public List<TAlarmQuery> getAlarm(SummaryQuery query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 设置查询条件
        Date todayStart = new Date();
        Date todayEnd = addDays(todayStart, 1); // 明天凌晨
        TAlarmQuery tAlarmQuery = new TAlarmQuery();
        tAlarmQuery.setStartTime(query.getStartDate() == null ? todayStart : query.getStartDate());
        tAlarmQuery.setEndTime(query.getEndDate() == null ? todayEnd : query.getEndDate());
        tAlarmQuery.setDelFlag(0);
        tAlarmQuery.setDeptIds(authDeptIds);

        // 查询所有符合条件的预警
        return tAlarmMapper.selectTAlarmListByDeptIds(tAlarmQuery);
    }


    @Override
    public List<SupplyChainAnalysisVO> getSupplyChainAnalysis(SummaryQuery query) {
        // 获取当前用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 查询权限范围内有效的供应商，按 businessCode 去重
        List<TDeptSuppler> validSupplers = tDeptSupplerMapper.selectValidSupplersByDeptIds(authDeptIds);

        // 按 businessCode 分组，获取唯一供应商
        Map<String, TDeptSuppler> supplierMap = validSupplers.stream()
                .collect(Collectors.toMap(TDeptSuppler::getBusinessCode, Function.identity(), (e1, e2) -> e1));

        // 构建结果列表
        List<SupplyChainAnalysisVO> result = new ArrayList<>();

        for (TDeptSuppler suppler : supplierMap.values()) {
            SupplyChainAnalysisVO vo = new SupplyChainAnalysisVO();
            vo.setName(suppler.getName());

            // 统计该供应商在权限范围内覆盖的主体数量
            int schoolCount = tDeptSupplerMapper.countSchoolsBySupplierAndDeptIds(suppler.getId(), authDeptIds);
            vo.setSchoolCount(schoolCount);

            // 设置查询条件
            Date todayStart = new Date();
            Date todayEnd = addDays(todayStart, 1); // 明天凌晨
            int orderCount = tNewProcurementMapper.countOrdersBySupplierAndDate(suppler.getId(), todayStart, todayEnd);
            vo.setOrderCount(orderCount);

            result.add(vo);
        }

        return result;
    }


    @Override
    public List<DinerRateAnalysisVO> getDinerRateAnalysis(SummaryQuery query) {
        // 获取当前用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 设置查询条件
        Date todayStart = new Date();
        Date todayEnd = addDays(todayStart, 1); // 明天凌晨

        // 查询当天各主体的就餐数据
        List<TDayNumberDinersQuery> dinerList = tDayNumberDinersMapper.selectDinerDataByDateAndDeptIds(todayStart, todayEnd, authDeptIds);

        // 构建结果列表
        List<DinerRateAnalysisVO> result = new ArrayList<>();
        for (TDayNumberDinersQuery diner : dinerList) {
            DinerRateAnalysisVO vo = new DinerRateAnalysisVO();
            vo.setDeptName(diner.getDeptName());
            vo.setExpectedTotal(diner.getExpectedTotal());
            vo.setActualTotal(diner.getActualTotal());

            // 计算入口率
            if (diner.getExpectedTotal() != null && diner.getExpectedTotal() > 0) {
                double rate = ((double) diner.getActualTotal()) / diner.getExpectedTotal() * 100;
                vo.setEntryRate(Math.round(rate * 100.0) / 100.0); // 保留两位小数
            } else {
                vo.setEntryRate(0.0);
            }

            result.add(vo);
        }

        return result;
    }

    @Override
    public InvoiceStatusVO getInvoiceStatus(SummaryQuery query) {
        Long userId = SecurityUtils.getUserId();
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new InvoiceStatusVO(0, 0, 0);
        }


        // 查询当天所有验收记录总数（A）
        int total = tNewProcurementAcceptanceMapper.countAcceptancesByDateAndDeptIds(authDeptIds);

        // 查询当天索票索证为空的记录数（B）
        int notUploaded = tNewProcurementAcceptanceMapper.countAcceptancesWithEmptyTickets(authDeptIds);

        // 查询当天索票索证不为空的记录数（C）

        int uploaded = tNewProcurementAcceptanceMapper.countAcceptancesWithTickets(authDeptIds);

        return new InvoiceStatusVO(total, uploaded, notUploaded);
    }


    @Override
    public PageResult<InvoiceUploadedVO> getInvoiceUploadedDown(Integer pageNum, Integer pageSize, InvoiceUploadedVO query) {
        Long userId = SecurityUtils.getUserId();
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        List<Long> authDeptIds;
        if (isSystemAdmin) {
            authDeptIds = deptService.selectAllDepts();
        } else {
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return new PageResult<>(Collections.emptyList(), 0);
        }

        PageHelper.startPage(pageNum, pageSize);

        List<InvoiceUploadedVO> list = tNewProcurementAcceptanceMapper.selectInvoiceUploadedDown(authDeptIds, query);
        PageInfo<InvoiceUploadedVO> pageInfo = new PageInfo<>(list);
        return new PageResult<>(pageInfo.getList(), pageInfo.getTotal());
    }

    @Override
    public List<MapVO> getMap(SummaryQuery query) {
        // 获取当前登录用户ID
        Long userId = SecurityUtils.getUserId();

        // 获取当前用户的角色
        List<SysRole> roles = roleMapper.selectRolePermissionByUserId(SecurityUtils.getLoginUser().getUser().getUserId());
        boolean isSystemAdmin = roles.stream().anyMatch(role -> "admin".equals(role.getRoleKey()));

        // 获取当前用户权限下的所有有效主体ID（部门）
        List<Long> authDeptIds;
        if (isSystemAdmin) {
            // 超级管理员：查询所有有效的主体
            authDeptIds = deptService.selectAllDepts();
        } else {
            // 普常用户：根据角色权限获取
            authDeptIds = sysRoleDeptMapper.selectAuthDeptIdsByUserId(userId);
        }

        if (authDeptIds.isEmpty()) {
            return Collections.emptyList();
        }

        // 过滤出标签为"学校"（deptLevel="1"）的有效主体
        List<SysDept> schools = sysDeptMapper.selectBatchIdsList(authDeptIds)
                .stream()
                .filter(dept -> "1".equals(dept.getDeptLevel()) && "0".equals(dept.getStatus()))
                .collect(Collectors.toList());

        if (schools.isEmpty()) {
            return Collections.emptyList();
        }

        return schools.stream()
                .map(school -> {
                    MapVO mapVO = new MapVO();
                    mapVO.setId(school.getDeptId());
                    mapVO.setName(school.getDeptName());
                    mapVO.setLongitude(school.getLongitude());
                    mapVO.setLatitude(school.getLatitude());
                    mapVO.setDeptType(school.getDeptType());
                    mapVO.setDeptLevel(school.getDeptLevel());
                    return mapVO;
                })
                .collect(Collectors.toList());
    }
}
