package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TRegulationsSupHandle;
import com.fyzs.web.service.ITRegulationsSupHandleService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规监管部门地方催办信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/sup/handle")
public class TRegulationsSupHandleController extends BaseController
{

    private final ITRegulationsSupHandleService tRegulationsSupHandleService;

    /**
     * 查询违法违规监管部门地方催办信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:list')")
    @GetMapping("/list")
    public TableDataInfo list(TRegulationsSupHandle tRegulationsSupHandle)
    {
        startPage();
        List<TRegulationsSupHandle> list = tRegulationsSupHandleService.selectTRegulationsSupHandleList(tRegulationsSupHandle);
        return getDataTable(list);
    }

    /**
     * 导出违法违规监管部门地方催办信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:export')")
    @Log(title = "违法违规监管部门地方催办信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TRegulationsSupHandle tRegulationsSupHandle)
    {
        List<TRegulationsSupHandle> list = tRegulationsSupHandleService.selectTRegulationsSupHandleList(tRegulationsSupHandle);
        ExcelUtil<TRegulationsSupHandle> util = new ExcelUtil<TRegulationsSupHandle>(TRegulationsSupHandle.class);
        util.exportExcel(response, list, "违法违规监管部门地方催办信息数据");
    }

    /**
     * 获取违法违规监管部门地方催办信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tRegulationsSupHandleService.selectTRegulationsSupHandleById(id));
    }

    /**
     * 新增违法违规监管部门地方催办信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:add')")
    @Log(title = "违法违规监管部门地方催办信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TRegulationsSupHandle tRegulationsSupHandle)
    {
        return toAjax(tRegulationsSupHandleService.save(tRegulationsSupHandle));
    }

    /**
     * 修改违法违规监管部门地方催办信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:edit')")
    @Log(title = "违法违规监管部门地方催办信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TRegulationsSupHandle tRegulationsSupHandle)
    {
        return toAjax(tRegulationsSupHandleService.updateById(tRegulationsSupHandle));
    }

    /**
     * 删除违法违规监管部门地方催办信息
     */
    //@PreAuthorize("@ss.hasPermi('web:handle:remove')")
    @Log(title = "违法违规监管部门地方催办信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tRegulationsSupHandleService.deleteTRegulationsSupHandleByIds(ids));
    }
}
