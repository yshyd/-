package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TMonthPlan;
import com.fyzs.web.entity.query.TMonthPlanQuery;

/**
 * 食安监管-月调度-月计划Service接口
 * 
 * @author ysh
 * @date 2025-12-02
 */
public interface ITMonthPlanService extends IService<TMonthPlan>
{
    /**
     * 查询食安监管-月调度-月计划
     * 
     * @param id 食安监管-月调度-月计划主键
     * @return 食安监管-月调度-月计划
     */
    public TMonthPlanQuery selectTMonthPlanById(Long id);

    /**
     * 查询食安监管-月调度-月计划列表
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 食安监管-月调度-月计划集合
     */
    public List<TMonthPlanQuery> selectTMonthPlanList(TMonthPlanQuery tMonthPlan);

    /**
     * 新增食安监管-月调度-月计划
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 结果
     */
    public int insertTMonthPlan(TMonthPlan tMonthPlan);

    /**
     * 修改食安监管-月调度-月计划
     * 
     * @param tMonthPlan 食安监管-月调度-月计划
     * @return 结果
     */
    public int updateTMonthPlan(TMonthPlan tMonthPlan);

    /**
     * 批量删除食安监管-月调度-月计划
     * 
     * @param ids 需要删除的食安监管-月调度-月计划主键集合
     * @return 结果
     */
    public int deleteTMonthPlanByIds(Long[] ids);

    /**
     * 删除食安监管-月调度-月计划信息
     * 
     * @param id 食安监管-月调度-月计划主键
     * @return 结果
     */
    public int deleteTMonthPlanById(Long id);
}
