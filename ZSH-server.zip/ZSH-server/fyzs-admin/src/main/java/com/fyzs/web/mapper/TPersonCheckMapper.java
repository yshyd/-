package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fyzs.web.entity.TPersonCheck;
import com.fyzs.web.entity.query.TPersonCheckQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * 食堂人员日检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-19
 */
@Mapper
public interface TPersonCheckMapper  extends BaseMapper<TPersonCheck> {
    /**
     * 查询食堂人员日检
     *
     * @param id 食堂人员日检主键
     * @return 食堂人员日检
     */
    public TPersonCheckQuery selectTPersonCheckById(Long id);

    /**
     * 查询食堂人员日检列表
     *
     * @return 食堂人员日检集合
     */
    public List<TPersonCheckQuery> selectTPersonCheckList(TPersonCheckQuery query);

    /**
     * 新增食堂人员日检
     *
     * @param tPersonCheck 食堂人员日检
     * @return 结果
     */
    public int insertTPersonCheck(TPersonCheck tPersonCheck);

    /**
     * 修改食堂人员日检
     *
     * @param tPersonCheck 食堂人员日检
     * @return 结果
     */
    public int updateTPersonCheck(TPersonCheck tPersonCheck);

    /**
     * 删除食堂人员日检
     *
     * @param id 食堂人员日检主键
     * @return 结果
     */
    public int deleteTPersonCheckById(Long id);

    /**
     * 批量删除食堂人员日检
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTPersonCheckByIds(Long[] ids);


    // 统计活跃员工数量（未请假的工勤人员）
    int countActiveStaff(@Param("startDate") Date startDate,
                         @Param("endDate") Date endDate, @Param("deptIds") List<Long> deptIds);

    // 获取平均每日运营餐次
    int getAverageMealTimes(@Param("deptIds") List<Long> deptIds);

    // 统计已完成的检查数量
    int countCompletedChecks(@Param("startDate") Date startDate,
                             @Param("endDate") Date endDate,
                             @Param("deptIds") List<Long> deptIds);

    // 统计正常检查数量
    int countNormalChecks(@Param("startDate") Date startDate,
                          @Param("endDate") Date endDate,
                          @Param("deptIds") List<Long> deptIds);

    // 获取指定日期各主体未请假且需要日检的工勤人员数量
    List<Map<String, Object>> getActiveStaffCountForDate(@Param("date") Date date, @Param("endDate") Date endDate, @Param("deptIds") List<Long> deptIds);

    /**
     * 统计已完成的检查数量（按人员去重）
     *
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @param personIds 工勤人员 ID 列表
     * @return 已完成的检查数量（同一人员同一天只算 1 次）
     */
    int countCompletedChecksWithPersonIds(@Param("startDate") Date startDate,
                                          @Param("endDate") Date endDate,
                                          @Param("personIds") List<Long> personIds);

    /**
     * 统计正常检查数量（按人员 ID 统计）
     *
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @param personIds 工勤人员 ID 列表
     * @return 正常检查数量
     */
    int countNormalChecksWithPersonIds(@Param("startDate") Date startDate,
                                       @Param("endDate") Date endDate,
                                       @Param("personIds") List<Long> personIds);
    /**
     * 统计异常检查数量（按人员 ID 统计）
     *
     * @param startDate 开始日期
     * @param endDate   结束日期
     * @param personIds 工勤人员 ID 列表
     * @return 正常检查数量
     */
    int countAbnormalChecksWithPersonIds(@Param("startDate") Date startDate,
                                       @Param("endDate") Date endDate,
                                       @Param("personIds") List<Long> personIds);


}
