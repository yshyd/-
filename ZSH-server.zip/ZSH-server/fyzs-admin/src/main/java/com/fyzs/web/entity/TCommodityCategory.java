package com.fyzs.web.entity;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 商品分类对象 t_commodity_category
 *
 * @author ysh
 * @date 2025-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_commodity_category")
public class TCommodityCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String name;

    /**
     * 营养分析系统中的类别名称
     */
    @Schema(description = "营养分析系统中的类别名称")
    @Excel(name = "营养分析系统中的类别名称")
    private String nutritionName;

    /**
     * 状态【1禁用，0启用】
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "状态【1禁用，0启用】")
    private Integer delFlag;

    /**
     * 创建人id
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人id")
    @Excel(name = "创建人id")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

}
