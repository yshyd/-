package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TTrainingRecordQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TTrainingRecord;
import com.fyzs.web.service.ITTrainingRecordService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 工勤人员培训记录Controller
 * 
 * @author ysh
 * @date 2025-12-02
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/train/record")
public class TTrainingRecordController extends BaseController
{

    private final ITTrainingRecordService tTrainingRecordService;

    /**
     * 查询工勤人员培训记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:record:list')")
    @GetMapping("/list")
    public TableDataInfo list(TTrainingRecordQuery tTrainingRecord)
    {
        startPage();
        List<TTrainingRecordQuery> list = tTrainingRecordService.selectTTrainingRecordList(tTrainingRecord);
        return getDataTable(list);
    }

    /**
     * 导出工勤人员培训记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:record:export')")
    @Log(title = "工勤人员培训记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TTrainingRecordQuery tTrainingRecord)
    {
        List<TTrainingRecordQuery> list = tTrainingRecordService.selectTTrainingRecordList(tTrainingRecord);
        ExcelUtil<TTrainingRecordQuery> util = new ExcelUtil<TTrainingRecordQuery>(TTrainingRecordQuery.class);
        util.exportExcel(response, list, "工勤人员培训记录数据");
    }

    /**
     * 获取工勤人员培训记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:record:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tTrainingRecordService.selectTTrainingRecordById(id));
    }

    /**
     * 新增工勤人员培训记录
     */
    //@PreAuthorize("@ss.hasPermi('web:record:add')")
    @Log(title = "工勤人员培训记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TTrainingRecord tTrainingRecord)
    {
        tTrainingRecord.setDelFlag(0);
        return toAjax(tTrainingRecordService.save(tTrainingRecord));
    }

    /**
     * 修改工勤人员培训记录
     */
    //@PreAuthorize("@ss.hasPermi('web:record:edit')")
    @Log(title = "工勤人员培训记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TTrainingRecord tTrainingRecord)
    {
        return toAjax(tTrainingRecordService.updateById(tTrainingRecord));
    }

    /**
     * 删除工勤人员培训记录
     */
    //@PreAuthorize("@ss.hasPermi('web:record:remove')")
    @Log(title = "工勤人员培训记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tTrainingRecordService.deleteTTrainingRecordByIds(ids));
    }
}
