package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TAnnouncementItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TAnnouncementItemDTO extends TAnnouncementItem {
}
