package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * 食材消耗大数据分析结果VO
 */
@Data
@Schema(description = "食材消耗大数据分析结果")
public class FoodConsumptionAnalysisVO {

    @Schema(description = "学校数量(A)")
    private Long schoolCount;

    @Schema(description = "参与评估的学校名称列表")
    private List<String> schoolNames;

    @Schema(description = "各品类食材总消耗量(B1...Bn)")
    private Map<String, BigDecimal> categoryTotals;

    @Schema(description = "各品类食材人均消耗量(C1...Cn = B1/A ... Bn/A)")
    private Map<String, BigDecimal> perCapitaConsumptions;

    @Schema(description = "评估开始日期")
    private String startDate;

    @Schema(description = "评估结束日期")
    private String endDate;
}