package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;


import com.fyzs.web.entity.query.TCanteenPractitionersQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCanteenPractitioners;
import com.fyzs.web.service.ITCanteenPractitionersService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食堂人员基础信息Controller
 * 
 * @author ysh
 * @date 2025-10-26
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/practitioners")
public class TCanteenPractitionersController extends BaseController
{

    private final ITCanteenPractitionersService tCanteenPractitionersService;

    /**
     * 查询食堂人员基础信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCanteenPractitionersQuery tCanteenPractitioners)
    {
        startPage();
        List<TCanteenPractitionersQuery> list = tCanteenPractitionersService.selectTCanteenPractitionersList(tCanteenPractitioners);
        return getDataTable(list);
    }

    /**
     * 查询食堂人员基础信息列表(下拉)
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TCanteenPractitionersQuery tCanteenPractitioners)
    {
        List<TCanteenPractitionersQuery> list = tCanteenPractitionersService.selectTCanteenPractitionersList(tCanteenPractitioners);
        return getDataTable(list);
    }

    /**
     * 导出食堂人员基础信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:export')")
    @Log(title = "食堂人员基础信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCanteenPractitionersQuery tCanteenPractitioners)
    {
        List<TCanteenPractitionersQuery> list = tCanteenPractitionersService.selectTCanteenPractitionersList(tCanteenPractitioners);
        ExcelUtil<TCanteenPractitionersQuery> util = new ExcelUtil<TCanteenPractitionersQuery>(TCanteenPractitionersQuery.class);
        util.exportExcel(response, list, "食堂人员基础信息数据");
    }

    /**
     * 获取食堂人员基础信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCanteenPractitionersService.selectTCanteenPractitionersById(id));
    }

    /**
     * 新增食堂人员基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:add')")
    @Log(title = "食堂人员基础信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCanteenPractitioners tCanteenPractitioners)
    {
        return toAjax(tCanteenPractitionersService.insertTCanteenPractitioners(tCanteenPractitioners));
    }

    /**
     * 修改食堂人员基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:edit')")
    @Log(title = "食堂人员基础信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCanteenPractitioners tCanteenPractitioners)
    {
        return toAjax(tCanteenPractitionersService.updateTCanteenPractitioners(tCanteenPractitioners));
    }

    /**
     * 删除食堂人员基础信息
     */
    //@PreAuthorize("@ss.hasPermi('web:practitioners:remove')")
    @Log(title = "食堂人员基础信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCanteenPractitionersService.deleteTCanteenPractitionersByIds(ids));
    }
}
