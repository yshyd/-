package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TReferencePrice;
import com.fyzs.web.entity.query.TReferencePriceQuery;
import com.fyzs.web.entity.vo.TReferencePriceVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 食材标准参考价发布记录主Mapper接口
 * 
 * @author ysh
 * @date 2025-11-24
 */
@Mapper
public interface TReferencePriceMapper  extends BaseMapper<TReferencePrice>
{
    /**
     * 查询食材标准参考价发布记录主
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 食材标准参考价发布记录主
     */
    public TReferencePriceVO selectTReferencePriceById(Long id);

    /**
     * 查询食材标准参考价发布记录主列表
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 食材标准参考价发布记录主集合
     */
    public List<TReferencePriceQuery> selectTReferencePriceList(TReferencePriceQuery tReferencePrice);

    /**
     * 新增食材标准参考价发布记录主
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 结果
     */
    public int insertTReferencePrice(TReferencePrice tReferencePrice);

    /**
     * 修改食材标准参考价发布记录主
     * 
     * @param tReferencePrice 食材标准参考价发布记录主
     * @return 结果
     */
    public int updateTReferencePrice(TReferencePrice tReferencePrice);

    /**
     * 删除食材标准参考价发布记录主
     * 
     * @param id 食材标准参考价发布记录主主键
     * @return 结果
     */
    public int deleteTReferencePriceById(Long id);

    /**
     * 批量删除食材标准参考价发布记录主
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTReferencePriceByIds(Long[] ids);
}
