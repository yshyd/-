package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class SummaryQuery  implements Serializable {
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date startDate;           // 开始日期
    @JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
    private Date endDate;             // 结束日期
    private List<Long> deptIds;       // 选中的组织ID列表
    private Long userId;              // 当前用户ID
    private String deptId;            //主体id
}
