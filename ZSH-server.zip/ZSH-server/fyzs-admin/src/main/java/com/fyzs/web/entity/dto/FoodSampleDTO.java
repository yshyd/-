package com.fyzs.web.entity.dto;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class FoodSampleDTO extends SummaryItemDTO {
    private Integer shouldSample;     // 应留样数
    private Integer sampled;          // 已留样数
    private Integer notSampled;      // 未留样数
    private Integer destroyed;        // 已销样数
    private Integer normalDestroyed;  // 正常销样数
    private Integer earlyDestroyed;   // 提前销样数
    private BigDecimal sampleRate;    // 留样率
    private BigDecimal normalDestroyRate; // 正常销样率
    private BigDecimal earlyDestroyRate;  // 提前销样率

    public void calculateSampleRates() {
        // 计算留样率
        if (shouldSample != null && shouldSample > 0) {
            this.sampleRate = BigDecimal.valueOf(sampled)
                    .divide(BigDecimal.valueOf(shouldSample), 3, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(1, BigDecimal.ROUND_HALF_UP);
        } else {
            this.sampleRate = BigDecimal.ZERO;
        }

        // 计算正常销样率
        if (destroyed != null && destroyed > 0) {
            this.normalDestroyRate = BigDecimal.valueOf(normalDestroyed)
                    .divide(BigDecimal.valueOf(destroyed), 3, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(1, BigDecimal.ROUND_HALF_UP);
        } else {
            this.normalDestroyRate = BigDecimal.ZERO;
        }

        // 计算提前销样率
        if (destroyed != null && destroyed > 0) {
            this.earlyDestroyRate = BigDecimal.valueOf(earlyDestroyed)
                    .divide(BigDecimal.valueOf(destroyed), 3, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(1, BigDecimal.ROUND_HALF_UP);
        } else {
            this.earlyDestroyRate = BigDecimal.ZERO;
        }
    }
    @Override
    public void calculateScores() {
        // 设置总分
        this.totalScore = BigDecimal.valueOf(initialExecutionScore + initialQualificationScore)
                .setScale(3, BigDecimal.ROUND_HALF_UP);

        // 留样得分 = 初始执行分 × (留样率/100)，保留 3 位小数
        if (sampleRate != null) {
            this.executionScore = BigDecimal.valueOf(initialExecutionScore)
                    .multiply(sampleRate.divide(BigDecimal.valueOf(100), 3, BigDecimal.ROUND_HALF_UP))
                    .setScale(3, BigDecimal.ROUND_HALF_UP);
        } else {
            this.executionScore = BigDecimal.ZERO;
        }

        // 销样得分 = 初始合格分 × (正常销样率/100)，保留 3 位小数
        if (normalDestroyRate != null) {
            this.qualificationScore = BigDecimal.valueOf(initialQualificationScore)
                    .multiply(normalDestroyRate.divide(BigDecimal.valueOf(100), 3, BigDecimal.ROUND_HALF_UP))
                    .setScale(3, BigDecimal.ROUND_HALF_UP);
        } else {
            this.qualificationScore = BigDecimal.ZERO;
        }

        // 最终得分 = 留样得分 + 销样得分，保留 3 位小数
        this.finalScore = (this.executionScore != null ? this.executionScore : BigDecimal.ZERO)
                .add(this.qualificationScore != null ? this.qualificationScore : BigDecimal.ZERO)
                .setScale(3, BigDecimal.ROUND_HALF_UP);
    }

}
