package com.fyzs.web.entity.query;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Data
public class TIncomeExpenditureEarlyQuery {

    /**
     * $cleanComment
     */
    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 主体ID
     */
    @Schema(description = "主体ID")
    @Excel(name = "主体ID")
    private Long deptId;

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    /**
     * 年度
     */
    @Schema(description = "年度")
    @Excel(name = "年度")
    private Integer annual;

    /**
     * 类型：0上学期1下学期
     */
    @Schema(description = "类型：0上学期1下学期")
    @Excel(name = "类型：0上学期1下学期")
    private Integer type;

    /**
     * 收支：0收入1支出
     */
    @Schema(description = "收入：0收入1支出")
    @Excel(name = "收入：0收入1支出")
    private Integer isIncome;

    /**
     * 开始日期：格式-年月日
     */
    @Schema(description = "开始日期：格式-年月日")
    @Excel(name = "开始日期：格式-年月日")
    private String startTime;

    /**
     * 结束日期：格式-年月日
     */
    @Schema(description = "结束日期：格式-年月日")
    @Excel(name = "结束日期：格式-年月日")
    private String endTime;

    /**
     * 总收入金额(元)
     */
    @Schema(description = "总收入金额(元)")
    @Excel(name = "总收入金额(元)")
    private BigDecimal amount;

    /**
     * 总支出金额(元)
     */
    @Schema(description = "总支出金额(元)")
    @Excel(name = "总支出金额(元)")
    private BigDecimal expenditure;

    /**
     * 已结算金额(元)
     */
    @Schema(description = "已结算金额(元)")
    @Excel(name = "已结算金额(元)")
    private BigDecimal settlementAmount;

    /**
     * 收支差
     */
    @Schema(description = "收支差")
    @Excel(name = "收支差")
    private BigDecimal amountDifference;

    /**
     * 预警类型 0:正常 1:正偏离过大 2:负偏离过大
     */
    @Schema(description = "预警类型")
    @Excel(name = "预警类型")
    private Integer warningType;

    // 添加正偏离阈值百分比字段
    @Schema(description = "正偏离阈值百分比")
    @Excel(name = "正偏离阈值百分比")
    private Integer positiveThreshold;

    // 添加负偏离阈值百分比字段
    @Schema(description = "负偏离阈值百分比")
    @Excel(name = "负偏离阈值百分比")
    private Integer negativeThreshold;



    /** 0有效1作废 */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "0有效1作废")
    private Integer delFlag;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
