package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食安监管-日管控-日常就餐-就餐人数对象 t_day_number_diners
 *
 * @author ysh
 * @date 2025-11-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_number_diners")
public class TDayNumberDiners implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 日期 */
        @Schema(description = "日期")
        @Excel(name = "日期")
        private String date;

        /** 早餐预计 */
        @Schema(description = "早餐预计")
        @Excel(name = "早餐预计")
        private Long breakfastExpected;

        /** 午餐预计 */
        @Schema(description = "午餐预计")
        @Excel(name = "午餐预计")
        private Long lunchExpected;

        /** 晚餐预计 */
        @Schema(description = "晚餐预计")
        @Excel(name = "晚餐预计")
        private Long dinnerExpected;

        /** 早餐实际 */
        @Schema(description = "早餐实际")
        @Excel(name = "早餐实际")
        private Long breakfastActual;

        /** 午餐实际 */
        @Schema(description = "午餐实际")
        @Excel(name = "午餐实际")
        private Long lunchtActual;

        /** 级晚餐实际 */
        @Schema(description = "级晚餐实际")
        @Excel(name = "级晚餐实际")
        private Long dinnertActual;

        /** 实际总计：人餐(所有加起来) */
        @Schema(description = "实际总计：人餐(所有加起来)")
        @Excel(name = "实际总计：人餐(所有加起来)")
        private Long actualTotal;

        /** 预计总计：人餐(所有加起来) */
        @Schema(description = "预计总计：人餐(所有加起来)")
        @Excel(name = "预计总计：人餐(所有加起来)")
        private Long expectedTotal;

        /** 填报人 */
        @Schema(description = "填报人")
        @Excel(name = "填报人")
        private String reporter;

        /** 填报时间 */
        @Schema(description = "填报时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
        @Excel(name = "填报时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm")
        private Date reporterDate;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

}
