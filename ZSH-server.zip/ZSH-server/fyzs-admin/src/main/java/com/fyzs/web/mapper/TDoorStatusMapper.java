package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TDoorStatus;
import com.fyzs.web.entity.query.TDoorStatusQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 留样柜柜门状态Mapper接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
@org.apache.ibatis.annotations.Mapper
public interface TDoorStatusMapper  extends BaseMapper<TDoorStatus>
{
    /**
     * 查询留样柜柜门状态
     * 
     * @param id 留样柜柜门状态主键
     * @return 留样柜柜门状态
     */
    public TDoorStatusQuery selectTDoorStatusById(Long id);

    /**
     * 查询留样柜柜门状态列表
     * 
     * @param tDoorStatus 留样柜柜门状态
     * @return 留样柜柜门状态集合
     */
    public List<TDoorStatusQuery> selectTDoorStatusList(TDoorStatusQuery tDoorStatus);

    /**
     * 新增留样柜柜门状态
     * 
     * @param tDoorStatus 留样柜柜门状态
     * @return 结果
     */
    public int insertTDoorStatus(TDoorStatus tDoorStatus);

    /**
     * 修改留样柜柜门状态
     * 
     * @param tDoorStatus 留样柜柜门状态
     * @return 结果
     */
    public int updateTDoorStatus(TDoorStatus tDoorStatus);

    /**
     * 删除留样柜柜门状态
     * 
     * @param id 留样柜柜门状态主键
     * @return 结果
     */
    public int deleteTDoorStatusById(Long id);

    /**
     * 批量删除留样柜柜门状态
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDoorStatusByIds(Long[] ids);
}
