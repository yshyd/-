package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;




/**
 * 违法违规处置信息对象 t_regulations_self_handle
 *
 * @author ysh
 * @date 2025-10-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_regulations_self_handle")
public class TRegulationsSelfHandle implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $column.columnComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 违法违规识别信息表的主键ID */
        @Schema(description = "违法违规识别信息表的主键ID")
        @Excel(name = "违法违规识别信息表的主键ID")
        private Long riskID;

        /** 与经营主体基本信息表或其他组织机构基本信息表中一致,统一信用代码 */
        @Schema(description = "与经营主体基本信息表或其他组织机构基本信息表中一致,统一信用代码")
        @Excel(name = "与经营主体基本信息表或其他组织机构基本信息表中一致,统一信用代码")
        private String unisCID;

        /** 处置状态01-待处置
02-已处置 */
        @Schema(description = "处置状态01-待处置 02-已处置")
        @Excel(name = "处置状态01-待处置 02-已处置")
        private String handleStatus;

        /** 处置时间，已处置状态下必填 */
        @Schema(description = "处置时间，已处置状态下必填")
        @Excel(name = "处置时间，已处置状态下必填")
        private String handleTime;

        /** 处置人（指的是企业），已处置状态下必填 */
        @Schema(description = "处置人（指的是企业），已处置状态下必填")
        @Excel(name = "处置人", readConverterExp = "指=的是企业")
        private String handlePerson;

        /** 处置部门（企业具体部门），已处置状态下必填 */
        @Schema(description = "处置部门（企业具体部门），已处置状态下必填")
        @Excel(name = "处置部门", readConverterExp = "企=业具体部门")
        private String handleOrgan;

        /** 处理结果描述，已处置状态下必填 */
        @Schema(description = "处理结果描述，已处置状态下必填")
        @Excel(name = "处理结果描述，已处置状态下必填")
        private String handleResultMome;

        /** 备注，已处置状态下必填 */
        @Schema(description = "备注，已处置状态下必填")
        @Excel(name = "备注，已处置状态下必填")
        private String memo;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

        /** 0启用1禁用 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0启用1禁用")
        private Long delFlag;

}
