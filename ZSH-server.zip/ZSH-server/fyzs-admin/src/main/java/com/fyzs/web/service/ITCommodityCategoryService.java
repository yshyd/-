package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCommodityCategory;

/**
 * 商品分类Service接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
public interface ITCommodityCategoryService extends IService<TCommodityCategory>
{
    /**
     * 查询商品分类
     * 
     * @param id 商品分类主键
     * @return 商品分类
     */
    public TCommodityCategory selectTCommodityCategoryById(Long id);

    /**
     * 查询商品分类列表
     * 
     * @param tCommodityCategory 商品分类
     * @return 商品分类集合
     */
    public List<TCommodityCategory> selectTCommodityCategoryList(TCommodityCategory tCommodityCategory);

    /**
     * 新增商品分类
     * 
     * @param tCommodityCategory 商品分类
     * @return 结果
     */
    public int insertTCommodityCategory(TCommodityCategory tCommodityCategory);

    /**
     * 修改商品分类
     * 
     * @param tCommodityCategory 商品分类
     * @return 结果
     */
    public int updateTCommodityCategory(TCommodityCategory tCommodityCategory);

    /**
     * 批量删除商品分类
     * 
     * @param ids 需要删除的商品分类主键集合
     * @return 结果
     */
    public int deleteTCommodityCategoryByIds(Long[] ids);

    /**
     * 删除商品分类信息
     * 
     * @param id 商品分类主键
     * @return 结果
     */
    public int deleteTCommodityCategoryById(Long id);
}
