package com.fyzs.web.entity.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.web.entity.TFoodRecipse;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;


import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Data
public class TFoodRecipseVO implements Serializable {

    /**
     * 发布时间
     */
    @ApiModelProperty("发布时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date date;

    /**
     * 星期几
     */
    @ApiModelProperty("星期几")
    private Integer day;

    /**
     * 菜谱
     */
    @ApiModelProperty("菜谱")
    private List<TFoodRecipse> food;


}
