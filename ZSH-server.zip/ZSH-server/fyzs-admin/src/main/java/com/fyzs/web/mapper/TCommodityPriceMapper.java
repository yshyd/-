package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCommodityPrice;
import com.fyzs.web.entity.query.TCommodityPriceQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 价格管理Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@Mapper
public interface TCommodityPriceMapper  extends BaseMapper<TCommodityPrice>
{
    /**
     * 查询价格管理
     * 
     * @param id 价格管理主键
     * @return 价格管理
     */
    public TCommodityPriceQuery selectTCommodityPriceById(Long id);

    /**
     * 查询价格管理列表
     * 
     * @param tCommodityPrice 价格管理
     * @return 价格管理集合
     */
    public List<TCommodityPriceQuery> selectTCommodityPriceList(TCommodityPriceQuery tCommodityPrice);

    /**
     * 新增价格管理
     * 
     * @param tCommodityPrice 价格管理
     * @return 结果
     */
    public int insertTCommodityPrice(TCommodityPrice tCommodityPrice);

    /**
     * 修改价格管理
     * 
     * @param tCommodityPrice 价格管理
     * @return 结果
     */
    public int updateTCommodityPrice(TCommodityPrice tCommodityPrice);

    /**
     * 删除价格管理
     * 
     * @param id 价格管理主键
     * @return 结果
     */
    public int deleteTCommodityPriceById(Long id);

    /**
     * 批量删除价格管理
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCommodityPriceByIds(Long[] ids);
    /**
     * 批量插入价格记录
     */
    int insertBatch(@Param("list") List<TCommodityPrice> toInsert);
}
