package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 空气消毒净化记录对象 t_air_recode
 *
 * @author ysh
 * @date 2026-08-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_air_recode")
public class TAirRecode implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 设备序列号(对应t_device中serial_number) */
        @Schema(description = "设备序列号(对应t_device中serial_number)")
        @Excel(name = "设备序列号(对应t_device中serial_number)")
        private String serialNumber;

        /** 事件类型 */
        @Schema(description = "事件类型")
        @Excel(name = "事件类型")
        private String type;

        /** 执行时间(插入记录时系统时间) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "执行时间(插入记录时系统时间)")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "执行时间(插入记录时系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

}
