package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TNewReview;
import com.fyzs.web.entity.query.TNewReviewQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 盘点Mapper接口
 * 
 * @author ysh
 * @date 2025-10-31
 */
@Mapper
public interface TNewReviewMapper  extends BaseMapper<TNewReview>
{
    /**
     * 查询盘点
     * 
     * @param id 盘点主键
     * @return 盘点
     */
    public TNewReviewQuery selectTNewReviewById(Long id);

    /**
     * 查询盘点列表
     * 
     * @param tNewReview 盘点
     * @return 盘点集合
     */
    public List<TNewReviewQuery> selectTNewReviewList(TNewReview tNewReview);

    /**
     * 新增盘点
     * 
     * @param tNewReview 盘点
     * @return 结果
     */
    public int insertTNewReview(TNewReview tNewReview);

    /**
     * 修改盘点
     * 
     * @param tNewReview 盘点
     * @return 结果
     */
    public int updateTNewReview(TNewReview tNewReview);

    /**
     * 删除盘点
     * 
     * @param id 盘点主键
     * @return 结果
     */
    public int deleteTNewReviewById(Long id);

    /**
     * 批量删除盘点
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewReviewByIds(Long[] ids);
}
