package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TPersonCheck;
import com.fyzs.web.entity.query.TPersonCheckQuery;

/**
 * 食堂人员日检Service接口
 * 
 * @author ysh
 * @date 2025-11-19
 */
public interface ITPersonCheckService extends IService<TPersonCheck>
{
    /**
     * 查询食堂人员日检
     * 
     * @param id 食堂人员日检主键
     * @return 食堂人员日检
     */
    public TPersonCheckQuery selectTPersonCheckById(Long id);

    /**
     * 查询食堂人员日检列表
     * 
     * @param query 食堂人员日检
     * @return 食堂人员日检集合
     */
    public List<TPersonCheckQuery> selectTPersonCheckList(TPersonCheckQuery query);

    /**
     * 根据查询条件导出全部食堂人员日检数据（不分页）
     */
    public List<TPersonCheckQuery> selectTPersonCheckExportList(TPersonCheckQuery query);

    /**
     * 新增食堂人员日检
     * 
     * @param tPersonCheck 食堂人员日检
     * @return 结果
     */
    public int insertTPersonCheck(TPersonCheck tPersonCheck);

    /**
     * 修改食堂人员日检
     * 
     * @param tPersonCheck 食堂人员日检
     * @return 结果
     */
    public int updateTPersonCheck(TPersonCheck tPersonCheck);

    /**
     * 批量删除食堂人员日检
     * 
     * @param ids 需要删除的食堂人员日检主键集合
     * @return 结果
     */
    public int deleteTPersonCheckByIds(Long[] ids);

    /**
     * 删除食堂人员日检信息
     * 
     * @param id 食堂人员日检主键
     * @return 结果
     */
    public int deleteTPersonCheckById(Long id);

    int cancel(TPersonCheck tPersonCheck);
}
