package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TSnapshot;
import com.fyzs.web.entity.query.TSnapshotQuery;

/**
 * AI盒子违规抓拍Service接口
 * 
 * @author ysh
 * @date 2026-01-05
 */
public interface ITSnapshotService extends IService<TSnapshot>
{
    /**
     * 查询AI盒子违规抓拍
     * 
     * @param id AI盒子违规抓拍主键
     * @return AI盒子违规抓拍
     */
    public TSnapshotQuery selectTSnapshotById(Long id);

    /**
     * 查询AI盒子违规抓拍列表
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return AI盒子违规抓拍集合
     */
    public List<TSnapshotQuery> selectTSnapshotList(TSnapshotQuery tSnapshot);

    /**
     * 新增AI盒子违规抓拍
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return 结果
     */
    public int insertTSnapshot(TSnapshot tSnapshot);

    /**
     * 修改AI盒子违规抓拍
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return 结果
     */
    public int updateTSnapshot(TSnapshot tSnapshot);

    /**
     * 批量删除AI盒子违规抓拍
     * 
     * @param ids 需要删除的AI盒子违规抓拍主键集合
     * @return 结果
     */
    public int deleteTSnapshotByIds(Long[] ids);

    /**
     * 删除AI盒子违规抓拍信息
     * 
     * @param id AI盒子违规抓拍主键
     * @return 结果
     */
    public int deleteTSnapshotById(Long id);
}
