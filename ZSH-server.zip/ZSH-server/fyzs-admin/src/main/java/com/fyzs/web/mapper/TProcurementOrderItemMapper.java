package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TProcurementOrderItem;
import com.fyzs.web.entity.vo.TProcurementOrderItemVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 采购计划副Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@Mapper
public interface TProcurementOrderItemMapper  extends BaseMapper<TProcurementOrderItem>
{
    /**
     * 查询采购计划副
     * 
     * @param id 采购计划副主键
     * @return 采购计划副
     */
    public TProcurementOrderItem selectTProcurementOrderItemById(Long id);

    /**
     * 查询采购计划副列表
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 采购计划副集合
     */
    public List<TProcurementOrderItem> selectTProcurementOrderItemList(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 新增采购计划副
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 结果
     */
    public int insertTProcurementOrderItem(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 修改采购计划副
     * 
     * @param tProcurementOrderItem 采购计划副
     * @return 结果
     */
    public int updateTProcurementOrderItem(TProcurementOrderItem tProcurementOrderItem);

    /**
     * 删除采购计划副
     * 
     * @param id 采购计划副主键
     * @return 结果
     */
    public int deleteTProcurementOrderItemById(Long id);

    /**
     * 批量删除采购计划副
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTProcurementOrderItemByIds(Long[] ids);

    /**
     * 批量插入采购订单项
     * @param itemList 采购订单项列表
     * @return 插入记录数
     */
    int insertBatch(@Param("list") List<TProcurementOrderItem> itemList);

    List<TProcurementOrderItemVO> selectOrderItem(Long id);
}
