package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 违法违规识别图片固证文件存储信息对象 t_camera_regulations_img
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_regulations_img")
public class TCameraRegulationsImg implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 关联违法违规行为识别信息 */
        @Schema(description = "关联违法违规行为识别信息")
        @Excel(name = "关联违法违规行为识别信息")
        private Long riskId;

        /** 关联可视化视频监控设备基本信息表监控设备编码 */
        @Schema(description = "关联可视化视频监控设备基本信息表监控设备编码")
        @Excel(name = "关联可视化视频监控设备基本信息表监控设备编码")
        private String devId;

        /** 社会信用代码与经营主体基本信息表或其他组织机构基本信息表中一致 */
        @Schema(description = "社会信用代码与经营主体基本信息表或其他组织机构基本信息表中一致")
        @Excel(name = "社会信用代码与经营主体基本信息表或其他组织机构基本信息表中一致")
        private String unisCid;

        /** 关联可视化视频监控设备基本信息表监控设备业务编码。 */
        @Schema(description = "关联可视化视频监控设备基本信息表监控设备业务编码。")
        @Excel(name = "关联可视化视频监控设备基本信息表监控设备业务编码。")
        private String bissId;

        /** 文件名称 */
        @Schema(description = "文件名称")
        @Excel(name = "文件名称")
        private String fileName;

        /** 1jpg、2png、m3u8 */
        @Schema(description = "1jpg、2png、m3u8")
        @Excel(name = "1jpg、2png、m3u8")
        private String fileFormat;

        /** 互联网地址，地址变化后需要重新报送 */
        @Schema(description = "互联网地址，地址变化后需要重新报送")
        @Excel(name = "互联网地址，地址变化后需要重新报送")
        private String picFilePath;

        /** 违法违规图片概要值(哈希值)，用于完整性、可信性校验。 */
        @Schema(description = "违法违规图片概要值(哈希值)，用于完整性、可信性校验。")
        @Excel(name = "违法违规图片概要值(哈希值)，用于完整性、可信性校验。")
        private String esig;

        /** 创建人ID */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID")
        @Excel(name = "创建人ID")
        private Long createUser;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

        /** 0启用1禁用 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0启用1禁用")
        private Long delFlag;

}
