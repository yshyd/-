package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.TMonitoringLinksConfig;
import com.fyzs.web.entity.dto.TreeNode;
import com.fyzs.web.service.ITMonitoringLinksConfigService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;

import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 关键监控环节配置Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/monitoring/config")
public class TMonitoringLinksConfigController extends BaseController
{

    private final ITMonitoringLinksConfigService tMonitoringLinksConfigService;

    /**
     * 查询关键监控环节配置列表
     */
    //@PreAuthorize("@ss.hasPermi('system:config:list')")
    @GetMapping("/list")
    public TableDataInfo list(TMonitoringLinksConfig tMonitoringLinksConfig)
    {
        startPage();
        List<TMonitoringLinksConfig> list = tMonitoringLinksConfigService.selectTMonitoringLinksConfigList(tMonitoringLinksConfig);
        return getDataTable(list);
    }

    /**
     * 导出关键监控环节配置列表
     */
    //@PreAuthorize("@ss.hasPermi('system:config:export')")
    @Log(title = "关键监控环节配置", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TMonitoringLinksConfig tMonitoringLinksConfig)
    {
        List<TMonitoringLinksConfig> list = tMonitoringLinksConfigService.selectTMonitoringLinksConfigList(tMonitoringLinksConfig);
        ExcelUtil<TMonitoringLinksConfig> util = new ExcelUtil<TMonitoringLinksConfig>(TMonitoringLinksConfig.class);
        util.exportExcel(response, list, "关键监控环节配置数据");
    }

    /**
     * 获取关键监控环节配置详细信息
     */
    //@PreAuthorize("@ss.hasPermi('system:config:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tMonitoringLinksConfigService.selectTMonitoringLinksConfigById(id));
    }

    /**
     * 新增关键监控环节配置
     */
    //@PreAuthorize("@ss.hasPermi('system:config:add')")
    @Log(title = "关键监控环节配置", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody TMonitoringLinksConfig tMonitoringLinksConfig)
    {
        return toAjax(tMonitoringLinksConfigService.save(tMonitoringLinksConfig));
    }

    /**
     * 修改关键监控环节配置
     */
    //@PreAuthorize("@ss.hasPermi('system:config:edit')")
    @Log(title = "关键监控环节配置", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody TMonitoringLinksConfig tMonitoringLinksConfig)
    {
        return toAjax(tMonitoringLinksConfigService.updateById(tMonitoringLinksConfig));
    }

    /**
     * 删除关键监控环节配置
     */
    //@PreAuthorize("@ss.hasPermi('system:config:remove')")
    @Log(title = "关键监控环节配置", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tMonitoringLinksConfigService.deleteTMonitoringLinksConfigByIds(ids));
    }

    /**
     * 获取模版树
     * @return
     */
    @GetMapping("/tree")
    public AjaxResult getTree(TMonitoringLinksConfig tMonitoringLinksConfig) {
        List<TMonitoringLinksConfig> list = tMonitoringLinksConfigService.selectConfigList(tMonitoringLinksConfig);
        List<TreeNode> tree = tMonitoringLinksConfigService.buildTree(list);
        return success(tree);
    }
}
