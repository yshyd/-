package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TAnnouncement;
import com.fyzs.web.entity.TAnnouncementItem;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TAnnouncementDTO extends TAnnouncement {

    @Schema(description = "列表")
    private List<Long> deptIds;
}
