package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayDisinfectionTableware;
import com.fyzs.web.entity.query.TDayDisinfectionTablewareQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常消毒-餐饮具消毒Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@Mapper
public interface TDayDisinfectionTablewareMapper  extends BaseMapper<TDayDisinfectionTableware>
{
    /**
     * 查询学校食堂日管控-日常消毒-餐饮具消毒
     * 
     * @param id 学校食堂日管控-日常消毒-餐饮具消毒主键
     * @return 学校食堂日管控-日常消毒-餐饮具消毒
     */
    public TDayDisinfectionTablewareQuery selectTDayDisinfectionTablewareById(Long id);

    /**
     * 查询学校食堂日管控-日常消毒-餐饮具消毒列表
     *
     * @return 学校食堂日管控-日常消毒-餐饮具消毒集合
     */
    public List<TDayDisinfectionTablewareQuery> selectTDayDisinfectionTablewareList(TDayDisinfectionTablewareQuery query);

    /**
     * 新增学校食堂日管控-日常消毒-餐饮具消毒
     * 
     * @param tDayDisinfectionTableware 学校食堂日管控-日常消毒-餐饮具消毒
     * @return 结果
     */
    public int insertTDayDisinfectionTableware(TDayDisinfectionTableware tDayDisinfectionTableware);

    /**
     * 修改学校食堂日管控-日常消毒-餐饮具消毒
     * 
     * @param tDayDisinfectionTableware 学校食堂日管控-日常消毒-餐饮具消毒
     * @return 结果
     */
    public int updateTDayDisinfectionTableware(TDayDisinfectionTableware tDayDisinfectionTableware);

    /**
     * 删除学校食堂日管控-日常消毒-餐饮具消毒
     * 
     * @param id 学校食堂日管控-日常消毒-餐饮具消毒主键
     * @return 结果
     */
    public int deleteTDayDisinfectionTablewareById(Long id);

    /**
     * 批量删除学校食堂日管控-日常消毒-餐饮具消毒
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayDisinfectionTablewareByIds(Long[] ids);

    int countValidDisinfections(@Param("startDate") Date startDate,
                                @Param("endDate") Date endDate,
                                @Param("deptIds") List<Long> deptIds);
}
