package com.fyzs.web.entity.dto;

import lombok.Data;

@Data
public class DeviceTypeCountDTO {
    private Integer type;   // 对应 t_device.type（0~5）
    private Integer count;  // 该类型设备的启用数量（del_flag = 0）
}