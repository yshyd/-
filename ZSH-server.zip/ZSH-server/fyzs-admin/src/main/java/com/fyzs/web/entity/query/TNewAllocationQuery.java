package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TNewAllocation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewAllocationQuery extends TNewAllocation {

    @Schema(description = "区域ID")
    private Long areaId;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    @Schema(description = "供应商名称")
    @Excel(name = "供应商名称")
    private String supplerName;

    @Schema(description = "仓库名称")
    @Excel(name = "仓库名称")
    private String warehouseName;

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;
    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 单位 */
    @Schema(description = "单位")
    @Excel(name = "单位")
    private String purchaUnit;

    /** 入库时间 */
    @Schema(description = "入库时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
    @Excel(name = "入库时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date inboundTime;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
