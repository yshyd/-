package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SupplierDataDownVO {
    @Schema(description = "供应商名称")
    private String name;

    @Schema(description = "联系人")
    private String contactPerson;

    @Schema(description = "联系电话")
    private String contactPhone;

    @Schema(description = "证件类型")
    private String documentType;

    @Schema(description = "证件图片URL")
    private String img;
}