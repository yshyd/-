package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TInventory;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TInventoryQuery extends TInventory {

    private Long areaId;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    @Schema(description = "供应商名称")
    @Excel(name = "供应商名称")
    private String supplerName;

    @Schema(description = "仓库名称")
    @Excel(name = "仓库名称")
    private String warehouseName;

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;
    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    @Schema(description = "食材类型ID")
    private Long categoryId;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;



    @Schema(description = "验收状态查询")
    private Integer type;

    /** 采购计量单位(用于账单核算) */
    @Schema(description = "统一计量单位")
    @Excel(name = "统一计量单位")
    private String purchaUnit;


    @Schema(description = "总库存(预警列表)")
    @Excel(name = "总库存(预警列表)")
    private BigDecimal totalInventory;

    private String inventoryStatus;


    /** 库存上限 */
    @Schema(description = "库存上限")
    @Excel(name = "库存上限")
    private BigDecimal up;

    /** 库存下限 */
    @Schema(description = "库存下限")
    @Excel(name = "库存下限")
    private BigDecimal low;

    @Schema(description = "验收时间")
    private String accpeptanceDate;

    @Schema(description = "是否有库存")
    private Integer hasInventory;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    @Schema(description = "判断是验收id是否为空")
    private Integer isAcceptanceId;


    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
