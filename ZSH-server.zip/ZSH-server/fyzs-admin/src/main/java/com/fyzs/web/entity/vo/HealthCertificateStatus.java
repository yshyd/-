package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class HealthCertificateStatus {
    /** 有效数 */
    @Schema(description = "有效数")
    private Integer validCount;
    /** 无效数 */
    @Schema(description = "无效数")
    private Integer invalidCount;
    /** 有效率 */
    @Schema(description = "有效率")
    private double validRatio;
    /** 无效率 */
    @Schema(description = "无效率")
    private double invalidRatio;
}
