package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食安监管-月调度-月计划对象 t_month_plan
 *
 * @author ysh
 * @date 2025-12-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_month_plan")
public class TMonthPlan implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体名称 */
        @Schema(description = "主体名称")
        @Excel(name = "主体名称")
        private Long deptId;

        /** 年度 */
        @Schema(description = "年度")
        @Excel(name = "年度")
        private Long year;

        /** 月(这一年第多少月) */
        @Schema(description = "月(这一年第多少月)")
        @Excel(name = "月(这一年第多少月)")
        private Long month;

        /** 作用开始日期，格式：2025-11-01 */
        @Schema(description = "作用开始日期，格式：2025-11-01")
        @Excel(name = "作用开始日期，格式：2025-11-01")
        private String startDate;

        /** 作用结束日期，格式：2025-11-30 */
        @Schema(description = "作用结束日期，格式：2025-11-30")
        @Excel(name = "作用结束日期，格式：2025-11-30")
        private String endDate;

        /** 月计划指标1000字内 */
        @Schema(description = "月计划指标1000字内")
        @Excel(name = "月计划指标1000字内")
        private String plan;

        /** 登记人 */
        @Schema(description = "登记人")
        @Excel(name = "登记人")
        private String searchPeople;

        /** 登记时间 */
        @Schema(description = "登记时间")
        @Excel(name = "登记时间")
        private String searchTime;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
