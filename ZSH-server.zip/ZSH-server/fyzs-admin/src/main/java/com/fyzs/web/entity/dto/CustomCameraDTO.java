package com.fyzs.web.entity.dto;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TCamera;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class CustomCameraDTO extends TCamera {
    /**
     * 在线监控视频地址
     */
    @Schema(description = "在线监控视频地址")
    @Excel(name = "在线监控视频地址")
    private String videoUel;

    /**
     * 在线监控地址子码流
     */
    @Schema(description = "在线监控地址子码流")
    @Excel(name = "在线监控地址子码流")
    private String videoUelItem;

    /**
     * rtmp在线监控地址主码流
     */
    @Schema(description = "rtmp在线监控地址主码流")
    @Excel(name = "rtmp在线监控地址主码流")
    private String rtmpUel;

    /**
     * rtmp在线监控地址子码流
     */
    @Schema(description = "rtmp在线监控地址子码流")
    @Excel(name = "rtmp在线监控地址子码流")
    private String ttmpUelItm;

    /** 在线监控视频地址 */
    @Schema(description = "在线监控视频地址")
    @Excel(name = "在线监控视频地址")
    private String recVideoUel;

    /** 格式“YYYY-MM-DD--YYYY-MM-DD” 按天回放 */
    @Schema(description = "格式“YYYY-MM-DD--YYYY-MM-DD” 按天回放")
    @Excel(name = "格式“YYYY-MM-DD--YYYY-MM-DD” 按天回放")
    private String recVideoDate;
}
