package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PositionDistribution {
    @Schema(description = "名称")
    private String deptName;
    @Schema(description = "数量")
    private Integer count;
}
