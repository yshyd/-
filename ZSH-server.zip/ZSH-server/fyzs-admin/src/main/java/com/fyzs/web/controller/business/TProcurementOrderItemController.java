package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TProcurementOrderItem;
import com.fyzs.web.service.ITProcurementOrderItemService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 采购计划副Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/order/item")
public class TProcurementOrderItemController extends BaseController
{

    private final ITProcurementOrderItemService tProcurementOrderItemService;

    /**
     * 查询采购计划副列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:list')")
    @GetMapping("/list")
    public TableDataInfo list(TProcurementOrderItem tProcurementOrderItem)
    {
        startPage();
        List<TProcurementOrderItem> list = tProcurementOrderItemService.selectTProcurementOrderItemList(tProcurementOrderItem);
        return getDataTable(list);
    }

    /**
     * 导出采购计划副列表
     */
    //@PreAuthorize("@ss.hasPermi('web:item:export')")
    @Log(title = "采购计划副", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TProcurementOrderItem tProcurementOrderItem)
    {
        List<TProcurementOrderItem> list = tProcurementOrderItemService.selectTProcurementOrderItemList(tProcurementOrderItem);
        ExcelUtil<TProcurementOrderItem> util = new ExcelUtil<TProcurementOrderItem>(TProcurementOrderItem.class);
        util.exportExcel(response, list, "采购计划副数据");
    }

    /**
     * 获取采购计划副详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:item:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tProcurementOrderItemService.selectTProcurementOrderItemById(id));
    }

    /**
     * 新增采购计划副
     */
    //@PreAuthorize("@ss.hasPermi('web:item:add')")
    @Log(title = "采购计划副", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TProcurementOrderItem tProcurementOrderItem)
    {
        return toAjax(tProcurementOrderItemService.save(tProcurementOrderItem));
    }

    /**
     * 修改采购计划副
     */
    //@PreAuthorize("@ss.hasPermi('web:item:edit')")
    @Log(title = "采购计划副", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TProcurementOrderItem tProcurementOrderItem)
    {
        return toAjax(tProcurementOrderItemService.updateById(tProcurementOrderItem));
    }

    /**
     * 删除采购计划副
     */
    //@PreAuthorize("@ss.hasPermi('web:item:remove')")
    @Log(title = "采购计划副", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tProcurementOrderItemService.deleteTProcurementOrderItemByIds(ids));
    }
}
