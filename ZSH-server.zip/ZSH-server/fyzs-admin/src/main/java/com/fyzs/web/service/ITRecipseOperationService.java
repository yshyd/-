package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TRecipseOperation;
import com.fyzs.web.entity.query.TRecipseOperationQuery;

/**
 * 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)Service接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
public interface ITRecipseOperationService extends IService<TRecipseOperation>
{
    /**
     * 查询食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * 
     * @param id 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)主键
     * @return 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     */
    public TRecipseOperationQuery selectTRecipseOperationById(Long id);

    /**
     * 查询食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)列表
     * 

     * @return 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)集合
     */
    public List<TRecipseOperationQuery> selectTRecipseOperationList(TRecipseOperationQuery query);

    /**
     * 新增食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * 
     * @param tRecipseOperation 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * @return 结果
     */
    public int insertTRecipseOperation(TRecipseOperation tRecipseOperation);

    /**
     * 修改食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * 
     * @param tRecipseOperation 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * @return 结果
     */
    public int updateTRecipseOperation(TRecipseOperation tRecipseOperation);

    /**
     * 批量删除食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)
     * 
     * @param ids 需要删除的食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)主键集合
     * @return 结果
     */
    public int deleteTRecipseOperationByIds(Long[] ids);

    /**
     * 删除食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)信息
     * 
     * @param id 食谱操作记录(食谱操作，留样、销样，试尝，陪餐等记录)主键
     * @return 结果
     */
    public int deleteTRecipseOperationById(Long id);
}
