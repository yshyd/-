package com.fyzs.web.entity;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 违法违规处置证明文件存储信息对象 t_regulations_del_file
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_regulations_del_file")
public class TRegulationsDelFile implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 关联违法违规行为识别信息表 */
        @Schema(description = "关联违法违规行为识别信息表")
        @Excel(name = "关联违法违规行为识别信息表")
        private Long riskId;

        /** 关联企业处置信息表 */
        @Schema(description = "关联企业处置信息表")
        @Excel(name = "关联企业处置信息表")
        private Long handleId;

        /** 关联可视化视频监控设备基本信息表监控设备编码 */
        @Schema(description = "关联可视化视频监控设备基本信息表监控设备编码")
        @Excel(name = "关联可视化视频监控设备基本信息表监控设备编码")
        private String devId;

        /** 统一社会信用代码，与经营主体基本信息表或其他组织机构基本信息表中一致 */
        @Schema(description = "统一社会信用代码，与经营主体基本信息表或其他组织机构基本信息表中一致")
        @Excel(name = "统一社会信用代码，与经营主体基本信息表或其他组织机构基本信息表中一致")
        private String unisCid;

        /** 关联可视化视频监控设备基本信息表监控设备业务编码。 */
        @Schema(description = "关联可视化视频监控设备基本信息表监控设备业务编码。")
        @Excel(name = "关联可视化视频监控设备基本信息表监控设备业务编码。")
        private String bissId;

        /** 文件名称 */
        @Schema(description = "文件名称")
        @Excel(name = "文件名称")
        private String fileName;

        /** 1jpg、2png、3m3u8 */
        @Schema(description = "1jpg、2png、3m3u8")
        @Excel(name = "1jpg、2png、3m3u8")
        private String fileFormat;

        /** 互联网地址，地址变化后需要重新报送。 */
        @Schema(description = "互联网地址，地址变化后需要重新报送。")
        @Excel(name = "互联网地址，地址变化后需要重新报送。")
        private String filePath;

        /** 违法违规视频概要值，用于完整性、可信性校验。 */
        @Schema(description = "违法违规视频概要值，用于完整性、可信性校验。")
        @Excel(name = "违法违规视频概要值，用于完整性、可信性校验。")
        private String esig;

}
