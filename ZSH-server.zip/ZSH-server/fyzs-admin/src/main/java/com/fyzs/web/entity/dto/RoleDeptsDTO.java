package com.fyzs.web.entity.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RoleDeptsDTO {

    /** 用户ID */
    private Long userId;

    /** 角色ID */
    private Long roleId;

    /** 区域id */
    @Schema(description = "区域id")
    private Long areaId;

    /** 主体id */
    @Schema(description = "主体id")
    private Long deptId;

}
