package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TDoorStatus;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TDoorStatusQuery extends TDoorStatus {

    /** 主体ID */
    @Schema(description = "主体ID")
    @Excel(name = "主体ID")
    private Long deptId;

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "在线状态 0在线 1离线")
    private Integer onlineStatus;

    /** 心跳时间 */
    @Schema(description = "心跳时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "心跳时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date heartTime;


    /** 柜门1留样状态 */
    @Schema(description = "柜门1留样状态 ")
    @Excel(name = "柜门1留样状态")
    private String doorOneStatus;

    /** 柜门2留样状态 */
    @Schema(description = "柜门2留样状态")
    @Excel(name = "柜门2留样状态")
    private String doorTwoStatus;

    /** 柜门3留样状态 */
    @Schema(description = "柜门3留样状态")
    @Excel(name = "柜门3留样状态")
    private String doorThreeStatus;

    /** 柜门4留样状态 */
    @Schema(description = "柜门4留样状态")
    @Excel(name = "柜门4留样状态")
    private String doorFourStatus;

    /** 柜门5留样状态 */
    @Schema(description = "柜门5留样状态")
    @Excel(name = "柜门5留样状态")
    private String doorFiveStatus;

    /** 柜门6留样状态 */
    @Schema(description = "柜门6留样状态")
    @Excel(name = "柜门6留样状态")
    private String doorSixStatus;

    /** 柜门7留样状态 */
    @Schema(description = "柜门7留样状态")
    @Excel(name = "柜门7留样状态")
    private String doorSevenStatus;

    /** 柜门8留样状态 */
    @Schema(description = "柜门8留样状态")
    @Excel(name = "柜门8留样状态")
    private String doorEightStatus;

    /** 柜门9留样状态 */
    @Schema(description = "柜门9留样状态")
    @Excel(name = "柜门9留样状态")
    private String doorNineStatus;

    /** 柜门10留样状态 */
    @Schema(description = "柜门10留样状态")
    @Excel(name = "柜门10留样状态")
    private String doorTenStatus;

    /** 柜门11留样状态 */
    @Schema(description = "柜门11留样状态")
    @Excel(name = "柜门11留样状态")
    private String doorElevenStatus;

    /** 柜门12留样状态 */
    @Schema(description = "柜门12留样状态")
    @Excel(name = "柜门12留样状态")
    private String doorTwelveStatus;

    /** 柜门13留样状态 */
    @Schema(description = "柜门13留样状态")
    @Excel(name = "柜门13留样状态")
    private String doorThirteenStatus;

    /** 柜门14留样状态 */
    @Schema(description = "柜门14留样状态")
    @Excel(name = "柜门14留样状态")
    private String doorFourteenStatus;

    /** 柜门15留样状态 */
    @Schema(description = "柜门15留样状态")
    @Excel(name = "柜门15留样状态")
    private String doorFifteenStatus;

    /** 柜门16留样状态 */
    @Schema(description = "柜门16留样状态")
    @Excel(name = "柜门16留样状态")
    private String doorSixteenStatus;
    

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
