package com.fyzs.web.entity.vo;


import lombok.Data;

@Data
public class InvoiceStatusVO {
    private Integer total; // A = B + C
    private Integer uploaded; // C：已上传（索票索证不为空）
    private Integer notUploaded; // B：未上传（索票索证为空）

    public InvoiceStatusVO(int total, int uploaded, int notUploaded) {
        this.total = total;
        this.uploaded = uploaded;
        this.notUploaded = notUploaded;
    }
}
