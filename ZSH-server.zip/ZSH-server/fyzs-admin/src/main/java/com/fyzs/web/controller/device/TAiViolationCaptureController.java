package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TAiViolationCaptureQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TAiViolationCapture;
import com.fyzs.web.service.ITAiViolationCaptureService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * AI违规抓拍Controller
 * 
 * @author ysh
 * @date 2025-12-09
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/ai/capture")
public class TAiViolationCaptureController extends BaseController
{

    private final ITAiViolationCaptureService captureService;

    /**
     * 查询AI违规抓拍列表
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAiViolationCaptureQuery tAiViolationCapture)
    {
        startPage();
        List<TAiViolationCaptureQuery> list = captureService.selectTAiViolationCaptureList(tAiViolationCapture);
        return getDataTable(list);
    }

    /**
     * 导出AI违规抓拍列表
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:export')")
    @Log(title = "AI违规抓拍", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TAiViolationCaptureQuery tAiViolationCapture)
    {
        List<TAiViolationCaptureQuery> list = captureService.selectTAiViolationCaptureList(tAiViolationCapture);
        ExcelUtil<TAiViolationCaptureQuery> util = new ExcelUtil<TAiViolationCaptureQuery>(TAiViolationCaptureQuery.class);
        util.exportExcel(response, list, "AI违规抓拍数据");
    }

    /**
     * 获取AI违规抓拍详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(captureService.selectTAiViolationCaptureById(id));
    }

    /**
     * 新增AI违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:add')")
    @Log(title = "AI违规抓拍", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TAiViolationCapture tAiViolationCapture)
    {
        return toAjax(captureService.save(tAiViolationCapture));
    }

    /**
     * 修改AI违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:edit')")
    @Log(title = "AI违规抓拍", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TAiViolationCapture tAiViolationCapture)
    {
        return toAjax(captureService.updateById(tAiViolationCapture));
    }

    /**
     * 删除AI违规抓拍
     */
    //@PreAuthorize("@ss.hasPermi('web:capture:remove')")
    @Log(title = "AI违规抓拍", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(captureService.deleteTAiViolationCaptureByIds(ids));
    }
}
