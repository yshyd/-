package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TInventoryQuery;
import com.fyzs.web.entity.vo.TInventoryExportVO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TInventory;
import com.fyzs.web.service.ITInventoryService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品批次库存Controller
 * 
 * @author ysh
 * @date 2025-10-30
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/inventory")
public class TInventoryController extends BaseController
{

    private final ITInventoryService tInventoryService;

    /**
     * 查询商品批次库存列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:list')")
    @GetMapping("/list")
    public TableDataInfo list(TInventoryQuery tInventory)
    {
        startPage();
        List<TInventoryQuery> list = tInventoryService.selectTInventoryList(tInventory);
        return getDataTable(list);
    }

    /**
     * 查询库存预警列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:list')")
    @GetMapping("/warn/list")
    public TableDataInfo warnList(TInventoryQuery tInventory){
        startPage();
        List<TInventoryQuery> list = tInventoryService.warnList(tInventory);
        return getDataTable(list);
    }

    /**
     * 下拉商品批次库存列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TInventoryQuery tInventory)
    {
        List<TInventoryQuery> list = tInventoryService.pullList(tInventory);
        return getDataTable(list);
    }
    /**
     * 下拉商品批次库存列表(分页)
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:list')")
    @GetMapping("/page/pull/list")
    public TableDataInfo pageList(TInventoryQuery tInventory)
    {
        startPage();
        List<TInventoryQuery> list = tInventoryService.pullList(tInventory);
        return getDataTable(list);
    }
    /**
     * 导出商品批次库存列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:export')")
    @Log(title = "商品批次库存", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TInventoryQuery tInventory)
    {
        List<TInventoryExportVO> list = tInventoryService.selectTInventoryExportList(tInventory);
        ExcelUtil<TInventoryExportVO> util = new ExcelUtil<TInventoryExportVO>(TInventoryExportVO.class);
        util.exportExcel(response, list, "商品库存汇总数据");
    }

    /**
     * 获取商品批次库存详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tInventoryService.selectTInventoryById(id));
    }

    /**
     * 新增商品批次库存
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:add')")
    @Log(title = "商品批次库存", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TInventory tInventory)
    {
        return toAjax(tInventoryService.save(tInventory));
    }

    /**
     * 修改商品批次库存
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:edit')")
    @Log(title = "商品批次库存", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TInventory tInventory)
    {
        return toAjax(tInventoryService.updateById(tInventory));
    }

    /**
     * 删除商品批次库存
     */
    //@PreAuthorize("@ss.hasPermi('web:inventory:remove')")
    @Log(title = "商品批次库存", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tInventoryService.deleteTInventoryByIds(ids));
    }
}
