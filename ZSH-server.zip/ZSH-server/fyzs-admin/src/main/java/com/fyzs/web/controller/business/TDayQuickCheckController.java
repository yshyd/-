package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TDayQuickCheckQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayQuickCheck;
import com.fyzs.web.service.ITDayQuickCheckService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常检查-日常快检Controller
 * 
 * @author ysh
 * @date 2025-11-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/quick/check")
public class TDayQuickCheckController extends BaseController
{

    private final ITDayQuickCheckService tDayQuickCheckService;

    private final ITAlarmService alarmService;


    /**
     * 查询学校食堂日管控-日常检查-日常快检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayQuickCheckQuery query)
    {
        startPage();
        List<TDayQuickCheckQuery> list = tDayQuickCheckService.selectTDayQuickCheckList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常检查-日常快检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:export')")
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayQuickCheckQuery query)
    {
        List<TDayQuickCheckQuery> list = tDayQuickCheckService.selectTDayQuickCheckList(query);
        ExcelUtil<TDayQuickCheckQuery> util = new ExcelUtil<TDayQuickCheckQuery>(TDayQuickCheckQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常检查-日常快检数据");
    }

    /**
     * 获取学校食堂日管控-日常检查-日常快检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:check:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDayQuickCheckService.selectTDayQuickCheckById(id));
    }

    /**
     * 新增学校食堂日管控-日常检查-日常快检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:add')")
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayQuickCheck tDayQuickCheck)
    {
        return toAjax(tDayQuickCheckService.insertTDayQuickCheck(tDayQuickCheck));
    }

    /**
     * 修改学校食堂日管控-日常检查-日常快检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:edit')")
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayQuickCheck tDayQuickCheck)
    {
        return toAjax(tDayQuickCheckService.updateTDayQuickCheck(tDayQuickCheck));
    }

    /**
     * 批量作废按钮
     */
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.UPDATE)
    @PostMapping("/batch/cancel")
    public AjaxResult batchCancel(@RequestBody Long[] ids)
    {
        return toAjax(tDayQuickCheckService.batchCancel(ids));
    }

    /**
     * 启用/禁用
     */
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.UPDATE)
    @PostMapping("/enable")
    public AjaxResult enable(@RequestBody TDayQuickCheck tDayQuickCheck) {
        return toAjax(tDayQuickCheckService.enable(tDayQuickCheck));
    }


    /**
     * 删除学校食堂日管控-日常检查-日常快检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:remove')")
    @Log(title = "学校食堂日管控-日常检查-日常快检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDayQuickCheckService.deleteTDayQuickCheckByIds(ids));
    }
}
