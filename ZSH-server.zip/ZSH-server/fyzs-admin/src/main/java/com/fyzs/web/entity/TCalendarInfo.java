package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;



import java.io.Serializable;

/**
 * 食堂运营配置对象 t_calendar_info
 *
 * @author ysh
 * @date 2025-10-25
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_calendar_info")
public class TCalendarInfo implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 年份 */
        @Schema(description = "年份")
        @Excel(name = "年份")
        private String dateYear;

        /** 月份 */
        @Schema(description = "月份")
        @Excel(name = "月份")
        private String dateMonth;

        /** 日 */
        @Schema(description = "日")
        @Excel(name = "日")
        private String dateDay;

        /** 日期(格式：2025-05-02) */
        @Schema(description = "日期(格式：2025-05-02)")
        @Excel(name = "日期(格式：2025-05-02)")
        private String date;

        /** 早餐供应情况：0不供应、1供应 */
        @Schema(description = "早餐供应情况：0不供应、1供应")
        @Excel(name = "早餐供应情况：0不供应、1供应")
        private Integer breakfast;

        /** 午餐供应情况：0不供应、1供应 */
        @Schema(description = "午餐供应情况：0不供应、1供应")
        @Excel(name = "午餐供应情况：0不供应、1供应")
        private Integer lunch;

        /** 晚餐供应情况：0不供应、1供应 */
        @Schema(description = "晚餐供应情况：0不供应、1供应")
        @Excel(name = "晚餐供应情况：0不供应、1供应")
        private Integer dinner;

        /** 创建人ID */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID")
        @Excel(name = "创建人ID")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

        /** 0有效1无效 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1无效")
        private String delFlag;


}
