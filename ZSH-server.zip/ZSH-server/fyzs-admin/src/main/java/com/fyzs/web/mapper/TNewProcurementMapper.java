package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TNewProcurement;
import com.fyzs.web.entity.query.TNewProcurementQuery;
import com.fyzs.web.entity.vo.TNewProcurementVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 商品采购Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@Mapper
public interface TNewProcurementMapper  extends BaseMapper<TNewProcurement>
{
    /**
     * 查询商品采购
     * 
     * @param id 商品采购主键
     * @return 商品采购
     */
    public TNewProcurementQuery selectTNewProcurementById(Long id);

    /**
     * 查询商品采购列表
     * 
     * @param tNewProcurement 商品采购
     * @return 商品采购集合
     */
    public List<TNewProcurementQuery> selectTNewProcurementList(TNewProcurementQuery tNewProcurement);

    /**
     * 新增商品采购
     * 
     * @param tNewProcurement 商品采购
     * @return 结果
     */
    public int insertTNewProcurement(TNewProcurement tNewProcurement);

    /**
     * 修改商品采购
     * 
     * @param tNewProcurement 商品采购
     * @return 结果
     */
    public int updateTNewProcurement(TNewProcurement tNewProcurement);

    /**
     * 删除商品采购
     * 
     * @param id 商品采购主键
     * @return 结果
     */
    public int deleteTNewProcurementById(Long id);

    /**
     * 批量删除商品采购
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewProcurementByIds(Long[] ids);

    String selectMaxOrderNumByDatePrefix(@Param("datePrefix")String datePrefix);

    /**
     * 根据ID列表批量查询采购订单
     * @param ids 采购订单ID数组
     * @return 采购订单列表
     */
    List<TNewProcurement> selectByIds(@Param("ids") Long[] ids);

    List<TNewProcurementVO> selectExportList(TNewProcurementQuery tNewProcurement);

    int countOrdersBySupplierAndDate(@Param("id")Long id,@Param("todayStart") Date todayStart,@Param("todayEnd") Date todayEnd);
}
