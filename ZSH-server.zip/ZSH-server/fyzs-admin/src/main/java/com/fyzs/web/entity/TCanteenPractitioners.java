package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食堂人员基础信息对象 t_canteen_practitioners
 *
 * @author ysh
 * @date 2025-10-26
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_canteen_practitioners")
public class TCanteenPractitioners implements Serializable {

    private static final long serialVersionUID = 1L;

        /** 主键 */
        @Schema(description = "主键")
        private Long id;

        /** 人员名称 */
        @Schema(description = "人员名称")
        @Excel(name = "人员名称")
        private String name;

        /** 性别 0女 1男 */
        @Schema(description = "性别 0女 1男")
        @Excel(name = "性别 0女 1男")
        private String sex;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        @Schema(description = "主体名称")
        private String deptName;

    /** 区域id */
        @Schema(description = "区域id")
        @Excel(name = "区域id")
        private Long areaId;

        /** 身份证号码 */
        @Schema(description = "身份证号码")
        @Excel(name = "身份证号码")
        private String idCard;

        /** 身份证照片正面照片 */
        @Schema(description = "身份证照片正面照片")
        @Excel(name = "身份证照片正面照片")
        private String idCardFront;

        /** 身份证照片背面照片 */
        @Schema(description = "身份证照片背面照片")
        @Excel(name = "身份证照片背面照片")
        private String idCardBack;

        /** 电话号码 */
        @Schema(description = "电话号码")
        @Excel(name = "电话号码")
        private String phoneNumber;

        /** 入职时间 */
        @Schema(description = "入职时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "入职时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date entryTime;

        /** 健康证号码 */
        @Schema(description = "健康证号码")
        @Excel(name = "健康证号码")
        private String healthCertificate;

        /** 健康证开始日期 */
        @Schema(description = "健康证开始日期")
        @Excel(name = "健康证开始日期")
        private String healthCertificateStart;

        /** 健康证结束日期 */
        @Schema(description = "健康证结束日期")
        @Excel(name = "健康证结束日期")
        private String healthCertificateEnd;

        /** 健康证照片逗号分割 */
        @Schema(description = "健康证照片逗号分割")
        @Excel(name = "健康证照片逗号分割")
        private String healthCertificateImg;

        /** 食品安全培训合格证号码 */
        @Schema(description = "食品安全培训合格证号码")
        @Excel(name = "食品安全培训合格证号码")
        private String healthTrainCertificate;

        /** 食品安全培训合格证开始日期 */
        @Schema(description = "食品安全培训合格证开始日期")
        @Excel(name = "食品安全培训合格证开始日期")
        private String healthTrainCertificateStart;

        /** 食品安全培训合格证结束日期 */
        @Schema(description = "食品安全培训合格证结束日期")
        @Excel(name = "食品安全培训合格证结束日期")
        private String healthTrainCertificateEnd;

        /** 食品安全培训合格证照片逗号分割 */
        @Schema(description = "食品安全培训合格证照片逗号分割")
        @Excel(name = "食品安全培训合格证照片逗号分割")
        private String healthTrainCertificateImg;

        /** 留样柜开锁口令(单个主体下面4位不重复的数字) */
        @Schema(description = "留样柜开锁口令(单个主体下面4位不重复的数字)")
        @Excel(name = "留样柜开锁口令(单个主体下面4位不重复的数字)")
        private String reservedPassword;

        /** 是否日检0是1否 */
        @Schema(description = "是否日检0是1否")
        @Excel(name = "是否日检0是1否")
        private String isCheck;

        /** 是否培训0是1否 */
        @Schema(description = "是否培训0是1否")
        @Excel(name = "是否培训0是1否")
        private Integer isTrain;

        /** 是否可以留样 */
        @Schema(description = "是否可以留样")
        @Excel(name = "是否可以留样")
        private String isReserved;

        /** 家庭详细住址 */
        @Schema(description = "家庭详细住址")
        @Excel(name = "家庭详细住址")
        private String houseAddress;

        /** 学历(0文盲，1小学、2初中、3高中、4专科、5本科、6硕士、7博士) */
        @Schema(description = "学历(0文盲，1小学、2初中、3高中、4专科、5本科、6硕士、7博士)")
        @Excel(name = "学历(0文盲，1小学、2初中、3高中、4专科、5本科、6硕士、7博士)")
        private String education;

        /** 头像地址 */
        @Schema(description = "头像地址")
        @Excel(name = "头像地址")
        private String portrait;

        /** 删除标识(0有效1无效) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "删除标识(0有效1无效)")
        private Integer delFlag;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

        /** 创建人ID */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID")
        @Excel(name = "创建人ID")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

}
