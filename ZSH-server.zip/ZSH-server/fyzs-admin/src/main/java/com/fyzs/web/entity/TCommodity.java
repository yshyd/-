package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 系统标准商品库对象 t_commodity
 *
 * @author ysh
 * @date 2025-10-28
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_commodity")
public class TCommodity implements Serializable {

    private static final long serialVersionUID = 1L;

        /** 主键id */
        @Schema(description = "主键id")
        private Long id;

        /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
        @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
        private String commodityCode;

        /** 商品名称 */
        @Schema(description = "商品名称")
        @Excel(name = "商品名称")
        private String commodityName;

        /** 商品类别id */
        @Schema(description = "商品类别id")
        private Long categoryId;

        /** 品牌 */
        @Schema(description = "品牌")
        @Excel(name = "品牌")
        private String brand;

        /** 型号 */
        @Schema(description = "型号")
        @Excel(name = "型号")
        private String model;

        /** 规格 */
        @Schema(description = "规格")
        @Excel(name = "规格")
        private String specification;

        /** 商品类型(0预包装1非预包装) */
        @Schema(description = "商品类型(0预包装1非预包装)")
        private Integer type;

        /** 图片 */
        @Schema(description = "图片")
        private String img;

        /** 是否有效【1无效，0有效】 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "是否有效【1无效，0有效】")
        private Integer delFlag;

        /** 创建日期 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建日期")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        private Long createUser;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        private String updateName;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        private String createName;

}
