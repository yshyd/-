package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 入库记录对象 t_new_procurement_warehouse
 *
 * @author ysh
 * @date 2025-10-30
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_new_procurement_warehouse")
public class TNewProcurementWarehouse implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 仓库id */
        @Schema(description = "仓库id")
        @Excel(name = "仓库id")
        private Long warehouseId;

        /** 采购ID */
        @Schema(description = "采购ID")
        @Excel(name = "采购ID")
        private Long procurementId;

        /** 采购单号 */
        @Schema(description = "采购单号")
        @Excel(name = "采购单号")
        private String procurementNum;

        /** 验收记录ID(验收入库必传) */
        @Schema(description = "验收记录ID(验收入库必传)")
        @Excel(name = "验收记录ID(验收入库必传)")
        private Long acceptanceId;

        /** 入库类型：0采购验收入库1初始入库2调拨入库3盘盈入库 */
        @Schema(description = "入库类型：0采购验收入库1初始入库2调拨入库3盘盈入库4退领入库5退货撤销入库")
        @Excel(name = "入库类型：0采购验收入库1初始入库2调拨入库3盘盈入库4退领入库5退货撤销入库")
        private Integer type;

        /** 批次(生成规则：YS/CS+PC+20251029+仓库ID+商品ID+000001递增) 注意不要重复 */
        @Schema(description = "批次(生成规则：YS/CS+PC+20251029+仓库ID+商品ID+000001递增)注意不要重复")
        @Excel(name = "批次(生成规则：YS/CS+PC+20251029+仓库ID+商品ID+000001递增)注意不要重复")
        private String batch;

        /** 入库商品ID */
        @Schema(description = "入库商品ID")
        @Excel(name = "入库商品ID")
        private Long commodityId;

        /** 入库数量 */
        @Schema(description = "入库数量")
        @Excel(name = "入库数量")
        private BigDecimal innerNumber;

        /** 生产日期(验收时必填) */
        @Schema(description = "生产日期(验收时必填)")
        @Excel(name = "生产日期(验收时必填)")
        private String productionDate;

        /** 保质期数量(验收时必填) */
        @Schema(description = "保质期数量(验收时必填)")
        @Excel(name = "保质期数量(验收时必填)")
        private Integer shelfLifeNumber;

        /** 保质期类型(0天，1月)，验收时必填 */
        @Schema(description = "保质期类型(0天，1月)，验收时必填")
        @Excel(name = "保质期类型(0天，1月)，验收时必填")
        private Integer shelfLifeType;

        /** 保质期到期日期(验收时计算) */
        @Schema(description = "保质期到期日期(验收时计算)")
        @Excel(name = "保质期到期日期(验收时计算)")
        private String endDate;

        /** 入库人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "入库人id")
        @Excel(name = "入库人id")
        private Long createUser;

        /** 入库人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "入库人姓名")
        @Excel(name = "入库人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss ")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
