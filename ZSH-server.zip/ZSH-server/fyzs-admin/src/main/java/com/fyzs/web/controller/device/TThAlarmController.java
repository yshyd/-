package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TThAlarmQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TThAlarm;
import com.fyzs.web.service.ITThAlarmService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 温湿度检测仪的告警记录Controller
 * 
 * @author ysh
 * @date 2026-08-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/alarm")
public class TThAlarmController extends BaseController
{

    private final ITThAlarmService tThAlarmService;

    /**
     * 查询温湿度检测仪的告警记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:list')")
    @GetMapping("/th/list")
    public TableDataInfo list(TThAlarmQuery tThAlarm)
    {
        startPage();
        List<TThAlarmQuery> list = tThAlarmService.selectTThAlarmList(tThAlarm);
        return getDataTable(list);
    }

    /**
     * 导出温湿度检测仪的告警记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:export')")
    @Log(title = "温湿度检测仪的告警记录", businessType = BusinessType.EXPORT)
    @PostMapping("/th/export")
    public void export(HttpServletResponse response, TThAlarmQuery tThAlarm)
    {
        List<TThAlarmQuery> list = tThAlarmService.selectTThAlarmList(tThAlarm);
        ExcelUtil<TThAlarmQuery> util = new ExcelUtil<TThAlarmQuery>(TThAlarmQuery.class);
        util.exportExcel(response, list, "温湿度检测仪的告警记录数据");
    }

    /**
     * 获取温湿度检测仪的告警记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:query')")
    @GetMapping(value = "/th/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tThAlarmService.selectTThAlarmById(id));
    }

    /**
     * 新增温湿度检测仪的告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:add')")
    @Log(title = "温湿度检测仪的告警记录", businessType = BusinessType.INSERT)
    @PostMapping("/th/add")
    public AjaxResult add(@RequestBody TThAlarm tThAlarm)
    {
        return toAjax(tThAlarmService.save(tThAlarm));
    }

    /**
     * 修改温湿度检测仪的告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:edit')")
    @Log(title = "温湿度检测仪的告警记录", businessType = BusinessType.UPDATE)
    @PutMapping("/th/edit")
    public AjaxResult edit(@RequestBody TThAlarm tThAlarm)
    {
        return toAjax(tThAlarmService.updateById(tThAlarm));
    }

    /**
     * 删除温湿度检测仪的告警记录
     */
    //@PreAuthorize("@ss.hasPermi('web:alarm:remove')")
    @Log(title = "温湿度检测仪的告警记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/th/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tThAlarmService.deleteTThAlarmByIds(ids));
    }
}
