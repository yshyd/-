package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TMonitoringLinksConfig;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.util.List;

@Data
public class TCameraDTO {

    @Schema(description = "配置列表")
    private List<TMonitoringLinksConfigDTO> configList;
}
