package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 违法违规监管部门地方催办信息对象 t_regulations_sup_handle
 *
 * @author ysh
 * @date 2025-10-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_regulations_sup_handle")
public class TRegulationsSupHandle implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $column.columnComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 违法违规识别信息表的主键ID */
        @Schema(description = "违法违规识别信息表的主键ID")
        @Excel(name = "违法违规识别信息表的主键ID")
        private Long riskID;

        /** 监管处理责任人所在单位。 */
        @Schema(description = "监管处理责任人所在单位。")
        @Excel(name = "监管处理责任人所在单位。")
        private String superPersonUnit;

        /** 对应违法违规处置监管人员姓名 */
        @Schema(description = "对应违法违规处置监管人员姓名")
        @Excel(name = "对应违法违规处置监管人员姓名")
        private String superVisor;

        /** 监管人员联系方式（手机号） */
        @Schema(description = "监管人员联系方式（手机号）")
        @Excel(name = "监管人员联系方式", readConverterExp = "手=机号")
        private String superVisorTEL;

        /** 0未催办1已催办 */
        @Schema(description = "0未催办 1已催办")
        @Excel(name = "0未催办 1已催办")
        private String iSUrging;

        /** 催办时间，格式“YYYY-MM-DDhh-mm-ss” */
        @Schema(description = "催办时间，格式“YYYY-MM-DDhh-mm-ss”")
        @Excel(name = "催办时间，格式“YYYY-MM-DDhh-mm-ss”")
        private String urgingTime;

        /** 催办意见 */
        @Schema(description = "催办意见")
        @Excel(name = "催办意见")
        private String urgentOpinions;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

        /** 0启用1禁用 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0启用1禁用")
        private Long delFlag;

}
