package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TNewAllocationDTO;
import com.fyzs.web.entity.query.TNewAllocationQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewAllocation;
import com.fyzs.web.service.ITNewAllocationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 库间调拨记录Controller
 * 
 * @author ysh
 * @date 2025-10-31
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/allocation")
public class TNewAllocationController extends BaseController
{

    private final ITNewAllocationService tNewAllocationService;

    /**
     * 查询库间调拨记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewAllocationQuery tNewAllocation)
    {
        startPage();
        List<TNewAllocationQuery> list = tNewAllocationService.selectTNewAllocationList(tNewAllocation);
        return getDataTable(list);
    }

    /**
     * 导出库间调拨记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:export')")
    @Log(title = "库间调拨记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewAllocationQuery tNewAllocation)
    {
        List<TNewAllocationQuery> list = tNewAllocationService.selectTNewAllocationList(tNewAllocation);
        ExcelUtil<TNewAllocationQuery> util = new ExcelUtil<TNewAllocationQuery>(TNewAllocationQuery.class);
        util.exportExcel(response, list, "库间调拨记录数据");
    }

    /**
     * 获取库间调拨记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tNewAllocationService.selectTNewAllocationById(id));
    }

    /**
     * 确认操作
     */
    @PostMapping("/confirm")
    public AjaxResult confirm(@RequestBody TNewAllocationDTO dto) {
        return AjaxResult.success(tNewAllocationService.confirm(dto)) ;
    }
    /**
     * 新增库间调拨记录
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:add')")
    @Log(title = "库间调拨记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewAllocation tNewAllocation)
    {
        return toAjax(tNewAllocationService.save(tNewAllocation));
    }

    /**
     * 修改库间调拨记录
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:edit')")
    @Log(title = "库间调拨记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewAllocation tNewAllocation)
    {
        return toAjax(tNewAllocationService.updateById(tNewAllocation));
    }

    /**
     * 删除库间调拨记录
     */
    //@PreAuthorize("@ss.hasPermi('web:allocation:remove')")
    @Log(title = "库间调拨记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tNewAllocationService.deleteTNewAllocationByIds(ids));
    }
}
