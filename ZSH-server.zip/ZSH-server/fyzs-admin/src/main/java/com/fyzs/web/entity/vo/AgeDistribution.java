package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class AgeDistribution {
    @Schema(description = "25岁以下")
    private int under25Count;
    @Schema(description = "25-35岁")
    private int twentyFiveTo35Count;
    @Schema(description = "36-45岁")
    private int thirtySixTo45Count;
    @Schema(description = "45岁以上")
    private int over45Count;

    private double under25Ratio ;
    private double twentyFiveTo35Ratio;
    private double thirtySixTo45Ratio;
    private double over45Ratio;
}
