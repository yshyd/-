package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TAirRecodeQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TAirRecode;
import com.fyzs.web.service.ITAirRecodeService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 空气消毒净化记录Controller
 * 
 * @author ysh
 * @date 2026-08-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/air/recode")
public class TAirRecodeController extends BaseController
{

    private final ITAirRecodeService tAirRecodeService;

    /**
     * 查询空气消毒净化记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:list')")
    @GetMapping("/list")
    public TableDataInfo list(TAirRecodeQuery tAirRecode)
    {
        startPage();
        List<TAirRecodeQuery> list = tAirRecodeService.selectTAirRecodeList(tAirRecode);
        return getDataTable(list);
    }

    /**
     * 导出空气消毒净化记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:export')")
    @Log(title = "空气消毒净化记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TAirRecodeQuery tAirRecode)
    {
        List<TAirRecodeQuery> list = tAirRecodeService.selectTAirRecodeList(tAirRecode);
        ExcelUtil<TAirRecodeQuery> util = new ExcelUtil<TAirRecodeQuery>(TAirRecodeQuery.class);
        util.exportExcel(response, list, "空气消毒净化记录数据");
    }

    /**
     * 获取空气消毒净化记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tAirRecodeService.selectTAirRecodeById(id));
    }

    /**
     * 新增空气消毒净化记录
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:add')")
    @Log(title = "空气消毒净化记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TAirRecode tAirRecode)
    {
        return toAjax(tAirRecodeService.save(tAirRecode));
    }

    /**
     * 修改空气消毒净化记录
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:edit')")
    @Log(title = "空气消毒净化记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TAirRecode tAirRecode)
    {
        return toAjax(tAirRecodeService.updateById(tAirRecode));
    }

    /**
     * 删除空气消毒净化记录
     */
    //@PreAuthorize("@ss.hasPermi('web:recode:remove')")
    @Log(title = "空气消毒净化记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tAirRecodeService.deleteTAirRecodeByIds(ids));
    }
}
