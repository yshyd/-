package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayPlaceCheck;
import com.fyzs.web.entity.query.TDayPlaceCheckQuery;

/**
 * 学校食堂日管控-日常巡检-场所环境卫生巡检Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayPlaceCheckService extends IService<TDayPlaceCheck>
{
    /**
     * 查询学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param id 学校食堂日管控-日常巡检-场所环境卫生巡检主键
     * @return 学校食堂日管控-日常巡检-场所环境卫生巡检
     */
    public TDayPlaceCheckQuery selectTDayPlaceCheckById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-场所环境卫生巡检列表
     * 

     * @return 学校食堂日管控-日常巡检-场所环境卫生巡检集合
     */
    public List<TDayPlaceCheckQuery> selectTDayPlaceCheckList(TDayPlaceCheckQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param tDayPlaceCheck 学校食堂日管控-日常巡检-场所环境卫生巡检
     * @return 结果
     */
    public int insertTDayPlaceCheck(TDayPlaceCheck tDayPlaceCheck);

    /**
     * 修改学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param tDayPlaceCheck 学校食堂日管控-日常巡检-场所环境卫生巡检
     * @return 结果
     */
    public int updateTDayPlaceCheck(TDayPlaceCheck tDayPlaceCheck);

    /**
     * 批量删除学校食堂日管控-日常巡检-场所环境卫生巡检
     * 
     * @param ids 需要删除的学校食堂日管控-日常巡检-场所环境卫生巡检主键集合
     * @return 结果
     */
    public int deleteTDayPlaceCheckByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常巡检-场所环境卫生巡检信息
     * 
     * @param id 学校食堂日管控-日常巡检-场所环境卫生巡检主键
     * @return 结果
     */
    public int deleteTDayPlaceCheckById(Long id);

    int cancel(TDayPlaceCheck tDayPlaceCheck);
}
