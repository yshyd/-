package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TSampleDeviceOperation;
import com.fyzs.web.entity.query.TSampleDeviceOperationQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 留样柜操作日志Mapper接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
@org.apache.ibatis.annotations.Mapper
public interface TSampleDeviceOperationMapper  extends BaseMapper<TSampleDeviceOperation>
{
    /**
     * 查询留样柜操作日志
     * 
     * @param id 留样柜操作日志主键
     * @return 留样柜操作日志
     */
    public TSampleDeviceOperationQuery selectTSampleDeviceOperationById(Long id);

    /**
     * 查询留样柜操作日志列表
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 留样柜操作日志集合
     */
    public List<TSampleDeviceOperationQuery> selectTSampleDeviceOperationList(TSampleDeviceOperationQuery tSampleDeviceOperation);

    /**
     * 新增留样柜操作日志
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 结果
     */
    public int insertTSampleDeviceOperation(TSampleDeviceOperation tSampleDeviceOperation);

    /**
     * 修改留样柜操作日志
     * 
     * @param tSampleDeviceOperation 留样柜操作日志
     * @return 结果
     */
    public int updateTSampleDeviceOperation(TSampleDeviceOperation tSampleDeviceOperation);

    /**
     * 删除留样柜操作日志
     * 
     * @param id 留样柜操作日志主键
     * @return 结果
     */
    public int deleteTSampleDeviceOperationById(Long id);

    /**
     * 批量删除留样柜操作日志
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTSampleDeviceOperationByIds(Long[] ids);
}
