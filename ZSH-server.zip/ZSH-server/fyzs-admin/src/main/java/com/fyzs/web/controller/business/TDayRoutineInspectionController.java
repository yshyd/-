package com.fyzs.web.controller.business;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TDayRoutineInspectionQuery;
import com.fyzs.web.service.ITAlarmService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayRoutineInspection;
import com.fyzs.web.service.ITDayRoutineInspectionService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 学校食堂日管控-日常检查-常规日检Controller
 * 
 * @author ysh
 * @date 2025-11-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/inspection")
public class TDayRoutineInspectionController extends BaseController
{

    private final ITDayRoutineInspectionService tDayRoutineInspectionService;

    private final ITAlarmService alarmService;


    /**
     * 查询学校食堂日管控-日常检查-常规日检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayRoutineInspectionQuery query)
    {
        startPage();
        List<TDayRoutineInspectionQuery> list = tDayRoutineInspectionService.selectTDayRoutineInspectionList(query);
        return getDataTable(list);
    }

    /**
     * 导出学校食堂日管控-日常检查-常规日检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:export')")
    @Log(title = "学校食堂日管控-日常检查-常规日检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayRoutineInspectionQuery query)
    {
        List<TDayRoutineInspectionQuery> list = tDayRoutineInspectionService.selectTDayRoutineInspectionList(query);
        ExcelUtil<TDayRoutineInspectionQuery> util = new ExcelUtil<TDayRoutineInspectionQuery>(TDayRoutineInspectionQuery.class);
        util.exportExcel(response, list, "学校食堂日管控-日常检查-常规日检数据");
    }

    /**
     * 获取学校食堂日管控-日常检查-常规日检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDayRoutineInspectionService.selectTDayRoutineInspectionById(id));
    }

    /**
     * 新增学校食堂日管控-日常检查-常规日检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:add')")
    @Log(title = "学校食堂日管控-日常检查-常规日检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayRoutineInspection tDayRoutineInspection)
    {

        List<TDayRoutineInspection> list = tDayRoutineInspectionService.list(new LambdaQueryWrapper<TDayRoutineInspection>()
                .eq(TDayRoutineInspection::getDeptId, tDayRoutineInspection.getDeptId())
                .eq(TDayRoutineInspection::getDate, tDayRoutineInspection.getDate())
        );

        if ( !list.isEmpty()){
            return error("当日该主体已经存在日检记录，如有需要可通过'修改'按钮进行修改或通过'启用'按钮生效后再通过'修改'按钮进行变更");
        }
//        calculateFinalResult(tDayRoutineInspection);
        return toAjax(tDayRoutineInspectionService.insertTDayRoutineInspection(tDayRoutineInspection));
    }

    /**
     * 修改学校食堂日管控-日常检查-常规日检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:edit')")
    @Log(title = "学校食堂日管控-日常检查-常规日检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayRoutineInspection tDayRoutineInspection)
    {
        long count = tDayRoutineInspectionService.count(new LambdaQueryWrapper<TDayRoutineInspection>()
                .eq(TDayRoutineInspection::getDeptId, tDayRoutineInspection.getDeptId())
                .eq(TDayRoutineInspection::getCheckTime, tDayRoutineInspection.getCheckTime())
                .ne(TDayRoutineInspection::getId, tDayRoutineInspection.getId())
        );
        if (count > 0){
            return error("当日该主体已经存在日检记录，如有需要可通过'修改'按钮进行修改或通过'启用'按钮生效后再通过'修改'按钮进行变更");
        }
//        calculateFinalResult(tDayRoutineInspection);
        return toAjax(tDayRoutineInspectionService.updateTDayRoutineInspection(tDayRoutineInspection));
    }


    /**
     * 启用/禁用
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:edit')")
    @Log(title = "学校食堂日管控-日常检查-常规日检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TDayRoutineInspection tDayRoutineInspection)
    {

        return toAjax(tDayRoutineInspectionService.cancel(tDayRoutineInspection));
    }

    private void calculateFinalResult(TDayRoutineInspection inspection) {

        List<Integer> inspectionItems = Arrays.asList(
                inspection.getPersonalHygiene(),
                inspection.getPhysicalMentalState(),
                inspection.getSwitchSocket(),
                inspection.getDoorsWindows(),
                inspection.getWallCornerCeiling(),
                inspection.getKitchen(),
                inspection.getRoughProcessingSite(),
                inspection.getSewer(),
                inspection.getTrashcan(),
                inspection.getRotDeteriorate(),
                inspection.getVegetableStandardsGarbageDisposal(),
                inspection.getMeatAndVegetables(),
                inspection.getBasinFrame(),
                inspection.getMeal(),
                inspection.getLunch(),
                inspection.getSellIndividualMeals(),
                inspection.getReserved(),
                inspection.getFinishedMeal(),
                inspection.getStove(),
                inspection.getKitchenware(),
                inspection.getOperationConsole(),
                inspection.getDisinfectionTank(),
                inspection.getTableware(),
                inspection.getFireFightingEquipment(),
                inspection.getFourPestsFacilities()
        );


        boolean hasUnqualified = inspectionItems.stream()
                .filter(Objects::nonNull)
                .anyMatch(item -> item == 1);

        inspection.setResult(hasUnqualified ? 1 : 0);
    }


    /**
     * 删除学校食堂日管控-日常检查-常规日检
     */
    //@PreAuthorize("@ss.hasPermi('web:inspection:remove')")
    @Log(title = "学校食堂日管控-日常检查-常规日检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDayRoutineInspectionService.deleteTDayRoutineInspectionByIds(ids));
    }
}
