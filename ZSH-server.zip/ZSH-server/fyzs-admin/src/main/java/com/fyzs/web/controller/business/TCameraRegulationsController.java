package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TCameraRegulations;
import com.fyzs.web.service.ITCameraRegulationsService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 违法违规行为识别信息Controller
 * 
 * @author ysh
 * @date 2025-10-21
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/regulations")
public class TCameraRegulationsController extends BaseController
{

    private final ITCameraRegulationsService tCameraRegulationsService;

    /**
     * 查询违法违规行为识别信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:list')")
    @GetMapping("/list")
    public TableDataInfo list(TCameraRegulations tCameraRegulations)
    {
        startPage();
        List<TCameraRegulations> list = tCameraRegulationsService.selectTCameraRegulationsList(tCameraRegulations);
        return getDataTable(list);
    }

    /**
     * 导出违法违规行为识别信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:export')")
    @Log(title = "违法违规行为识别信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TCameraRegulations tCameraRegulations)
    {
        List<TCameraRegulations> list = tCameraRegulationsService.selectTCameraRegulationsList(tCameraRegulations);
        ExcelUtil<TCameraRegulations> util = new ExcelUtil<TCameraRegulations>(TCameraRegulations.class);
        util.exportExcel(response, list, "违法违规行为识别信息数据");
    }

    /**
     * 获取违法违规行为识别信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tCameraRegulationsService.selectTCameraRegulationsById(id));
    }

    /**
     * 新增违法违规行为识别信息
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:add')")
    @Log(title = "违法违规行为识别信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TCameraRegulations tCameraRegulations)
    {
        return toAjax(tCameraRegulationsService.save(tCameraRegulations));
    }

    /**
     * 修改违法违规行为识别信息
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:edit')")
    @Log(title = "违法违规行为识别信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TCameraRegulations tCameraRegulations)
    {
        return toAjax(tCameraRegulationsService.updateById(tCameraRegulations));
    }

    /**
     * 删除违法违规行为识别信息
     */
    //@PreAuthorize("@ss.hasPermi('web:regulations:remove')")
    @Log(title = "违法违规行为识别信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tCameraRegulationsService.deleteTCameraRegulationsByIds(ids));
    }
}
