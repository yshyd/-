package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TWeekChemicals;
import com.fyzs.web.entity.query.TWeekChemicalsQuery;

/**
 * 学校食堂周排查-化学品风险排查Service接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
public interface ITWeekChemicalsService extends IService<TWeekChemicals>
{
    /**
     * 查询学校食堂周排查-化学品风险排查
     * 
     * @param id 学校食堂周排查-化学品风险排查主键
     * @return 学校食堂周排查-化学品风险排查
     */
    public TWeekChemicalsQuery selectTWeekChemicalsById(Long id);

    /**
     * 查询学校食堂周排查-化学品风险排查列表
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 学校食堂周排查-化学品风险排查集合
     */
    public List<TWeekChemicalsQuery> selectTWeekChemicalsList(TWeekChemicalsQuery tWeekChemicals);

    /**
     * 新增学校食堂周排查-化学品风险排查
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 结果
     */
    public int insertTWeekChemicals(TWeekChemicals tWeekChemicals);

    /**
     * 修改学校食堂周排查-化学品风险排查
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 结果
     */
    public int updateTWeekChemicals(TWeekChemicals tWeekChemicals);

    /**
     * 批量删除学校食堂周排查-化学品风险排查
     * 
     * @param ids 需要删除的学校食堂周排查-化学品风险排查主键集合
     * @return 结果
     */
    public int deleteTWeekChemicalsByIds(Long[] ids);

    /**
     * 删除学校食堂周排查-化学品风险排查信息
     * 
     * @param id 学校食堂周排查-化学品风险排查主键
     * @return 结果
     */
    public int deleteTWeekChemicalsById(Long id);

    int cancel(TWeekChemicals tWeekChemicals);
}
