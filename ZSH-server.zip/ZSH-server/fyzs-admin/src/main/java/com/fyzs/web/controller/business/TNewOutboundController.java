package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.dto.TNewOutboundDTO;
import com.fyzs.web.entity.query.TNewOutboundQuery;
import com.fyzs.web.entity.vo.TNewOutboundExportVO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewOutbound;
import com.fyzs.web.service.ITNewOutboundService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 出库记录Controller
 * 
 * @author ysh
 * @date 2025-10-30
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/outbound")
public class TNewOutboundController extends BaseController
{

    private final ITNewOutboundService tNewOutboundService;

    /**
     * 查询出库记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewOutboundQuery tNewOutbound)
    {
        startPage();
        List<TNewOutboundQuery> list = tNewOutboundService.selectTNewOutboundList(tNewOutbound);
        return getDataTable(list);
    }

    /**
     * 退领入库查询列表(弹窗)
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:list')")
    @GetMapping("/out/list")
    public TableDataInfo outList(TNewOutboundQuery tNewOutbound)
    {

        List<TNewOutboundQuery> list = tNewOutboundService.selectTNewOutList(tNewOutbound);
        return getDataTable(list);
    }
    /**
     * 下拉查询出库记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TNewOutboundQuery tNewOutbound)
    {
        List<TNewOutboundQuery> list = tNewOutboundService.selectTNewOutboundList(tNewOutbound);
        return getDataTable(list);
    }


    /**
     * 导出出库记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:export')")
    @Log(title = "出库记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewOutboundQuery tNewOutbound)
    {
        List<TNewOutboundExportVO> list = tNewOutboundService.selectTNewOutboundExportList(tNewOutbound);
        ExcelUtil<TNewOutboundExportVO> util = new ExcelUtil<TNewOutboundExportVO>(TNewOutboundExportVO.class);
        util.exportExcel(response, list, "出库记录数据");
    }

    /**
     * 出库操作按钮
     */
    @Log(title = "出库记录", businessType = BusinessType.UPDATE)
    @PostMapping("/confirm")
    public AjaxResult confirm(@RequestBody TNewOutboundDTO dto) {
        return AjaxResult.success(tNewOutboundService.confirm(dto)) ;
    }

    /**
     * 获取出库记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tNewOutboundService.selectTNewOutboundById(id));
    }

    /**
     * 新增出库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:add')")
    @Log(title = "出库记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewOutbound tNewOutbound)
    {
        return toAjax(tNewOutboundService.save(tNewOutbound));
    }

    /**
     * 修改出库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:edit')")
    @Log(title = "出库记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewOutbound tNewOutbound)
    {
        return toAjax(tNewOutboundService.updateById(tNewOutbound));
    }

    /**
     * 删除出库记录
     */
    //@PreAuthorize("@ss.hasPermi('web:outbound:remove')")
    @Log(title = "出库记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tNewOutboundService.deleteTNewOutboundByIds(ids));
    }
}
