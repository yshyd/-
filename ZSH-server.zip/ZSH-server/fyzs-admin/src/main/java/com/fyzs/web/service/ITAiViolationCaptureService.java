package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TAiViolationCapture;
import com.fyzs.web.entity.query.TAiViolationCaptureQuery;

/**
 * AI违规抓拍Service接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
public interface ITAiViolationCaptureService extends IService<TAiViolationCapture>
{
    /**
     * 查询AI违规抓拍
     * 
     * @param id AI违规抓拍主键
     * @return AI违规抓拍
     */
    public TAiViolationCaptureQuery selectTAiViolationCaptureById(Long id);

    /**
     * 查询AI违规抓拍列表
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return AI违规抓拍集合
     */
    public List<TAiViolationCaptureQuery> selectTAiViolationCaptureList(TAiViolationCaptureQuery tAiViolationCapture);

    /**
     * 新增AI违规抓拍
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return 结果
     */
    public int insertTAiViolationCapture(TAiViolationCapture tAiViolationCapture);

    /**
     * 修改AI违规抓拍
     * 
     * @param tAiViolationCapture AI违规抓拍
     * @return 结果
     */
    public int updateTAiViolationCapture(TAiViolationCapture tAiViolationCapture);

    /**
     * 批量删除AI违规抓拍
     * 
     * @param ids 需要删除的AI违规抓拍主键集合
     * @return 结果
     */
    public int deleteTAiViolationCaptureByIds(Long[] ids);

    /**
     * 删除AI违规抓拍信息
     * 
     * @param id AI违规抓拍主键
     * @return 结果
     */
    public int deleteTAiViolationCaptureById(Long id);
}
