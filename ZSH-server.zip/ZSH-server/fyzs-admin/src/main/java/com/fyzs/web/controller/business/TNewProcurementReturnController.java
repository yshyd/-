package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;


import com.fyzs.web.entity.dto.TNewProcurementReturnDTO;
import com.fyzs.web.entity.query.TNewProcurementReturnQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewProcurementReturn;
import com.fyzs.web.service.ITNewProcurementReturnService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 退货记录Controller
 *
 * @author ysh
 * @date 2025-10-30
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/return")
public class TNewProcurementReturnController extends BaseController {

    private final ITNewProcurementReturnService tNewProcurementReturnService;

    /**
     * 查询退货记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:return:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewProcurementReturnQuery tNewProcurementReturn) {
        startPage();
        List<TNewProcurementReturnQuery> list = tNewProcurementReturnService.selectTNewProcurementReturnList(tNewProcurementReturn);
        return getDataTable(list);
    }

    /**
     * 导出退货记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:return:export')")
    @Log(title = "退货记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewProcurementReturnQuery tNewProcurementReturn) {
        List<TNewProcurementReturnQuery> list = tNewProcurementReturnService.selectTNewProcurementReturnList(tNewProcurementReturn);
        ExcelUtil<TNewProcurementReturnQuery> util = new ExcelUtil<TNewProcurementReturnQuery>(TNewProcurementReturnQuery.class);
        util.exportExcel(response, list, "退货记录数据");
    }

    /**
     * 获取退货记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:return:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(tNewProcurementReturnService.selectTNewProcurementReturnById(id));
    }

    /**
     * 作废按钮操作
     */
    @Log(title = "退货记录", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel/{id}")
    public AjaxResult cancel(@PathVariable("id") Long id) {
        return toAjax(tNewProcurementReturnService.cancel(id));
    }

    /**
     * 确认按钮操作
     */
    @Log(title = "退货记录", businessType = BusinessType.UPDATE)
    @PutMapping("/confirm")
    public AjaxResult confirm(@RequestBody TNewProcurementReturnDTO dto) {
        return toAjax(tNewProcurementReturnService.confirm(dto));
    }

    /**
     * 批量获取商品价格
     */
    @PostMapping("/getCommodityPrice")
    public AjaxResult getCommodityPrice(@RequestBody Long[] ids) {
        return AjaxResult.success(tNewProcurementReturnService.getCommodityPrice(ids)) ;
    }

    /**
     * 批量结算
     */
    @Log(title = "退货记录", businessType = BusinessType.UPDATE)
    @PutMapping("/batchSettlement")
    public AjaxResult batchSettlement(@RequestBody List<TNewProcurementReturnDTO> dtos) {
        return toAjax(tNewProcurementReturnService.batchSettlement(dtos));
    }

    /**
     * 新增退货记录
     */
    //@PreAuthorize("@ss.hasPermi('web:return:add')")
    @Log(title = "退货记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewProcurementReturn tNewProcurementReturn) {
        return toAjax(tNewProcurementReturnService.save(tNewProcurementReturn));
    }

    /**
     * 修改退货记录
     */
    //@PreAuthorize("@ss.hasPermi('web:return:edit')")
    @Log(title = "退货记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewProcurementReturn tNewProcurementReturn) {
        return toAjax(tNewProcurementReturnService.updateById(tNewProcurementReturn));
    }

    /**
     * 删除退货记录
     */
    //@PreAuthorize("@ss.hasPermi('web:return:remove')")
    @Log(title = "退货记录", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tNewProcurementReturnService.deleteTNewProcurementReturnByIds(ids));
    }
}
