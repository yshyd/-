package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校信息档案对象 t_school_information
 *
 * @author ysh
 * @date 2025-12-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_school_information")
public class TSchoolInformation implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 区域ID */
        @Schema(description = "区域ID")
        @Excel(name = "区域ID")
        private Long areaId;

        /** 校长姓名 */
        @Schema(description = "校长姓名")
        @Excel(name = "校长姓名")
        private String principalName;

        /** 校长电话 */
        @Schema(description = "校长电话")
        @Excel(name = "校长电话")
        private String principalPhone;

        /** 学校地址 */
        @Schema(description = "学校地址")
        @Excel(name = "学校地址")
        private String schoolAddress;

        /** 学校类型：0幼儿园、1小学、2初中、3九年一贯制、4十二年一贯制、5高中、6完中、7中职、8特殊教育、9大专、10大学 */
        @Schema(description = "学校类型：0幼儿园、1小学、2初中、3九年一贯制、4十二年一贯制、5高中、6完中、7中职、8特殊教育、9大专、10大学")
        @Excel(name = "学校类型：0幼儿园、1小学、2初中、3九年一贯制、4十二年一贯制、5高中、6完中、7中职、8特殊教育、9大专、10大学")
        private Integer schoolType;

        /** 在校人数 */
        @Schema(description = "在校人数")
        @Excel(name = "在校人数")
        private Long number;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

        /** 删除标识 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "删除标识")
        private Integer delFlag;

}
