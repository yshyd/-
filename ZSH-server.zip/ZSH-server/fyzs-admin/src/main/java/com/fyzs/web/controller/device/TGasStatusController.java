package com.fyzs.web.controller.device;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TGasStatus;
import com.fyzs.web.service.ITGasStatusService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 可燃气体监测报警仪实时状态Controller
 * 
 * @author ysh
 * @date 2026-08-17
 */
@RestController
@AllArgsConstructor
@RequestMapping("/web/gas/status")
public class TGasStatusController extends BaseController
{

    private final ITGasStatusService tGasStatusService;

    /**
     * 查询可燃气体监测报警仪实时状态列表
     */
    //@PreAuthorize("@ss.hasPermi('web:status:list')")
    @GetMapping("/list")
    public TableDataInfo list(TGasStatus tGasStatus)
    {
        startPage();
        List<TGasStatus> list = tGasStatusService.selectTGasStatusList(tGasStatus);
        return getDataTable(list);
    }

    /**
     * 导出可燃气体监测报警仪实时状态列表
     */
    //@PreAuthorize("@ss.hasPermi('web:status:export')")
    @Log(title = "可燃气体监测报警仪实时状态", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TGasStatus tGasStatus)
    {
        List<TGasStatus> list = tGasStatusService.selectTGasStatusList(tGasStatus);
        ExcelUtil<TGasStatus> util = new ExcelUtil<TGasStatus>(TGasStatus.class);
        util.exportExcel(response, list, "可燃气体监测报警仪实时状态数据");
    }

    /**
     * 获取可燃气体监测报警仪实时状态详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:status:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tGasStatusService.selectTGasStatusById(id));
    }

    /**
     * 新增可燃气体监测报警仪实时状态
     */
    //@PreAuthorize("@ss.hasPermi('web:status:add')")
    @Log(title = "可燃气体监测报警仪实时状态", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TGasStatus tGasStatus)
    {
        return toAjax(tGasStatusService.save(tGasStatus));
    }

    /**
     * 修改可燃气体监测报警仪实时状态
     */
    //@PreAuthorize("@ss.hasPermi('web:status:edit')")
    @Log(title = "可燃气体监测报警仪实时状态", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TGasStatus tGasStatus)
    {
        return toAjax(tGasStatusService.updateById(tGasStatus));
    }

    /**
     * 删除可燃气体监测报警仪实时状态
     */
    //@PreAuthorize("@ss.hasPermi('web:status:remove')")
    @Log(title = "可燃气体监测报警仪实时状态", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tGasStatusService.deleteTGasStatusByIds(ids));
    }
}
