package com.fyzs.web.entity.query;

import com.fyzs.web.entity.TReferencePriceItem;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TReferencePriceItemQuery extends TReferencePriceItem {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
