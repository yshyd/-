package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食堂菜谱、留样、试尝、陪餐信息对象 t_food_recipse
 *
 * @author ysh
 * @date 2025-11-18
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_food_recipse")
public class TFoodRecipse implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     *
     */
    @Schema(description = "")
    private Long id;

    /**
     * 主体id
     */
    @Schema(description = "主体id")
    @Excel(name = "主体id")
    private Long deptId;

    /**
     * 菜谱日期(格式：2025-04-08)
     */
    @Schema(description = "菜谱日期(格式：2025-04-08)")
    @Excel(name = "菜谱日期(格式：2025-04-08)")
    private String date;

    /**
     * 菜名
     */
    @Schema(description = "菜名")
    @Excel(name = "菜名")
    private String name;

    /**
     * 餐次(1早餐、2午餐、3晚餐)
     */
    @Schema(description = "餐次(1早餐、2午餐、3晚餐)")
    @Excel(name = "餐次(1早餐、2午餐、3晚餐)")
    private String type;

    /**
     * 留样状态0未留样、1已留样、2已销样
     */
    @Schema(description = "留样状态0未留样、1已留样、2已销样")
    @Excel(name = "留样状态0未留样、1已留样、2已销样")
    private String isReserved;

    /**
     * 留样人(留样状态变成已留样时必传、变更时系统时间)
     */
    @Schema(description = "留样人(留样状态变成已留样时必传、变更时系统时间)")
    @Excel(name = "留样人(留样状态变成已留样时必传、变更时系统时间)")
    private String reservedPersonName;

    /**
     * 留样时间(留样状态变成已留样必传)
     */
    @Schema(description = "留样时间(留样状态变成已留样必传)")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Excel(name = "留样时间(留样状态变成已留样必传)", width = 30, dateFormat = "yyyy-MM-dd HH:mm")
    private Date reservedTime;

    /**
     * 留样重量
     */
    @Schema(description = "留样重量")
    @Excel(name = "留样重量")
    private BigDecimal reservedWeight;

    /**
     * 数据来源：0软件上报、1硬件上报(留样状态变成已留样必传)
     */
    @Schema(description = "数据来源：0软件上报、1硬件上报(留样状态变成已留样必传)")
    @Excel(name = "数据来源：0软件上报、1硬件上报(留样状态变成已留样必传)")
    private String reservedSource;

    /**
     * 留样设备序列号(首次留样状态变成已留样且数据来源为1必传)
     */
    @Schema(description = "留样设备序列号(首次留样状态变成已留样且数据来源为1必传)")
    @Excel(name = "留样设备序列号(首次留样状态变成已留样且数据来源为1必传)")
    private String reservedSerialNumber;

    /**
     * 留样拍照，逗号分割
     */
    @Schema(description = "留样拍照，逗号分割")
    @Excel(name = "留样拍照，逗号分割")
    private String reservedImg;

    /**
     * 销样人(销样必传)
     */
    @Schema(description = "销样人(销样必传)")
    @Excel(name = "销样人(销样必传)")
    private String cancleSamplePerson;

    /**
     * 销样时间(销样必传)
     */
    @Schema(description = "销样时间(销样必传)")
    @Excel(name = "销样时间(销样必传)")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    private Date cancleSampleTime;

    /**
     * 销样图片
     */
    @Schema(description = "销样图片")
    @Excel(name = "销样图片")
    private String cancleSampleImg;


    /**
     * 签字图片
     */
    @Schema(description = "签字图片")
    @Excel(name = "签字图片")
    private String singleImg;

    /**
     * 试尝状态：0未试尝1已试尝
     */
    @Schema(description = "试尝状态：0未试尝1已试尝")
    @Excel(name = "试尝状态：0未试尝1已试尝")
    private String isTasting;

    /**
     * 试尝结果：0正常1异常(试尝时必填)
     */
    @Schema(description = "试尝结果：0正常1异常(试尝时必填)")
    @Excel(name = "试尝结果：0正常1异常(试尝时必填)")
    private Integer tastingResult;

    /**
     * 试尝异常处置说明：试尝结果为异常时必填，300字内
     */
    @Schema(description = "试尝异常处置说明：试尝结果为异常时必填，300字内")
    @Excel(name = "试尝异常处置说明：试尝结果为异常时必填，300字内")
    private String tastingRemarks;



    /**
     * 试尝拍照：最多3张
     */
    @Schema(description = "试尝拍照：最多3张")
    @Excel(name = "试尝拍照：最多3张")
    private String tastingImg;

    /**
     * 试尝人(试尝状态变成已试尝时必填)
     */
    @Schema(description = "试尝人(试尝状态变成已试尝时必填)")
    @Excel(name = "试尝人(试尝状态变成已试尝时必填)")
    private String tastingPerson;

    /**
     * 试尝时间(试尝状态变成已试尝时必传、变更时系统时间)
     */
    @Schema(description = "试尝时间(试尝状态变成已试尝时必传、变更时系统时间)")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm")
    @Excel(name = "试尝时间(试尝状态变成已试尝时必传、变更时系统时间)", width = 30, dateFormat = "yyyy-MM-dd HH:mm")
    private Date tastingTime;

    /**
     * 陪餐状态：0未陪餐1陪餐
     */
    @Schema(description = "陪餐状态：0未陪餐1陪餐")
    @Excel(name = "陪餐状态：0未陪餐1陪餐")
    private String isAccompaniment;

    /**
     * 陪餐领导(陪餐状态变成陪餐时必填)
     */
    @Schema(description = "陪餐领导(陪餐状态变成陪餐时必填)")
    @Excel(name = "陪餐领导(陪餐状态变成陪餐时必填)")
    private String accompanimentPerson;

    /**
     * 陪餐时间：(陪餐状态变成已陪餐时必传)
     */
    @Schema(description = "陪餐时间：(陪餐状态变成已陪餐时必传)")
    @Excel(name = "陪餐时间：(陪餐状态变成已陪餐时必传)")
    private String accompanimentTime;

    /**
     * 陪餐照片,最多3张
     */
    @Schema(description = "陪餐照片,最多3张")
    @Excel(name = "陪餐照片,最多3张")
    private String accompanimentImg;

    /**
     * 0启用1禁用
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "0启用1禁用")
    private Integer delFlag;

    /**
     * 创建人ID
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人ID")
    @Excel(name = "创建人ID")
    private Long createUser;

    /**
     * 创建人姓名
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "创建人姓名")
    @Excel(name = "创建人姓名")
    private String createName;

    /**
     * 修改人id
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人id")
    @Excel(name = "修改人id")
    private Long updateUser;

    /**
     * 修改人名称
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "修改人名称")
    @Excel(name = "修改人名称")
    private String updateName;

    /**
     * 菜谱创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    @Schema(description = "菜谱创建时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "菜谱创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;

    /**
     * 菜谱修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)
    @Schema(description = "菜谱修改时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Excel(name = "菜谱修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date updateDate;

}
