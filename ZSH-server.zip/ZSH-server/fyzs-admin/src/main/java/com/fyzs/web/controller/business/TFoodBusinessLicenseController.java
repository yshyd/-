package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.fyzs.common.utils.ImageURL;
import com.fyzs.common.utils.StringUtils;
import com.fyzs.system.domain.query.TFoodBusinessLicenseQuery;
import com.fyzs.web.controller.common.CommonController;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.system.domain.TFoodBusinessLicense;
import com.fyzs.system.service.ITFoodBusinessLicenseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食品经营许可信息Controller
 * 
 * @author ysh
 * @date 2025-10-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/license")
public class TFoodBusinessLicenseController extends BaseController
{
    
    private  final ITFoodBusinessLicenseService tFoodBusinessLicenseService;

    /**
     * 查询食品经营许可信息列表
     */
    //@PreAutho("@ss.hasPermi('system:license:list')")
    @GetMapping("/list")
    public TableDataInfo list(TFoodBusinessLicenseQuery tFoodBusinessLicense)
    {
        startPage();
        List<TFoodBusinessLicenseQuery> list = tFoodBusinessLicenseService.selectTFoodBusinessLicenseList(tFoodBusinessLicense);
        return getDataTable(list);
    }

    /**
     * 导出食品经营许可信息列表
     */
    //@PreAutho("@ss.hasPermi('system:license:export')")
    @Log(title = "食品经营许可信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TFoodBusinessLicenseQuery tFoodBusinessLicense)
    {
        List<TFoodBusinessLicenseQuery> list = tFoodBusinessLicenseService.selectTFoodBusinessLicenseList(tFoodBusinessLicense);
        ExcelUtil<TFoodBusinessLicenseQuery> util = new ExcelUtil<TFoodBusinessLicenseQuery>(TFoodBusinessLicenseQuery.class);
        util.exportExcel(response, list, "食品经营许可信息数据");
    }

    /**
     * 获取食品经营许可信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:license:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tFoodBusinessLicenseService.selectTFoodBusinessLicenseById(id));
    }
    /**
     * 获取食品经营许可信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:license:query')")
    @GetMapping(value = "/info/{deptId}")
    public AjaxResult getInfoDept(@PathVariable("deptId") Long deptId)
    {
        return success(tFoodBusinessLicenseService.getOne(new LambdaQueryWrapper<>(TFoodBusinessLicense.class).eq(TFoodBusinessLicense::getDeptId,deptId)));
    }
    /**
     * 新增食品经营许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:add')")
    @Log(title = "食品经营许可信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TFoodBusinessLicense tFoodBusinessLicense)
    {
        TFoodBusinessLicense one = tFoodBusinessLicenseService.getOne(new LambdaQueryWrapper<>(TFoodBusinessLicense.class).eq(TFoodBusinessLicense::getDeptId, tFoodBusinessLicense.getDeptId()));
        if (!ObjectUtils.isEmpty( one)){
            tFoodBusinessLicense.setId(one.getId());
            return toAjax(tFoodBusinessLicenseService.updateById(tFoodBusinessLicense));
        }

        return toAjax(tFoodBusinessLicenseService.save(tFoodBusinessLicense));
    }

    /**
     * 修改食品经营许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:edit')")
    @Log(title = "食品经营许可信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TFoodBusinessLicense tFoodBusinessLicense)
    {
        // 先查询原记录
        TFoodBusinessLicense existingLicense = tFoodBusinessLicenseService.getById(tFoodBusinessLicense.getId());
        if (ObjectUtils.isNotEmpty(existingLicense)) {
            // 处理图片字段 - 假设实体中有 licenseImg 字段
            if (StringUtils.isNotEmpty(existingLicense.getImg())) {
                // 如果修改后的图片为空或者与原图片不同，则删除原图片
                if (StringUtils.isEmpty(tFoodBusinessLicense.getImg()) ||
                        !existingLicense.getImg().equals(tFoodBusinessLicense.getImg())) {
                    String[] originalImages = existingLicense.getImg().split(",");
                    for (String imageUrl : originalImages) {
                        String key = ImageURL.extractKeyFromUrl(imageUrl.trim());
                        if (org.apache.commons.lang3.StringUtils.isNotBlank(key)) {
                            CommonController.deleteOldImage(key);
                        }
                    }
                }
            }
        }

        return toAjax(tFoodBusinessLicenseService.updateById(tFoodBusinessLicense));
    }

    /**
     * 删除食品经营许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:remove')")
    @Log(title = "食品经营许可信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tFoodBusinessLicenseService.deleteTFoodBusinessLicenseByIds(ids));
    }
}
