package com.fyzs.web.entity;

import java.math.BigDecimal;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 商品采购验收单副对象 t_procurement_acceptance_itm
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_procurement_acceptance_itm")
public class TProcurementAcceptanceItm implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 商品ID */
        @Schema(description = "商品ID")
        @Excel(name = "商品ID")
        private Long commodityId;

        /** 验收主表ID */
        @Schema(description = "验收主表ID")
        @Excel(name = "验收主表ID")
        private Long acceptanceId;

        /** 供应商id */
        @Schema(description = "供应商id")
        @Excel(name = "供应商id")
        private Long supplerId;

        /** 采购数量 */
        @Schema(description = "采购数量")
        @Excel(name = "采购数量")
        private BigDecimal purchaseQuantity;

        /** 验收数量(验收时必填) */
        @Schema(description = "验收数量(验收时必填)")
        @Excel(name = "验收数量(验收时必填)")
        private BigDecimal acceptanceQuantity;

        /** 生产日期(验收时必填) */
        @Schema(description = "生产日期(验收时必填)")
        @Excel(name = "生产日期(验收时必填)")
        private String productionDate;

        /** 保质期数量(验收时必填) */
        @Schema(description = "保质期数量(验收时必填)")
        @Excel(name = "保质期数量(验收时必填)")
        private Integer shelfLifeNumber;

        /** 保质期类型(0天，1月)，验收时必填 */
        @Schema(description = "保质期类型(0天，1月)，验收时必填")
        @Excel(name = "保质期类型(0天，1月)，验收时必填")
        private Integer shelfLifeType;

        /** 保质期到期日期(验收时计算) */
        @Schema(description = "保质期到期日期(验收时计算)")
        @Excel(name = "保质期到期日期(验收时计算)")
        private String endDate;

        /** 查验检查是否正常0正常1异常(异常不允许入库) 1、检查气味、形态、腐烂变质等情况 2、米、面、油、调味品、牛奶、饮料、包装零食等需检查是否符合GB 7718规定，包括生产日期、保质期、生产商、生产许可证编号（SC标志）等。 3、猪肉类需查验猪肉身上的检疫验讫印章 */
        @Schema(description = "查验检查是否正常0正常1异常(异常不允许入库) 1、检查气味、形态、腐烂变质等情况 2、米、面、油、调味品、牛奶、饮料、包装零食等需检查是否符合GB 7718规定，包括生产日期、保质期、生产商、生产许可证编号（SC标志）等。 3、猪肉类需查验猪肉身上的检疫验讫印章")
        @Excel(name = "查验检查是否正常0正常1异常(异常不允许入库) 1、检查气味、形态、腐烂变质等情况 2、米、面、油、调味品、牛奶、饮料、包装零食等需检查是否符合GB 7718规定，包括生产日期、保质期、生产商、生产许可证编号", readConverterExp = "S=C标志")
        private String visualInspection;

        /** 验收时商品拍照图片 */
        @Schema(description = "验收时商品拍照图片")
        @Excel(name = "验收时商品拍照图片")
        private String img;

        /** 采购凭证 */
        @Schema(description = "采购凭证")
        @Excel(name = "采购凭证")
        private String vouchers;

        /** 索票索证，逗号分割，限传5张 */
        @Schema(description = "索票索证，逗号分割，限传5张")
        @Excel(name = "索票索证，逗号分割，限传5张")
        private String ticketsAndCertificates;

        /** 数据来源，验收时必传0软件系统、1硬件设备 */
        @Schema(description = "数据来源，验收时必传0软件系统、1硬件设备")
        @Excel(name = "数据来源，验收时必传0软件系统、1硬件设备")
        private Integer dataSource;

        /** 验收设备序列号，当数据来源于硬件设备时必传 */
        @Schema(description = "验收设备序列号，当数据来源于硬件设备时必传")
        @Excel(name = "验收设备序列号，当数据来源于硬件设备时必传")
        private String serialNumber;

        /** 验收状态：0未验收1已验收 */
        @Schema(description = "验收状态：0未验收1已验收")
        @Excel(name = "验收状态：0未验收1已验收")
        private String acceptanceStatus;

        /** 结算状态：0未结算1已结算 */
        @Schema(description = "结算状态：0未结算1已结算")
        @Excel(name = "结算状态：0未结算1已结算")
        private Integer settlementStatus;

        /** 入库状态：0未入库1已入库 */
        @Schema(description = "入库状态：0未入库1已入库")
        @Excel(name = "入库状态：0未入库1已入库")
        private Integer warehousedStatus;

        /** 异常备注：验收数量为0时，此项必填 如：质量不合格、不予入库 */
        @Schema(description = "异常备注：验收数量为0时，此项必填如：质量不合格、不予入库")
        @Excel(name = "异常备注：验收数量为0时，此项必填如：质量不合格、不予入库")
        private String remarks;

        /** 验收人id(验收时必更新) */
        @Schema(description = "验收人id(验收时必更新)")
        @Excel(name = "验收人id(验收时必更新)")
        private Long acceptanceUser;

        /** 验收人(验收时必更新) */
        @Schema(description = "验收人(验收时必更新)")
        @Excel(name = "验收人(验收时必更新)")
        private String acceptanceUserName;

        /** 验收时间(验收时必更新) */
        @Schema(description = "验收时间(验收时必更新)")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "验收时间(验收时必更新)", width = 30, dateFormat = "yyyy-MM-dd")
        private Date acceptanceDate;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
