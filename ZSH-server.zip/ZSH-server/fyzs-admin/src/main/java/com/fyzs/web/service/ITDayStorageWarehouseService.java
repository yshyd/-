package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayStorageWarehouse;
import com.fyzs.web.entity.query.TDayStorageWarehouseQuery;

/**
 * 学校食堂日管控-日常巡检-库房贮藏巡检Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayStorageWarehouseService extends IService<TDayStorageWarehouse>
{
    /**
     * 查询学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param id 学校食堂日管控-日常巡检-库房贮藏巡检主键
     * @return 学校食堂日管控-日常巡检-库房贮藏巡检
     */
    public TDayStorageWarehouseQuery selectTDayStorageWarehouseById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-库房贮藏巡检列表
     * 

     * @return 学校食堂日管控-日常巡检-库房贮藏巡检集合
     */
    public List<TDayStorageWarehouseQuery> selectTDayStorageWarehouseList(TDayStorageWarehouseQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param tDayStorageWarehouse 学校食堂日管控-日常巡检-库房贮藏巡检
     * @return 结果
     */
    public int insertTDayStorageWarehouse(TDayStorageWarehouse tDayStorageWarehouse);

    /**
     * 修改学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param tDayStorageWarehouse 学校食堂日管控-日常巡检-库房贮藏巡检
     * @return 结果
     */
    public int updateTDayStorageWarehouse(TDayStorageWarehouse tDayStorageWarehouse);

    /**
     * 批量删除学校食堂日管控-日常巡检-库房贮藏巡检
     * 
     * @param ids 需要删除的学校食堂日管控-日常巡检-库房贮藏巡检主键集合
     * @return 结果
     */
    public int deleteTDayStorageWarehouseByIds(Long[] ids);

    /**
     * 删除学校食堂日管控-日常巡检-库房贮藏巡检信息
     * 
     * @param id 学校食堂日管控-日常巡检-库房贮藏巡检主键
     * @return 结果
     */
    public int deleteTDayStorageWarehouseById(Long id);

    int cancel(TDayStorageWarehouse tDayStorageWarehouse);
}
