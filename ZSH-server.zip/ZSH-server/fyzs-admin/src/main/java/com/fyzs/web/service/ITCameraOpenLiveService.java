package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraOpenLive;

/**
 * 明厨亮灶三方接入信息Service接口
 * 
 * @author ysh
 * @date 2025-12-17
 */
public interface ITCameraOpenLiveService extends IService<TCameraOpenLive>
{
    /**
     * 查询明厨亮灶三方接入信息
     * 
     * @param id 明厨亮灶三方接入信息主键
     * @return 明厨亮灶三方接入信息
     */
    public TCameraOpenLive selectTCameraOpenLiveById(Long id);

    /**
     * 查询明厨亮灶三方接入信息列表
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 明厨亮灶三方接入信息集合
     */
    public List<TCameraOpenLive> selectTCameraOpenLiveList(TCameraOpenLive tCameraOpenLive);

    /**
     * 新增明厨亮灶三方接入信息
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 结果
     */
    public int insertTCameraOpenLive(TCameraOpenLive tCameraOpenLive);

    /**
     * 修改明厨亮灶三方接入信息
     * 
     * @param tCameraOpenLive 明厨亮灶三方接入信息
     * @return 结果
     */
    public int updateTCameraOpenLive(TCameraOpenLive tCameraOpenLive);

    /**
     * 批量删除明厨亮灶三方接入信息
     * 
     * @param ids 需要删除的明厨亮灶三方接入信息主键集合
     * @return 结果
     */
    public int deleteTCameraOpenLiveByIds(Long[] ids);

    /**
     * 删除明厨亮灶三方接入信息信息
     * 
     * @param id 明厨亮灶三方接入信息主键
     * @return 结果
     */
    public int deleteTCameraOpenLiveById(Long id);
}
