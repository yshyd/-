package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.entity.vo.AreaDeptTreeVO;
import com.fyzs.system.domain.dto.SysAreaDTO;
import com.fyzs.web.entity.TDevice;
import com.fyzs.web.entity.query.TDeviceQuery;
import com.fyzs.web.entity.vo.DeviceOverviewVO;

/**
 * 设备基础信息Service接口
 * 
 * @author ysh
 * @date 2025-12-09
 */
public interface ITDeviceService extends IService<TDevice>
{
    /**
     * 查询设备基础信息
     * 
     * @param id 设备基础信息主键
     * @return 设备基础信息
     */
    public TDeviceQuery selectTDeviceById(Long id);

    /**
     * 查询设备基础信息列表
     * 
     * @param tDevice 设备基础信息
     * @return 设备基础信息集合
     */
    public List<TDeviceQuery> selectTDeviceList(TDeviceQuery tDevice);
    /**
     * 查询设备基础信息列表
     *
     * @param tDevice 设备基础信息
     * @return 设备基础信息集合
     */
    public List<TDeviceQuery> selectTDeviceCount(TDeviceQuery tDevice);

    /**
     * 新增设备基础信息
     * 
     * @param tDevice 设备基础信息
     * @return 结果
     */
    public int insertTDevice(TDevice tDevice);

    /**
     * 修改设备基础信息
     * 
     * @param tDevice 设备基础信息
     * @return 结果
     */
    public int updateTDevice(TDevice tDevice);

    /**
     * 批量删除设备基础信息
     * 
     * @param ids 需要删除的设备基础信息主键集合
     * @return 结果
     */
    public int deleteTDeviceByIds(Long[] ids);

    /**
     * 删除设备基础信息信息
     * 
     * @param id 设备基础信息主键
     * @return 结果
     */
    public int deleteTDeviceById(Long id);

    boolean updateBatchEnable(Long[] ids, Long delFlag);

    List<AreaDeptTreeVO> areaDataTree(SysAreaDTO sysArea);

    List<AreaDeptTreeVO> areaDataTreeWithTotal(SysAreaDTO sysArea);

    List<DeviceOverviewVO> getDeviceSummary(TDeviceQuery query);
}
