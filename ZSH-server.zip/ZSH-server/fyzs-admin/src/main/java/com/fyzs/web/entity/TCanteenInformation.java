package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食堂信息档案对象 t_canteen_information
 *
 * @author ysh
 * @date 2025-12-08
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_canteen_information")
public class TCanteenInformation implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 区域ID */
        @Schema(description = "区域ID")
        @Excel(name = "区域ID")
        private Long areaId;

        /** 法定代表姓名 */
        @Schema(description = "法定代表姓名")
        @Excel(name = "法定代表姓名")
        private String legalRepresentativeName;

        /** 法定代表电话 */
        @Schema(description = "法定代表电话")
        @Excel(name = "法定代表电话")
        private String legalRepresentativePhone;

        /** 食堂地址 */
        @Schema(description = "食堂地址")
        @Excel(name = "食堂地址")
        private String canteenAddress;

        /** 食堂类型：0自营食堂、1外包食堂 */
        @Schema(description = "食堂类型：0自营食堂、1外包食堂")
        @Excel(name = "食堂类型：0自营食堂、1外包食堂")
        private Integer canteenType;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

        /** 删除标志 0正常 1删除 */
        @Schema(description = "删除标志 0正常 1删除")
        @TableField(fill = FieldFill.INSERT)
        private Integer delFlag;

}
