package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCalendarInfo;
import com.fyzs.web.entity.dto.TCalendarInfoDTO;
import com.fyzs.web.entity.query.TCalendarInfoQuery;

/**
 * 食堂运营配置Service接口
 * 
 * @author ysh
 * @date 2025-10-25
 */
public interface ITCalendarInfoService extends IService<TCalendarInfo>
{
    /**
     * 查询食堂运营配置
     * 
     * @param id 食堂运营配置主键
     * @return 食堂运营配置
     */
    public TCalendarInfo selectTCalendarInfoById(Long id);

    /**
     * 查询食堂运营配置列表
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 食堂运营配置集合
     */
    public List<TCalendarInfoQuery> selectTCalendarInfoList(TCalendarInfoQuery tCalendarInfo);

    /**
     * 新增食堂运营配置
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 结果
     */
    public int insertTCalendarInfo(TCalendarInfo tCalendarInfo);

    /**
     * 修改食堂运营配置
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 结果
     */
    public int updateTCalendarInfo(TCalendarInfo tCalendarInfo);

    /**
     * 批量删除食堂运营配置
     * 
     * @param ids 需要删除的食堂运营配置主键集合
     * @return 结果
     */
    public int deleteTCalendarInfoByIds(Long[] ids);

    /**
     * 删除食堂运营配置信息
     * 
     * @param id 食堂运营配置主键
     * @return 结果
     */
    public int deleteTCalendarInfoById(Long id);

    void batchSave(TCalendarInfoDTO dto);

    boolean existsByDeptIdAndDate(Long deptId, String date);
}
