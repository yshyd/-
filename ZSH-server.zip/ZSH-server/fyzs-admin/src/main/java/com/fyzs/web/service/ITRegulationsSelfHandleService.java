package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TRegulationsSelfHandle;

/**
 * 违法违规处置信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITRegulationsSelfHandleService extends IService<TRegulationsSelfHandle>
{
    /**
     * 查询违法违规处置信息
     * 
     * @param id 违法违规处置信息主键
     * @return 违法违规处置信息
     */
    public TRegulationsSelfHandle selectTRegulationsSelfHandleById(Long id);

    /**
     * 查询违法违规处置信息列表
     * 
     * @param tRegulationsSelfHandle 违法违规处置信息
     * @return 违法违规处置信息集合
     */
    public List<TRegulationsSelfHandle> selectTRegulationsSelfHandleList(TRegulationsSelfHandle tRegulationsSelfHandle);

    /**
     * 新增违法违规处置信息
     * 
     * @param tRegulationsSelfHandle 违法违规处置信息
     * @return 结果
     */
    public int insertTRegulationsSelfHandle(TRegulationsSelfHandle tRegulationsSelfHandle);

    /**
     * 修改违法违规处置信息
     * 
     * @param tRegulationsSelfHandle 违法违规处置信息
     * @return 结果
     */
    public int updateTRegulationsSelfHandle(TRegulationsSelfHandle tRegulationsSelfHandle);

    /**
     * 批量删除违法违规处置信息
     * 
     * @param ids 需要删除的违法违规处置信息主键集合
     * @return 结果
     */
    public int deleteTRegulationsSelfHandleByIds(Long[] ids);

    /**
     * 删除违法违规处置信息信息
     * 
     * @param id 违法违规处置信息主键
     * @return 结果
     */
    public int deleteTRegulationsSelfHandleById(Long id);
}
