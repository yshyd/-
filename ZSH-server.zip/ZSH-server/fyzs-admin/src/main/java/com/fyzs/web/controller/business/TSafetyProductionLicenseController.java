package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.fyzs.system.domain.query.TSafetyProductionLicenseQuery;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import com.fyzs.system.domain.TSafetyProductionLicense;
import com.fyzs.system.service.ITSafetyProductionLicenseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食品生产许可信息Controller
 * 
 * @author ysh
 * @date 2025-10-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/safety")
public class TSafetyProductionLicenseController extends BaseController
{
    
    private final ITSafetyProductionLicenseService tSafetyProductionLicenseService;

    /**
     * 查询食品生产许可信息列表
     */
    //@PreAutho("@ss.hasPermi('system:license:list')")
    @GetMapping("/list")
    public TableDataInfo list(TSafetyProductionLicenseQuery tSafetyProductionLicense)
    {
        startPage();
        List<TSafetyProductionLicenseQuery> list = tSafetyProductionLicenseService.selectTSafetyProductionLicenseList(tSafetyProductionLicense);
        return getDataTable(list);
    }

    /**
     * 导出食品生产许可信息列表
     */
    //@PreAutho("@ss.hasPermi('system:license:export')")
    @Log(title = "食品生产许可信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TSafetyProductionLicenseQuery tSafetyProductionLicense)
    {
        List<TSafetyProductionLicenseQuery> list = tSafetyProductionLicenseService.selectTSafetyProductionLicenseList(tSafetyProductionLicense);
        ExcelUtil<TSafetyProductionLicenseQuery> util = new ExcelUtil<TSafetyProductionLicenseQuery>(TSafetyProductionLicenseQuery.class);
        util.exportExcel(response, list, "食品生产许可信息数据");
    }

    /**
     * 获取食品生产许可信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:license:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tSafetyProductionLicenseService.selectTSafetyProductionLicenseById(id));
    }

    /**
     * 获取食品生产许可信息详细信息
     */
    //@PreAutho("@ss.hasPermi('system:license:query')")
    @GetMapping(value = "/info/{deptId}")
    public AjaxResult getDeptInfo(@PathVariable("deptId") Long deptId)
    {
        return success(tSafetyProductionLicenseService.getOne(new LambdaQueryWrapper<>(TSafetyProductionLicense.class).eq(TSafetyProductionLicense::getDeptId, deptId)));
    }

    /**
     * 新增食品生产许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:add')")
    @Log(title = "食品生产许可信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TSafetyProductionLicense tSafetyProductionLicense)
    {
        return toAjax(tSafetyProductionLicenseService.save(tSafetyProductionLicense));
    }

    /**
     * 修改食品生产许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:edit')")
    @Log(title = "食品生产许可信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TSafetyProductionLicense tSafetyProductionLicense)
    {
        return toAjax(tSafetyProductionLicenseService.updateById(tSafetyProductionLicense));
    }

    /**
     * 删除食品生产许可信息
     */
    //@PreAutho("@ss.hasPermi('system:license:remove')")
    @Log(title = "食品生产许可信息", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tSafetyProductionLicenseService.deleteTSafetyProductionLicenseByIds(ids));
    }
}
