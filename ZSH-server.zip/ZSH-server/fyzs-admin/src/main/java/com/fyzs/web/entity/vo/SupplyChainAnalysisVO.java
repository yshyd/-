package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class SupplyChainAnalysisVO {

    @Schema(description = "供应商名称")
    private String name;

    @Schema(description = "覆盖学校(所)")
    private Integer schoolCount;

    @Schema(description = "订单数量")
    private Integer orderCount;
}