package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TNewInventoryOperationQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TNewInventoryOperation;
import com.fyzs.web.service.ITNewInventoryOperationService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 库存操作记录Controller
 * 
 * @author ysh
 * @date 2025-10-31
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/operation")
public class TNewInventoryOperationController extends BaseController
{

    private final ITNewInventoryOperationService tNewInventoryOperationService;

    /**
     * 查询库存操作记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:list')")
    @GetMapping("/list")
    public TableDataInfo list(TNewInventoryOperationQuery tNewInventoryOperation)
    {
        startPage();
        List<TNewInventoryOperationQuery> list = tNewInventoryOperationService.selectTNewInventoryOperationList(tNewInventoryOperation);
        return getDataTable(list);
    }

    /**
     * 下拉查询库存操作记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:list')")
    @GetMapping("/pull/list")
    public TableDataInfo pullList(TNewInventoryOperationQuery tNewInventoryOperation)
    {

        List<TNewInventoryOperationQuery> list = tNewInventoryOperationService.selectTNewInventoryOperationList(tNewInventoryOperation);
        return getDataTable(list);
    }

    /**
     * 导出库存操作记录列表
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:export')")
    @Log(title = "库存操作记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TNewInventoryOperationQuery tNewInventoryOperation)
    {
        List<TNewInventoryOperationQuery> list = tNewInventoryOperationService.selectTNewInventoryOperationList(tNewInventoryOperation);
        ExcelUtil<TNewInventoryOperationQuery> util = new ExcelUtil<TNewInventoryOperationQuery>(TNewInventoryOperationQuery.class);
        util.exportExcel(response, list, "库存操作记录数据");
    }

    /**
     * 获取库存操作记录详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tNewInventoryOperationService.selectTNewInventoryOperationById(id));
    }

    /**
     * 新增库存操作记录
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:add')")
    @Log(title = "库存操作记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TNewInventoryOperation tNewInventoryOperation)
    {
        return toAjax(tNewInventoryOperationService.save(tNewInventoryOperation));
    }

    /**
     * 修改库存操作记录
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:edit')")
    @Log(title = "库存操作记录", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TNewInventoryOperation tNewInventoryOperation)
    {
        return toAjax(tNewInventoryOperationService.updateById(tNewInventoryOperation));
    }

    /**
     * 删除库存操作记录
     */
    //@PreAuthorize("@ss.hasPermi('web:operation:remove')")
    @Log(title = "库存操作记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tNewInventoryOperationService.deleteTNewInventoryOperationByIds(ids));
    }
}
