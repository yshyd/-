package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TWeekFile;
import com.fyzs.web.entity.query.TWeekFileQuery;

/**
 * 学校食堂周排查-文件是否有缺失Service接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
public interface ITWeekFileService extends IService<TWeekFile>
{
    /**
     * 查询学校食堂周排查-文件是否有缺失
     * 
     * @param id 学校食堂周排查-文件是否有缺失主键
     * @return 学校食堂周排查-文件是否有缺失
     */
    public TWeekFileQuery selectTWeekFileById(Long id);

    /**
     * 查询学校食堂周排查-文件是否有缺失列表
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 学校食堂周排查-文件是否有缺失集合
     */
    public List<TWeekFileQuery> selectTWeekFileList(TWeekFileQuery tWeekFile);

    /**
     * 新增学校食堂周排查-文件是否有缺失
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 结果
     */
    public int insertTWeekFile(TWeekFile tWeekFile);

    /**
     * 修改学校食堂周排查-文件是否有缺失
     * 
     * @param tWeekFile 学校食堂周排查-文件是否有缺失
     * @return 结果
     */
    public int updateTWeekFile(TWeekFile tWeekFile);

    /**
     * 批量删除学校食堂周排查-文件是否有缺失
     * 
     * @param ids 需要删除的学校食堂周排查-文件是否有缺失主键集合
     * @return 结果
     */
    public int deleteTWeekFileByIds(Long[] ids);

    /**
     * 删除学校食堂周排查-文件是否有缺失信息
     * 
     * @param id 学校食堂周排查-文件是否有缺失主键
     * @return 结果
     */
    public int deleteTWeekFileById(Long id);

    int cancel(TWeekFile tWeekFile);
}
