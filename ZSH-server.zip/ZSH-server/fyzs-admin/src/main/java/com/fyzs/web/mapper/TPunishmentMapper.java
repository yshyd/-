package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TPunishment;
import com.fyzs.web.entity.query.TPunishmentQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 食安监管-督察处罚Mapper接口
 * 
 * @author ysh
 * @date 2025-12-02
 */
@org.apache.ibatis.annotations.Mapper
public interface TPunishmentMapper  extends BaseMapper<TPunishment>
{
    /**
     * 查询食安监管-督察处罚
     * 
     * @param id 食安监管-督察处罚主键
     * @return 食安监管-督察处罚
     */
    public TPunishmentQuery selectTPunishmentById(Long id);

    /**
     * 查询食安监管-督察处罚列表
     * 
     * @param tPunishment 食安监管-督察处罚
     * @return 食安监管-督察处罚集合
     */
    public List<TPunishmentQuery> selectTPunishmentList(TPunishmentQuery tPunishment);

    /**
     * 新增食安监管-督察处罚
     * 
     * @param tPunishment 食安监管-督察处罚
     * @return 结果
     */
    public int insertTPunishment(TPunishment tPunishment);

    /**
     * 修改食安监管-督察处罚
     * 
     * @param tPunishment 食安监管-督察处罚
     * @return 结果
     */
    public int updateTPunishment(TPunishment tPunishment);

    /**
     * 删除食安监管-督察处罚
     * 
     * @param id 食安监管-督察处罚主键
     * @return 结果
     */
    public int deleteTPunishmentById(Long id);

    /**
     * 批量删除食安监管-督察处罚
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTPunishmentByIds(Long[] ids);
}
