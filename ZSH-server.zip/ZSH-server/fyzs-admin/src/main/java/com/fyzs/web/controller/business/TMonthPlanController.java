package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TMonthPlanQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TMonthPlan;
import com.fyzs.web.service.ITMonthPlanService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食安监管-月调度-月计划Controller
 * 
 * @author ysh
 * @date 2025-12-02
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/month/plan")
public class TMonthPlanController extends BaseController
{

    private final ITMonthPlanService tMonthPlanService;

    /**
     * 查询食安监管-月调度-月计划列表
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:list')")
    @GetMapping("/list")
    public TableDataInfo list(TMonthPlanQuery tMonthPlan)
    {
        startPage();
        List<TMonthPlanQuery> list = tMonthPlanService.selectTMonthPlanList(tMonthPlan);
        return getDataTable(list);
    }

    /**
     * 导出食安监管-月调度-月计划列表
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:export')")
    @Log(title = "食安监管-月调度-月计划", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TMonthPlanQuery tMonthPlan)
    {
        List<TMonthPlanQuery> list = tMonthPlanService.selectTMonthPlanList(tMonthPlan);
        ExcelUtil<TMonthPlanQuery> util = new ExcelUtil<TMonthPlanQuery>(TMonthPlanQuery.class);
        util.exportExcel(response, list, "食安监管-月调度-月计划数据");
    }

    /**
     * 获取食安监管-月调度-月计划详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tMonthPlanService.selectTMonthPlanById(id));
    }

    /**
     * 新增食安监管-月调度-月计划
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:add')")
    @Log(title = "食安监管-月调度-月计划", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TMonthPlan tMonthPlan)
    {
        //后端:检查这个主体这个年度这个月是否已经存在记录，不管状态怎么样
        //Y:不存在  直接插入
        //N:已经存在 已经存在当前月度计划，如有需要可通过修改按钮变更或启用后进行修改变更
        long count = tMonthPlanService.count(new LambdaQueryWrapper<>(TMonthPlan.class)
                .eq(TMonthPlan::getDeptId, tMonthPlan.getDeptId())
                .eq(TMonthPlan::getYear, tMonthPlan.getYear())
                .eq(TMonthPlan::getMonth, tMonthPlan.getMonth())
        );
        if (count > 0){
            return error("已经存在当前月度计划，如有需要可通过修改按钮变更或启用后进行修改变更");
        }

        return toAjax(tMonthPlanService.save(tMonthPlan));
    }

    /**
     * 修改食安监管-月调度-月计划
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:edit')")
    @Log(title = "食安监管-月调度-月计划", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TMonthPlan tMonthPlan)
    {
        long count = tMonthPlanService.count(new LambdaQueryWrapper<>(TMonthPlan.class)
                .eq(TMonthPlan::getDeptId, tMonthPlan.getDeptId())
                .eq(TMonthPlan::getYear, tMonthPlan.getYear())
                .eq(TMonthPlan::getMonth, tMonthPlan.getMonth())
                .ne(TMonthPlan::getId, tMonthPlan.getId())
        );
        if (count > 0){
            return error("已经存在当前月度计划，如有需要可通过修改按钮变更或启用后进行修改变更");
        }

        return toAjax(tMonthPlanService.updateById(tMonthPlan));
    }

    /**
     * 删除食安监管-月调度-月计划
     */
    //@PreAuthorize("@ss.hasPermi('web:plan:remove')")
    @Log(title = "食安监管-月调度-月计划", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tMonthPlanService.deleteTMonthPlanByIds(ids));
    }
}
