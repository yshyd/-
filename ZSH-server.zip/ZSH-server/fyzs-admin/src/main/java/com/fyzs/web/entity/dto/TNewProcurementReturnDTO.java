package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TNewProcurementReturn;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewProcurementReturnDTO extends TNewProcurementReturn {
}
