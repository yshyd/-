package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TWeekChemicals;
import com.fyzs.web.entity.query.TWeekChemicalsQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 学校食堂周排查-化学品风险排查Mapper接口
 * 
 * @author ysh
 * @date 2025-11-27
 */
@Mapper
public interface TWeekChemicalsMapper  extends BaseMapper<TWeekChemicals>
{
    /**
     * 查询学校食堂周排查-化学品风险排查
     * 
     * @param id 学校食堂周排查-化学品风险排查主键
     * @return 学校食堂周排查-化学品风险排查
     */
    public TWeekChemicalsQuery selectTWeekChemicalsById(Long id);

    /**
     * 查询学校食堂周排查-化学品风险排查列表
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 学校食堂周排查-化学品风险排查集合
     */
    public List<TWeekChemicalsQuery> selectTWeekChemicalsList(TWeekChemicalsQuery tWeekChemicals);

    /**
     * 新增学校食堂周排查-化学品风险排查
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 结果
     */
    public int insertTWeekChemicals(TWeekChemicals tWeekChemicals);

    /**
     * 修改学校食堂周排查-化学品风险排查
     * 
     * @param tWeekChemicals 学校食堂周排查-化学品风险排查
     * @return 结果
     */
    public int updateTWeekChemicals(TWeekChemicals tWeekChemicals);

    /**
     * 删除学校食堂周排查-化学品风险排查
     * 
     * @param id 学校食堂周排查-化学品风险排查主键
     * @return 结果
     */
    public int deleteTWeekChemicalsById(Long id);

    /**
     * 批量删除学校食堂周排查-化学品风险排查
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTWeekChemicalsByIds(Long[] ids);
}
