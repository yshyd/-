package com.fyzs.web.controller.system;

import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.config.FyzsConfig;
import com.fyzs.common.utils.StringUtils;

/**
 * 首页
 *
 * @author ysh
 */
@RestController
@AllArgsConstructor
public class SysIndexController
{
    /** 系统基础配置 */
    private  final FyzsConfig fyzsConfig;

    /**
     * 访问首页，提示语
     */
    @RequestMapping("/")
    public String index()
    {
        return StringUtils.format("欢迎使用{}后台管理框架，当前版本：v{}，请通过前端地址访问。", fyzsConfig.getName(), fyzsConfig.getVersion());
    }
}
