package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayDisinfectionEquipment;
import com.fyzs.web.entity.query.TDayDisinfectionEquipmentQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常消毒-场所设备消毒Mapper接口
 * 
 * @author ysh
 * @date 2025-11-19
 */
@org.apache.ibatis.annotations.Mapper
public interface TDayDisinfectionEquipmentMapper  extends BaseMapper<TDayDisinfectionEquipment>
{
    /**
     * 查询学校食堂日管控-日常消毒-场所设备消毒
     * 
     * @param id 学校食堂日管控-日常消毒-场所设备消毒主键
     * @return 学校食堂日管控-日常消毒-场所设备消毒
     */
    public TDayDisinfectionEquipmentQuery selectTDayDisinfectionEquipmentById(Long id);

    /**
     * 查询学校食堂日管控-日常消毒-场所设备消毒列表
     *
     * @return 学校食堂日管控-日常消毒-场所设备消毒集合
     */
    public List<TDayDisinfectionEquipmentQuery> selectTDayDisinfectionEquipmentList(TDayDisinfectionEquipmentQuery query);

    /**
     * 新增学校食堂日管控-日常消毒-场所设备消毒
     * 
     * @param tDayDisinfectionEquipment 学校食堂日管控-日常消毒-场所设备消毒
     * @return 结果
     */
    public int insertTDayDisinfectionEquipment(TDayDisinfectionEquipment tDayDisinfectionEquipment);

    /**
     * 修改学校食堂日管控-日常消毒-场所设备消毒
     * 
     * @param tDayDisinfectionEquipment 学校食堂日管控-日常消毒-场所设备消毒
     * @return 结果
     */
    public int updateTDayDisinfectionEquipment(TDayDisinfectionEquipment tDayDisinfectionEquipment);

    /**
     * 删除学校食堂日管控-日常消毒-场所设备消毒
     * 
     * @param id 学校食堂日管控-日常消毒-场所设备消毒主键
     * @return 结果
     */
    public int deleteTDayDisinfectionEquipmentById(Long id);

    /**
     * 批量删除学校食堂日管控-日常消毒-场所设备消毒
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayDisinfectionEquipmentByIds(Long[] ids);

    int countValidDisinfections(@Param("startDate") Date startDate,
                                @Param("endDate") Date endDate,
                                @Param("deptIds") List<Long> deptIds);
}
