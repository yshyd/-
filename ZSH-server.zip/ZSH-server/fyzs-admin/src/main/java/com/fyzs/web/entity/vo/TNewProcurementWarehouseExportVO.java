package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 入库记录导出对象
 */
@Data
public class TNewProcurementWarehouseExportVO {

    @Excel(name = "主体名称", sort = 1)
    private String deptName;

    @Excel(name = "仓库", sort = 2)
    private String warehouseName;

    @Excel(name = "批次", sort = 3)
    private String batch;

    @Excel(name = "商品", sort = 4)
    private String commodityName;

    @Excel(name = "品牌", sort = 5)
    private String brand;

    @Excel(name = "型号", sort = 6)
    private String model;

    @Excel(name = "规格", sort = 7)
    private String specification;

    @Excel(name = "入库类型", sort = 8,
            readConverterExp = "0=采购验收入库,1=初始入库,2=调拨入库,3=盘盈入库,4=退领入库,5=退货撤销入库")
    private Integer type;

    @Excel(name = "入库数量", sort = 9)
    private BigDecimal innerNumber;

    @Excel(name = "单位", sort = 10)
    private String purchaUnit;

    @Excel(name = "入库时间", sort = 11, width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
    private Date createDate;
}
