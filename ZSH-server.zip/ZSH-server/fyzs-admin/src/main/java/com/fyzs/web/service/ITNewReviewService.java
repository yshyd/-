package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TNewReview;
import com.fyzs.web.entity.dto.TNewReviewDTO;
import com.fyzs.web.entity.query.TNewReviewQuery;

/**
 * 盘点Service接口
 * 
 * @author ysh
 * @date 2025-10-31
 */
public interface ITNewReviewService extends IService<TNewReview>
{
    /**
     * 查询盘点
     * 
     * @param id 盘点主键
     * @return 盘点
     */
    public TNewReviewQuery selectTNewReviewById(Long id);

    /**
     * 查询盘点列表
     * 
     * @param tNewReview 盘点
     * @return 盘点集合
     */
    public List<TNewReviewQuery> selectTNewReviewList(TNewReviewQuery tNewReview);

    /**
     * 新增盘点
     * 
     * @param tNewReview 盘点
     * @return 结果
     */
    public int insertTNewReview(TNewReview tNewReview);

    /**
     * 修改盘点
     * 
     * @param tNewReview 盘点
     * @return 结果
     */
    public int updateTNewReview(TNewReview tNewReview);

    /**
     * 批量删除盘点
     * 
     * @param ids 需要删除的盘点主键集合
     * @return 结果
     */
    public int deleteTNewReviewByIds(Long[] ids);

    /**
     * 删除盘点信息
     * 
     * @param id 盘点主键
     * @return 结果
     */
    public int deleteTNewReviewById(Long id);

    int confirm(TNewReviewDTO dto);
}
