package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TPersonCheckQuery;
import com.fyzs.web.entity.vo.TPersonCheckExportVO;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TPersonCheck;
import com.fyzs.web.service.ITPersonCheckService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

import java.util.stream.Collectors;

/**
 * 食堂人员日检Controller
 * 
 * @author ysh
 * @date 2025-11-19
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/person/check")
public class TPersonCheckController extends BaseController
{

    private final ITPersonCheckService personCheckService;

    /**
     * 查询食堂人员日检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:list')")
    @GetMapping("/list")
    public TableDataInfo list(TPersonCheckQuery query)
    {
        startPage();
        List<TPersonCheckQuery> list = personCheckService.selectTPersonCheckList(query);
        return getDataTable(list);
    }

    /**
     * 导出食堂人员日检列表
     */
    //@PreAuthorize("@ss.hasPermi('web:check:export')")
    @Log(title = "食堂人员日检", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TPersonCheckQuery query)
    {
        List<TPersonCheckQuery> list = personCheckService.selectTPersonCheckExportList(query);
        List<TPersonCheckExportVO> exportList = list.stream().map(item -> {
            TPersonCheckExportVO exportVO = new TPersonCheckExportVO();
            BeanUtils.copyProperties(item, exportVO);
            return exportVO;
        }).collect(Collectors.toList());
        ExcelUtil<TPersonCheckExportVO> util = new ExcelUtil<TPersonCheckExportVO>(TPersonCheckExportVO.class);
        util.exportExcel(response, exportList, "食堂人员日检数据");
    }

    /**
     * 获取食堂人员日检详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:check:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(personCheckService.selectTPersonCheckById(id));
    }

    /**
     * 新增食堂人员日检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:add')")
    @Log(title = "食堂人员日检", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TPersonCheck tPersonCheck)
    {
//        long count = personCheckService.count(new LambdaQueryWrapper<TPersonCheck>()
//                .eq(TPersonCheck::getDeptId, tPersonCheck.getDeptId())
//                .eq(TPersonCheck::getPersonId, tPersonCheck.getPersonId())
//                .eq(TPersonCheck::getDate, tPersonCheck.getDate())
//                .eq(TPersonCheck::getType, tPersonCheck.getType())
//        );
//        if (count > 0) {
//            return error("该人员已经做过检查，如有更改需要,请通过修改功能进行更改,或启用后通过修改功能进行变更!");
//        }
        return toAjax(personCheckService.insertTPersonCheck(tPersonCheck));
    }

    /**
     * 修改食堂人员日检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:edit')")
    @Log(title = "食堂人员日检", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TPersonCheck tPersonCheck)
    {
//        long count = personCheckService.count(new LambdaQueryWrapper<TPersonCheck>()
//                .eq(TPersonCheck::getDeptId, tPersonCheck.getDeptId())
//                .eq(TPersonCheck::getPersonId, tPersonCheck.getPersonId())
//                .eq(TPersonCheck::getDate, tPersonCheck.getDate())
//                .eq(TPersonCheck::getType, tPersonCheck.getType())
//                .ne(TPersonCheck::getId, tPersonCheck.getId())
//        );
//        if (count > 0) {
//            return error("该人员已经做过检查，如有更改需要,请通过修改功能进行更改,或启用后通过修改功能进行变更!");
//        }

        return toAjax(personCheckService.updateTPersonCheck(tPersonCheck));
    }

    /**
     * 启用/禁用
     */
    //@PreAuthorize("@ss.hasPermi('web:check:edit')")
    @Log(title = "食堂人员日检", businessType = BusinessType.UPDATE)
    @PutMapping("/cancel")
    public AjaxResult cancel(@RequestBody TPersonCheck tPersonCheck)
    {
        return toAjax(personCheckService.cancel(tPersonCheck));
    }

    /**
     * 删除食堂人员日检
     */
    //@PreAuthorize("@ss.hasPermi('web:check:remove')")
    @Log(title = "食堂人员日检", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(personCheckService.deleteTPersonCheckByIds(ids));
    }
}
