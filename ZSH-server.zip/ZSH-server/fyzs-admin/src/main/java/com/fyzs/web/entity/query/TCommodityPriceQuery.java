package com.fyzs.web.entity.query;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TCommodityPrice;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCommodityPriceQuery extends TCommodityPrice {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "供应商名称")
    private String supperName;

    @Schema(description = "主体名称")
    @Excel(name = "主体名称")
    private String deptName;

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;

    /** 商品类别id */
    @Schema(description = "商品类别")
    @Excel(name = "商品类别")
    private String categoryName;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
