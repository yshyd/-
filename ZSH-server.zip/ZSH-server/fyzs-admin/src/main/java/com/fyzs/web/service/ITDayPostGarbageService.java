package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TDayPostGarbage;
import com.fyzs.web.entity.query.TDayPostGarbageQuery;

/**
 * 食安监管-日管控-餐厨垃圾Service接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
public interface ITDayPostGarbageService extends IService<TDayPostGarbage>
{
    /**
     * 查询食安监管-日管控-餐厨垃圾
     * 
     * @param id 食安监管-日管控-餐厨垃圾主键
     * @return 食安监管-日管控-餐厨垃圾
     */
    public TDayPostGarbageQuery selectTDayPostGarbageById(Long id);

    /**
     * 查询食安监管-日管控-餐厨垃圾列表
     * 
     * @param query 食安监管-日管控-餐厨垃圾
     * @return 食安监管-日管控-餐厨垃圾集合
     */
    public List<TDayPostGarbageQuery> selectTDayPostGarbageList(TDayPostGarbageQuery query);

    /**
     * 新增食安监管-日管控-餐厨垃圾
     * 
     * @param tDayPostGarbage 食安监管-日管控-餐厨垃圾
     * @return 结果
     */
    public int insertTDayPostGarbage(TDayPostGarbage tDayPostGarbage);

    /**
     * 修改食安监管-日管控-餐厨垃圾
     * 
     * @param tDayPostGarbage 食安监管-日管控-餐厨垃圾
     * @return 结果
     */
    public int updateTDayPostGarbage(TDayPostGarbage tDayPostGarbage);

    /**
     * 批量删除食安监管-日管控-餐厨垃圾
     * 
     * @param ids 需要删除的食安监管-日管控-餐厨垃圾主键集合
     * @return 结果
     */
    public int deleteTDayPostGarbageByIds(Long[] ids);

    /**
     * 删除食安监管-日管控-餐厨垃圾信息
     * 
     * @param id 食安监管-日管控-餐厨垃圾主键
     * @return 结果
     */
    public int deleteTDayPostGarbageById(Long id);
}
