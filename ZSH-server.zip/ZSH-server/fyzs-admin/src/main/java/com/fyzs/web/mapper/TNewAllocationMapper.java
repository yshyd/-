package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TNewAllocation;
import com.fyzs.web.entity.query.TNewAllocationQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 库间调拨记录Mapper接口
 * 
 * @author ysh
 * @date 2025-10-31
 */
@org.apache.ibatis.annotations.Mapper
public interface TNewAllocationMapper  extends BaseMapper<TNewAllocation>
{
    /**
     * 查询库间调拨记录
     * 
     * @param id 库间调拨记录主键
     * @return 库间调拨记录
     */
    public TNewAllocationQuery selectTNewAllocationById(Long id);

    /**
     * 查询库间调拨记录列表
     * 
     * @param tNewAllocation 库间调拨记录
     * @return 库间调拨记录集合
     */
    public List<TNewAllocationQuery> selectTNewAllocationList(TNewAllocationQuery tNewAllocation);

    /**
     * 新增库间调拨记录
     * 
     * @param tNewAllocation 库间调拨记录
     * @return 结果
     */
    public int insertTNewAllocation(TNewAllocation tNewAllocation);

    /**
     * 修改库间调拨记录
     * 
     * @param tNewAllocation 库间调拨记录
     * @return 结果
     */
    public int updateTNewAllocation(TNewAllocation tNewAllocation);

    /**
     * 删除库间调拨记录
     * 
     * @param id 库间调拨记录主键
     * @return 结果
     */
    public int deleteTNewAllocationById(Long id);

    /**
     * 批量删除库间调拨记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewAllocationByIds(Long[] ids);
}
