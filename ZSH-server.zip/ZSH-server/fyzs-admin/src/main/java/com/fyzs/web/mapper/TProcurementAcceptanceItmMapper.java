package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TProcurementAcceptanceItm;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 商品采购验收单副Mapper接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
@Mapper
public interface TProcurementAcceptanceItmMapper  extends BaseMapper<TProcurementAcceptanceItm>
{
    /**
     * 查询商品采购验收单副
     * 
     * @param id 商品采购验收单副主键
     * @return 商品采购验收单副
     */
    public TProcurementAcceptanceItm selectTProcurementAcceptanceItmById(Long id);

    /**
     * 查询商品采购验收单副列表
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 商品采购验收单副集合
     */
    public List<TProcurementAcceptanceItm> selectTProcurementAcceptanceItmList(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 新增商品采购验收单副
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 结果
     */
    public int insertTProcurementAcceptanceItm(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 修改商品采购验收单副
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 结果
     */
    public int updateTProcurementAcceptanceItm(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 删除商品采购验收单副
     * 
     * @param id 商品采购验收单副主键
     * @return 结果
     */
    public int deleteTProcurementAcceptanceItmById(Long id);

    /**
     * 批量删除商品采购验收单副
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTProcurementAcceptanceItmByIds(Long[] ids);

    /**
     * 批量插入验收单项
     */
    int insertBatch(@Param("list") List<TProcurementAcceptanceItm> itemList);
}
