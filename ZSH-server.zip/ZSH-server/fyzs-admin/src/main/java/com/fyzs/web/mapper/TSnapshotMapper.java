package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TSnapshot;
import com.fyzs.web.entity.query.TSnapshotQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * AI盒子违规抓拍Mapper接口
 * 
 * @author ysh
 * @date 2026-01-05
 */
@Mapper
public interface TSnapshotMapper  extends BaseMapper<TSnapshot>
{
    /**
     * 查询AI盒子违规抓拍
     * 
     * @param id AI盒子违规抓拍主键
     * @return AI盒子违规抓拍
     */
    public TSnapshotQuery selectTSnapshotById(Long id);

    /**
     * 查询AI盒子违规抓拍列表
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return AI盒子违规抓拍集合
     */
    public List<TSnapshotQuery> selectTSnapshotList(TSnapshotQuery tSnapshot);

    /**
     * 新增AI盒子违规抓拍
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return 结果
     */
    public int insertTSnapshot(TSnapshot tSnapshot);

    /**
     * 修改AI盒子违规抓拍
     * 
     * @param tSnapshot AI盒子违规抓拍
     * @return 结果
     */
    public int updateTSnapshot(TSnapshot tSnapshot);

    /**
     * 删除AI盒子违规抓拍
     * 
     * @param id AI盒子违规抓拍主键
     * @return 结果
     */
    public int deleteTSnapshotById(Long id);

    /**
     * 批量删除AI盒子违规抓拍
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTSnapshotByIds(Long[] ids);
}
