package com.fyzs.web.entity.vo;

import lombok.Data;

@Data
public class AlarmStatisticsVO {
    private String type;           // 预警类型（如"证件预警"）
    private Integer count;      // 该类型预警数量

    public AlarmStatisticsVO(String type, Integer count) {
        this.type = type;
        this.count = count;
    }

}
