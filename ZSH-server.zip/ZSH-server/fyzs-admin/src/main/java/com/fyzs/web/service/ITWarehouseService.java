package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TWarehouse;
import com.fyzs.web.entity.query.TWarehouseQuery;

/**
 * 仓库信息Service接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
public interface ITWarehouseService extends IService<TWarehouse>
{
    /**
     * 查询仓库信息
     * 
     * @param id 仓库信息主键
     * @return 仓库信息
     */
    public TWarehouseQuery selectTWarehouseById(Long id);

    /**
     * 查询仓库信息列表
     * 
     * @param tWarehouse 仓库信息
     * @return 仓库信息集合
     */
    public List<TWarehouseQuery> selectTWarehouseList(TWarehouseQuery tWarehouse);

    /**
     * 新增仓库信息
     * 
     * @param tWarehouse 仓库信息
     * @return 结果
     */
    public int insertTWarehouse(TWarehouse tWarehouse);

    /**
     * 修改仓库信息
     * 
     * @param tWarehouse 仓库信息
     * @return 结果
     */
    public int updateTWarehouse(TWarehouse tWarehouse);

    /**
     * 批量删除仓库信息
     * 
     * @param ids 需要删除的仓库信息主键集合
     * @return 结果
     */
    public int deleteTWarehouseByIds(Long[] ids);

    /**
     * 删除仓库信息信息
     * 
     * @param id 仓库信息主键
     * @return 结果
     */
    public int deleteTWarehouseById(Long id);
}
