package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCommodity;
import com.fyzs.web.entity.query.TCommodityQuery;

/**
 * 系统标准商品库Service接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
public interface ITCommodityService extends IService<TCommodity>
{
    /**
     * 查询系统标准商品库
     * 
     * @param id 系统标准商品库主键
     * @return 系统标准商品库
     */
    public TCommodityQuery selectTCommodityById(Long id);

    /**
     * 查询系统标准商品库列表
     * 
     * @param tCommodity 系统标准商品库
     * @return 系统标准商品库集合
     */
    public List<TCommodityQuery> selectTCommodityList(TCommodityQuery tCommodity);

    /**
     * 新增系统标准商品库
     * 
     * @param tCommodity 系统标准商品库
     * @return 结果
     */
    public int insertTCommodity(TCommodity tCommodity);

    /**
     * 修改系统标准商品库
     * 
     * @param tCommodity 系统标准商品库
     * @return 结果
     */
    public int updateTCommodity(TCommodity tCommodity);

    /**
     * 批量删除系统标准商品库
     * 
     * @param ids 需要删除的系统标准商品库主键集合
     * @return 结果
     */
    public int deleteTCommodityByIds(Long[] ids);

    /**
     * 删除系统标准商品库信息
     * 
     * @param id 系统标准商品库主键
     * @return 结果
     */
    public int deleteTCommodityById(Long id);

    String generateCommodityCode();
}
