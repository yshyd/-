package com.fyzs.web.entity;


import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 关键监控环节配置对象 t_monitoring_links_config
 *
 * @author ysh
 * @date 2025-10-21
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_monitoring_links_config")
public class TMonitoringLinksConfig implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * $column.columnComment
     */


    @Schema(description = "$column.columnComment")
    private Long id;

    /**
     * 业务类型
     * 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务
     */
    @Schema(description = "业务类型 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务")
    @Excel(name = "业务类型 1、普通食品生产2、特殊食品生产3、普通食品销售4、特殊食品销售5、餐饮服务")
    private String businessType;

    /**
     * 食品类别
     */
    @Schema(description = "食品类别")
    @Excel(name = "食品类别")
    private String foodType;

    /**
     * 食品类别名称
     */
    @Schema(description = "食品类别名称")
    @Excel(name = "食品类别名称")
    private String foodTypeName;

    /**
     * 关键监控环节代码
     */
    @Schema(description = "关键监控环节代码")
    @Excel(name = "关键监控环节代码")
    private String linksCode;

    /**
     * 关键监控环节名称
     */
    @Schema(description = "关键监控环节名称")
    @Excel(name = "关键监控环节名称")
    private String linksName;

    /**
     * 安装位置
     */


    @Schema(description = "安装位置")
    @Excel(name = "安装位置")
    private String location;

    /**
     * 关键环节需要安装对接的摄像头最少个数
     */
    @Schema(description = "关键环节需要安装对接的摄像头最少个数")
    @Excel(name = "关键环节需要安装对接的摄像头最少个数")
    private Long number;

    /**
     * 摄像头是否需要配置AI抓拍识别功能 （0是/1否）
     */
    @Schema(description = "摄像头是否需要配置AI抓拍识别功能 （0是/1否）")
    @Excel(name = "摄像头是否需要配置AI抓拍识别功能 ", readConverterExp = "0=是/1否")
    private String isAi;

    /**
     * 摄像头安装要求
     */
    @Schema(description = "摄像头安装要求")
    @Excel(name = "摄像头安装要求")
    private String installationRequirements;

    /**
     * 摄像头存储要求，最少保存录像天数
     */
    @Schema(description = "摄像头存储要求，最少保存录像天数")
    @Excel(name = "摄像头存储要求，最少保存录像天数")
    private Integer storageRequirements;

    /**
     * 需要监管的不规范情形
     */
    @Schema(description = "需要监管的不规范情形")
    @Excel(name = "需要监管的不规范情形")
    private String regulationsType;

    /**
     * 违法违规代码
     */
    @Schema(description = "违法违规代码")
    @Excel(name = "违法违规代码")
    private String regulationsCode;

}
