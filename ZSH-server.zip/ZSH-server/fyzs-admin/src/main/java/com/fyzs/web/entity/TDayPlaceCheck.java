package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常巡检-场所环境卫生巡检对象 t_day_place_check
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_place_check")
public class TDayPlaceCheck implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 地面、墙壁、天花板、门窗 是否清洁无油污、无霉斑 0是1否 */
        @Schema(description = "地面、墙壁、天花板、门窗 是否清洁无油污、无霉斑 0是1否 ")
        @Excel(name = "地面、墙壁、天花板、门窗 是否清洁无油污、无霉斑 0是1否 ")
        private Integer isGround;

        /** 下水道是否通畅，无淤积、无异味 0是1否 */
        @Schema(description = "下水道是否通畅，无淤积、无异味 0是1否")
        @Excel(name = "下水道是否通畅，无淤积、无异味 0是1否")
        private Integer isSewer;

        /** 垃圾是否及时清理，垃圾桶加盖，外观清洁。 0是1否 */
        @Schema(description = "垃圾是否及时清理，垃圾桶加盖，外观清洁。 0是1否")
        @Excel(name = "垃圾是否及时清理，垃圾桶加盖，外观清洁。 0是1否")
        private Integer isGarbage;

        /** 库房是否原料摆放整齐，区域干净整洁，离墙离地存放，防水防潮 0是1否 */
        @Schema(description = "库房是否原料摆放整齐，区域干净整洁，离墙离地存放，防水防潮 0是1否")
        @Excel(name = "库房是否原料摆放整齐，区域干净整洁，离墙离地存放，防水防潮 0是1否")
        private Integer isWarehouse;

        /** 消毒区是否独立，专用，隔离食品加工区、备餐区、就餐区，远离卫生间、垃圾站等污染源 0是1否 */
        @Schema(description = "消毒区是否独立，专用，隔离食品加工区、备餐区、就餐区，远离卫生间、垃圾站等污染源 0是1否")
        @Excel(name = "消毒区是否独立，专用，隔离食品加工区、备餐区、就餐区，远离卫生间、垃圾站等污染源 0是1否")
        private Integer isDisinfectionArea;

        /** 现场拍照(逗号分割，限制5张) */
        @Schema(description = "现场拍照(逗号分割，限制5张)")
        @Excel(name = "现场拍照(逗号分割，限制5张)")
        private String img;

        /** 整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1 */
        @Schema(description = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        @Excel(name = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        private Integer isAbnormal;

        /** 异常处置说明，限1000个字符 当整体出现异常时必填 */
        @Schema(description = "异常处置说明，限1000个字符 当整体出现异常时必填")
        @Excel(name = "异常处置说明，限1000个字符 当整体出现异常时必填")
        private String abnormalHandleRemarks;

        /** 巡检人 */
        @Schema(description = "巡检人")
        @Excel(name = "巡检人")
        private String inspectionUser;

        /** 巡检时间，年月日时分(格式：2025-05-05 08:40) */
        @Schema(description = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        @Excel(name = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        private String inspectionDate;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 巡检人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人ID(对应sys_user)")
        @Excel(name = "巡检人ID(对应sys_user)")
        private Long createUser;

        /** 巡检人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人姓名(对应sys_user)")
        @Excel(name = "巡检人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
