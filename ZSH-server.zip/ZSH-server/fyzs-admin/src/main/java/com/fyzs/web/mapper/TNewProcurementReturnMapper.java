package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TNewProcurementReturn;
import com.fyzs.web.entity.query.TNewProcurementReturnQuery;
import com.fyzs.web.entity.vo.TNewProcurementReturnVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 退货记录Mapper接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
@Mapper
public interface TNewProcurementReturnMapper  extends BaseMapper<TNewProcurementReturn>
{
    /**
     * 查询退货记录
     * 
     * @param id 退货记录主键
     * @return 退货记录
     */
    public TNewProcurementReturnQuery selectTNewProcurementReturnById(Long id);

    /**
     * 查询退货记录列表
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 退货记录集合
     */
    public List<TNewProcurementReturnQuery> selectTNewProcurementReturnList(TNewProcurementReturnQuery tNewProcurementReturn);

    /**
     * 新增退货记录
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 结果
     */
    public int insertTNewProcurementReturn(TNewProcurementReturn tNewProcurementReturn);

    /**
     * 修改退货记录
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 结果
     */
    public int updateTNewProcurementReturn(TNewProcurementReturn tNewProcurementReturn);

    /**
     * 删除退货记录
     * 
     * @param id 退货记录主键
     * @return 结果
     */
    public int deleteTNewProcurementReturnById(Long id);

    /**
     * 批量删除退货记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewProcurementReturnByIds(Long[] ids);

    List<TNewProcurementReturnVO> selectByIds(@Param("ids")  Long[] ids);
}
