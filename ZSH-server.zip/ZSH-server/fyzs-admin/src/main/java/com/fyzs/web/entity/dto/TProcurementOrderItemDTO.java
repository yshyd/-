package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TProcurementOrderItem;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TProcurementOrderItemDTO extends TProcurementOrderItem {
}
