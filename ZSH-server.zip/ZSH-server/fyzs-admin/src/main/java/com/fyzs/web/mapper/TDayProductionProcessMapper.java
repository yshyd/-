package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayProductionProcess;
import com.fyzs.web.entity.query.TDayProductionProcessQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常巡检-食品加工制作过程巡检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-20
 */
@org.apache.ibatis.annotations.Mapper
public interface TDayProductionProcessMapper  extends BaseMapper<TDayProductionProcess>
{
    /**
     * 查询学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param id 学校食堂日管控-日常巡检-食品加工制作过程巡检主键
     * @return 学校食堂日管控-日常巡检-食品加工制作过程巡检
     */
    public TDayProductionProcessQuery selectTDayProductionProcessById(Long id);

    /**
     * 查询学校食堂日管控-日常巡检-食品加工制作过程巡检列表
     *
     * @return 学校食堂日管控-日常巡检-食品加工制作过程巡检集合
     */
    public List<TDayProductionProcessQuery> selectTDayProductionProcessList(TDayProductionProcessQuery query);

    /**
     * 新增学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param tDayProductionProcess 学校食堂日管控-日常巡检-食品加工制作过程巡检
     * @return 结果
     */
    public int insertTDayProductionProcess(TDayProductionProcess tDayProductionProcess);

    /**
     * 修改学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param tDayProductionProcess 学校食堂日管控-日常巡检-食品加工制作过程巡检
     * @return 结果
     */
    public int updateTDayProductionProcess(TDayProductionProcess tDayProductionProcess);

    /**
     * 删除学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param id 学校食堂日管控-日常巡检-食品加工制作过程巡检主键
     * @return 结果
     */
    public int deleteTDayProductionProcessById(Long id);

    /**
     * 批量删除学校食堂日管控-日常巡检-食品加工制作过程巡检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayProductionProcessByIds(Long[] ids);

    int countValidInspections(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    int countNormalInspections(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    int countAbnormalInspections(@Param("startDate") Date startDate,
                                 @Param("endDate") Date endDate,
                                 @Param("deptIds") List<Long> deptIds);
}
