package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常消毒-垃圾区域消毒对象 t_day_disinfection_garbage
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_disinfection_garbage")
public class TDayDisinfectionGarbage implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 消毒方式：0消毒剂消毒 */
        @Schema(description = "消毒方式：0消毒剂消毒")
        @Excel(name = "消毒方式：0消毒剂消毒")
        private Integer disinfectionType;

        /** 消毒人 */
        @Schema(description = "消毒人")
        @Excel(name = "消毒人")
        private String disinfectionUser;

        /** 消毒时段 格式时分区间，24小时制(09:30-10:30)逗号分割多个时段 */
        @Schema(description = "消毒时段 格式时分区间，24小时制(09:30-10:30)逗号分割多个时段")
        @Excel(name = "消毒时段 格式时分区间，24小时制(09:30-10:30)逗号分割多个时段")
        private String disinfectionTimes;

        /** 消毒日期(格式年月日：2025-05-05) */
        @Schema(description = "消毒日期(格式年月日：2025-05-05)")
        @Excel(name = "消毒日期(格式年月日：2025-05-05)")
        private String disinfectionDate;

        /** 监督人 */
        @Schema(description = "监督人")
        @Excel(name = "监督人")
        private String supervisionUser;

        /** 消毒现场照片,逗号分割，最多3张 */
        @Schema(description = "消毒现场照片,逗号分割，最多3张")
        @Excel(name = "消毒现场照片,逗号分割，最多3张")
        private String disinfectionImg;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
