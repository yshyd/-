package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 公告发布对象 t_announcement
 *
 * @author ysh
 * @date 2025-12-04
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_announcement")
public class TAnnouncement implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 发布公告对应人的主体ID */
        @Schema(description = "发布公告对应人的主体ID")
        @Excel(name = "发布公告对应人的主体ID")
        private Long deptId;

        /** 发布人ID */
        @Schema(description = "发布人ID")
        @Excel(name = "发布人ID")
        private Long userId;

        /** 发布人对应的主体名称 */
        @Schema(description = "发布人对应的主体名称")
        @Excel(name = "发布人对应的主体名称")
        private String deptName;

        /** 发布人姓名 */
        @Schema(description = "发布人姓名")
        @Excel(name = "发布人姓名")
        private String userName;

        /** 公告类型：0教体局公告、1学校公告、2供应商公告、3市监局公告、4食堂公告、5政府公告 */
        @Schema(description = "公告类型：0教体局公告、1学校公告、2供应商公告、3市监局公告、4食堂公告、5政府公告")
        @Excel(name = "公告类型：0教体局公告、1学校公告、2供应商公告、3市监局公告、4食堂公告、5政府公告")
        private Integer type;

        /** 公告标题(255字内) */
        @Schema(description = "公告标题(255字内)")
        @Excel(name = "公告标题(255字内)")
        private String title;

        /** 公告内容5000字(副文本) */
        @Schema(description = "公告内容5000字(副文本)")
        @Excel(name = "公告内容5000字(副文本)")
        private String content;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 发布人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "发布人id")
        @Excel(name = "发布人id")
        private Long createUser;

        /** 发布人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "发布人姓名")
        @Excel(name = "发布人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
