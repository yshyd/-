package com.fyzs.web.entity.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class SummaryItemDTO {
    protected String moduleName;        // 模块名称
    protected Integer shouldDo;         // 应做数量
    protected Integer done;             // 已做数量
    protected Integer notDone;          // 未做数量
    protected Integer normal;           // 正常数量
    protected Integer abnormal;         // 异常数量
    protected BigDecimal executionRate;  // 执行率
    protected BigDecimal qualificationRate; // 合格率
    //总分
    protected BigDecimal totalScore;
    //执行得分
    protected BigDecimal executionScore;
    //合格得分
    protected BigDecimal qualificationScore;
    //总得分
    protected BigDecimal finalScore;

    // 初始执行分
    protected Double initialExecutionScore = 4.0;
    // 初始合格分
    protected Double initialQualificationScore = 4.0;

    public void calculateRates() {
        // 计算执行率
        if (shouldDo != null && shouldDo > 0) {
            this.executionRate = BigDecimal.valueOf(done)
                    .divide(BigDecimal.valueOf(shouldDo), 3, BigDecimal.ROUND_HALF_UP)
                    .multiply(BigDecimal.valueOf(100))
                    .setScale(1, BigDecimal.ROUND_HALF_UP);
        } else {
            this.executionRate = BigDecimal.ZERO;
        }

        // 计算合格率（仅当存在正常和异常数据时计算）
        if (normal != null || abnormal != null) {
            int totalNormal = normal != null ? normal : 0;
            int totalAbnormal = abnormal != null ? abnormal : 0;
            int total = totalNormal + totalAbnormal;

            if (total > 0) {
                this.qualificationRate = BigDecimal.valueOf(totalNormal)
                        .divide(BigDecimal.valueOf(total), 3, BigDecimal.ROUND_HALF_UP)
                        .multiply(BigDecimal.valueOf(100))
                        .setScale(1, BigDecimal.ROUND_HALF_UP);
            } else {
                this.qualificationRate = BigDecimal.ZERO;
            }
        } else {
            // 如果没有正常/异常数据，则合格率为0
            this.qualificationRate = BigDecimal.ZERO;
        }
    }

    // 通用评分计算方法
    public void calculateScores() {
        // 设置总分
        this.totalScore = BigDecimal.valueOf(initialExecutionScore + initialQualificationScore)
                .setScale(3, BigDecimal.ROUND_HALF_UP);

        // 执行得分 = 初始执行分 × (执行率/100)，保留3位小数
        if (executionRate != null) {
            this.executionScore = BigDecimal.valueOf(initialExecutionScore)
                    .multiply(executionRate.divide(BigDecimal.valueOf(100), 3, BigDecimal.ROUND_HALF_UP))
                    .setScale(3, BigDecimal.ROUND_HALF_UP);
        } else {
            this.executionScore = BigDecimal.ZERO;
        }

        // 合格得分 = 初始合格分 × (合格率/100)，保留3位小数
        if (qualificationRate != null) {
            this.qualificationScore = BigDecimal.valueOf(initialQualificationScore)
                    .multiply(qualificationRate.divide(BigDecimal.valueOf(100), 3, BigDecimal.ROUND_HALF_UP))
                    .setScale(3, BigDecimal.ROUND_HALF_UP);
        } else {
            this.qualificationScore = BigDecimal.ZERO;
        }

        // 最终得分 = 执行得分 + 合格得分，保留3位小数
        this.finalScore = (this.executionScore != null ? this.executionScore : BigDecimal.ZERO)
                .add(this.qualificationScore != null ? this.qualificationScore : BigDecimal.ZERO)
                .setScale(3, BigDecimal.ROUND_HALF_UP);
    }

    // 设置自定义初始分值
    public void setInitialScores(Double executionScore, Double qualificationScore) {
        this.initialExecutionScore = executionScore;
        this.initialQualificationScore = qualificationScore;
        this.totalScore = BigDecimal.valueOf(initialExecutionScore + initialQualificationScore);
    }
}