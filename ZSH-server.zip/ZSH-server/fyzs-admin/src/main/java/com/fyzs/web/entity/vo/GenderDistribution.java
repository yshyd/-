package com.fyzs.web.entity.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class GenderDistribution {

    /** 男性人数 */
    @Schema(description = "男性人数")
    private Integer maleCount;
    /** 女性人数 */
    @Schema(description = "女性人数")
    private Integer femaleCount;
    /** 男性占比 */
    @Schema(description = "男性占比")
    private double maleRatio; // 百分比
    /** 女性占比 */
    @Schema(description = "女性占比")
    private double femaleRatio;
}
