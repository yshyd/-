package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.web.entity.query.TDayNumberDinersQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDayNumberDiners;
import com.fyzs.web.service.ITDayNumberDinersService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 食安监管-日管控-日常就餐-就餐人数Controller
 * 
 * @author ysh
 * @date 2025-11-24
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/number/diners")
public class TDayNumberDinersController extends BaseController
{

    private final ITDayNumberDinersService tDayNumberDinersService;

    /**
     * 查询食安监管-日管控-日常就餐-就餐人数列表
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDayNumberDinersQuery tDayNumberDiners)
    {
        startPage();
        List<TDayNumberDinersQuery> list = tDayNumberDinersService.selectTDayNumberDinersList(tDayNumberDiners);
        return getDataTable(list);
    }

    /**
     * 导出食安监管-日管控-日常就餐-就餐人数列表
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:export')")
    @Log(title = "食安监管-日管控-日常就餐-就餐人数", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDayNumberDinersQuery tDayNumberDiners)
    {
        List<TDayNumberDinersQuery> list = tDayNumberDinersService.selectTDayNumberDinersList(tDayNumberDiners);
        ExcelUtil<TDayNumberDinersQuery> util = new ExcelUtil<TDayNumberDinersQuery>(TDayNumberDinersQuery.class);
        util.exportExcel(response, list, "食安监管-日管控-日常就餐-就餐人数数据");
    }

    /**
     * 获取食安监管-日管控-日常就餐-就餐人数详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDayNumberDinersService.selectTDayNumberDinersById(id));
    }

    /**
     * 新增食安监管-日管控-日常就餐-就餐人数
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:add')")
    @Log(title = "食安监管-日管控-日常就餐-就餐人数", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDayNumberDiners tDayNumberDiners)
    {
        return toAjax(tDayNumberDinersService.insertTDayNumberDiners(tDayNumberDiners));
    }

    /**
     * 修改食安监管-日管控-日常就餐-就餐人数
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:edit')")
    @Log(title = "食安监管-日管控-日常就餐-就餐人数", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDayNumberDiners tDayNumberDiners)
    {
        return toAjax(tDayNumberDinersService.updateTDayNumberDiners(tDayNumberDiners));
    }

    /**
     * 生效/作废(只传id和delFlag)
     */
    @Log(title = "食安监管-日管控-日常就餐-就餐人数", businessType = BusinessType.UPDATE)
    @PutMapping("/status")
    public AjaxResult status(@RequestBody TDayNumberDiners tDayNumberDiners) {
        return toAjax(tDayNumberDinersService.updateById(tDayNumberDiners));
    }

    /**
     * 删除食安监管-日管控-日常就餐-就餐人数
     */
    //@PreAuthorize("@ss.hasPermi('web:diners:remove')")
    @Log(title = "食安监管-日管控-日常就餐-就餐人数", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDayNumberDinersService.deleteTDayNumberDinersByIds(ids));
    }
}
