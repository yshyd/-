package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.entity.TNewProcurementWarehouse;
import com.fyzs.web.entity.dto.TNewProcurementWarehouseDTO;
import com.fyzs.web.entity.query.TNewProcurementWarehouseQuery;
import com.fyzs.web.entity.vo.TNewProcurementWarehouseExportVO;

/**
 * 入库记录Service接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
public interface ITNewProcurementWarehouseService extends IService<TNewProcurementWarehouse>
{
    /**
     * 查询入库记录
     * 
     * @param id 入库记录主键
     * @return 入库记录
     */
    public TNewProcurementWarehouseQuery selectTNewProcurementWarehouseById(Long id);

    /**
     * 查询入库记录列表
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 入库记录集合
     */
    public List<TNewProcurementWarehouseQuery> selectTNewProcurementWarehouseList(TNewProcurementWarehouseQuery tNewProcurementWarehouse);

    /**
     * 根据筛选条件查询全部入库导出数据（不分页）
     *
     * @param tNewProcurementWarehouse 入库记录筛选条件
     * @return 入库记录集合
     */
    public List<TNewProcurementWarehouseExportVO> selectTNewProcurementWarehouseExportList(TNewProcurementWarehouseQuery tNewProcurementWarehouse);

    /**
     * 新增入库记录
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 结果
     */
    public int insertTNewProcurementWarehouse(TNewProcurementWarehouse tNewProcurementWarehouse);

    /**
     * 修改入库记录
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 结果
     */
    public int updateTNewProcurementWarehouse(TNewProcurementWarehouse tNewProcurementWarehouse);

    /**
     * 批量删除入库记录
     * 
     * @param ids 需要删除的入库记录主键集合
     * @return 结果
     */
    public int deleteTNewProcurementWarehouseByIds(Long[] ids);

    /**
     * 删除入库记录信息
     * 
     * @param id 入库记录主键
     * @return 结果
     */
    public int deleteTNewProcurementWarehouseById(Long id);

    int warehouse(TNewProcurementWarehouseDTO dto);

    int returnWarehouse(TNewProcurementWarehouseDTO dto);
}
