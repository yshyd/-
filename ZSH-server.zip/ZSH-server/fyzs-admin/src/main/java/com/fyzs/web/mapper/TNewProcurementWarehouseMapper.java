package com.fyzs.web.mapper;

import java.math.BigDecimal;
import java.util.List;
import com.fyzs.web.entity.TNewProcurementWarehouse;
import com.fyzs.web.entity.query.TNewProcurementWarehouseQuery;
import com.fyzs.web.entity.vo.TNewProcurementWarehouseExportVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 入库记录Mapper接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
@Mapper
public interface TNewProcurementWarehouseMapper  extends BaseMapper<TNewProcurementWarehouse>
{
    /**
     * 查询入库记录
     * 
     * @param id 入库记录主键
     * @return 入库记录
     */
    public TNewProcurementWarehouseQuery selectTNewProcurementWarehouseById(Long id);

    /**
     * 查询入库记录列表
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 入库记录集合
     */
    public List<TNewProcurementWarehouseQuery> selectTNewProcurementWarehouseList(TNewProcurementWarehouseQuery tNewProcurementWarehouse);

    /**
     * 根据筛选条件查询全部入库导出数据
     *
     * @param tNewProcurementWarehouse 入库记录筛选条件
     * @return 入库记录集合
     */
    public List<TNewProcurementWarehouseExportVO> selectTNewProcurementWarehouseExportList(TNewProcurementWarehouseQuery tNewProcurementWarehouse);

    /**
     * 新增入库记录
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 结果
     */
    public int insertTNewProcurementWarehouse(TNewProcurementWarehouse tNewProcurementWarehouse);

    /**
     * 修改入库记录
     * 
     * @param tNewProcurementWarehouse 入库记录
     * @return 结果
     */
    public int updateTNewProcurementWarehouse(TNewProcurementWarehouse tNewProcurementWarehouse);

    /**
     * 删除入库记录
     * 
     * @param id 入库记录主键
     * @return 结果
     */
    public int deleteTNewProcurementWarehouseById(Long id);

    /**
     * 批量删除入库记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTNewProcurementWarehouseByIds(Long[] ids);

    String getMaxSequence(String dateStr);

    /**
     * 统计指定商品和批次的入库数量总和
     * @param commodityId 商品 ID
     * @param batch 批次
     * @return 入库数量总和
     */
    BigDecimal sumInnerNumberByCommodityAndBatch(@Param("commodityId") Long commodityId,@Param("batch") String batch);

    /**
     * 统计指定商品和批次且指定类型的入库数量总和
     * @param commodityId 商品 ID
     * @param batch 批次
     * @return 入库数量总和
     */
    BigDecimal sumInnerNumberByCommodityAndBatchWithType(@Param("commodityId") Long commodityId,@Param("batch") String batch);
}
