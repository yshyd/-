package com.fyzs.web.entity.vo;

import lombok.Data;

@Data
public class StatisticsResponseVO {
    /** 学校数量 */
    private Integer schoolCount;
    /** 食堂数量 */
    private Integer canteenCount;
    /** 从业人员 */
    private Integer staffCount;
    /** 就餐人员 */
    private Integer diningCount;
    /** 供应商数量 */
    private Integer supplierCount;
}
