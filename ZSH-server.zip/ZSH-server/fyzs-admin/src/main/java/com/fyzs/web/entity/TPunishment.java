package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 食安监管-督察处罚对象 t_punishment
 *
 * @author ysh
 * @date 2025-12-02
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_punishment")
public class TPunishment implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        private Long deptId;

        /** 登记人 */
        @Schema(description = "登记人")
        @Excel(name = "登记人")
        private String registrantUser;

        /** 登记时间 */
        @Schema(description = "登记时间")
        @Excel(name = "登记时间")
        private String registrantTime;

        /** 责令整改通知书，最多5张 */
        @Schema(description = "责令整改通知书，最多5张")
        @Excel(name = "责令整改通知书，最多5张")
        private String notice;

        /** 行政处罚决定书,最多5张 */
        @Schema(description = "行政处罚决定书,最多5张")
        @Excel(name = "行政处罚决定书,最多5张")
        private String decisionDocument;

        /** 处罚影像 */
        @Schema(description = "处罚影像")
        @Excel(name = "处罚影像")
        private String penaltyVideo;

        /** 处罚说明：500字内 */
        @Schema(description = "处罚说明：500字内")
        @Excel(name = "处罚说明：500字内")
        private String penaltyExplanation;

        /** 0有效1作废 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1作废")
        private Integer delFlag;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
