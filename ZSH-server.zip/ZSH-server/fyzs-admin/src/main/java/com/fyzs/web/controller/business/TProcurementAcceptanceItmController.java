package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TProcurementAcceptanceItm;
import com.fyzs.web.service.ITProcurementAcceptanceItmService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品采购验收单副Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/acceptance/itm")
public class TProcurementAcceptanceItmController extends BaseController
{

    private final ITProcurementAcceptanceItmService tProcurementAcceptanceItmService;

    /**
     * 查询商品采购验收单副列表
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:list')")
    @GetMapping("/list")
    public TableDataInfo list(TProcurementAcceptanceItm tProcurementAcceptanceItm)
    {
        startPage();
        List<TProcurementAcceptanceItm> list = tProcurementAcceptanceItmService.selectTProcurementAcceptanceItmList(tProcurementAcceptanceItm);
        return getDataTable(list);
    }

    /**
     * 导出商品采购验收单副列表
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:export')")
    @Log(title = "商品采购验收单副", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TProcurementAcceptanceItm tProcurementAcceptanceItm)
    {
        List<TProcurementAcceptanceItm> list = tProcurementAcceptanceItmService.selectTProcurementAcceptanceItmList(tProcurementAcceptanceItm);
        ExcelUtil<TProcurementAcceptanceItm> util = new ExcelUtil<TProcurementAcceptanceItm>(TProcurementAcceptanceItm.class);
        util.exportExcel(response, list, "商品采购验收单副数据");
    }

    /**
     * 获取商品采购验收单副详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tProcurementAcceptanceItmService.selectTProcurementAcceptanceItmById(id));
    }

    /**
     * 新增商品采购验收单副
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:add')")
    @Log(title = "商品采购验收单副", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TProcurementAcceptanceItm tProcurementAcceptanceItm)
    {
        return toAjax(tProcurementAcceptanceItmService.save(tProcurementAcceptanceItm));
    }

    /**
     * 修改商品采购验收单副
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:edit')")
    @Log(title = "商品采购验收单副", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TProcurementAcceptanceItm tProcurementAcceptanceItm)
    {
        return toAjax(tProcurementAcceptanceItmService.updateById(tProcurementAcceptanceItm));
    }

    /**
     * 删除商品采购验收单副
     */
    //@PreAuthorize("@ss.hasPermi('web:itm:remove')")
    @Log(title = "商品采购验收单副", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tProcurementAcceptanceItmService.deleteTProcurementAcceptanceItmByIds(ids));
    }
}
