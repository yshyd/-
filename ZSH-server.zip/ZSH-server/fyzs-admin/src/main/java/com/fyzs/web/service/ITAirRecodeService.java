package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TAirRecode;
import com.fyzs.web.entity.query.TAirRecodeQuery;

/**
 * 空气消毒净化记录Service接口
 * 
 * @author ysh
 * @date 2026-08-17
 */
public interface ITAirRecodeService extends IService<TAirRecode>
{
    /**
     * 查询空气消毒净化记录
     * 
     * @param id 空气消毒净化记录主键
     * @return 空气消毒净化记录
     */
    public TAirRecode selectTAirRecodeById(Long id);

    /**
     * 查询空气消毒净化记录列表
     * 
     * @param tAirRecode 空气消毒净化记录
     * @return 空气消毒净化记录集合
     */
    public List<TAirRecodeQuery> selectTAirRecodeList(TAirRecodeQuery tAirRecode);

    /**
     * 新增空气消毒净化记录
     * 
     * @param tAirRecode 空气消毒净化记录
     * @return 结果
     */
    public int insertTAirRecode(TAirRecode tAirRecode);

    /**
     * 修改空气消毒净化记录
     * 
     * @param tAirRecode 空气消毒净化记录
     * @return 结果
     */
    public int updateTAirRecode(TAirRecode tAirRecode);

    /**
     * 批量删除空气消毒净化记录
     * 
     * @param ids 需要删除的空气消毒净化记录主键集合
     * @return 结果
     */
    public int deleteTAirRecodeByIds(Long[] ids);

    /**
     * 删除空气消毒净化记录信息
     * 
     * @param id 空气消毒净化记录主键
     * @return 结果
     */
    public int deleteTAirRecodeById(Long id);
}
