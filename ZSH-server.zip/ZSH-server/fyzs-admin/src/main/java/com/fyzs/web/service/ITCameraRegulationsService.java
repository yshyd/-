package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCameraRegulations;

/**
 * 违法违规行为识别信息Service接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
public interface ITCameraRegulationsService extends IService<TCameraRegulations>
{
    /**
     * 查询违法违规行为识别信息
     * 
     * @param id 违法违规行为识别信息主键
     * @return 违法违规行为识别信息
     */
    public TCameraRegulations selectTCameraRegulationsById(Long id);

    /**
     * 查询违法违规行为识别信息列表
     * 
     * @param tCameraRegulations 违法违规行为识别信息
     * @return 违法违规行为识别信息集合
     */
    public List<TCameraRegulations> selectTCameraRegulationsList(TCameraRegulations tCameraRegulations);

    /**
     * 新增违法违规行为识别信息
     * 
     * @param tCameraRegulations 违法违规行为识别信息
     * @return 结果
     */
    public int insertTCameraRegulations(TCameraRegulations tCameraRegulations);

    /**
     * 修改违法违规行为识别信息
     * 
     * @param tCameraRegulations 违法违规行为识别信息
     * @return 结果
     */
    public int updateTCameraRegulations(TCameraRegulations tCameraRegulations);

    /**
     * 批量删除违法违规行为识别信息
     * 
     * @param ids 需要删除的违法违规行为识别信息主键集合
     * @return 结果
     */
    public int deleteTCameraRegulationsByIds(Long[] ids);

    /**
     * 删除违法违规行为识别信息信息
     * 
     * @param id 违法违规行为识别信息主键
     * @return 结果
     */
    public int deleteTCameraRegulationsById(Long id);
}
