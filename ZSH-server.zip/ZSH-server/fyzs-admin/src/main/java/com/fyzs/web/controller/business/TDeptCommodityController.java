package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.web.entity.query.TDeptCommodityQuery;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TDeptCommodity;
import com.fyzs.web.service.ITDeptCommodityService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 主体商品库Controller
 * 
 * @author ysh
 * @date 2025-10-28
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/dept/commodity")
public class TDeptCommodityController extends BaseController
{

    private final ITDeptCommodityService tDeptCommodityService;

    /**
     * 查询主体商品库列表
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:list')")
    @GetMapping("/list")
    public TableDataInfo list(TDeptCommodityQuery tDeptCommodity)
    {
        startPage();
        List<TDeptCommodityQuery> list = tDeptCommodityService.selectTDeptCommodityList(tDeptCommodity);
        return getDataTable(list);
    }
    /**
     * 查询主体商品库列表(只查自己)
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:list')")
    @GetMapping("/oneself/list")
    public TableDataInfo oneselfList(TDeptCommodityQuery tDeptCommodity)
    {
        startPage();
        List<TDeptCommodityQuery> list = tDeptCommodityService.selectOneselfList(tDeptCommodity);
        return getDataTable(list);
    }

    /**
     * 获取不在主体下的商品列表
     */
    @GetMapping("/list/notInDept")
    public AjaxResult listNotInDept(TDeptCommodityQuery tDeptCommodity){
        if (ObjectUtils.isEmpty(tDeptCommodity.getDeptId())){
            return error("请选择主体");
        }
        return success(tDeptCommodityService.listNotInDept(tDeptCommodity));
    }


    /**
     * 导出主体商品库列表
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:export')")
    @Log(title = "主体商品库", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TDeptCommodityQuery tDeptCommodity)
    {
        List<TDeptCommodityQuery> list = tDeptCommodityService.selectTDeptCommodityList(tDeptCommodity);
        ExcelUtil<TDeptCommodityQuery> util = new ExcelUtil<TDeptCommodityQuery>(TDeptCommodityQuery.class);
        util.exportExcel(response, list, "主体商品库数据");
    }

    /**
     * 获取主体商品库详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tDeptCommodityService.selectTDeptCommodityById(id));
    }

    /**
     * 新增主体商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:add')")
    @Log(title = "主体商品库", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TDeptCommodity tDeptCommodity)
    {
        long count = tDeptCommodityService.count(new LambdaQueryWrapper<TDeptCommodity>()
                .eq(TDeptCommodity::getDeptId, tDeptCommodity.getDeptId())
                .eq(TDeptCommodity::getCommodityId, tDeptCommodity.getCommodityId())
        );
        if (count > 0) {
            return error("该商品已经添加，请勿重复添加");
        }
        tDeptCommodity.setDelFlag(0);
        return toAjax(tDeptCommodityService.save(tDeptCommodity));
    }

    /**
     * 批量新增主体商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:add')")
    @Log(title = "主体商品库", businessType = BusinessType.INSERT)
    @PostMapping("/batchAdd")
    @Transactional(rollbackFor = Exception.class)
    public AjaxResult batchAdd(@RequestBody List<TDeptCommodity> tDeptCommodities)
    {
        if (tDeptCommodities == null || tDeptCommodities.isEmpty()) {
            return error("商品列表不能为空");
        }

        for (TDeptCommodity tDeptCommodity : tDeptCommodities) {
            long count = tDeptCommodityService.count(new LambdaQueryWrapper<TDeptCommodity>()
                    .eq(TDeptCommodity::getDeptId, tDeptCommodity.getDeptId())
                    .eq(TDeptCommodity::getCommodityId, tDeptCommodity.getCommodityId())
            );
            if (count > 0) {
                return error("商品" + tDeptCommodity.getCommodityId() + "已经存在，请勿重复添加");
            }
            tDeptCommodity.setDelFlag(0);
        }

        return toAjax(tDeptCommodityService.saveBatch(tDeptCommodities));
    }

    /**
     * 修改主体商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:edit')")
    @Log(title = "主体商品库", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TDeptCommodity tDeptCommodity)
    {
        long count = tDeptCommodityService.count(new LambdaQueryWrapper<TDeptCommodity>()
                .eq(TDeptCommodity::getDeptId, tDeptCommodity.getDeptId())
                .eq(TDeptCommodity::getCommodityId, tDeptCommodity.getCommodityId())
                .ne(TDeptCommodity::getId, tDeptCommodity.getId())
        );
        if (count > 0) {
            return error("该商品已经添加，请勿重复添加");
        }
        return toAjax(tDeptCommodityService.updateById(tDeptCommodity));
    }

    /**
     * 删除主体商品库
     */
    //@PreAuthorize("@ss.hasPermi('web:commodity:remove')")
    @Log(title = "主体商品库", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tDeptCommodityService.deleteTDeptCommodityByIds(ids));
    }
}
