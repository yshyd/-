package com.fyzs.web.mapper;

import java.util.List;

import com.fyzs.web.entity.TCameraRegulationsVideo;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 违法违规识别视频固证文件存储信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TCameraRegulationsVideoMapper  extends BaseMapper<TCameraRegulationsVideo>
{
    /**
     * 查询违法违规识别视频固证文件存储信息
     * 
     * @param id 违法违规识别视频固证文件存储信息主键
     * @return 违法违规识别视频固证文件存储信息
     */
    public TCameraRegulationsVideo selectTCameraRegulationsVideoById(Long id);

    /**
     * 查询违法违规识别视频固证文件存储信息列表
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 违法违规识别视频固证文件存储信息集合
     */
    public List<TCameraRegulationsVideo> selectTCameraRegulationsVideoList(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 新增违法违规识别视频固证文件存储信息
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 结果
     */
    public int insertTCameraRegulationsVideo(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 修改违法违规识别视频固证文件存储信息
     * 
     * @param tCameraRegulationsVideo 违法违规识别视频固证文件存储信息
     * @return 结果
     */
    public int updateTCameraRegulationsVideo(TCameraRegulationsVideo tCameraRegulationsVideo);

    /**
     * 删除违法违规识别视频固证文件存储信息
     * 
     * @param id 违法违规识别视频固证文件存储信息主键
     * @return 结果
     */
    public int deleteTCameraRegulationsVideoById(Long id);

    /**
     * 批量删除违法违规识别视频固证文件存储信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraRegulationsVideoByIds(Long[] ids);
}
