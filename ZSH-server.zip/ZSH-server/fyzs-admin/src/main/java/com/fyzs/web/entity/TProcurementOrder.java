package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 * 商品采购单主对象 t_procurement_order
 *
 * @author ysh
 * @date 2025-10-29
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_procurement_order")
public class TProcurementOrder implements Serializable {

    private static final long serialVersionUID = 1L;

        /**  */
        @Schema(description = "")
        private Long id;

        /** 主体ID */
        @Schema(description = "主体ID")
        @Excel(name = "主体ID")
        @NotNull(message = "主体ID不能为空")
        private Long deptId;

        /** 供应商id */
        @Schema(description = "供应商id")
        @Excel(name = "供应商id")
        @NotNull(message = "供应商id不能为空")
        private Long supplerId;

        /** 采购订单号(格式：CGD202510280001依次递增) */
        @Schema(description = "采购订单号(格式：CGD202510280001依次递增)")
        @Excel(name = "采购订单号(格式：CGD202510280001依次递增)")
        private String orderNum;

        /** 订单状态：0待确认、1已作废、2已确认 */
        @Schema(description = "订单状态：0待确认、1已作废、2已确认")
        @Excel(name = "订单状态：0待确认、1已作废、2已确认")
        private Integer status;

        /** 采购单验收状态0待验收，1部分验收，2全部验收 */
        @Schema(description = "采购单验收状态0待验收，1部分验收，2全部验收")
        @Excel(name = "采购单验收状态0待验收，1部分验收，2全部验收")
        private Integer acceptanceStatus;

        /** 结算状态：0未结算1已结算 */
        @Schema(description = "结算状态：0未结算1已结算 ")
        @Excel(name = "结算状态：0未结算1已结算 ")
        private Integer settlementStatus;

        /** 到货日期 */
        @Schema(description = "到货日期")
        @Excel(name = "到货日期")
        @NotBlank(message = "到货日期不能为空")
        private String date;

        /** 创建人id */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人id")
        @Excel(name = "创建人id")
        private Long createUser;

        /** 创建人姓名 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名")
        @Excel(name = "创建人姓名")
        private String createName;

        /** 修改人id */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id")
        @Excel(name = "修改人id")
        private Long updateUser;

        /** 修改人名称 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称")
        @Excel(name = "修改人名称")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd")
        private Date updateDate;

}
