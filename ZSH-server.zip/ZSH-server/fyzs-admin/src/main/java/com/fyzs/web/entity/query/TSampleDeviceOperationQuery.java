package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TSampleDeviceOperation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TSampleDeviceOperationQuery extends TSampleDeviceOperation {

    /** 主体ID */
    @Schema(description = "主体ID")
    @Excel(name = "主体ID")
    private Long deptId;

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    /** 心跳时间 */
    @Schema(description = "心跳时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "心跳时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date heartTime;


    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
