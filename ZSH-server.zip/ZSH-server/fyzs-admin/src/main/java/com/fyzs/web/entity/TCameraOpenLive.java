package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 明厨亮灶三方接入信息对象 t_camera_open_live
 *
 * @author ysh
 * @date 2025-12-17
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_camera_open_live")
public class TCameraOpenLive implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        @Excel(name = "${comment}", readConverterExp = "$column.readConverterExp()")
        private String authCode;

        /** 公司名称 */
        @Schema(description = "公司名称")
        @Excel(name = "公司名称")
        private String companyName;

        /** 回调摄像头的baseURL */
        @Schema(description = "回调摄像头的baseURL")
        @Excel(name = "回调摄像头的baseURL")
        private String baseUrl;

        /** 所属业务 */
        @Schema(description = "所属业务")
        @Excel(name = "所属业务")
        private String business;

        /** 删除标志 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "删除标志")
        private Integer delFlag;

        /** 对接联系人(一般在于后期摄像头使用过程中第三方平台存在问题时联系) */
        @Schema(description = "对接联系人(一般在于后期摄像头使用过程中第三方平台存在问题时联系)")
        @Excel(name = "对接联系人(一般在于后期摄像头使用过程中第三方平台存在问题时联系)")
        private String contactPerson;

        /** 对接联系人电话(一般在于后期摄像头使用过程中第三方平台存在问题时联系) */
        @Schema(description = "对接联系人电话(一般在于后期摄像头使用过程中第三方平台存在问题时联系)")
        @Excel(name = "对接联系人电话(一般在于后期摄像头使用过程中第三方平台存在问题时联系)")
        private String cantactPhone;

        /** 单个学校最大接入数量 */
        @Schema(description = "单个学校最大接入数量")
        @Excel(name = "单个学校最大接入数量")
        private Long maxNumber;

        /** 状态0 启用 1禁用 */
        @Schema(description = "状态0 启用 1禁用")
        @Excel(name = "状态0 启用 1禁用")
        private Long status;

        /** 创建人ID */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人ID")
        @Excel(name = "创建人ID")
        private Long createUser;

        /** 创建人 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人")
        @Excel(name = "创建人")
        private String createName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改人ID */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人ID")
        @Excel(name = "修改人ID")
        private Long updateUser;

        /** 修改人 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人")
        @Excel(name = "修改人")
        private String updateName;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
