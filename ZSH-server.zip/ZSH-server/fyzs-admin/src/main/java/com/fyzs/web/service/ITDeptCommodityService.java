package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TCommodity;
import com.fyzs.web.entity.TDeptCommodity;
import com.fyzs.web.entity.query.TDeptCommodityQuery;

/**
 * 主体商品库Service接口
 * 
 * @author ysh
 * @date 2025-10-28
 */
public interface ITDeptCommodityService extends IService<TDeptCommodity>
{
    /**
     * 查询主体商品库
     * 
     * @param id 主体商品库主键
     * @return 主体商品库
     */
    public TDeptCommodity selectTDeptCommodityById(Long id);

    /**
     * 查询主体商品库列表
     * 
     * @param tDeptCommodity 主体商品库
     * @return 主体商品库集合
     */
    public List<TDeptCommodityQuery> selectTDeptCommodityList(TDeptCommodityQuery tDeptCommodity);

    /**
     * 新增主体商品库
     * 
     * @param tDeptCommodity 主体商品库
     * @return 结果
     */
    public int insertTDeptCommodity(TDeptCommodity tDeptCommodity);

    /**
     * 修改主体商品库
     * 
     * @param tDeptCommodity 主体商品库
     * @return 结果
     */
    public int updateTDeptCommodity(TDeptCommodity tDeptCommodity);

    /**
     * 批量删除主体商品库
     * 
     * @param ids 需要删除的主体商品库主键集合
     * @return 结果
     */
    public int deleteTDeptCommodityByIds(Long[] ids);

    /**
     * 删除主体商品库信息
     * 
     * @param id 主体商品库主键
     * @return 结果
     */
    public int deleteTDeptCommodityById(Long id);

    List<TCommodity> listNotInDept(TDeptCommodityQuery tDeptCommodity);

    List<TDeptCommodityQuery> selectOneselfList(TDeptCommodityQuery tDeptCommodity);
}
