package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.web.entity.TNewProcurementReturn;
import com.fyzs.web.entity.dto.TNewProcurementReturnDTO;
import com.fyzs.web.entity.query.TNewProcurementReturnQuery;
import com.fyzs.web.entity.vo.TNewProcurementReturnVO;

/**
 * 退货记录Service接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
public interface ITNewProcurementReturnService extends IService<TNewProcurementReturn>
{
    /**
     * 查询退货记录
     * 
     * @param id 退货记录主键
     * @return 退货记录
     */
    public TNewProcurementReturnQuery selectTNewProcurementReturnById(Long id);

    /**
     * 查询退货记录列表
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 退货记录集合
     */
    public List<TNewProcurementReturnQuery> selectTNewProcurementReturnList(TNewProcurementReturnQuery tNewProcurementReturn);

    /**
     * 新增退货记录
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 结果
     */
    public int insertTNewProcurementReturn(TNewProcurementReturn tNewProcurementReturn);

    /**
     * 修改退货记录
     * 
     * @param tNewProcurementReturn 退货记录
     * @return 结果
     */
    public int updateTNewProcurementReturn(TNewProcurementReturn tNewProcurementReturn);

    /**
     * 批量删除退货记录
     * 
     * @param ids 需要删除的退货记录主键集合
     * @return 结果
     */
    public int deleteTNewProcurementReturnByIds(Long[] ids);

    /**
     * 删除退货记录信息
     * 
     * @param id 退货记录主键
     * @return 结果
     */
    public int deleteTNewProcurementReturnById(Long id);

    int cancel(Long id);

    int confirm(TNewProcurementReturnDTO dto);

    List<TNewProcurementReturnVO> getCommodityPrice( Long[] ids);

    int batchSettlement(List<TNewProcurementReturnDTO> dtos);
}
