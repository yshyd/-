package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TInventory;
import com.fyzs.web.entity.query.TInventoryQuery;
import com.fyzs.web.entity.vo.TInventoryExportVO;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 商品批次库存Mapper接口
 * 
 * @author ysh
 * @date 2025-10-30
 */
@Mapper
public interface TInventoryMapper  extends BaseMapper<TInventory>
{
    /**
     * 查询商品批次库存
     * 
     * @param id 商品批次库存主键
     * @return 商品批次库存
     */
    public TInventoryQuery selectTInventoryById(Long id);

    /**
     * 查询商品批次库存列表
     * 
     * @param tInventory 商品批次库存
     * @return 商品批次库存集合
     */
    public List<TInventoryQuery> selectTInventoryList(TInventoryQuery tInventory);

    /**
     * 根据筛选条件查询商品库存汇总导出数据
     *
     * @param tInventory 库存筛选条件
     * @return 商品库存汇总集合
     */
    public List<TInventoryExportVO> selectTInventoryExportList(TInventoryQuery tInventory);

    /**
     * 新增商品批次库存
     * 
     * @param tInventory 商品批次库存
     * @return 结果
     */
    public int insertTInventory(TInventory tInventory);

    /**
     * 修改商品批次库存
     * 
     * @param tInventory 商品批次库存
     * @return 结果
     */
    public int updateTInventory(TInventory tInventory);

    /**
     * 删除商品批次库存
     * 
     * @param id 商品批次库存主键
     * @return 结果
     */
    public int deleteTInventoryById(Long id);

    /**
     * 批量删除商品批次库存
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTInventoryByIds(Long[] ids);

    void updateInventoryToZero(String batchNo);

     List<TInventoryQuery>  pullList (TInventoryQuery tInventory);

    List<TInventoryQuery> warnList(TInventoryQuery tInventory);
}
