package com.fyzs.web.mapper;

import java.util.List;
import java.util.Map;

import com.fyzs.web.entity.TCamera;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.fyzs.web.entity.dto.DeptCameraCountDTO;
import com.fyzs.web.entity.query.TCameraQuery;
import com.fyzs.web.entity.query.TDeviceQuery;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * 可视化视频监控设备基本信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TCameraMapper  extends BaseMapper<TCamera>
{
    /**
     * 查询可视化视频监控设备基本信息
     * 
     * @param id 可视化视频监控设备基本信息主键
     * @return 可视化视频监控设备基本信息
     */
    public TCamera selectTCameraById(Long id);

    /**
     * 查询可视化视频监控设备基本信息列表
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 可视化视频监控设备基本信息集合
     */
    public List<TCamera> selectTCameraList(TCamera tCamera);


    List<TCameraQuery> relevanceList(TCameraQuery tCamera);
    /**
     * 新增可视化视频监控设备基本信息
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 结果
     */
    public int insertTCamera(TCamera tCamera);

    /**
     * 修改可视化视频监控设备基本信息
     * 
     * @param tCamera 可视化视频监控设备基本信息
     * @return 结果
     */
    public int updateTCamera(TCamera tCamera);

    /**
     * 删除可视化视频监控设备基本信息
     * 
     * @param id 可视化视频监控设备基本信息主键
     * @return 结果
     */
    public int deleteTCameraById(Long id);

    /**
     * 批量删除可视化视频监控设备基本信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraByIds(Long[] ids);

    /**
     * 根据部门ID和环节代码查询最大的序号
     *
     * @param deptId 部门ID
     * @param linksCode 环节代码
     * @return 最大序号
     */
    Integer selectMaxSequenceByDeptAndLinksCode(@Param("deptId") Long deptId, @Param("linksCode") String linksCode, @Param("linksName") String linksName);

    Integer selectMaxDeptAndLinksName(@Param("deptId")Long deptId, @Param("linksName") String linksName);

    TCameraQuery getRelationInfo(Long id);

    List<DeptCameraCountDTO> selectDeptCameraCountMap();

    int selectCameraCountByQuery(TDeviceQuery query);
}
