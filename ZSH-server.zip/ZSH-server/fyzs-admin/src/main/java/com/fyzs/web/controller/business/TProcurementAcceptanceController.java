package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TProcurementAcceptance;
import com.fyzs.web.service.ITProcurementAcceptanceService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品采购验收Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/acceptance")
public class TProcurementAcceptanceController extends BaseController
{

    private final ITProcurementAcceptanceService tProcurementAcceptanceService;

    /**
     * 查询商品采购验收列表
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:list')")
    @GetMapping("/list")
    public TableDataInfo list(TProcurementAcceptance tProcurementAcceptance)
    {
        startPage();
        List<TProcurementAcceptance> list = tProcurementAcceptanceService.selectTProcurementAcceptanceList(tProcurementAcceptance);
        return getDataTable(list);
    }

    /**
     * 导出商品采购验收列表
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:export')")
    @Log(title = "商品采购验收", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TProcurementAcceptance tProcurementAcceptance)
    {
        List<TProcurementAcceptance> list = tProcurementAcceptanceService.selectTProcurementAcceptanceList(tProcurementAcceptance);
        ExcelUtil<TProcurementAcceptance> util = new ExcelUtil<TProcurementAcceptance>(TProcurementAcceptance.class);
        util.exportExcel(response, list, "商品采购验收数据");
    }

    /**
     * 获取商品采购验收详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tProcurementAcceptanceService.selectTProcurementAcceptanceById(id));
    }

    /**
     * 新增商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:add')")
    @Log(title = "商品采购验收", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TProcurementAcceptance tProcurementAcceptance)
    {
        return toAjax(tProcurementAcceptanceService.save(tProcurementAcceptance));
    }

    /**
     * 修改商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:edit')")
    @Log(title = "商品采购验收", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TProcurementAcceptance tProcurementAcceptance)
    {
        return toAjax(tProcurementAcceptanceService.updateById(tProcurementAcceptance));
    }

    /**
     * 删除商品采购验收
     */
    //@PreAuthorize("@ss.hasPermi('web:acceptance:remove')")
    @Log(title = "商品采购验收", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tProcurementAcceptanceService.deleteTProcurementAcceptanceByIds(ids));
    }
}
