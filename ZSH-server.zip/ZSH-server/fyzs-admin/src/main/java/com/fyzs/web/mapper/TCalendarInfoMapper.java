package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.fyzs.web.entity.TCalendarInfo;
import com.fyzs.web.entity.query.TCalendarInfoQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 食堂运营配置Mapper接口
 * 
 * @author ysh
 * @date 2025-10-25
 */
@Mapper
public interface TCalendarInfoMapper  extends BaseMapper<TCalendarInfo>
{
    /**
     * 查询食堂运营配置
     * 
     * @param id 食堂运营配置主键
     * @return 食堂运营配置
     */
    public TCalendarInfo selectTCalendarInfoById(Long id);

    /**
     * 查询食堂运营配置列表
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 食堂运营配置集合
     */
    public List<TCalendarInfoQuery> selectTCalendarInfoList(TCalendarInfoQuery tCalendarInfo);

    /**
     * 新增食堂运营配置
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 结果
     */
    public int insertTCalendarInfo(TCalendarInfo tCalendarInfo);

    /**
     * 修改食堂运营配置
     * 
     * @param tCalendarInfo 食堂运营配置
     * @return 结果
     */
    public int updateTCalendarInfo(TCalendarInfo tCalendarInfo);

    /**
     * 删除食堂运营配置
     * 
     * @param id 食堂运营配置主键
     * @return 结果
     */
    public int deleteTCalendarInfoById(Long id);

    /**
     * 批量删除食堂运营配置
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCalendarInfoByIds(Long[] ids);

    TCalendarInfo selectByDeptIdAndDate(@Param("deptId") Long deptId,@Param("date") String date);

    // 在 TCalendarInfoMapper.java 接口中添加
    int countValidMealTimes(@Param("startDate") Date startDate,
                            @Param("endDate") Date endDate,
                            @Param("deptIds") List<Long> deptIds);

    // 添加到 TCalendarInfoMapper 接口中
    int countOperatingEntitiesByDate(@Param("date") Date date, @Param("deptIds") List<Long> deptIds);

    int countOperatingEntitiesInWeek(@Param("weekStart")Date weekStart,@Param("weekEnd") Date weekEnd,@Param("deptIds") List<Long> deptIds);

    // TCalendarInfoMapper.java
    List<Map<String, Object>> selectOperatingDeptsToday(@Param("date") String date, @Param("deptIds") List<Long> deptIds);

}
