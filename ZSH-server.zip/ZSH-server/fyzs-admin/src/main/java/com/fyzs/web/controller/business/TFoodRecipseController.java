package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.fyzs.common.exception.ServiceException;
import com.fyzs.web.entity.dto.TFoodRecipseDTO;
import com.fyzs.web.entity.query.TFoodRecipseQuery;
import com.fyzs.web.entity.vo.TFoodRecipseExportVO;
import com.fyzs.web.entity.vo.TFoodRecipseVO;
import com.fyzs.web.service.ITAlarmService;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TFoodRecipse;
import com.fyzs.web.service.ITFoodRecipseService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;
import springfox.documentation.annotations.ApiIgnore;

import java.util.stream.Collectors;

/**
 * 食堂菜谱、留样、试尝、陪餐信息Controller
 *
 * @author ysh
 * @date 2025-11-18
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/food/recipse")
public class TFoodRecipseController extends BaseController {

    private final ITFoodRecipseService tFoodRecipseService;

    private final ITAlarmService alarmService;


    /**
     * 查询食堂菜谱、留样、试尝、陪餐信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:list')")
    @GetMapping("/list")
    public TableDataInfo list(TFoodRecipseQuery query) {
        startPage();
        List<TFoodRecipseQuery> list = tFoodRecipseService.selectTFoodRecipseList(query);
        return getDataTable(list);
    }

    /**
     * 导出食堂菜谱、留样、试尝、陪餐信息列表
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:export')")
    @Log(title = "食堂菜谱、留样、试尝、陪餐信息", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TFoodRecipseQuery query) {
        List<TFoodRecipseQuery> list = tFoodRecipseService.selectTFoodRecipseExportList(query);
        List<TFoodRecipseExportVO> exportList = list.stream().map(item -> {
            TFoodRecipseExportVO exportVO = new TFoodRecipseExportVO();
            BeanUtils.copyProperties(item, exportVO);
            return exportVO;
        }).collect(Collectors.toList());
        ExcelUtil<TFoodRecipseExportVO> util = new ExcelUtil<TFoodRecipseExportVO>(TFoodRecipseExportVO.class);
        util.exportExcel(response, exportList, "食堂菜谱留样数据");
    }

    /**
     * 获取食堂菜谱、留样、试尝、陪餐信息详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(tFoodRecipseService.selectTFoodRecipseById(id));
    }

    /**
     * 批量试尝
     */
    @PostMapping("/batchTry")
    public AjaxResult batchTry(@RequestBody List<TFoodRecipse> tFoodRecipses) {
        return toAjax(tFoodRecipseService.batchTry(tFoodRecipses));
    }



    /**
     * 批量试尝(改版)
     */
    @PostMapping("/batchTryNew")
    public AjaxResult batchTryNew(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getTastingPerson())) {
            throw new ServiceException("请提交试尝人");
        }
        if (ObjectUtils.isEmpty(tFoodRecipse.getTastingTime())) {
            throw new ServiceException("请提交试尝时间");
        }

        return toAjax(tFoodRecipseService.batchTryNew(tFoodRecipse));
    }
    /**
     * 批量修改
     */
    @PostMapping("/batchUpdate")
    public AjaxResult batchUpdate(@RequestBody List<TFoodRecipse> tFoodRecipses) {

        return toAjax(tFoodRecipseService.batchUpdate(tFoodRecipses));
    }

    /**
     * 批量修改(改版)
     */
    @PostMapping("/batchUpdateNew")
    public AjaxResult batchUpdateNew(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getTastingPerson())) {
            throw new ServiceException("请提交试尝人");
        }
        if (ObjectUtils.isEmpty(tFoodRecipse.getTastingTime())) {
            throw new ServiceException("请提交试尝时间");
        }
        return toAjax(tFoodRecipseService.batchUpdateNew(tFoodRecipse));
    }

    /**
     * 批量陪餐
     */
    @PostMapping("/batchMeal")
    public AjaxResult batchMeal(@RequestBody List<TFoodRecipse> tFoodRecipses) {
        return toAjax(tFoodRecipseService.batchMeal(tFoodRecipses));
    }

    /**
     * 批量陪餐(改版)
     */
    @PostMapping("/batchMealNew")
    public AjaxResult batchMealNew(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getAccompanimentPerson())) {
            throw new ServiceException("请提交陪餐领导");
        }
        if (StringUtils.isBlank(tFoodRecipse.getAccompanimentTime())) {
            throw new ServiceException("请提交陪餐时间");
        }
        return toAjax(tFoodRecipseService.batchMealNew(tFoodRecipse));
    }


    /**
     * 批量修改陪餐
     */
    @PostMapping("/batchUpdateMeal")
    public AjaxResult batchUpdateMeal(@RequestBody List<TFoodRecipse> tFoodRecipses) {
        return toAjax(tFoodRecipseService.batchUpdateMeal(tFoodRecipses));
    }

    /**
     * 批量修改陪餐(改版)
     */
    @PostMapping("/batchUpdateMealNew")
    public AjaxResult batchUpdateMealNew(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getAccompanimentPerson())) {
            throw new ServiceException("请提交陪餐领导");
        }
        if (StringUtils.isBlank(tFoodRecipse.getAccompanimentTime())) {
            throw new ServiceException("请提交陪餐时间");
        }
        return toAjax(tFoodRecipseService.batchUpdateMealNew(tFoodRecipse));
    }

    /**
     * 新增食堂菜谱、留样、试尝、陪餐信息
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:add')")
    @Log(title = "食堂菜谱、留样、试尝、陪餐信息", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TFoodRecipse tFoodRecipse) {
        TFoodRecipse one = tFoodRecipseService.getOne(new LambdaQueryWrapper<>(TFoodRecipse.class)
                .eq(TFoodRecipse::getDeptId, tFoodRecipse.getDeptId())
                .eq(TFoodRecipse::getDate, tFoodRecipse.getDate())
                .eq(TFoodRecipse::getType, tFoodRecipse.getType())
                .eq(TFoodRecipse::getName, tFoodRecipse.getName())
        );
        if (ObjectUtils.isNotEmpty(one)) {
            if (one.getDelFlag().equals(0)) {
                return error("当前餐次已经存在该食谱");
            }
            if (one.getDelFlag().equals(1)) {
                return error("当前餐次已经存在该食谱,请通过启用按钮进行设置启用状态");
            }

        }

        return toAjax(tFoodRecipseService.insertTFoodRecipse(tFoodRecipse));
    }

    /**
     * 修改食堂菜谱、留样、试尝、陪餐信息
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:edit')")
    @Log(title = "食堂菜谱、留样、试尝、陪餐信息", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TFoodRecipse tFoodRecipse) {
        TFoodRecipse one = tFoodRecipseService.getOne(new LambdaQueryWrapper<>(TFoodRecipse.class)
                .eq(TFoodRecipse::getDeptId, tFoodRecipse.getDeptId())
                .eq(TFoodRecipse::getDate, tFoodRecipse.getDate())
                .eq(TFoodRecipse::getType, tFoodRecipse.getType())
                .eq(TFoodRecipse::getName, tFoodRecipse.getName())
                .ne(TFoodRecipse::getId, tFoodRecipse.getId())
        );
        if (ObjectUtils.isNotEmpty(one)) {

            if (one.getDelFlag().equals(1)) {
                return error("当前餐次已经存在该食谱,请通过启用按钮进行设置启用状态");
            }
                return error("当前餐次已经存在该食谱");
        }

        return toAjax(tFoodRecipseService.updateTFoodRecipse(tFoodRecipse));
    }

    /**
     * 批量启用禁用(只要id 和 状态)
     */
    @PostMapping("/batchUpdateDelFlag")
    public AjaxResult batchUpdateDelFlag(@RequestBody List<TFoodRecipse> tFoodRecipses) {
        return toAjax(tFoodRecipseService.batchUpdateDelFlag(tFoodRecipses));
    }

    /**
     * 快捷管理
     */
    @GetMapping("/batchManage")
    public AjaxResult batchManage(@ApiIgnore TFoodRecipseDTO dto) {
        if (ObjectUtils.isEmpty(dto.getDeptId())) {
            return AjaxResult.error("请提交主体id");
        }
        if (ObjectUtils.isEmpty(dto.getReleaseTime())) {
            return AjaxResult.error("请提交时间");
        }
        List<TFoodRecipseVO> vos = tFoodRecipseService.batchManage(dto);
        return AjaxResult.success(vos);
    }

    /**
     * 快捷管理 修改接口
     */
    @PostMapping("/manageUpdate")
    public AjaxResult manageUpdate(@RequestBody TFoodRecipseDTO tFoodRecipses) {
        return toAjax(tFoodRecipseService.manageUpdate(tFoodRecipses));
    }

    /**
     * 留样
     */
    @PostMapping("/sample")
    public AjaxResult sample(@RequestBody TFoodRecipse tFoodRecipses) {
        return toAjax(tFoodRecipseService.sample(tFoodRecipses));
    }

    /**
     * 修改留样
     */
    @PostMapping("/update/sample")
    public AjaxResult updateSample(@RequestBody TFoodRecipse tFoodRecipses) {
        return toAjax(tFoodRecipseService.updateSample(tFoodRecipses));
    }

    /**
     * 销样
     */
    @PostMapping("/cancel/sample")
    public AjaxResult cancelSample(@RequestBody TFoodRecipse tFoodRecipses) {
        return toAjax(tFoodRecipseService.cancelSample(tFoodRecipses));
    }

    /**
     * 修改销样
     */
    @PostMapping("/update/cancel/sample")
    public AjaxResult updateCancelSample(@RequestBody TFoodRecipse tFoodRecipses) {
        return toAjax(tFoodRecipseService.updateCancelSample(tFoodRecipses));
    }


    /**
     * 批量销样
     */
    @PostMapping("/batchSample")
    public AjaxResult batchSample(@RequestBody List<TFoodRecipse> tFoodRecipses) {
        return toAjax(tFoodRecipseService.batchSample(tFoodRecipses));
    }
    /**
     * 判断销样时间和留样时间之差
     */
    @PostMapping("/judgeSample")
    public AjaxResult judgeSample(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getCancleSamplePerson())) {
            throw new ServiceException("请提交销样人");
        }
        if (ObjectUtils.isEmpty(tFoodRecipse.getCancleSampleTime())) {
            throw new ServiceException("请提交销样时间");
        }
        return toAjax(tFoodRecipseService.judgeSample(tFoodRecipse));
    }

    /**
     * 批量销样(改版)
     */
    @PostMapping("/batchSampleNew")
    public AjaxResult batchSampleNew(@RequestBody TFoodRecipse tFoodRecipse) {
        // 参数校验
        if (ObjectUtils.isEmpty(tFoodRecipse.getDeptId())) {
            throw new ServiceException("请提交主体 ID");
        }
        if (StringUtils.isBlank(tFoodRecipse.getDate())) {
            throw new ServiceException("请提交菜谱日期");
        }
        if (StringUtils.isBlank(tFoodRecipse.getType())) {
            throw new ServiceException("请提交餐次");
        }
        if (StringUtils.isBlank(tFoodRecipse.getCancleSamplePerson())) {
            throw new ServiceException("请提交销样人");
        }
        if (ObjectUtils.isEmpty(tFoodRecipse.getCancleSampleTime())) {
            throw new ServiceException("请提交销样时间");
        }
        return toAjax(tFoodRecipseService.batchSampleNew(tFoodRecipse));
    }

    /**
     * 删除食堂菜谱、留样、试尝、陪餐信息
     */
    //@PreAuthorize("@ss.hasPermi('web:recipse:remove')")
    @Log(title = "食堂菜谱、留样、试尝、陪餐信息", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(tFoodRecipseService.deleteTFoodRecipseByIds(ids));
    }
}
