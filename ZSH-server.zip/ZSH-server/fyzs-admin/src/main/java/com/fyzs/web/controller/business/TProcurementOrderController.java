package com.fyzs.web.controller.business;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.fyzs.system.constants.TXConstants;
import com.fyzs.web.entity.dto.TProcurementOrderDTO;
import com.fyzs.web.entity.query.TProcurementOrderQuery;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fyzs.common.annotation.Log;
import com.fyzs.common.core.controller.BaseController;
import com.fyzs.common.core.domain.AjaxResult;
import com.fyzs.common.enums.BusinessType;
import lombok.AllArgsConstructor;
import com.fyzs.web.entity.TProcurementOrder;
import com.fyzs.web.service.ITProcurementOrderService;
import com.fyzs.common.utils.poi.ExcelUtil;
import com.fyzs.common.core.page.TableDataInfo;

/**
 * 商品采购单主Controller
 * 
 * @author ysh
 * @date 2025-10-29
 */
@RestController
@AllArgsConstructor
@RequestMapping("/tx/order")
public class TProcurementOrderController extends BaseController
{

    private final ITProcurementOrderService tProcurementOrderService;

    /**
     * 查询商品采购单主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:order:list')")
    @GetMapping("/list")
    public TableDataInfo list(TProcurementOrderQuery tProcurementOrder)
    {
        startPage();
        List<TProcurementOrderQuery> list = tProcurementOrderService.selectTProcurementOrderList(tProcurementOrder);
        return getDataTable(list);
    }

    /**
     * 导出商品采购单主列表
     */
    //@PreAuthorize("@ss.hasPermi('web:order:export')")
    @Log(title = "商品采购单主", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, TProcurementOrderQuery tProcurementOrder)
    {
        List<TProcurementOrderQuery> list = tProcurementOrderService.selectTProcurementOrderList(tProcurementOrder);
        ExcelUtil<TProcurementOrderQuery> util = new ExcelUtil<TProcurementOrderQuery>(TProcurementOrderQuery.class);
        util.exportExcel(response, list, "商品采购单主数据");
    }

    /**
     * 获取商品采购单主详细信息
     */
    //@PreAuthorize("@ss.hasPermi('web:order:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(tProcurementOrderService.selectTProcurementOrderById(id));
    }

    /**
     * 采购订单下单
     */
    @PostMapping("/order")
    public AjaxResult order(@RequestBody @Validated TProcurementOrderDTO dto){
        return AjaxResult.success(tProcurementOrderService.order(dto)) ;
    }

    /**
     * 修改采购下单
     */
    @PostMapping("/amend")
    public AjaxResult amend(@RequestBody TProcurementOrderDTO dto){
        return AjaxResult.success(tProcurementOrderService.amend(dto)) ;
    }


    /**
     * 确认按钮
     */
    @PostMapping("/confirm")
    public AjaxResult confirm(@RequestBody Long id){
        return AjaxResult.success(tProcurementOrderService.confirm(id)) ;
    }
    /**
     * 新增商品采购单主(单表)
     */
    //@PreAuthorize("@ss.hasPermi('web:order:add')")
    @Log(title = "商品采购单主", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    public AjaxResult add(@RequestBody TProcurementOrder tProcurementOrder)
    {
        return toAjax(tProcurementOrderService.save(tProcurementOrder));
    }

    /**
     * 修改商品采购单主(单表)
     */
    //@PreAuthorize("@ss.hasPermi('web:order:edit')")
    @Log(title = "商品采购单主", businessType = BusinessType.UPDATE)
    @PutMapping("/edit")
    public AjaxResult edit(@RequestBody TProcurementOrder tProcurementOrder)
    {
        return toAjax(tProcurementOrderService.updateById(tProcurementOrder));
    }

    /**
     * 删除商品采购单主
     */
    //@PreAuthorize("@ss.hasPermi('web:order:remove')")
    @Log(title = "商品采购单主", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(tProcurementOrderService.deleteTProcurementOrderByIds(ids));
    }
}
