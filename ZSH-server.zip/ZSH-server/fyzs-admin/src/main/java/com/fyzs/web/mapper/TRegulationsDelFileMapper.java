package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TRegulationsDelFile;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 违法违规处置证明文件存储信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TRegulationsDelFileMapper  extends BaseMapper<TRegulationsDelFile>
{
    /**
     * 查询违法违规处置证明文件存储信息
     * 
     * @param id 违法违规处置证明文件存储信息主键
     * @return 违法违规处置证明文件存储信息
     */
    public TRegulationsDelFile selectTRegulationsDelFileById(Long id);

    /**
     * 查询违法违规处置证明文件存储信息列表
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 违法违规处置证明文件存储信息集合
     */
    public List<TRegulationsDelFile> selectTRegulationsDelFileList(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 新增违法违规处置证明文件存储信息
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 结果
     */
    public int insertTRegulationsDelFile(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 修改违法违规处置证明文件存储信息
     * 
     * @param tRegulationsDelFile 违法违规处置证明文件存储信息
     * @return 结果
     */
    public int updateTRegulationsDelFile(TRegulationsDelFile tRegulationsDelFile);

    /**
     * 删除违法违规处置证明文件存储信息
     * 
     * @param id 违法违规处置证明文件存储信息主键
     * @return 结果
     */
    public int deleteTRegulationsDelFileById(Long id);

    /**
     * 批量删除违法违规处置证明文件存储信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTRegulationsDelFileByIds(Long[] ids);
}
