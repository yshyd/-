package com.fyzs.web.entity.vo;

import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
public class MapVO implements Serializable {

    private Long id;

    private String name;
    /**
     * 经度
     */
    private BigDecimal longitude;
    /**
     * 纬度
     */

    private BigDecimal latitude;

    private Integer deptType;

    private String deptLevel;

}
