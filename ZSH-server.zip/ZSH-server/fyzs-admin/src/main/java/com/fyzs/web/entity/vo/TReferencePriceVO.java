package com.fyzs.web.entity.vo;

import com.fyzs.web.entity.TReferencePrice;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TReferencePriceVO extends TReferencePrice {

    @Schema(description = "商品列表")
    private List<TReferencePriceItemVO> commodityList;
}
