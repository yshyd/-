package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TNewProcurement;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewProcurementQuery extends TNewProcurement {

    @Schema(description = "状态（可多选）")
    private Integer[] statuses;

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "供应商名称")
    private String supplerName;

    @Schema(description = "主体名称")
    private String deptName;

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    @Schema(description = "食材类型ID")
    private Long categoryId;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 商品类型(0预包装1非预包装) */
    @Schema(description = "商品类型(0预包装1非预包装)")
    @Excel(name = "商品类型(0预包装1非预包装)")
    private Integer type;

    /** 采购单位 */
    @Schema(description = "采购单位")
    private String purchaUnit;

    @Schema(description = "是否入库即出库 0 是 1否")
    @Excel(name = "是否入库即出库 0 是 1否")
    private Integer enterAndExit;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
