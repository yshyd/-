package com.fyzs.web.entity.dto;

import com.fyzs.web.entity.TNewAllocation;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class TNewAllocationDTO extends TNewAllocation {
}
