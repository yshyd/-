package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.web.entity.TCanteenInformation;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TCanteenInformationQuery extends TCanteenInformation {

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;

    @Schema(description = "组织ID列表")
    private List<Long> deptIds;
}
