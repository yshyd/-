package com.fyzs.web.entity.query;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TDevice;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class TDeviceQuery extends TDevice {

    @Schema(description = "区域id")
    private Long areaId;

    @Schema(description = "主体名称")
    private String deptName;

    @Schema(description = "在线状态 0在线 1离线")
    private Integer onlineStatus;

    private List<Long> deptIds;

    /** 设备温度 */
    @Schema(description = "设备温度")
    @Excel(name = "设备温度")
    private BigDecimal temperature;

    /** 实时浓度 */
    @Schema(description = "实时浓度")
    @Excel(name = "实时浓度")
    private String realTimeConcentration;

    /** 实时温度 */
    @Schema(description = "实时温度")
    @Excel(name = "实时温度")
    private String realTimeTemperature;

    /** 实时湿度 */
    @Schema(description = "实时湿度")
    @Excel(name = "实时湿度")
    private String realTimeHumidity;

    @Schema(description = "开始时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date startTime;

    @Schema(description = "结束时间")
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date endTime;
}
