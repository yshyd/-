package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TProcurementAcceptanceItm;

/**
 * 商品采购验收单副Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITProcurementAcceptanceItmService extends IService<TProcurementAcceptanceItm>
{
    /**
     * 查询商品采购验收单副
     * 
     * @param id 商品采购验收单副主键
     * @return 商品采购验收单副
     */
    public TProcurementAcceptanceItm selectTProcurementAcceptanceItmById(Long id);

    /**
     * 查询商品采购验收单副列表
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 商品采购验收单副集合
     */
    public List<TProcurementAcceptanceItm> selectTProcurementAcceptanceItmList(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 新增商品采购验收单副
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 结果
     */
    public int insertTProcurementAcceptanceItm(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 修改商品采购验收单副
     * 
     * @param tProcurementAcceptanceItm 商品采购验收单副
     * @return 结果
     */
    public int updateTProcurementAcceptanceItm(TProcurementAcceptanceItm tProcurementAcceptanceItm);

    /**
     * 批量删除商品采购验收单副
     * 
     * @param ids 需要删除的商品采购验收单副主键集合
     * @return 结果
     */
    public int deleteTProcurementAcceptanceItmByIds(Long[] ids);

    /**
     * 删除商品采购验收单副信息
     * 
     * @param id 商品采购验收单副主键
     * @return 结果
     */
    public int deleteTProcurementAcceptanceItmById(Long id);
}
