package com.fyzs.web.entity;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;
import com.fyzs.common.annotation.Excel;

import java.io.Serializable;

/**
 * 学校食堂日管控-日常巡检-食品加工制作过程巡检对象 t_day_production_process
 *
 * @author ysh
 * @date 2025-11-20
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName("t_day_production_process")
public class TDayProductionProcess implements Serializable {

    private static final long serialVersionUID = 1L;

        /** $cleanComment */
        @Schema(description = "$column.columnComment")
        private Long id;

        /** 主体id */
        @Schema(description = "主体id")
        @Excel(name = "主体id")
        private Long deptId;

        /** 蔬菜、肉类、水产品是否在不同的水池中清洗 0是1否 */
        @Schema(description = "蔬菜、肉类、水产品是否在不同的水池中清洗 0是1否")
        @Excel(name = "蔬菜、肉类、水产品是否在不同的水池中清洗 0是1否")
        private Integer isPool;

        /** 切配用的砧板、刀具是否按颜色或标识区分使用（如：红色-生肉，蓝色-水产品，绿色-蔬菜，白色-熟食），使用后是否及时清洗消毒 0是1否 */
        @Schema(description = "切配用的砧板、刀具是否按颜色或标识区分使用（如：红色-生肉，蓝色-水产品，绿色-蔬菜，白色-熟食），使用后是否及时清洗消毒 0是1否")
        @Excel(name = "切配用的砧板、刀具是否按颜色或标识区分使用", readConverterExp = "如=：红色-生肉，蓝色-水产品，绿色-蔬菜，白色-熟食")
        private Integer isChoppingBoard;

        /** 检查烹饪中心温度，特别是大块肉类、禽类，确保中心温度≥70℃。 0是1否 */
        @Schema(description = "检查烹饪中心温度，特别是大块肉类、禽类，确保中心温度≥70℃。 0是1否")
        @Excel(name = "检查烹饪中心温度，特别是大块肉类、禽类，确保中心温度≥70℃。 0是1否")
        private Integer isCookThoroughly;

        /** 食品加工后至食用前是否控制在安全时间内（通常建议不超过2小时） 0是1否 */
        @Schema(description = "食品加工后至食用前是否控制在安全时间内（通常建议不超过2小时） 0是1否")
        @Excel(name = "食品加工后至食用前是否控制在安全时间内", readConverterExp = "通=常建议不超过2小时")
        private Integer isTimeControl;

        /** 售餐窗口是否有效防护，防止飞沫等污染（如使用防护罩、玻璃隔断） 0是1否 */
        @Schema(description = "售餐窗口是否有效防护，防止飞沫等污染（如使用防护罩、玻璃隔断） 0是1否")
        @Excel(name = "售餐窗口是否有效防护，防止飞沫等污染", readConverterExp = "如=使用防护罩、玻璃隔断")
        private Integer isProtectiveMeasures;

        /** 巡检照片，最多5张 */
        @Schema(description = "巡检照片，最多5张")
        @Excel(name = "巡检照片，最多5张")
        private String img;

        /** 整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1 */
        @Schema(description = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        @Excel(name = "整体是否存在异常：0正常1异常 以上任何一项异常(也就是为1)，此项都为1")
        private Integer isAbnormal;

        /** 异常处置说明，限1000个字符 当整体出现异常时必填 */
        @Schema(description = "异常处置说明，限1000个字符 当整体出现异常时必填")
        @Excel(name = "异常处置说明，限1000个字符 当整体出现异常时必填")
        private String abnormalHandleRemarks;

        /** 巡检人 */
        @Schema(description = "巡检人")
        @Excel(name = "巡检人")
        private String inspectionUser;

        /** 巡检时间，年月日时分(格式：2025-05-05 08:40) */
        @Schema(description = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        @Excel(name = "巡检时间，年月日时分(格式：2025-05-05 08:40)")
        private String inspectionDate;

        /** 0有效1无效 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "0有效1无效")
        private Integer delFlag;

        /** 巡检人ID(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "巡检人ID(对应sys_user)")
        @Excel(name = "巡检人ID(对应sys_user)")
        private Long createUser;

        /** 创建人姓名(对应sys_user) */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建人姓名(对应sys_user)")
        @Excel(name = "创建人姓名(对应sys_user)")
        private String createName;

        /** 修改人id(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人id(对应sys_user)")
        @Excel(name = "修改人id(对应sys_user)")
        private Long updateUser;

        /** 修改人名称(对应sys_user) */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改人名称(对应sys_user)")
        @Excel(name = "修改人名称(对应sys_user)")
        private String updateName;

        /** 创建时间 */
        @TableField(fill = FieldFill.INSERT)
        @Schema(description = "创建时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date createDate;

        /** 修改时间 */
        @TableField(fill = FieldFill.INSERT_UPDATE)
        @Schema(description = "修改时间")
        @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
        @Excel(name = "修改时间", width = 30, dateFormat = "yyyy-MM-dd HH:mm:ss")
        private Date updateDate;

}
