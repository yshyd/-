package com.fyzs.web.service;

import java.util.List;
import com.baomidou.mybatisplus.extension.service.IService;
import com.fyzs.web.entity.TNewProcurement;
import com.fyzs.web.entity.query.TNewProcurementQuery;
import com.fyzs.web.entity.vo.TNewProcurementVO;

/**
 * 商品采购Service接口
 * 
 * @author ysh
 * @date 2025-10-29
 */
public interface ITNewProcurementService extends IService<TNewProcurement>
{
    /**
     * 查询商品采购
     * 
     * @param id 商品采购主键
     * @return 商品采购
     */
    public TNewProcurementQuery selectTNewProcurementById(Long id);

    /**
     * 查询商品采购列表
     * 
     * @param tNewProcurement 商品采购
     * @return 商品采购集合
     */
    public List<TNewProcurementQuery> selectTNewProcurementList(TNewProcurementQuery tNewProcurement);

    /**
     * 新增商品采购
     * 
     * @param tNewProcurement 商品采购
     * @return 结果
     */
    public int insertTNewProcurement(TNewProcurement tNewProcurement);

    /**
     * 修改商品采购
     * 
     * @param tNewProcurement 商品采购
     * @return 结果
     */
    public int updateTNewProcurement(TNewProcurement tNewProcurement);

    /**
     * 批量删除商品采购
     * 
     * @param ids 需要删除的商品采购主键集合
     * @return 结果
     */
    public int deleteTNewProcurementByIds(Long[] ids);

    /**
     * 删除商品采购信息
     * 
     * @param id 商品采购主键
     * @return 结果
     */
    public int deleteTNewProcurementById(Long id);

    int place(TNewProcurement tNewProcurement);

    List<TNewProcurementVO> selectExportList(TNewProcurementQuery tNewProcurement);
}
