package com.fyzs.web.mapper;

import java.util.List;
import com.fyzs.web.entity.TCameraRegulationsImg;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * 违法违规识别图片固证文件存储信息Mapper接口
 * 
 * @author ysh
 * @date 2025-10-21
 */
@Mapper
public interface TCameraRegulationsImgMapper  extends BaseMapper<TCameraRegulationsImg>
{
    /**
     * 查询违法违规识别图片固证文件存储信息
     * 
     * @param id 违法违规识别图片固证文件存储信息主键
     * @return 违法违规识别图片固证文件存储信息
     */
    public TCameraRegulationsImg selectTCameraRegulationsImgById(Long id);

    /**
     * 查询违法违规识别图片固证文件存储信息列表
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 违法违规识别图片固证文件存储信息集合
     */
    public List<TCameraRegulationsImg> selectTCameraRegulationsImgList(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 新增违法违规识别图片固证文件存储信息
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 结果
     */
    public int insertTCameraRegulationsImg(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 修改违法违规识别图片固证文件存储信息
     * 
     * @param tCameraRegulationsImg 违法违规识别图片固证文件存储信息
     * @return 结果
     */
    public int updateTCameraRegulationsImg(TCameraRegulationsImg tCameraRegulationsImg);

    /**
     * 删除违法违规识别图片固证文件存储信息
     * 
     * @param id 违法违规识别图片固证文件存储信息主键
     * @return 结果
     */
    public int deleteTCameraRegulationsImgById(Long id);

    /**
     * 批量删除违法违规识别图片固证文件存储信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTCameraRegulationsImgByIds(Long[] ids);
}
