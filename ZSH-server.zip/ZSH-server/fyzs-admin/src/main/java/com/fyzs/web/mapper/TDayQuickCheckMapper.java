package com.fyzs.web.mapper;

import java.util.Date;
import java.util.List;
import com.fyzs.web.entity.TDayQuickCheck;
import com.fyzs.web.entity.query.TDayQuickCheckQuery;
import org.apache.ibatis.annotations.Mapper;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Param;

/**
 * 学校食堂日管控-日常检查-日常快检Mapper接口
 * 
 * @author ysh
 * @date 2025-11-18
 */
@Mapper
public interface TDayQuickCheckMapper  extends BaseMapper<TDayQuickCheck>
{
    /**
     * 查询学校食堂日管控-日常检查-日常快检
     * 
     * @param id 学校食堂日管控-日常检查-日常快检主键
     * @return 学校食堂日管控-日常检查-日常快检
     */
    public TDayQuickCheckQuery selectTDayQuickCheckById(Long id);

    /**
     * 查询学校食堂日管控-日常检查-日常快检列表
     * 
     * @param tDayQuickCheck 学校食堂日管控-日常检查-日常快检
     * @return 学校食堂日管控-日常检查-日常快检集合
     */
    public List<TDayQuickCheckQuery> selectTDayQuickCheckList(TDayQuickCheck tDayQuickCheck);

    /**
     * 新增学校食堂日管控-日常检查-日常快检
     * 
     * @param tDayQuickCheck 学校食堂日管控-日常检查-日常快检
     * @return 结果
     */
    public int insertTDayQuickCheck(TDayQuickCheck tDayQuickCheck);

    /**
     * 修改学校食堂日管控-日常检查-日常快检
     * 
     * @param tDayQuickCheck 学校食堂日管控-日常检查-日常快检
     * @return 结果
     */
    public int updateTDayQuickCheck(TDayQuickCheck tDayQuickCheck);

    /**
     * 删除学校食堂日管控-日常检查-日常快检
     * 
     * @param id 学校食堂日管控-日常检查-日常快检主键
     * @return 结果
     */
    public int deleteTDayQuickCheckById(Long id);

    /**
     * 批量删除学校食堂日管控-日常检查-日常快检
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteTDayQuickCheckByIds(Long[] ids);

    int countValidQuickChecks(@Param("startDate") Date startDate,
                              @Param("endDate") Date endDate,
                              @Param("deptIds") List<Long> deptIds);

    int countNormalQuickChecks(@Param("startDate") Date startDate,
                               @Param("endDate") Date endDate,
                               @Param("deptIds") List<Long> deptIds);

    int countAbnormalQuickChecks(@Param("startDate") Date startDate,
                                 @Param("endDate") Date endDate,
                                 @Param("deptIds") List<Long> deptIds);
}
