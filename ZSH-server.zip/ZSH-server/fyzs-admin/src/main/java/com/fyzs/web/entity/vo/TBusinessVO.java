package com.fyzs.web.entity.vo;

import com.fyzs.common.annotation.Excel;
import com.fyzs.web.entity.TBusiness;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
public class TBusinessVO extends TBusiness {

    /** 商品编码(添加时自动生成：SP+0000001的递增，开始) */
    @Schema(description = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    @Excel(name = "商品编码(添加时自动生成：SP+0000001的递增，开始)")
    private String commodityCode;

    /** 商品名称 */
    @Schema(description = "商品名称")
    @Excel(name = "商品名称")
    private String commodityName;

    /**
     * 类别名称
     */
    @Schema(description = "类别名称")
    @Excel(name = "类别名称")
    private String categoryName;

    /** 品牌 */
    @Schema(description = "品牌")
    @Excel(name = "品牌")
    private String brand;

    /** 型号 */
    @Schema(description = "型号")
    @Excel(name = "型号")
    private String model;

    /** 规格 */
    @Schema(description = "规格")
    @Excel(name = "规格")
    private String specification;

    /** 单位   */
    @Schema(description = "单位   ")
    @Excel(name = "单位   ")
    private String purchaUnit;

    @Schema(description = "数量")
    private BigDecimal number;

    @Schema(description = "单价")
    private BigDecimal price;

    @Schema(description = "合计")
    private BigDecimal total;

    @Schema(description = "结算类型 0采购结算 1退货结算")
    private Integer settlementType;

}
